## What I'll change

### 1. Separate tenures for MSER and RMSE
The data model already has `mser.tenureMonths` and `rmse.tenureMonths` as independent fields — the UI card exposes both, and the calc engine already blends by amount × tenure. I'll verify the labelling reads clearly ("MSER Tenure", "RMSE Tenure") and expose them as prominent inputs so it's obvious they're independent (matches the Excel behaviour).

### 2. Strip all dummy data (except past deals)
Remove hardcoded numbers from `pricing-data.ts`:
- Market snapshot (Repo, G-Sec, CD, CP, T-Bill, Call Money) → `null` until fetched
- 12-month trend sparklines → removed (no official free time series available from a Worker)
- Treasury COF options (T-Bill 3M, Repo 1Y/3Y, Fixed 1Y/3Y/5Y) → labels kept, **rates set to user-editable** with an empty starting state (this is SIDBI internal Treasury data — no public source exists)
- Benchmark options → rates pulled live from the RBI feed where available; the rest editable
- Bank deposit ladders (callable / non-callable) → emptied per bank; UI shows "Rate card not connected"
- **Past deals: kept** (per your instruction — these are historical negotiation records, not market data)

### 3. Live data via server-side scraping — realistic scope

I tested each official source from the Cloudflare Worker environment we deploy on:

| Source | Status | What I can pull |
|---|---|---|
| **RBI** (rbi.org.in) | Works | Policy Repo, Reverse Repo, SDF, MSF, Bank Rate — parsed from homepage HTML |
| **FBIL** (fbil.org.in) | JS-only SPA | Cannot scrape from a Worker (no headless browser) |
| **CCIL** (ccilindia.com) | JS-only | 10Y G-Sec, T-Bill yields are loaded via client JS — cannot scrape |
| **Bank bulk deposit pages** (HDFC/ICICI/Axis/SBI/etc.) | Mixed | Most publish PDFs or JS-rendered tables — per-bank scrapers would be fragile and need individual work |

**What I'll implement now:** a server route `/api/public/market` that scrapes RBI's homepage on request (cached ~30 min), returns the policy rates it can parse, and returns `null` for everything else. The UI displays live values where available and a plain "Not available — official source pending" placeholder everywhere else. No fake numbers anywhere.

**What's out of scope until you decide:** headless-browser scraping for FBIL/CCIL (needs a separate service — not a Worker), and per-bank deposit-rate scrapers (each bank needs its own parser, plus the pages change without notice). I'll flag both in the UI with a "connect data source" hint so it's clear these are pending, not missing.

### 4. Editable Treasury COF panel
Since Treasury rates come from SIDBI's internal desk (no public feed), I'll turn the CoF dropdown into an inline-editable list — you type each option's current rate once at the start of the session, and the negotiation math flows from there.

## Files touched
- `src/lib/pricing-data.ts` — strip mock values, keep bank names/categories/past deals
- `src/routes/api/public/market.ts` — new server route, scrapes RBI, caches per instance
- `src/lib/market-client.ts` — client hook to fetch and hold market state
- `src/routes/index.tsx` — wire fetched values, add "—" placeholders, add editable CoF/Benchmark rows, tighten MSER/RMSE tenure labelling
- `src/lib/pricing-export.ts` — pass through nulls in export

## Confirm before I build
- **Editable Treasury COF** (user types the rates once per session) — OK, or do you have an internal SIDBI Treasury API/URL I should call instead?
- **Bank deposit rates**: leave empty with "pending" chips for now, and I set up per-bank scrapers in a follow-up? Or do you want me to attempt HDFC + SBI now as a first pass, knowing they'll need maintenance?
