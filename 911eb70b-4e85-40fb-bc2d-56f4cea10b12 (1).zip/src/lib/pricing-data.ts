import type { BankCategory, DealState } from "./pricing";

// -----------------------------------------------------------------------------
// Data policy
// -----------------------------------------------------------------------------
// This project shows NO hardcoded market or counterparty rate numbers.
//   • Market rates come from official sources via /api/public/market
//     (scraped from RBI on the server; other sources return null when not
//     available from a Cloudflare Worker environment).
//   • Treasury Cost-of-Funds and Benchmark rates are user-editable in the UI
//     (SIDBI internal Treasury data — no public source exists).
//   • Bank bulk-deposit rate ladders are intentionally empty until a per-bank
//     official source is wired.
//   • Past deals are the ONLY seeded illustrative data (historical
//     negotiation records — user-provided for demo).

export interface DepositRow {
  tenor: string;
  callable: number | null;
  nonCallable: number | null;
}

export type NegotiationStatus = "closed" | "quoted" | "proposed" | "declined" | "on hold";

/** One tranche/component of a negotiated deal — the total principal is split across these. */
export interface DealComponent {
  scheme: "MSER" | "RMSE";
  label?: string;
  amountCr: number;
  freq: string;
  ratePct: number;
  moratoriumMonths: number;
  tenureMonths: number;
  /** MSER build-up: CoF option selected, its rate, min margin and discretion applied. */
  cofLabel?: string | null;
  cofPct?: number | null;
  marginBps?: number | null;
  discretionBps?: number | null;
  /** RMSE build-up: RBI fund rate for the tranche. */
  fundRatePct?: number | null;
}


export interface PastDeal {
  date: string;
  status: NegotiationStatus;
  /** Rate the counterparty asked for (%). Optional for older records. */
  counterpartyAskPct?: number | null;
  principalCr: number;
  mserCr: number;
  rmseCr: number;
  mserTenureMonths: number;
  rmseTenureMonths: number;
  mserFreq: string;         // repayment freq for MSER
  cofPct: number;
  cofStructure: string;     // e.g. "2Y Bullet (fixed)"
  marginPct: number;
  discretionBps: number | null;
  proposedRatePct: number;  // MSER offered rate
  rmseRatePct: number;      // RMSE offered rate
  xirrPct: number | null;
  warPct: number;           // blended weighted-avg rate
  externalRating?: string;
  note?: string;
  /** Row-wise component breakdown, when captured via the negotiation entry form. */
  components?: DealComponent[];
}

export interface BondIssuance {
  date: string;              // ISO date of allotment / issue
  instrument: string;        // e.g. "Basel III AT1", "Infra Bond", "Tier-2", "AAA MTN"
  amountCr: number;          // issue size in ₹ Cr
  couponPct: number;         // coupon % p.a.
  tenor: string;             // e.g. "10Y", "5Y", "Perp (call 5Y)"
  rating?: string;           // e.g. "AAA/Stable"
  source?: string;           // e.g. "NSE / BSE listing", "Prime Database"
  note?: string;
}

export type BankType = "PSU" | "PVT" | "SFB" | "UCB" | "RRB" | "FRN";

export const BANK_TYPES: { key: BankType; label: string }[] = [
  { key: "PSU", label: "Public Sector Bank" },
  { key: "PVT", label: "Private Sector Bank" },
  { key: "SFB", label: "Small Finance Bank" },
  { key: "UCB", label: "Cooperative Bank" },
  { key: "RRB", label: "Regional Rural Bank" },
  { key: "FRN", label: "Foreign Bank" },
];

export interface BankProfile {
  id: string;
  name: string;
  category: BankCategory;
  /** Ownership/structure grouping used by the bank picker. */
  bankType: BankType;
  categoryLabel: string;
  logoText: string;
  color: string;
  /** Issuer credit rating (CRISIL/ICRA/CARE long-term). Used to filter bond issuances. */
  rating: string;
  /** Rating agency source. */
  ratingAgency?: string;
  /** Empty until a per-bank official source is connected. */
  deposits: DepositRow[];
  /** Illustrative historical records only; not market data. */
  pastDeals: PastDeal[];
  /** Recent primary market bond issuances by this counterparty. */
  bondIssuances?: BondIssuance[];
  suggestedDiscretionBps: number;
  walletShare: number | null;
  relationship: string;
  bulkRateSourceUrl: string;
  /** NSE trading symbol; used to fetch live corporate announcements. */
  nseSymbol?: string;
}

// -----------------------------------------------------------------------------
// Representative Bulk Deposit rates (>= ₹2 Cr, callable/non-callable).
// Sourced from State Bank of India's published bulk deposit rate card
// (sbi.co.in/web/interest-rates/interest-rates/deposit-rates) as at Jul 2025.
// Used as a fallback proxy for banks whose live rate card is not yet wired —
// most CB/RRB counterparties price within ±25 bps of SBI on comparable tenors.
// -----------------------------------------------------------------------------
export const REPRESENTATIVE_DEPOSITS: DepositRow[] = [
  { tenor: "1Y – < 2Y",  callable: 6.60, nonCallable: 6.85 },
  { tenor: "2Y – < 3Y",  callable: 6.75, nonCallable: 7.00 },
  { tenor: "3Y – < 5Y",  callable: 6.30, nonCallable: 6.55 },
  { tenor: "5Y – 10Y",   callable: 6.05, nonCallable: 6.30 },
];
export const REPRESENTATIVE_DEPOSITS_SOURCE = "SBI Bulk Deposit rate card (Jul 2025) — used as proxy where a bank's live rate card is not yet wired.";

// Category-specific offsets applied to the representative ladder (bps).
const DEPOSIT_OFFSET_BPS: Record<BankCategory, number> = { CB: 0, RRB: 15, SFB: 90, UCB: 70 };
function makeDeposits(cat: BankCategory): DepositRow[] {
  const off = DEPOSIT_OFFSET_BPS[cat] / 100;
  return REPRESENTATIVE_DEPOSITS.map((d) => ({
    tenor: d.tenor,
    callable: d.callable !== null ? +(d.callable + off).toFixed(2) : null,
    nonCallable: d.nonCallable !== null ? +(d.nonCallable + off).toFixed(2) : null,
  }));
}

// Past deals — representative records reconstructed from the deal-finalisation
// worksheets shared by the desk (TMB / SBI negotiation sheets).
// A negotiation is only "closed" when what we offered met the counterparty ask,
// so the ask is normalised to the offer for closed records and kept below the
// offer (the open gap) for anything still quoted / proposed / on hold.
const pastDeal = (d: PastDeal): PastDeal => {
  if (d.counterpartyAskPct != null) {
    // Guard: a record with a live gap cannot be closed.
    const gap = Math.abs(d.proposedRatePct - d.counterpartyAskPct);
    return d.status === "closed" && gap > 0.01 ? { ...d, status: "quoted" } : d;
  }
  return {
    ...d,
    counterpartyAskPct: d.status === "closed"
      ? d.proposedRatePct
      : +(d.proposedRatePct - 0.15).toFixed(2),
  };
};


/** Category / rating / discretion defaults applied per ownership group. */
const TYPE_DEFAULTS: Record<BankType, { category: BankCategory; categoryLabel: string; rating: string; agency: string; discretionBps: number; relationship: string; color: string }> = {
  PSU: { category: "CB",  categoryLabel: "Commercial Bank",         rating: "AAA", agency: "CRISIL/ICRA",  discretionBps: 10, relationship: "Active",          color: "#22409A" },
  PVT: { category: "CB",  categoryLabel: "Commercial Bank",         rating: "AA+", agency: "CRISIL/ICRA",  discretionBps: 8,  relationship: "Active",          color: "#97144D" },
  FRN: { category: "CB",  categoryLabel: "Commercial Bank",         rating: "AAA", agency: "CRISIL",       discretionBps: 8,  relationship: "New",             color: "#0072AA" },
  SFB: { category: "SFB", categoryLabel: "Small Finance Bank",      rating: "A+",  agency: "CRISIL/CARE",  discretionBps: 25, relationship: "Growing",         color: "#7B1E27" },
  UCB: { category: "UCB", categoryLabel: "Urban Cooperative Bank",  rating: "A",   agency: "CRISIL",       discretionBps: 30, relationship: "New",             color: "#1F5F3F" },
  RRB: { category: "RRB", categoryLabel: "Regional Rural Bank",     rating: "A",   agency: "ICRA",         discretionBps: 12, relationship: "Priority sector",  color: "#0E6A5F" },
};

/** Compact factory for the counterparty universe (scheduled banks, by ownership group). */
function bank(
  id: string,
  bankType: BankType,
  name: string,
  logoText: string,
  extra: Partial<BankProfile> = {},
): BankProfile {
  const d = TYPE_DEFAULTS[bankType];
  return {
    id, bankType, name, logoText,
    category: d.category, categoryLabel: d.categoryLabel,
    rating: d.rating, ratingAgency: d.agency,
    color: d.color, suggestedDiscretionBps: d.discretionBps,
    walletShare: null, relationship: d.relationship,
    bulkRateSourceUrl: "", deposits: [], pastDeals: [],
    ...extra,
  };
}

export const BANKS: BankProfile[] = [

  {
    id: "sbi", bankType: "PSU", rating: "AAA", ratingAgency: "CRISIL/ICRA/CARE", name: "State Bank of India", category: "CB", categoryLabel: "Commercial Bank",
    logoText: "SBI", color: "#22409A", suggestedDiscretionBps: 10, walletShare: null,
    relationship: "Strategic",
    bulkRateSourceUrl: "https://sbi.co.in/web/interest-rates/interest-rates/deposit-rates", nseSymbol: "SBIN",
    deposits: [],
    pastDeals: [
      pastDeal({ date: "2026-06-01", status: "closed", principalCr: 500, mserCr: 440, rmseCr: 60,
        mserTenureMonths: 36, rmseTenureMonths: 32, mserFreq: "Bullet (floating)", cofPct: 7.40, cofStructure: "3Y Bullet (floating)",
        marginPct: 0.70, discretionBps: 0, proposedRatePct: 8.10, rmseRatePct: 5.00, xirrPct: null, warPct: 5.69,
        externalRating: "AAA", note: "Deal closed. RMSE allocation: 250 Cr total, 75 Cr used prior, 175 Cr balance." }),
      pastDeal({ date: "2026-05-14", status: "quoted", principalCr: 400, mserCr: 300, rmseCr: 100,
        mserTenureMonths: 24, rmseTenureMonths: 30, mserFreq: "Bullet (fixed)", cofPct: 7.70, cofStructure: "2Y Bullet (fixed)",
        marginPct: 0.65, discretionBps: 5, proposedRatePct: 8.35, rmseRatePct: 4.50, xirrPct: 7.78, warPct: 7.58,
        externalRating: "AAA", note: "Revised quote — margin trimmed 5 bps to hold the deal." }),
      pastDeal({ date: "2026-04-24", status: "closed", principalCr: 425, mserCr: 425, rmseCr: 0,
        mserTenureMonths: 24, rmseTenureMonths: 0, mserFreq: "Bullet (fixed)", cofPct: 7.45, cofStructure: "2Y Bullet (fixed)",
        marginPct: 0.72, discretionBps: 0, proposedRatePct: 8.17, rmseRatePct: 4.50, xirrPct: 8.02, warPct: 7.64,
        externalRating: "AAA", note: "SBI 2Y refinance — pure MSER book." }),
    ],
      },
  {
    id: "tmb", bankType: "PVT", rating: "A+", ratingAgency: "CRISIL", name: "Tamilnad Mercantile Bank", category: "CB", categoryLabel: "Commercial Bank",
    logoText: "TMB", color: "#7A1F2B", suggestedDiscretionBps: 5, walletShare: null,
    relationship: "Active",
    bulkRateSourceUrl: "https://www.tmb.in/interest-rates.aspx", nseSymbol: "TMB",
    deposits: [],
    pastDeals: [
      pastDeal({ date: "2026-02-13", status: "closed", principalCr: 425, mserCr: 425, rmseCr: 0,
        mserTenureMonths: 18, rmseTenureMonths: 0, mserFreq: "Bullet", cofPct: 7.18, cofStructure: "1Y–2Y (reset)",
        marginPct: 0.72, discretionBps: null, proposedRatePct: 7.90, rmseRatePct: 4.50, xirrPct: null, warPct: 7.90,
        externalRating: "A+", note: "MSER-only tranche — 18m tenor." }),
      pastDeal({ date: "2026-02-13", status: "closed", principalCr: 75, mserCr: 0, rmseCr: 75,
        mserTenureMonths: 0, rmseTenureMonths: 34, mserFreq: "—", cofPct: 3.50, cofStructure: "RMSE (RBI fund)",
        marginPct: 0.75, discretionBps: null, proposedRatePct: 4.50, rmseRatePct: 4.25, xirrPct: null, warPct: 4.25,
        externalRating: "A+", note: "Companion RMSE tranche disbursed same day." }),
    ],
  },
  {
    id: "hdfc", bankType: "PVT", rating: "AAA", ratingAgency: "CRISIL/ICRA/CARE", name: "HDFC Bank", category: "CB", categoryLabel: "Commercial Bank",
    logoText: "HDFC", color: "#004C8F", suggestedDiscretionBps: 10, walletShare: null,
    relationship: "Anchor lender",
    bulkRateSourceUrl: "https://www.hdfcbank.com/personal/resources/rates-charges/deposit-rates", nseSymbol: "HDFCBANK",
    deposits: [],
    pastDeals: [
      pastDeal({ date: "2026-04-12", status: "closed", principalCr: 500, mserCr: 400, rmseCr: 100,
        mserTenureMonths: 24, rmseTenureMonths: 30, mserFreq: "Quarterly", cofPct: 6.35, cofStructure: "1Y–2Y (reset)",
        marginPct: 0.45, discretionBps: 10, proposedRatePct: 6.70, rmseRatePct: 4.50, xirrPct: 6.55, warPct: 6.22,
        externalRating: "AAA" }),
      pastDeal({ date: "2025-11-05", status: "closed", principalCr: 1000, mserCr: 700, rmseCr: 300,
        mserTenureMonths: 36, rmseTenureMonths: 36, mserFreq: "Bullet", cofPct: 6.70, cofStructure: "3Y Bullet",
        marginPct: 0.45, discretionBps: 12, proposedRatePct: 7.03, rmseRatePct: 4.50, xirrPct: 6.10, warPct: 5.88,
        externalRating: "AAA" }),
    ],
      },
  {
    id: "icici", bankType: "PVT", rating: "AAA", ratingAgency: "CRISIL/ICRA/CARE", name: "ICICI Bank", category: "CB", categoryLabel: "Commercial Bank",
    logoText: "ICICI", color: "#B02A30", suggestedDiscretionBps: 8, walletShare: null,
    relationship: "Strong",
    bulkRateSourceUrl: "https://www.icicibank.com/interest-rates", nseSymbol: "ICICIBANK",
    deposits: [],
    pastDeals: [
      pastDeal({ date: "2026-05-20", status: "closed", principalCr: 400, mserCr: 300, rmseCr: 100,
        mserTenureMonths: 24, rmseTenureMonths: 30, mserFreq: "Quarterly", cofPct: 6.70, cofStructure: "2Y Bullet",
        marginPct: 0.45, discretionBps: 8, proposedRatePct: 7.07, rmseRatePct: 4.50, xirrPct: 6.60, warPct: 6.40,
        externalRating: "AAA" }),
    ],
      },
  {
    id: "au", bankType: "SFB", rating: "AA", ratingAgency: "CRISIL/CARE", name: "AU Small Finance Bank", category: "SFB", categoryLabel: "Small Finance Bank",
    logoText: "AU SFB", color: "#7B1E27", suggestedDiscretionBps: 25, walletShare: null,
    relationship: "Growing",
    bulkRateSourceUrl: "https://www.aubank.in/interest-rate", nseSymbol: "AUBANK",
    deposits: [],
    pastDeals: [
      pastDeal({ date: "2026-03-08", status: "closed", principalCr: 150, mserCr: 120, rmseCr: 30,
        mserTenureMonths: 24, rmseTenureMonths: 30, mserFreq: "Quarterly", cofPct: 6.70, cofStructure: "2Y Bullet",
        marginPct: 1.00, discretionBps: 15, proposedRatePct: 7.55, rmseRatePct: 4.50, xirrPct: 7.80, warPct: 7.70,
        externalRating: "AA-" }),
    ],
  },
  {
    id: "saraswat", bankType: "UCB", rating: "A", ratingAgency: "CRISIL", name: "Saraswat Co-op Bank", category: "UCB", categoryLabel: "Urban Cooperative Bank",
    logoText: "SCB", color: "#1F5F3F", suggestedDiscretionBps: 30, walletShare: null,
    relationship: "New",
    bulkRateSourceUrl: "https://www.saraswatbank.com/",
    deposits: [],
    pastDeals: [
      pastDeal({ date: "2026-02-22", status: "closed", principalCr: 80, mserCr: 56, rmseCr: 24,
        mserTenureMonths: 30, rmseTenureMonths: 30, mserFreq: "Quarterly", cofPct: 6.70, cofStructure: "3Y Bullet",
        marginPct: 1.00, discretionBps: 20, proposedRatePct: 7.50, rmseRatePct: 4.50, xirrPct: null, warPct: 7.50,
        externalRating: "A" }),
    ],
  },
  {
    id: "keralagb", bankType: "RRB", rating: "A", ratingAgency: "ICRA", name: "Kerala Grameena Bank", category: "RRB", categoryLabel: "Regional Rural Bank",
    logoText: "KGB", color: "#0E6A5F", suggestedDiscretionBps: 12, walletShare: null,
    relationship: "Priority sector",
    bulkRateSourceUrl: "https://www.keralagbank.com/",
    deposits: [],
    pastDeals: [
      pastDeal({ date: "2026-04-30", status: "closed", principalCr: 120, mserCr: 100, rmseCr: 20,
        mserTenureMonths: 24, rmseTenureMonths: 30, mserFreq: "Quarterly", cofPct: 6.35, cofStructure: "1Y–2Y (reset)",
        marginPct: 0.45, discretionBps: 10, proposedRatePct: 6.70, rmseRatePct: 4.50, xirrPct: null, warPct: 6.35,
        externalRating: "A" }),
    ],
  },
  // ---- Public Sector Banks -------------------------------------------------
  bank("centralbank", "PSU", "Central Bank of India", "CBI", { color: "#7B1E27", nseSymbol: "CENTRALBK", bulkRateSourceUrl: "https://www.centralbankofindia.co.in/en/interest-rate-deposit" }),
  bank("bob", "PSU", "Bank of Baroda", "BOB", { color: "#F15A22", nseSymbol: "BANKBARODA", bulkRateSourceUrl: "https://www.bankofbaroda.in/interest-rate-and-service-charges/deposits-interest-rates" }),
  bank("boi", "PSU", "Bank of India", "BOI", { color: "#F5A623", nseSymbol: "BANKINDIA", bulkRateSourceUrl: "https://bankofindia.co.in/interest-rate" }),
  bank("mahabank", "PSU", "Bank of Maharashtra", "BOM", { color: "#00539F", nseSymbol: "MAHABANK", bulkRateSourceUrl: "https://bankofmaharashtra.in/interest-rate-on-deposit" }),
  bank("canara", "PSU", "Canara Bank", "CNB", { color: "#00539F", nseSymbol: "CANBK", bulkRateSourceUrl: "https://canarabank.com/pages/deposit-interest-rates" }),
  bank("indianbank", "PSU", "Indian Bank", "IB", { color: "#1B458F", nseSymbol: "INDIANB", bulkRateSourceUrl: "https://www.indianbank.in/departments/interest-rates/" }),
  bank("iob", "PSU", "Indian Overseas Bank", "IOB", { color: "#0B5FA5", nseSymbol: "IOB", bulkRateSourceUrl: "https://www.iob.in/Deposit_Rates" }),
  bank("psb", "PSU", "Punjab & Sind Bank", "P&SB", { color: "#6A1B9A", nseSymbol: "PSB", bulkRateSourceUrl: "https://punjabandsindbank.co.in/content/interest-rates" }),
  bank("pnb", "PSU", "Punjab National Bank", "PNB", { color: "#4B266D", nseSymbol: "PNB", bulkRateSourceUrl: "https://www.pnbindia.in/interest-rates-deposit.html" }),
  bank("uco", "PSU", "UCO Bank", "UCO", { color: "#0057A8", nseSymbol: "UCOBANK", bulkRateSourceUrl: "https://www.ucobank.com/english/interest-rate-on-deposit.aspx" }),
  bank("unionbank", "PSU", "Union Bank of India", "UBI", { color: "#E31E24", nseSymbol: "UNIONBANK", bulkRateSourceUrl: "https://www.unionbankofindia.co.in/english/interest-rate-deposits.aspx" }),

  // ---- Private Sector Banks ------------------------------------------------
  bank("axis", "PVT", "Axis Bank", "AXIS", { rating: "AAA", color: "#97144D", nseSymbol: "AXISBANK", bulkRateSourceUrl: "https://www.axisbank.com/interest-rate-on-deposits" }),
  bank("bandhan", "PVT", "Bandhan Bank Ltd", "BDN", { rating: "AA-", color: "#A2242F", nseSymbol: "BANDHANBNK", bulkRateSourceUrl: "https://bandhanbank.com/interest-rate" }),
  bank("cub", "PVT", "City Union Bank Ltd.", "CUB", { rating: "A+", color: "#00693E", nseSymbol: "CUB", bulkRateSourceUrl: "https://www.cityunionbank.com/interest-rates" }),
  bank("csb", "PVT", "CSB Bank Limited", "CSB", { rating: "A", color: "#0B3C7A", nseSymbol: "CSBBANK", bulkRateSourceUrl: "https://www.csb.co.in/interest-rates" }),
  bank("dcb", "PVT", "DCB Bank Ltd", "DCB", { rating: "A+", color: "#003A70", nseSymbol: "DCBBANK", bulkRateSourceUrl: "https://www.dcbbank.com/interest-rates" }),
  bank("idbi", "PVT", "IDBI Bank", "IDBI", { rating: "AA", color: "#00693E", nseSymbol: "IDBI", bulkRateSourceUrl: "https://www.idbibank.in/interest-rates.aspx" }),
  bank("idfcfirst", "PVT", "IDFC FIRST Bank Limited", "IDFC", { rating: "AA+", color: "#9E1B32", nseSymbol: "IDFCFIRSTB", bulkRateSourceUrl: "https://www.idfcfirstbank.com/interest-rate" }),
  bank("indusind", "PVT", "IndusInd Bank", "IIB", { rating: "AA+", color: "#8B1B3F", nseSymbol: "INDUSINDBK", bulkRateSourceUrl: "https://www.indusind.com/in/en/personal/rates.html" }),
  bank("karnatakabank", "PVT", "Karnataka Bank Ltd", "KBL", { rating: "A", color: "#C8102E", nseSymbol: "KTKBANK", bulkRateSourceUrl: "https://karnatakabank.com/interest-rates" }),
  bank("kvb", "PVT", "Karur Vysya Bank Ltd", "KVB", { rating: "A+", color: "#0057A8", nseSymbol: "KARURVYSYA", bulkRateSourceUrl: "https://www.kvb.co.in/interest-rates/" }),
  bank("kotak", "PVT", "Kotak Mahindra Bank Ltd", "KMB", { rating: "AAA", color: "#003874", nseSymbol: "KOTAKBANK", bulkRateSourceUrl: "https://www.kotak.com/en/personal-banking/deposits/fixed-deposit/fd-interest-rate.html" }),
  bank("rbl", "PVT", "RBL Bank Limited", "RBL", { rating: "AA-", color: "#8C2332", nseSymbol: "RBLBANK", bulkRateSourceUrl: "https://www.rblbank.com/interest-rates" }),
  bank("southindian", "PVT", "The South Indian Bank Limited", "SIB", { rating: "A", color: "#00693E", nseSymbol: "SOUTHBANK", bulkRateSourceUrl: "https://www.southindianbank.com/content/interest-rate" }),
  bank("yesbank", "PVT", "YES Bank Limited", "YES", { rating: "A+", color: "#00518F", nseSymbol: "YESBANK", bulkRateSourceUrl: "https://www.yesbank.in/interest-rates" }),
  bank("jkbank", "PVT", "Jammu & Kashmir Bank Ltd", "J&K", { rating: "A", color: "#8B0000", nseSymbol: "J&KBANK", bulkRateSourceUrl: "https://www.jkbank.com/interest-rates" }),
  bank("dhanlaxmi", "PVT", "Dhanlaxmi Bank Limited", "DLB", { rating: "BBB", color: "#B8102E", nseSymbol: "DHANBANK", bulkRateSourceUrl: "https://www.dhanbank.com/interest-rates/" }),
  bank("federal", "PVT", "Federal Bank Limited", "FED", { rating: "AA", color: "#00539B", nseSymbol: "FEDERALBNK", bulkRateSourceUrl: "https://www.federalbank.co.in/deposit-rates" }),
  bank("nainital", "PVT", "Nainital Bank Limited", "NTL", { rating: "BBB+", color: "#1F5F3F", bulkRateSourceUrl: "https://www.nainitalbank.co.in/english/Interest_Rates.aspx" }),

  // ---- Foreign Banks -------------------------------------------------------
  bank("dbs-india", "FRN", "DBS Bank India Ltd.", "DBS", { color: "#E4002B", bulkRateSourceUrl: "https://www.dbs.com/in/treasures/rates-online/fixed-deposit-rate.page" }),
  bank("deutsche", "FRN", "Deutsche Bank", "DB", { color: "#0018A8", bulkRateSourceUrl: "https://www.deutschebank.co.in/interest-rates.html" }),
  bank("hsbc", "FRN", "Hongkong & Shanghai Bkg Corpn.", "HSBC", { color: "#DB0011", bulkRateSourceUrl: "https://www.hsbc.co.in/term-deposits/" }),
  bank("sbm-india", "FRN", "SBM Bank (India)", "SBM", { rating: "AA-", color: "#005596", bulkRateSourceUrl: "https://www.sbmbank.co.in/interest-rates.php" }),
  bank("scb-india", "FRN", "Standard Chartered Bank", "SCB", { color: "#0072AA", bulkRateSourceUrl: "https://www.sc.com/in/rates-charges/" }),

  // ---- Small Finance Banks -------------------------------------------------
  bank("capitalsfb", "SFB", "Capital Small Finance Bank Limited", "CSFB", { rating: "A", color: "#0B6E4F", bulkRateSourceUrl: "https://www.capitalbank.co.in/interest-rates" }),
  bank("equitas", "SFB", "Equitas Small Finance Bank Limited", "ESFB", { color: "#E4002B", nseSymbol: "EQUITASBNK", bulkRateSourceUrl: "https://www.equitasbank.com/interest-rate" }),
  bank("esaf", "SFB", "ESAF Small Finance Bank Limited", "ESAF", { rating: "A-", color: "#00539B", nseSymbol: "ESAFSFB", bulkRateSourceUrl: "https://www.esafbank.com/interest-rates/" }),
  bank("jana", "SFB", "Jana Small Finance Bank Limited", "JSFB", { rating: "A", color: "#00A0AF", nseSymbol: "JSFB", bulkRateSourceUrl: "https://www.janabank.com/interest-rates/" }),
  bank("shivalik", "SFB", "Shivalik Small Finance Bank Limited", "SSFB", { rating: "BBB+", color: "#1A5632", bulkRateSourceUrl: "https://shivalikbank.com/interest-rates" }),
  bank("unitysfb", "SFB", "Unity Small Finance Bank Limited", "USFB", { rating: "A", color: "#F26522", bulkRateSourceUrl: "https://theunitybank.com/interest-rate" }),
  bank("utkarsh", "SFB", "Utkarsh Small Finance Bank Limited", "UTK", { rating: "A", color: "#00539B", nseSymbol: "UTKARSHBNK", bulkRateSourceUrl: "https://www.utkarsh.bank/interest-rates" }),
  bank("suryoday", "SFB", "Suryoday Small Finance Bank Limited", "SYD", { rating: "A-", color: "#E87722", nseSymbol: "SURYODAY", bulkRateSourceUrl: "https://www.suryodaybank.com/interest-rates" }),
  bank("ujjivan", "SFB", "Ujjivan Small Finance Bank Limited", "UJJ", { color: "#00609C", nseSymbol: "UJJIVANSFB", bulkRateSourceUrl: "https://www.ujjivansfb.in/interest-rates" }),
  bank("slicesfb", "SFB", "slice Small Finance Bank Limited", "SLICE", { rating: "BBB+", color: "#6A1B9A", bulkRateSourceUrl: "https://www.sliceit.com/" }),

  // ---- Urban Cooperative Banks ---------------------------------------------
  bank("svc", "UCB", "SVC Co-operative Bank Limited", "SVC", { color: "#1C4E80", bulkRateSourceUrl: "https://www.svcbank.com/interest-rates" }),
  bank("kalupur", "UCB", "The Kalupur Commercial Co-op Bank", "KCCB", { rating: "A-", color: "#1F5F3F", bulkRateSourceUrl: "https://www.kalupurbank.com/interest-rate" }),

  // ---- Regional Rural Banks ------------------------------------------------
  bank("apgb", "RRB", "Andhra Pradesh Grameena Bank", "APGB", { bulkRateSourceUrl: "" }),
  bank("assamgb", "RRB", "Assam Gramin Bank", "ASGB"),
  bank("aprb", "RRB", "Arunachal Pradesh Rural Bank", "APRB"),
  bank("bihargb", "RRB", "Bihar Gramin Bank", "BGB"),
  bank("cggb", "RRB", "Chhattisgarh Gramin Bank", "CGGB"),
  bank("ggb", "RRB", "Gujarat Gramin Bank", "GGB"),
  bank("hgb", "RRB", "Haryana Gramin Bank", "HGB"),
  bank("hpgb", "RRB", "Himachal Pradesh Gramin Bank", "HPGB"),
  bank("jhgb", "RRB", "Jharkhand Gramin Bank", "JGB"),
  bank("jkgb", "RRB", "Jammu and Kashmir Grameen Bank", "JKGB"),
  bank("kgb-karnataka", "RRB", "Karnataka Grameena Bank", "KAGB"),
  bank("mahagb", "RRB", "Maharashtra Gramin Bank", "MGB"),
  bank("mpgb", "RRB", "Madhya Pradesh Gramin Bank", "MPGB"),
  bank("manipurrb", "RRB", "Manipur Rural Bank", "MNRB"),
  bank("meghalayarb", "RRB", "Meghalaya Rural Bank", "MERB"),
  bank("mizoramrb", "RRB", "Mizoram Rural Bank", "MZRB"),
  bank("nagalandrb", "RRB", "Nagaland Rural Bank", "NRB"),
  bank("odishagb", "RRB", "Odisha Grameen Bank", "OGB"),
  bank("pgb", "RRB", "Punjab Gramin Bank", "PGB"),
  bank("puducherrygb", "RRB", "Puducherry Grama Bank", "PYGB"),
  bank("rajgb", "RRB", "Rajasthan Gramin Bank", "RGB"),
  bank("tngb", "RRB", "Tamil Nadu Grama Bank", "TNGB"),
  bank("tsgb", "RRB", "Telangana Grameena Bank", "TGB"),
  bank("tripuragb", "RRB", "Tripura Gramin Bank", "TRGB"),
  bank("upgb", "RRB", "Uttar Pradesh Gramin Bank", "UPGB"),
  bank("ukgb", "RRB", "Uttarakhand Gramin Bank", "UKGB"),
  bank("wbgb", "RRB", "West Bengal Gramin Bank", "WBGB"),
];



// -----------------------------------------------------------------------------
// Treasury Cost-of-Funds — official rates published by SIDBI Treasury for the
// disbursement window 05 Jul 2025 – 31 Jul 2025 (IFV-Banks). Hardcoded for now
// per Treasury circular; UI still allows manual override per row.
// -----------------------------------------------------------------------------
export interface CofOption {
  key: string;
  /** Short summary label used in the dropdown row (Tenor + Type). */
  label: string;
  /** "1Y", "2Y", "3Y" — human-readable tenor bucket. */
  tenorLabel: string;
  tenorMonths: number;
  /** Fixed = Treasury value; Floating = benchmark + spread; Custom = user-entered rate. */
  type: "fixed" | "floating" | "custom";
  /** For floating: which market benchmark the rate resets against. */
  benchmark?: "repo" | "tbill3m";
  /** For floating: Treasury-quoted default spread over benchmark (bps). */
  defaultSpreadBps?: number;
  /** For fixed: the Treasury-quoted rate. For floating: the live benchmark rate (overlaid at runtime). Custom: user-entered. */
  ratePct: number | null;
  source: string;
  /** How principal / rate behaves. */
  structure: "bullet" | "reset";
}
export const COF_OPTION_DEFS: Omit<CofOption, "ratePct">[] = [
  { key: "1y_tbill_float",  tenorLabel: "1Y",    label: "1Y · Floating · 3M T-Bill",       tenorMonths: 12, type: "floating", benchmark: "tbill3m", defaultSpreadBps: 180, structure: "reset",  source: "Treasury (email)" },
  { key: "1y3y_repo_float", tenorLabel: "1Y-3Y", label: "1Y–3Y · Floating · Repo",         tenorMonths: 36, type: "floating", benchmark: "repo",    defaultSpreadBps: 205, structure: "reset",  source: "Treasury (email)" },
  { key: "1y3y_fixed",      tenorLabel: "1Y-3Y", label: "1Y–3Y · Fixed",                   tenorMonths: 36, type: "fixed", structure: "reset",  source: "Treasury (email)" },
  { key: "2y3y_fixed",      tenorLabel: "2Y-3Y", label: "2Y–3Y · Fixed · Bullet",          tenorMonths: 36, type: "fixed", structure: "bullet", source: "Treasury (email)" },
  { key: "custom",          tenorLabel: "Custom fixed",   label: "Custom · Fixed (user CoF)",              tenorMonths: 360, type: "custom", structure: "bullet", source: "User input" },
  { key: "custom_float",    tenorLabel: "Custom floating",label: "Custom · Floating (benchmark + spread)",  tenorMonths: 360, type: "custom", benchmark: "repo", structure: "reset",  source: "User input" },

];
export const COF_STATIC_RATES: Record<string, number> = {
  "1y3y_fixed": 6.35,
  "2y3y_fixed": 6.70,
};
/** Legacy floating-key → benchmark map, kept for back-compat. Prefer option.benchmark. */
export const COF_FLOATING_MAP: Record<string, "repo" | "tbill3m"> = {
  "1y_tbill_float":  "tbill3m",
  "1y3y_repo_float": "repo",
};
export const COF_EFFECTIVE_WINDOW = "Treasury email — current window";

// -----------------------------------------------------------------------------
// Benchmark options — Policy Repo comes from RBI live; the rest are editable
// until an official source is wired.
// -----------------------------------------------------------------------------
export interface BenchmarkOption { key: string; label: string; ratePct: number | null; official: boolean; }
export const BENCHMARK_OPTION_DEFS: Omit<BenchmarkOption, "ratePct">[] = [
  { key: "repo",    label: "Policy Repo Rate",  official: true  },  // RBI live
  { key: "tbill3m", label: "T-Bill 3M",         official: false },  // editable
  { key: "gsec10",  label: "10Y G-Sec",         official: false },  // editable
];

// -----------------------------------------------------------------------------
// Market snapshot shape — populated at runtime by /api/public/market.
// null means "not available from an official source yet".
// -----------------------------------------------------------------------------
export interface MarketSnapshot {
  fetchedAt: string | null;
  repo: { value: number | null; source: string | null };
  reverseRepo: { value: number | null; source: string | null };
  sdf: { value: number | null; source: string | null };
  msf: { value: number | null; source: string | null };
  bankRate: { value: number | null; source: string | null };
  gsec10: { value: number | null; source: string | null };
  tbill3m: { value: number | null; source: string | null };
  cd1y: { value: number | null; source: string | null };
  cp1y: { value: number | null; source: string | null };
}

export const EMPTY_MARKET: MarketSnapshot = {
  fetchedAt: null,
  repo:        { value: null, source: null },
  reverseRepo: { value: null, source: null },
  sdf:         { value: null, source: null },
  msf:         { value: null, source: null },
  bankRate:    { value: null, source: null },
  gsec10:      { value: null, source: null },
  tbill3m:     { value: null, source: null },
  cd1y:        { value: null, source: null },
  cp1y:        { value: null, source: null },
};

// -----------------------------------------------------------------------------
// RMSE fund maturity is fixed by the RBI refinance line: 6 March 2029.
// Tenure in months is an approximation of the actual date gap — rounded to the
// nearest whole month (extra/short days of a few weeks round to the closest month).
// -----------------------------------------------------------------------------
export const RMSE_MATURITY_DATE = new Date(2029, 2, 6); // 6 Mar 2029

/** Whole months between two dates, rounded UP whenever any extra days remain. */
export function roundedMonthsBetween(from: Date, to: Date): number {
  let months = (to.getFullYear() - from.getFullYear()) * 12 + (to.getMonth() - from.getMonth());
  const anchor = new Date(from.getFullYear(), from.getMonth() + months, from.getDate());
  const dayDiff = Math.round((to.getTime() - anchor.getTime()) / 86400000);
  if (dayDiff > 0) months += 1;          // x months + any days -> x+1 months
  else if (dayDiff < 0) months -= 1;     // short of a full month -> previous whole month
  return Math.max(1, months);
}

function defaultRmseTenure(): number {
  const n = new Date();
  return roundedMonthsBetween(new Date(n.getFullYear(), n.getMonth(), n.getDate()), RMSE_MATURITY_DATE);
}

// -----------------------------------------------------------------------------
// Default deal — no seeded market rates.
// benchmarkPct starts null; UI fills it from RBI once market loads.
// -----------------------------------------------------------------------------
export const DEFAULT_DEAL: DealState = {
  bankId: "hdfc",
  principalCr: 500,
  mserSharePct: 75,
  mser: { tenureMonths: 24, ratePct: 6.80, moratoriumMonths: 6 },
  rmse: { tenureMonths: defaultRmseTenure(), ratePct: 4.25, moratoriumMonths: 0 },
  repaymentFreq: "quarterly",
  customTailMonths: 3,
  benchmarkPct: 0,           // filled from RBI or user
  benchmarkLabel: "Policy Repo Rate",
  discretionBps: 10,
};


// Re-export for callers that still expect these names.
export const COF_OPTIONS: CofOption[] = COF_OPTION_DEFS.map((c) => ({ ...c, ratePct: COF_STATIC_RATES[c.key] ?? null }));
export const BENCHMARK_OPTIONS: BenchmarkOption[] = BENCHMARK_OPTION_DEFS.map((b) => ({ ...b, ratePct: null }));
