// -----------------------------------------------------------------------------
// Illustrative deal tapes.
//   1. Bloomberg-style counterparty market activity (what the bank has raised /
//      placed in the market recently).
//   2. SIDBI treasury deal tape (our own borrowing / placement deals that set
//      the cost-of-funds reference).
// All rows are ILLUSTRATIVE and generated deterministically per counterparty so
// the dashboard stays stable across renders. No live feed is wired.
// -----------------------------------------------------------------------------
import type { BankProfile } from "./pricing-data";

export interface CounterpartyMarketDeal {
  date: string;          // ISO
  instrument: string;    // CD / Bond / Term money / Loan participation
  /** All rows are funds RAISED by the bank (borrowing side only). */
  side: "Issued" | "Borrowed" | "Accepted";
  amountCr: number;
  ratePct: number;
  tenor: string;
  counterpartyType: string; // who was on the other side
  ticker?: string;
}

/**
 * Treasury / money-market tape — market-side prints picked up from Treasury and
 * news. These are NOT our own borrowings: they are deals closed in the market,
 * Treasury money-market operations and the 1Y CD market over the last 6-12
 * months, used as live pricing reference for the negotiation.
 */
export type TreasurySegment = "Deals closed" | "Money market ops" | "CD market";

export interface TreasuryDeal {
  date: string;
  segment: TreasurySegment;
  instrument: string;
  counterparty: string;   // issuer / counterparty in the market
  amountCr: number;
  ratePct: number;
  tenor: string;
  source: "Treasury" | "Bloomberg" | "News";
  note?: string;
}


/** Stable pseudo-random in [0,1) from a string seed. */
function seeded(seed: string, i: number): number {
  let h = 2166136261 ^ i;
  for (let k = 0; k < seed.length; k++) {
    h ^= seed.charCodeAt(k);
    h = Math.imul(h, 16777619);
  }
  return ((h >>> 0) % 10000) / 10000;
}

const RATING_SPREAD_BPS: Record<string, number> = {
  AAA: 0, "AA+": 18, AA: 32, "AA-": 48, "A+": 70, A: 92, "A-": 118,
};

function baseFor(bank: BankProfile): number {
  const r = RATING_SPREAD_BPS[bank.rating] ?? 60;
  const catAdj = bank.category === "CB" ? 0 : bank.category === "RRB" ? 15 : bank.category === "UCB" ? 55 : 80;
  return 6.85 + (r + catAdj) / 100;
}

function iso(monthsAgo: number, day: number): string {
  // UTC-anchored so SSR and client hydration produce identical dates.
  const today = new Date();
  const d = new Date(today);
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() - monthsAgo);
  d.setUTCDate(Math.min(day, 28));
  // Never quote a date in the future.
  if (d.getTime() > today.getTime()) return today.toISOString().slice(0, 10);
  return d.toISOString().slice(0, 10);
}


const CP_TEMPLATES: { instrument: string; side: CounterpartyMarketDeal["side"]; tenor: string; adj: number; counterpartyType: string }[] = [
  { instrument: "Certificate of Deposit", side: "Issued", tenor: "3M", adj: -0.55, counterpartyType: "MF / Liquid funds" },
  { instrument: "Certificate of Deposit", side: "Issued", tenor: "1Y", adj: -0.25, counterpartyType: "MF / Insurance" },
  { instrument: "Infra Bond", side: "Issued", tenor: "10Y", adj: 0.22, counterpartyType: "Insurance / Pension" },
  { instrument: "Tier-2 Bond", side: "Issued", tenor: "10Y (call 5Y)", adj: 0.45, counterpartyType: "Insurance / Banks" },
  { instrument: "Term Money", side: "Borrowed", tenor: "14D", adj: -0.85, counterpartyType: "Interbank" },
  { instrument: "Bulk Deposit", side: "Accepted", tenor: "2Y", adj: -0.05, counterpartyType: "Corporate / FI" },
];

export function counterpartyMarketDeals(bank: BankProfile): CounterpartyMarketDeal[] {
  const base = baseFor(bank);
  return CP_TEMPLATES.map((t, i) => {
    const jitter = (seeded(bank.id + t.instrument, i) - 0.5) * 0.16;
    const amt = 100 + Math.round(seeded(bank.id + "amt", i) * 18) * 50;
    return {
      date: iso(i === 0 ? 0 : i, 4 + Math.round(seeded(bank.id + "d", i) * 22)),
      instrument: t.instrument,
      side: t.side,
      amountCr: amt,
      ratePct: +(base + t.adj + jitter).toFixed(2),
      tenor: t.tenor,
      counterpartyType: t.counterpartyType,
      ticker: bank.nseSymbol,
    };
  }).sort((a, b) => (a.date < b.date ? 1 : -1));
}

function isoDaysAgo(days: number): string {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() - Math.max(0, days));
  return d.toISOString().slice(0, 10);
}


type TT = {
  segment: TreasurySegment;
  instrument: string;
  counterparty: string;
  tenor: string;
  adj: number;
  daysAgo: number;
  source: TreasuryDeal["source"];
  note?: string;
};

const TREASURY_TEMPLATES: TT[] = [
  // ---- Yesterday's deals closed (Treasury blotter) ----
  { segment: "Deals closed", instrument: "1Y CD — primary", counterparty: "Axis Bank", tenor: "1Y", adj: 0.02, daysAgo: 1, source: "Treasury", note: "Cleared at market; benchmark for 1Y CD pricing." },
  { segment: "Deals closed", instrument: "3M CD — secondary", counterparty: "Kotak Mahindra Bank", tenor: "3M", adj: -0.55, daysAgo: 1, source: "Treasury" },
  { segment: "Deals closed", instrument: "Bulk deposit (non-callable)", counterparty: "Bank of Baroda", tenor: "1Y", adj: -0.08, daysAgo: 1, source: "Treasury" },
  // ---- Money market operations ----
  { segment: "Money market ops", instrument: "TREPS lending", counterparty: "CCIL", tenor: "1D", adj: -1.72, daysAgo: 1, source: "Treasury" },
  { segment: "Money market ops", instrument: "Call money placement", counterparty: "Interbank", tenor: "1D", adj: -1.60, daysAgo: 2, source: "Treasury" },
  { segment: "Money market ops", instrument: "RBI VRRR auction", counterparty: "RBI", tenor: "7D", adj: -1.78, daysAgo: 3, source: "Treasury" },
  { segment: "Money market ops", instrument: "T-Bill 91D — cut-off", counterparty: "RBI auction", tenor: "91D", adj: -1.70, daysAgo: 5, source: "Treasury" },
  { segment: "Money market ops", instrument: "Commercial Paper — NBFC", counterparty: "AAA NBFC", tenor: "3M", adj: -0.35, daysAgo: 6, source: "Bloomberg" },
  // ---- 1Y CD market, last 6-12 months ----
  { segment: "CD market", instrument: "1Y CD print", counterparty: "HDFC Bank", tenor: "1Y", adj: 0.05, daysAgo: 22, source: "Bloomberg" },
  { segment: "CD market", instrument: "1Y CD print", counterparty: "ICICI Bank", tenor: "1Y", adj: 0.01, daysAgo: 48, source: "Bloomberg" },
  { segment: "CD market", instrument: "1Y CD print", counterparty: "Punjab National Bank", tenor: "1Y", adj: 0.09, daysAgo: 76, source: "News" },
  { segment: "CD market", instrument: "1Y CD print", counterparty: "Canara Bank", tenor: "1Y", adj: 0.12, daysAgo: 118, source: "Bloomberg" },
  { segment: "CD market", instrument: "1Y CD print", counterparty: "IndusInd Bank", tenor: "1Y", adj: 0.24, daysAgo: 165, source: "Bloomberg" },
  { segment: "CD market", instrument: "1Y CD print", counterparty: "State Bank of India", tenor: "1Y", adj: -0.06, daysAgo: 210, source: "News" },
  { segment: "CD market", instrument: "1Y CD print", counterparty: "Union Bank of India", tenor: "1Y", adj: 0.15, daysAgo: 305, source: "Bloomberg" },
];

export function treasuryDeals(): TreasuryDeal[] {
  const base = 7.05;
  return TREASURY_TEMPLATES.map((t, i) => {
    const jitter = (seeded(t.counterparty + t.instrument, i) - 0.5) * 0.10;
    const amt = 100 + Math.round(seeded("tamt" + t.counterparty, i) * 16) * 25;
    return {
      date: isoDaysAgo(t.daysAgo),
      segment: t.segment,
      instrument: t.instrument,
      counterparty: t.counterparty,
      amountCr: amt,
      ratePct: +Math.max(3.2, base + t.adj + jitter).toFixed(2),
      tenor: t.tenor,
      source: t.source,
      note: t.note,
    };
  }).sort((a, b) => (a.date < b.date ? 1 : -1));
}

