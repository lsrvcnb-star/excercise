import { useEffect, useState } from "react";

export interface LiveDepositRow { tenor: string; callable: number | null; nonCallable: number | null; nonCallableMin?: number | null; nonCallableMax?: number | null; amountBucket?: "3-5" | "5+" | null; }
export interface LiveAnnouncement {
  date: string;
  desc: string;
  amount: string | null;
  tenure: string | null;
  coupon: string | null;
  securityType: string | null;
  market: "Domestic" | "Offshore" | null;
  status: string | null;
  attachmentUrl: string | null;
  rating?: string | null;
}
export interface CounterpartyLive {
  fetchedAt: string | null;
  bankRating: string | null;
  deposits: { rows: LiveDepositRow[] | null; sourceUrl: string | null; asOf: string | null; note: string | null; illustrative?: boolean; hasAmountBuckets?: boolean };
  announcements: { rows: LiveAnnouncement[]; sourceUrl: string | null; note: string | null; illustrative?: boolean };
}

const EMPTY: CounterpartyLive = {
  fetchedAt: null,
  bankRating: null,
  deposits: { rows: null, sourceUrl: null, asOf: null, note: null },
  announcements: { rows: [], sourceUrl: null, note: null },
};

export function useCounterparty(bankId: string, nseSymbol?: string | null, rating?: string | null) {
  const [data, setData] = useState<CounterpartyLive>(EMPTY);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    const params = new URLSearchParams({ bank: bankId });
    if (nseSymbol) params.set("symbol", nseSymbol);
    if (rating) params.set("rating", rating);
    fetch(`/api/public/counterparty?${params.toString()}`)
      .then(async (r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((j: CounterpartyLive) => {
        if (cancelled) return;
        setData({
          fetchedAt: j.fetchedAt ?? null,
          bankRating: j.bankRating ?? null,
          deposits: j.deposits ?? EMPTY.deposits,
          announcements: j.announcements ?? EMPTY.announcements,
        });
      })
      .catch((e) => { if (!cancelled) setError(String(e.message ?? e)); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [bankId, nseSymbol, rating]);

  return { data, loading, error };
}
