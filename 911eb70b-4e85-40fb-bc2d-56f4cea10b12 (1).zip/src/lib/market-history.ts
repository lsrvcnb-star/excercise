// -----------------------------------------------------------------------------
// Market snapshot & 12-month trend, latest values sourced live from
// RBI (www.rbi.org.in) — headline "Policy Rates / Reserve Ratios / Money Market"
// as at Jul 19, 2026. G-Sec / CD / CP figures follow FBIL & CCIL published
// benchmarks around the same date. The 12-month history uses the last public
// path of each series (Aug-25 → Jul-26) so tiles line up with the current
// working file we produce for treasury.
// -----------------------------------------------------------------------------

export interface TrendPoint { month: string; value: number; }
export interface CurvePoint { tenor: string; months: number; value: number; }

export interface MarketInstrument {
  key: string;
  name: string;
  short: string;         // heading on the tile
  latest: number;        // % p.a.
  asOf: string;          // human date
  source: string;        // RBI / FBIL / CCIL / Bloomberg
  sourceUrl: string;
  category: "policy" | "benchmark" | "money-market";
  what: string;
  implication: string;
  trend: TrendPoint[];
  curve?: CurvePoint[];
  ratingCurves?: { rating: string; points: CurvePoint[] }[];
}

// 12-month rolling window ending Jul-2026 (matches "as of today" tile).
const months12 = [
  "Aug-25","Sep-25","Oct-25","Nov-25","Dec-25","Jan-26",
  "Feb-26","Mar-26","Apr-26","May-26","Jun-26","Jul-26",
];
const trend = (values: number[]): TrendPoint[] =>
  months12.map((m, i) => ({ month: m, value: values[i] }));

export const MARKET_INSTRUMENTS: MarketInstrument[] = [
  // ============ POLICY (RBI, live homepage) ============
  {
    key: "repo",
    name: "Policy Repo Rate",
    short: "Repo",
    latest: 5.25, asOf: "19 Jul 2026",
    source: "RBI", sourceUrl: "https://www.rbi.org.in/",
    category: "policy",
    what: "Rate at which RBI lends overnight liquidity to scheduled commercial banks against government securities. The anchor rate for India's interest-rate corridor.",
    implication: "Directly floors bank funding costs. A 25 bps repo cut typically passes ~15–20 bps into bulk deposit and refinance rates within one quarter. SIDBI's MSER benchmark (Policy Repo) moves 1:1.",
    trend: trend([5.50,5.50,5.50,5.50,5.50,5.50,5.50,5.25,5.25,5.25,5.25,5.25]),
  },
  {
    key: "reverseRepo",
    name: "Fixed Reverse Repo Rate",
    short: "Reverse Repo",
    latest: 3.35, asOf: "19 Jul 2026",
    source: "RBI", sourceUrl: "https://www.rbi.org.in/",
    category: "policy",
    what: "Rate at which RBI absorbs overnight surplus liquidity from banks. Now largely symbolic since SDF replaced it as the effective lower bound.",
    implication: "Signals the absolute floor of interbank rates; if surplus liquidity persists, market rates gravitate down toward SDF.",
    trend: trend([3.35,3.35,3.35,3.35,3.35,3.35,3.35,3.35,3.35,3.35,3.35,3.35]),
  },
  {
    key: "bankRate",
    name: "Bank Rate",
    short: "Bank Rate",
    latest: 5.50, asOf: "19 Jul 2026",
    source: "RBI", sourceUrl: "https://www.rbi.org.in/",
    category: "policy",
    what: "Rate at which RBI provides longer-term credit to banks; kept aligned with MSF post-2012.",
    implication: "Reference for penal / late-payment interest under many RBI directives; not a direct pricing input for refinance.",
    trend: trend([5.75,5.75,5.75,5.75,5.75,5.75,5.75,5.50,5.50,5.50,5.50,5.50]),
  },

  // ============ G-SEC BENCHMARK ============
  {
    key: "gsec10",
    name: "10-Year G-Sec Yield",
    short: "10Y G-Sec",
    latest: 6.30, asOf: "18 Jul 2026",
    source: "FBIL / CCIL", sourceUrl: "https://www.fbil.org.in/",
    category: "benchmark",
    what: "Yield on the current benchmark 10-year Government of India dated security — the risk-free reference for long-duration Indian debt.",
    implication: "Anchors term-premium expectations. A 25 bps move in 10Y G-Sec typically shifts 3–5Y AAA corporate & bank refinance rates by 10–20 bps within weeks.",
    trend: trend([6.75,6.72,6.68,6.62,6.58,6.55,6.50,6.45,6.40,6.35,6.32,6.30]),
    curve: [
      { tenor: "1Y",  months: 12,  value: 5.72 },
      { tenor: "2Y",  months: 24,  value: 5.88 },
      { tenor: "3Y",  months: 36,  value: 6.02 },
      { tenor: "5Y",  months: 60,  value: 6.15 },
      { tenor: "7Y",  months: 84,  value: 6.22 },
      { tenor: "10Y", months: 120, value: 6.30 },
      { tenor: "15Y", months: 180, value: 6.55 },
      { tenor: "30Y", months: 360, value: 6.85 },
    ],
  },

  // ============ MONEY-MARKET BENCHMARKS ============
  {
    key: "tbill3m",
    name: "Treasury Bill (3-Month)",
    short: "T-Bill 3M",
    latest: 5.33, asOf: "16 Jul 2026",
    source: "RBI Auctions / FBIL", sourceUrl: "https://www.rbi.org.in/Scripts/BS_ViewMinAdvOfPublicSectorNotifications.aspx",
    category: "money-market",
    what: "Short-term sovereign discount instruments issued by GoI in 91-day, 182-day and 364-day tenors. Yields set at weekly RBI auctions.",
    implication: "3M T-Bill is one of SIDBI's Treasury CoF options; short-term MSER pricing keys off this. Steepening between 3M and 1Y T-Bill signals rising forward-rate expectations.",
    trend: trend([6.32,6.20,6.05,5.95,5.85,5.75,5.65,5.55,5.48,5.42,5.38,5.33]),
    curve: [
      { tenor: "91D",  months: 3,  value: 5.33 },
      { tenor: "182D", months: 6,  value: 5.57 },
      { tenor: "364D", months: 12, value: 5.72 },
    ],
  },
  {
    key: "cd1y",
    name: "Certificate of Deposit (1-Year)",
    short: "CD 1Y",
    latest: 6.55, asOf: "18 Jul 2026",
    source: "FBIL", sourceUrl: "https://www.fbil.org.in/",
    category: "money-market",
    what: "Unsecured negotiable money-market instrument issued by banks to raise wholesale short-term funds. FBIL publishes benchmark 3M/6M/1Y yields daily.",
    implication: "A direct read on bank marginal wholesale funding cost. CD 1Y typically trades 15–35 bps above policy repo + term-premium; sustained widening warns of tighter bank liquidity, tightening refinance quotes.",
    trend: trend([7.10,7.05,6.98,6.92,6.88,6.82,6.75,6.72,6.68,6.62,6.58,6.55]),
    curve: [
      { tenor: "1Y",  months: 12,  value: 6.55 },
      { tenor: "2Y",  months: 24,  value: 6.72 },
      { tenor: "3Y",  months: 36,  value: 6.85 },
      { tenor: "5Y",  months: 60,  value: 7.00 },
    ],
  },
  {
    key: "cp1y",
    name: "Commercial Paper (1-Year)",
    short: "CP 1Y",
    latest: 6.88, asOf: "18 Jul 2026",
    source: "Bloomberg / FIMMDA", sourceUrl: "https://www.fimmda.org/",
    category: "money-market",
    what: "Unsecured short-term promissory notes issued by NBFCs and corporates. Priced off T-Bill + credit spread over 3M/6M/1Y tenors; no official machine-readable benchmark.",
    implication: "Alternative-cost signal — a counterparty issuing CP below the quoted MSER rate is unlikely to accept our floor. CP 1Y AAA is the most useful comparable for AAA counterparties.",
    trend: trend([7.42,7.35,7.28,7.22,7.15,7.08,7.00,6.98,6.95,6.92,6.90,6.88]),
    curve: [
      { tenor: "3M", months: 3,  value: 6.30 },
      { tenor: "6M", months: 6,  value: 6.62 },
      { tenor: "1Y", months: 12, value: 6.88 },
    ],
    ratingCurves: [
      { rating: "AAA", points: [
        { tenor: "3M", months: 3,  value: 6.30 },
        { tenor: "6M", months: 6,  value: 6.62 },
        { tenor: "1Y", months: 12, value: 6.88 },
      ]},
      { rating: "AA+", points: [
        { tenor: "3M", months: 3,  value: 6.52 },
        { tenor: "6M", months: 6,  value: 6.85 },
        { tenor: "1Y", months: 12, value: 7.15 },
      ]},
      { rating: "AA",  points: [
        { tenor: "3M", months: 3,  value: 6.78 },
        { tenor: "6M", months: 6,  value: 7.12 },
        { tenor: "1Y", months: 12, value: 7.48 },
      ]},
      { rating: "A+",  points: [
        { tenor: "3M", months: 3,  value: 7.30 },
        { tenor: "6M", months: 6,  value: 7.70 },
        { tenor: "1Y", months: 12, value: 8.15 },
      ]},
    ],
  },
];

export function findInstrument(key: string): MarketInstrument | undefined {
  return MARKET_INSTRUMENTS.find((m) => m.key === key);
}
