import { useEffect, useState } from "react";
import { EMPTY_MARKET, type MarketSnapshot } from "./pricing-data";

export interface MarketState {
  data: MarketSnapshot;
  loading: boolean;
  error: string | null;
  refresh: () => void;
}

export function useMarket(): MarketState {
  const [data, setData] = useState<MarketSnapshot>(EMPTY_MARKET);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    fetch("/api/public/market")
      .then(async (r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        return r.json();
      })
      .then((j) => {
        if (cancelled) return;
        setData({
          fetchedAt: j.fetchedAt ?? null,
          repo:        j.repo        ?? { value: null, source: null },
          reverseRepo: j.reverseRepo ?? { value: null, source: null },
          sdf:         j.sdf         ?? { value: null, source: null },
          msf:         j.msf         ?? { value: null, source: null },
          bankRate:    j.bankRate    ?? { value: null, source: null },
          gsec10:      j.gsec10      ?? { value: null, source: null },
          tbill3m:     j.tbill3m     ?? { value: null, source: null },
          cd1y:        j.cd1y        ?? { value: null, source: null },
          cp1y:        j.cp1y        ?? { value: null, source: null },
        });
      })
      .catch((e) => { if (!cancelled) setError(String(e.message ?? e)); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [tick]);

  return { data, loading, error, refresh: () => setTick((t) => t + 1) };
}
