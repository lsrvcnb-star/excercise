// Pricing engine: MSER/RMSE blended effective rate + XIRR
// Reference: Effective_Interest_Rate.xlsb, WAR_Sheet.xlsx

export type Frequency = "bullet" | "monthly" | "quarterly" | "halfyearly" | "annual" | "custom";

export const FREQUENCIES: { key: Frequency; label: string; periods: number | "bullet" | "custom" }[] = [
  { key: "monthly", label: "Monthly", periods: 12 },
  { key: "quarterly", label: "Quarterly", periods: 4 },
  { key: "halfyearly", label: "Half-Yearly", periods: 2 },
  { key: "annual", label: "Annual", periods: 1 },
  { key: "bullet", label: "Bullet", periods: "bullet" },
  { key: "custom", label: "Custom", periods: "custom" },
];

export interface Scheme {
  tenureMonths: number;
  ratePct: number;
  moratoriumMonths: number;
}

export interface DealState {
  bankId: string;
  principalCr: number;
  mserSharePct: number;
  mser: Scheme;
  rmse: Scheme;
  repaymentFreq: Frequency;
  /** Number of months at the END of tenure over which principal is repaid in equal monthly
   *  instalments when repaymentFreq === "custom". e.g. tail = 3 → principal split equally
   *  across the final 3 months; interest still accrues monthly on the outstanding balance. */
  customTailMonths?: number;
  // Negotiation
  benchmarkPct: number; // e.g., Repo 1Y — chosen by user
  benchmarkLabel: string;
  discretionBps: number; // 0..maxDiscretion
  /** Optional additional tranches ("splits") carved out of the MSER / RMSE amounts.
   *  Each split has its own rate, tenure, moratorium and repayment frequency, so a
   *  deal can mix e.g. MSER-fixed + MSER-floating, or RMSE from two funds. */
  splits?: DealSplit[];
}

/** An extra tranche within a scheme, carved out of that scheme's amount. */
export interface DealSplit {
  id: string;
  scheme: "mser" | "rmse";
  label: string;
  /** MSER: fixed vs floating basis. RMSE: fund source name is carried in `label`. */
  basis?: "fixed" | "floating";
  amountCr: number;
  ratePct: number;
  /** MSER splits: Treasury CoF option key driving the rate build-up (UI only). */
  cofKey?: string;
  /** MSER splits: margin over CoF in bps (rate = CoF + margin). */
  marginBps?: number;
  tenureMonths: number;
  moratoriumMonths: number;
  /** RMSE splits: tranche id the leg draws from (UI only). */
  trancheId?: string;


  /** Repayment structure for this split. Defaults: MSER → deal frequency, RMSE → bullet. */
  freq?: Frequency;
  customTailMonths?: number;
}

/** A fully-resolved cashflow-bearing tranche (base leg or split). */
export interface DealLeg {
  id: string;
  scheme: "mser" | "rmse";
  label: string;
  basis?: "fixed" | "floating";
  amountCr: number;
  freq: Frequency;
  customTailMonths?: number;
  scheme_: Scheme; // rate / tenure / moratorium
}

export interface SchemeAmounts { mserAmt: number; rmseAmt: number; }

/** Keep deal amounts at the input precision and avoid percentage floating-point drift. */
function money(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function schemeAmounts(s: Pick<DealState,"principalCr"|"mserSharePct">): SchemeAmounts {
  const principal = money(s.principalCr);
  const mserAmt = money((principal * s.mserSharePct) / 100);
  return { mserAmt, rmseAmt: money(principal - mserAmt) };
}

/** Total amount carved into splits for a scheme. */
export function splitTotal(state: DealState, scheme: "mser" | "rmse"): number {
  return (state.splits ?? [])
    .filter((sp) => sp.scheme === scheme)
    .reduce((t, sp) => t + (Number.isFinite(sp.amountCr) ? sp.amountCr : 0), 0);
}

/** Amount left on the base (primary) leg of a scheme after splits are carved out. */
export function baseLegAmount(state: DealState, scheme: "mser" | "rmse"): number {
  const { mserAmt, rmseAmt } = schemeAmounts(state);
  const total = scheme === "mser" ? mserAmt : rmseAmt;
  return Math.max(0, money(total - splitTotal(state, scheme)));
}

/**
 * Resolve the deal into cashflow-bearing legs.
 * Base MSER leg follows `freq`; base RMSE leg is always bullet.
 * Splits carry their own frequency (default: deal freq for MSER, bullet for RMSE).
 */
export function resolveLegs(state: DealState, freq: Frequency): DealLeg[] {
  const legs: DealLeg[] = [];
  const mserBase = baseLegAmount(state, "mser");
  const rmseBase = baseLegAmount(state, "rmse");
  const splits = state.splits ?? [];
  const mserSplits = splits.filter((s) => s.scheme === "mser");
  const rmseSplits = splits.filter((s) => s.scheme === "rmse");

  if (mserBase > 1e-9) {
    legs.push({
      id: "mser-base",
      scheme: "mser",
      label: mserSplits.length ? "MSER · Tranche 1" : "MSER",
      amountCr: mserBase,
      freq,
      customTailMonths: state.customTailMonths,
      scheme_: state.mser,
    });
  }
  mserSplits.forEach((sp, i) => {
    if (sp.amountCr <= 1e-9) return;
    legs.push({
      id: sp.id,
      scheme: "mser",
      label: sp.label?.trim() || `MSER · Tranche ${i + 2}`,
      basis: sp.basis,
      amountCr: sp.amountCr,
      freq: sp.freq ?? freq,
      customTailMonths: sp.customTailMonths ?? state.customTailMonths,
      scheme_: { ratePct: sp.ratePct, tenureMonths: sp.tenureMonths, moratoriumMonths: sp.moratoriumMonths },
    });
  });

  if (rmseBase > 1e-9) {
    legs.push({
      id: "rmse-base",
      scheme: "rmse",
      label: rmseSplits.length ? "RMSE · Tranche 1" : "RMSE",
      amountCr: rmseBase,
      freq: "bullet",
      scheme_: state.rmse,
    });
  }
  rmseSplits.forEach((sp, i) => {
    if (sp.amountCr <= 1e-9) return;
    legs.push({
      id: sp.id,
      scheme: "rmse",
      label: sp.label?.trim() || `RMSE · Tranche ${i + 2}`,
      amountCr: sp.amountCr,
      freq: sp.freq ?? "bullet",
      customTailMonths: sp.customTailMonths,
      scheme_: { ratePct: sp.ratePct, tenureMonths: sp.tenureMonths, moratoriumMonths: sp.moratoriumMonths },
    });
  });

  return legs;
}

/** Monthly schedule per leg — used by the detailed cashflow views. */
export function legSchedules(state: DealState, freq: Frequency): { leg: DealLeg; rows: MonthRow[] }[] {
  return resolveLegs(state, freq).map((leg) => ({
    leg,
    rows: schemeSchedule(leg.scheme_, leg.amountCr, leg.freq, leg.customTailMonths),
  }));
}


// ---------- Monthly schedule (mirrors WAR_Sheet formulas) ----------
// Excel convention (Qtly/HY/Annual/Bullet Princ Pmt sheets):
//   • Rows are MONTHLY. Interest = Opening × (rate/12) is paid every month.
//   • Principal is paid on multiples of the frequency (every 3 / 6 / 12 months)
//     or as one bullet at maturity.
//   • Moratorium: interest still accrues & is paid monthly, but principal is
//     deferred to after the moratorium window.

export interface MonthRow {
  month: number;      // 1..tenure
  opening: number;
  interest: number;   // monthly interest paid
  principal: number;  // principal repaid this month (0 unless a repayment month)
  closing: number;
  cashflow: number;   // interest + principal received by lender
}

export function schemeSchedule(scheme: Scheme, amt: number, freq: Frequency, customTailMonths?: number): MonthRow[] {
  const rows: MonthRow[] = [];
  const n = Math.max(1, Math.round(scheme.tenureMonths));
  const mrate = scheme.ratePct / 100 / 12;

  const spec = FREQUENCIES.find((f) => f.key === freq)!;
  const isBullet = spec.periods === "bullet";
  const isCustom = spec.periods === "custom";

  // Moratorium: interest still accrues & is paid monthly, principal is deferred.
  // Clamp so at least one month remains for principal repayment.
  const morat = Math.max(0, Math.min(n - 1, Math.round(scheme.moratoriumMonths || 0)));
  const amortMonths = n - morat; // months available for principal repayment

  const stepMonths = isBullet || isCustom ? amortMonths : 12 / (spec.periods as number);

  // Custom mode: principal repaid in equal monthly instalments over the final `tail` months
  // (the tail always sits at the end of tenure, so it is inherently post-moratorium).
  const tailRaw = isCustom ? Math.max(1, Math.min(amortMonths, Math.round(customTailMonths ?? 3))) : 0;
  const tailStart = isCustom ? n - tailRaw + 1 : 0;
  const tailPer = isCustom ? amt / tailRaw : 0;

  const instalments = isBullet || isCustom ? 1 : Math.max(1, Math.floor(amortMonths / stepMonths));
  const principalPer = isCustom ? 0 : amt / instalments;

  let opening = amt;
  for (let m = 1; m <= n; m++) {
    const interest = opening * mrate;
    let principal = 0;
    if (isBullet) {
      if (m === n) principal = opening;
    } else if (isCustom) {
      if (m >= tailStart) principal = Math.min(tailPer, opening);
    } else if (m > morat) {
      if ((m - morat) % stepMonths === 0 && opening >= principalPer - 1e-9) {
        principal = Math.min(principalPer, opening);
      }
    }
    // Final-row sweep for rounding residuals / stub periods.
    if (m === n && opening - principal > 1e-6) {
      principal = opening;
    }
    const closing = opening - principal;
    rows.push({ month: m, opening, interest, principal, closing, cashflow: interest + principal });
    opening = closing;
  }
  return rows;
}







/** Total interest for a scheme under a given repayment frequency (Excel col E/L sum). */
export function schemeTotalInterest(scheme: Scheme, amt: number, freq: Frequency, customTailMonths?: number): number {
  return schemeSchedule(scheme, amt, freq, customTailMonths).reduce((s, r) => s + r.interest, 0);
}

/** Denominator for effective ROI: Σ (amt × tenure years) — matches Entry Sheet D21+D22. */
/**
 * Weighted principal for a scheme = Σ opening_m / 12 (from the monthly schedule).
 * Mirrors Excel Qtly/HY/Annual/Bullet Princ Pmt "Weighted Principal" block
 * (e.g., Qtly Princ Pmt. F78:F100, summed into F101). For a bullet scheme
 * this collapses to amt × tenure_years; for an amortising scheme it is
 * lower because the opening balance declines each period.
 */
export function schemeWeightedPrincipal(scheme: Scheme, amt: number, freq: Frequency, customTailMonths?: number): number {
  return schemeSchedule(scheme, amt, freq, customTailMonths).reduce((s, r) => s + r.opening / 12, 0);
}

/** Denominator for effective ROI at a given repayment frequency = Σ weighted principal across all legs. */
export function denom(state: DealState, freq: Frequency = "bullet"): number {
  return resolveLegs(state, freq).reduce(
    (t, l) => t + schemeWeightedPrincipal(l.scheme_, l.amountCr, l.freq, l.customTailMonths),
    0,
  );
}


export function effectiveRateForFreq(state: DealState, freq: Frequency): {
  mserInt: number; rmseInt: number; total: number; effective: number; denom: number;
  legs: { leg: DealLeg; interest: number; weightedPrincipal: number }[];
} {
  const legs = resolveLegs(state, freq).map((leg) => ({
    leg,
    interest: schemeTotalInterest(leg.scheme_, leg.amountCr, leg.freq, leg.customTailMonths),
    weightedPrincipal: schemeWeightedPrincipal(leg.scheme_, leg.amountCr, leg.freq, leg.customTailMonths),
  }));
  const mserInt = legs.filter((l) => l.leg.scheme === "mser").reduce((t, l) => t + l.interest, 0);
  const rmseInt = legs.filter((l) => l.leg.scheme === "rmse").reduce((t, l) => t + l.interest, 0);
  const total = mserInt + rmseInt;
  const d = legs.reduce((t, l) => t + l.weightedPrincipal, 0);
  return { mserInt, rmseInt, total, effective: d > 0 ? (total / d) * 100 : 0, denom: d, legs };
}

/**
 * The same deal (amounts, rates, mix, repayment structure) re-cut with every leg's
 * tenure set to `months`. Moratoriums are clamped so principal still amortises.
 */
export function withTenureMonths(state: DealState, months = 12): DealState {
  const cap = (sc: Scheme): Scheme => ({
    ...sc,
    tenureMonths: months,
    moratoriumMonths: Math.max(0, Math.min(months - 1, sc.moratoriumMonths || 0)),
  });
  return {
    ...state,
    mser: cap(state.mser),
    rmse: cap(state.rmse),
    customTailMonths: state.customTailMonths ? Math.min(state.customTailMonths, months) : state.customTailMonths,
    splits: (state.splits ?? []).map((sp) => ({
      ...sp,
      tenureMonths: months,
      moratoriumMonths: Math.max(0, Math.min(months - 1, sp.moratoriumMonths || 0)),
      customTailMonths: sp.customTailMonths ? Math.min(sp.customTailMonths, months) : sp.customTailMonths,
    })),
  };
}

/**
 * WAR (12 month) — the deal structure re-priced as if every tranche had a 12-month tenor.
 * Same WAR formula (Σ interest ÷ weighted principal), applied to the 12-month re-cut deal.
 */
export function effectiveRateWindow(state: DealState, freq: Frequency, months = 12): {
  months: number; interest: number; weightedPrincipal: number; sumOpening: number; effective: number;
  legs: { leg: DealLeg; interest: number; weightedPrincipal: number }[];
} {
  const st = withTenureMonths(state, months);
  const r = effectiveRateForFreq(st, freq);
  return {
    months,
    interest: r.total,
    weightedPrincipal: r.denom,
    sumOpening: r.denom * 12,
    effective: r.effective,
    legs: r.legs,
  };
}

/**
 * Weighted Avg Rate (WAR) — matches Excel "WAR_Sheet" Entry Sheet C24.
 *   WAR = Σ (Amt_i × Rate_i × Tenure_i) / Σ (Amt_i × Tenure_i)
 * Summed across every leg (MSER/RMSE base legs plus any splits).
 */
export function weightedAvgRate(state: DealState): {
  mserWeightedInt: number; rmseWeightedInt: number;
  mserWeight: number; rmseWeight: number;
  numerator: number; denominator: number; war: number;
  legs: { leg: DealLeg; weightedInt: number; weight: number }[];
} {
  const legs = resolveLegs(state, "bullet").map((leg) => {
    const yr = leg.scheme_.tenureMonths / 12;
    return { leg, weightedInt: leg.amountCr * leg.scheme_.ratePct * yr, weight: leg.amountCr * yr };
  });
  const pick = (sc: "mser" | "rmse") => legs.filter((l) => l.leg.scheme === sc);
  const mserWeightedInt = pick("mser").reduce((t, l) => t + l.weightedInt, 0);
  const rmseWeightedInt = pick("rmse").reduce((t, l) => t + l.weightedInt, 0);
  const mserWeight = pick("mser").reduce((t, l) => t + l.weight, 0);
  const rmseWeight = pick("rmse").reduce((t, l) => t + l.weight, 0);
  const numerator = mserWeightedInt + rmseWeightedInt;
  const denominator = mserWeight + rmseWeight;
  return {
    mserWeightedInt, rmseWeightedInt,
    mserWeight, rmseWeight,
    numerator, denominator,
    war: denominator > 0 ? numerator / denominator : 0,
    legs,
  };
}



// ---------- Cashflows for XIRR (monthly, dated) ----------
// Excel uses 30-day spacing (W14 = TODAY(), W15 = W14+30 ...). We mirror that:
// t is expressed in years using 30-day months so results align with the sheet's XIRR.

// Excel XIRR convention: values are paired with actual calendar dates.
//   XIRR solves  Σ CF_i / (1 + r)^((date_i - date_0) / 365) = 0
// We anchor date_0 = today, then step forward by whole calendar months
// (respecting 30/31-day months, leap years) — identical to how the Excel
// workbook lays out W14 = TODAY(), W15 = EDATE(W14,1), … for XIRR.

export type DatedFlow = { date: Date; t: number; cf: number };

/** Today at 00:00 local — stable anchor for a single render pass. */
function _startDate(): Date {
  const n = new Date();
  return new Date(n.getFullYear(), n.getMonth(), n.getDate());
}

/** date_0 + m calendar months (Excel EDATE). */
function _addMonths(d0: Date, m: number): Date {
  return new Date(d0.getFullYear(), d0.getMonth() + m, d0.getDate());
}

function _yearFrac(d0: Date, d: Date): number {
  return Math.round((d.getTime() - d0.getTime()) / 86400000) / 365;
}

export function schemeCashflows(scheme: Scheme, amt: number, freq: Frequency, d0: Date = _startDate(), customTailMonths?: number): DatedFlow[] {
  const flows: DatedFlow[] = [{ date: d0, t: 0, cf: -amt }];
  const sched = schemeSchedule(scheme, amt, freq, customTailMonths);
  for (const r of sched) {
    if (r.cashflow > 0) {
      const date = _addMonths(d0, r.month);
      flows.push({ date, t: _yearFrac(d0, date), cf: r.cashflow });
    }
  }
  return flows;
}

export function combinedCashflows(state: DealState, freq: Frequency, d0: Date = _startDate()): DatedFlow[] {
  const all = resolveLegs(state, freq).flatMap((l) =>
    schemeCashflows(l.scheme_, l.amountCr, l.freq, d0, l.customTailMonths),
  );
  const map = new Map<number, { date: Date; cf: number }>();
  for (const f of all) {
    const key = f.date.getTime();
    const prev = map.get(key);
    if (prev) prev.cf += f.cf;
    else map.set(key, { date: f.date, cf: f.cf });
  }
  return Array.from(map.entries())
    .sort(([x], [y]) => x - y)
    .map(([, v]) => ({ date: v.date, t: _yearFrac(d0, v.date), cf: v.cf }));
}

/**
 * Periodic monthly cashflow vector for the combined deal (all legs).
 * Index 0 = −(total principal outflow); index m (1..N) = interest + principal received in month m.
 */
export function combinedMonthlyCashflows(state: DealState, freq: Frequency): number[] {
  const scheds = legSchedules(state, freq);
  const n = scheds.reduce((m, s) => Math.max(m, s.rows.length), 0);
  const arr = new Array(n + 1).fill(0);
  arr[0] = -scheds.reduce((t, s) => t + s.leg.amountCr, 0);
  for (const s of scheds) for (const r of s.rows) arr[r.month] += r.cashflow;
  return arr;
}


/**
 * Classic IRR on equally-spaced periodic cashflows (Excel IRR).
 * Returns the per-period rate as a decimal. Newton–Raphson with bisection fallback.
 */
export function irrPeriodic(cf: number[], guess = 0.01): number {
  if (cf.length < 2) return NaN;
  if (!cf.some((v) => v > 0) || !cf.some((v) => v < 0)) return NaN;
  const f = (r: number) => cf.reduce((s, c, t) => s + c / Math.pow(1 + r, t), 0);
  const df = (r: number) => cf.reduce((s, c, t) => s - (t * c) / Math.pow(1 + r, t + 1), 0);
  let r = guess;
  for (let i = 0; i < 100; i++) {
    const v = f(r), dv = df(r);
    if (!isFinite(v) || !isFinite(dv) || Math.abs(dv) < 1e-14) break;
    const next = r - v / dv;
    if (!isFinite(next)) break;
    if (Math.abs(next - r) < 1e-10) return next;
    r = next <= -0.999999 ? -0.999999 : next;
  }
  // bisection fallback
  let lo = NaN, hi = NaN, vLo = NaN;
  let pR = -0.99, pV = f(pR);
  for (let x = -0.98; x <= 10; x += 0.01) {
    const cV = f(x);
    if (isFinite(pV) && isFinite(cV) && pV * cV < 0) { lo = pR; hi = x; vLo = pV; break; }
    pR = x; pV = cV;
  }
  if (!isFinite(lo)) return NaN;
  for (let i = 0; i < 200; i++) {
    const mid = (lo + hi) / 2, vM = f(mid);
    if (Math.abs(vM) < 1e-9 || hi - lo < 1e-12) return mid;
    if (vLo * vM < 0) hi = mid; else { lo = mid; vLo = vM; }
  }
  return (lo + hi) / 2;
}

/**
 * Annualised IRR for the combined deal at a given MSER repayment frequency.
 * Returns a percentage. IRR is computed on monthly cashflows, then annualised as
 * (1 + r_monthly)^12 − 1 — matches Excel's convention of annualising a periodic IRR.
 */
export function irrAnnualPct(state: DealState, freq: Frequency): number {
  const rm = irrPeriodic(combinedMonthlyCashflows(state, freq));
  if (!isFinite(rm)) return NaN;
  return (Math.pow(1 + rm, 12) - 1) * 100;
}


// ---------- XIRR (Excel-style: Newton-Raphson + bisection fallback) ----------
// Mirrors Excel's XIRR(values, dates, [guess]). Accepts dated flows and
// discounts each by (date - date_0)/365, matching Excel to the last basis point.

function npv(flows: { t: number; cf: number }[], r: number): number {
  return flows.reduce((s, f) => s + f.cf / Math.pow(1 + r, f.t), 0);
}
function dnpv(flows: { t: number; cf: number }[], r: number): number {
  return flows.reduce((s, f) => s - (f.t * f.cf) / Math.pow(1 + r, f.t + 1), 0);
}

/**
 * XIRR — mirrors Excel's XIRR(values, dates, [guess]).
 * Newton–Raphson from `guess` (default 0.1, same as Excel). If NR fails to
 * converge (flat derivative, diverges, or hits the −100 % wall) we bracket
 * a sign change and finish with bisection so a rate is always returned.
 * Returns the rate as a percentage.
 */
export function xirr(flows: { t: number; cf: number }[], guess = 0.1): number {
  if (flows.length < 2) return NaN;
  const hasPos = flows.some((f) => f.cf > 0);
  const hasNeg = flows.some((f) => f.cf < 0);
  if (!hasPos || !hasNeg) return NaN;

  // ---- Newton–Raphson (Excel's primary method) ----
  let r = guess;
  for (let i = 0; i < 100; i++) {
    const v = npv(flows, r);
    const dv = dnpv(flows, r);
    if (!isFinite(v) || !isFinite(dv) || Math.abs(dv) < 1e-14) break;
    const next = r - v / dv;
    if (!isFinite(next)) break;
    if (Math.abs(next - r) < 1e-10) return next * 100;
    r = next <= -0.999999 ? -0.999999 : next;
  }

  // ---- Bisection fallback: bracket a sign change of NPV(r) ----
  // Scan a wide grid of rates for adjacent samples of opposite sign.
  const grid: number[] = [];
  for (let x = -0.99; x <= 10; x += 0.01) grid.push(x);
  let lo = NaN, hi = NaN, vLo = NaN;
  let prevR = grid[0];
  let prevV = npv(flows, prevR);
  for (let i = 1; i < grid.length; i++) {
    const curR = grid[i];
    const curV = npv(flows, curR);
    if (isFinite(prevV) && isFinite(curV) && prevV * curV < 0) {
      lo = prevR; hi = curR; vLo = prevV; break;
    }
    prevR = curR; prevV = curV;
  }
  if (!isFinite(lo)) return NaN;

  for (let i = 0; i < 200; i++) {
    const mid = (lo + hi) / 2;
    const vMid = npv(flows, mid);
    if (Math.abs(vMid) < 1e-9 || (hi - lo) < 1e-12) return mid * 100;
    if (vLo * vMid < 0) { hi = mid; } else { lo = mid; vLo = vMid; }
  }
  return ((lo + hi) / 2) * 100;
}

// ---------- Negotiation ----------

export type BankCategory = "CB" | "RRB" | "SFB" | "UCB";

export function marginBps(cat: BankCategory): number {
  return cat === "SFB" || cat === "UCB" ? 100 : 45;
}
export function discretionMaxBps(cat: BankCategory): number {
  return cat === "SFB" || cat === "UCB" ? 35 : 15;
}

export interface FloorBuildup {
  cof: number;
  minMargin: number;
  standard: number;
  discretion: number;
  finalRate: number;
  cofFloor: number;
  belowCof: boolean;
}

/**
 * MSER floor build-up. Base = Treasury Cost of Funds (CoF).
 *   standard = CoF + minMargin
 *   final    = max(CoF, standard − discretion)
 * Benchmarks (Repo, G-Sec, T-Bill) are shown as market context only —
 * they are NOT the pricing base.
 */
export function mserFloor(state: DealState, category: BankCategory, cofPct: number): FloorBuildup {
  const minMargin = marginBps(category) / 100;
  const standard = cofPct + minMargin;
  const discretion = state.discretionBps / 100;
  const finalRate = Math.max(cofPct, standard - discretion);
  return {
    cof: cofPct,
    minMargin,
    standard,
    discretion,
    finalRate,
    cofFloor: cofPct,
    belowCof: standard - discretion < cofPct,
  };
}

// RMSE pricing is fixed by policy: RBI fund cost 3.50% + 75 bps margin = 4.25%.
// The 4.25% is a hard cap — nothing above that is allowed.
export const RMSE_FUND_COST = 3.5;
export const RMSE_MARGIN_BPS = 75;
export const RMSE_FIXED_RATE = 4.25;
export function rmseFinalRate(): number {
  return RMSE_FIXED_RATE;
}
