// -----------------------------------------------------------------------------
// Excel export — mirrors WAR_Sheet.xlsx structure with LIVE FORMULAS.
//
// Sheets produced:
//   1. Entry Sheet          — inputs + WAR / XIRR summary (formulas)
//   2. Qtly Princ Pmt.      — monthly amortisation schedule (formulas)
//   3. HY Princ Pmt         — monthly amortisation schedule (formulas)
//   4. Annual Pmt           — monthly amortisation schedule (formulas)
//   5. Bullet Princ. Pmt    — monthly amortisation schedule (formulas)
//   6. Working              — Effective RoI per frequency (formulas)
//   7. Floor Build-up       — negotiation math (formulas)
//   8. Market Info          — RBI live snapshot (values + source links)
//   9. Counterparty         — bank deposit ladder + past deals
//
// The amortisation formulas mirror the WAR sheet exactly:
//   Interest (monthly) = Opening × (Rate p.a. / 12) / 100
//   Principal paid     = instalment amount when month lands on a repayment
//                        step (Qtly=3, HY=6, Annual=12), else 0
//                        Bullet = full opening at maturity
//   RMSE               = monthly interest, principal at RMSE maturity month
// -----------------------------------------------------------------------------

import * as XLSX from "xlsx";
import {
  type DealState, type Frequency,
  schemeAmounts, mserFloor, rmseFinalRate,
} from "./pricing";
import type { BankProfile, MarketSnapshot } from "./pricing-data";

type Cell = XLSX.CellObject;

const num = (v: number): Cell => ({ t: "n", v });
const str = (v: string): Cell => ({ t: "s", v });
const bold = (v: string): Cell => ({ t: "s", v, s: { font: { bold: true } } });
const f = (formula: string): Cell => ({ t: "n", f: formula });
const fPct = (formula: string): Cell => ({ t: "n", f: formula, z: "0.0000" });

/** Freq -> step months (bullet handled specially). */
const stepFor: Record<Exclude<Frequency, "bullet" | "custom">, number> = {
  monthly: 1, quarterly: 3, halfyearly: 6, annual: 12,
};

function setCell(ws: XLSX.WorkSheet, addr: string, cell: Cell) {
  ws[addr] = cell;
}
function ensureRange(ws: XLSX.WorkSheet, lastCol: number, lastRow: number) {
  const range = { s: { c: 0, r: 0 }, e: { c: lastCol, r: lastRow } };
  ws["!ref"] = XLSX.utils.encode_range(range);
}
function col(i: number) { return XLSX.utils.encode_col(i); }

// -----------------------------------------------------------------------------
// Schedule sheet builder — one sheet per frequency (Qtly / HY / Annual / Bullet)
// Layout mirrors WAR "Qtly Princ Pmt." conceptually but simplified:
//
//   Row  B          C           D         E         F         G          H
//   3    Scheme     MSER
//   4    Loan Amt   ='Entry Sheet'!D7
//   5    Rate p.a   ='Entry Sheet'!G7
//   6    Rate mo    =C5/12
//   7    Tenure(m)  ='Entry Sheet'!F7
//   8    Step (m)   {1|3|6|12|tenure}
//   9    Instal amt =C4/(C7/C8)
//
//   Row 12 header:  Month | Opening | Interest | Principal | Closing | Cashflow | Date
//   Row 13..:       monthly rows with formulas
//   Bottom:         Total interest, XIRR, Effective ROI
//
//   Column I..N:    RMSE block (always monthly interest + bullet principal
//                   at RMSE tenure month)
// -----------------------------------------------------------------------------

function buildScheduleSheet(
  state: DealState,
  freq: Exclude<Frequency, "monthly" | "custom">, // Excel breakdown covers 4 named freqs
  entryDateSerial: number,
): XLSX.WorkSheet {
  const ws: XLSX.WorkSheet = {};
  const nMonths = Math.max(state.mser.tenureMonths, state.rmse.tenureMonths);

  // ---- Parameter block (rows 1-9) ----
  setCell(ws, "B1", bold("Amortisation Schedule"));
  setCell(ws, "C1", str(freq === "bullet" ? "Bullet"
                    : freq === "quarterly" ? "Quarterly"
                    : freq === "halfyearly" ? "Half-Yearly" : "Annual"));

  setCell(ws, "B3", bold("Scheme")); setCell(ws, "C3", bold("MSER")); setCell(ws, "I3", bold("RMSE"));

  setCell(ws, "B4", str("Loan Amt (₹ Cr)"));
  setCell(ws, "C4", f("'Entry Sheet'!D7"));
  setCell(ws, "I4", f("'Entry Sheet'!D9"));

  setCell(ws, "B5", str("Interest p.a. (%)"));
  setCell(ws, "C5", f("'Entry Sheet'!G7"));
  setCell(ws, "I5", f("'Entry Sheet'!G9"));

  setCell(ws, "B6", str("Interest per month"));
  setCell(ws, "C6", f("C5/12/100")); ws["C6"].z = "0.00%";
  setCell(ws, "I6", f("I5/12/100")); ws["I6"].z = "0.00%";

  setCell(ws, "B7", str("Tenure (months)"));
  setCell(ws, "C7", f("'Entry Sheet'!F7"));
  setCell(ws, "I7", f("'Entry Sheet'!F9"));

  setCell(ws, "B8", str("Repayment step (m)"));
  const step = freq === "bullet" ? "C7" : String(stepFor[freq]);
  setCell(ws, "C8", freq === "bullet" ? f("C7") : num(stepFor[freq]));
  setCell(ws, "I8", f("I7"));   // RMSE always bullet at maturity

  setCell(ws, "B9", str("Instalment (₹ Cr)"));
  setCell(ws, "C9", f("IFERROR(C4/(C7/C8),0)"));
  setCell(ws, "I9", f("I4"));   // whole principal at maturity

  setCell(ws, "B10", str("Moratorium (m)"));
  setCell(ws, "C10", f("'Entry Sheet'!H7"));
  setCell(ws, "I10", f("'Entry Sheet'!H9"));

  // ---- Header row 12 ----
  const headers = [
    "Month", "Opening (MSER)", "Interest (MSER)", "Principal (MSER)", "Closing (MSER)", "CF MSER",
    "", "Opening (RMSE)", "Interest (RMSE)", "Principal (RMSE)", "Closing (RMSE)", "CF RMSE",
    "Total Cashflow", "Date",
  ];
  headers.forEach((h, i) => setCell(ws, col(1 + i) + "12", bold(h)));

  // ---- Amortisation rows (13..) ----
  const dateStart = "B13"; // cell that holds entry date as serial
  setCell(ws, dateStart, { t: "n", v: entryDateSerial, z: "yyyy-mm-dd" });

  for (let m = 1; m <= nMonths; m++) {
    const r = 12 + m; // Excel row
    const prev = r - 1;
    // MSER: pay principal every step months (within tenure, after moratorium)
    //       last month cleans up any residual (matches WAR "IF month=tenure ... opening").
    const mserOpen = m === 1 ? "C4" : `E${prev}`;
    const mserInt  = m === 1 ? `${mserOpen}*$C$6` : `B${r-1}*0` /*unused, replaced*/;

    setCell(ws, `B${r}`, num(m));                                            // Month
    setCell(ws, `C${r}`, m === 1 ? f("C4") : f(`F${prev}`));                 // Opening MSER
    setCell(ws, `D${r}`, f(`IF(B${r}<=$C$7, C${r}*$C$6, 0)`));               // Interest MSER
    // Principal MSER
    if (freq === "bullet") {
      setCell(ws, `E${r}`, f(`IF(B${r}=$C$7, C${r}, 0)`));
    } else {
      setCell(ws, `E${r}`, f(
        `IF(B${r}>$C$10, ` +
        `IF(B${r}=$C$7, C${r}, ` +
        `IF(MOD(B${r}-$C$10, $C$8)=0, MIN($C$9, C${r}), 0)), 0)`
      ));
    }
    setCell(ws, `F${r}`, f(`C${r}-E${r}`));                                  // Closing MSER
    setCell(ws, `G${r}`, f(`D${r}+E${r}`));                                  // CF MSER

    // RMSE: monthly interest + bullet at RMSE tenure
    setCell(ws, `I${r}`, m === 1 ? f("I4") : f(`L${prev}`));                 // Opening RMSE
    setCell(ws, `J${r}`, f(`IF(B${r}<=$I$7, I${r}*$I$6, 0)`));               // Interest RMSE
    setCell(ws, `K${r}`, f(`IF(B${r}=$I$7, I${r}, 0)`));                     // Principal RMSE
    setCell(ws, `L${r}`, f(`I${r}-K${r}`));                                  // Closing RMSE
    setCell(ws, `M${r}`, f(`J${r}+K${r}`));                                  // CF RMSE

    setCell(ws, `N${r}`, f(`G${r}+M${r}`));                                  // Combined cashflow
    // Date column O — first entry = entryDateSerial, then +30 each row
    if (m === 1) setCell(ws, `O${r}`, { t: "n", v: entryDateSerial, z: "yyyy-mm-dd" });
    else         setCell(ws, `O${r}`, { t: "n", f: `O${r-1}+30`, z: "yyyy-mm-dd" });
    // silence the placeholder we set for B13
    void mserInt; void mserOpen; void dateStart;
  }
  const lastRow = 12 + nMonths;

  // ---- Totals / KPIs ----
  const totRow = lastRow + 2;
  setCell(ws, `B${totRow}`, bold("Total Interest (MSER)"));
  setCell(ws, `C${totRow}`, f(`SUM(D13:D${lastRow})`));
  setCell(ws, `B${totRow+1}`, bold("Total Interest (RMSE)"));
  setCell(ws, `C${totRow+1}`, f(`SUM(J13:J${lastRow})`));
  setCell(ws, `B${totRow+2}`, bold("Total Interest"));
  setCell(ws, `C${totRow+2}`, f(`C${totRow}+C${totRow+1}`));

  setCell(ws, `B${totRow+4}`, bold("Effective ROI %"));
  // Wtd tenure denominator: C4*C7/12 + I4*I7/12
  setCell(ws, `C${totRow+4}`, fPct(`C${totRow+2}/(C4*C7/12 + I4*I7/12)*100`));

  setCell(ws, `B${totRow+5}`, bold("XIRR (Combined)"));
  // Build a cashflow column at Q: initial = -(C4+I4) on entry date; then combined per-month
  // Use existing dates in column O and cashflows in column N; prepend -(principal).
  // Simpler approach: dedicated Q column.
  setCell(ws, `P12`, bold("Date"));
  setCell(ws, `Q12`, bold("Cashflow"));
  setCell(ws, `P13`, { t: "n", v: entryDateSerial, z: "yyyy-mm-dd" });
  setCell(ws, `Q13`, f("-(C4+I4)"));
  for (let m = 1; m <= nMonths; m++) {
    const r = 13 + m;
    setCell(ws, `P${r}`, { t: "n", f: `P${r-1}+30`, z: "yyyy-mm-dd" });
    setCell(ws, `Q${r}`, f(`N${12+m}`));
  }
  setCell(ws, `C${totRow+5}`,
    fPct(`XIRR(Q13:Q${13+nMonths}, P13:P${13+nMonths})*100`));

  // Column widths
  ws["!cols"] = [
    { wch: 3 }, { wch: 20 }, { wch: 14 }, { wch: 14 }, { wch: 14 },
    { wch: 14 }, { wch: 14 }, { wch: 2 }, { wch: 14 }, { wch: 14 },
    { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 14 }, { wch: 14 },
    { wch: 3 }, { wch: 14 }, { wch: 14 },
  ];

  ensureRange(ws, 17, totRow + 6);
  return ws;
}

// -----------------------------------------------------------------------------
// Main entry
// -----------------------------------------------------------------------------

export function exportDealToExcel(
  state: DealState,
  bank: BankProfile,
  cofPct: number,
  cofLabel: string,
  market: MarketSnapshot | null = null,
) {
  const { mserAmt, rmseAmt } = schemeAmounts(state);
  const wb = XLSX.utils.book_new();

  // Excel serial for TODAY
  const today = new Date();
  const excelEpoch = new Date(Date.UTC(1899, 11, 30));
  const entryDateSerial = Math.floor((today.getTime() - excelEpoch.getTime()) / 86400000);

  // ============================================================
  // 1. Entry Sheet
  // ============================================================
  const entry: XLSX.WorkSheet = {};
  setCell(entry, "B1", bold("SIDBI Refinance — Effective Interest Rate Sheet"));
  setCell(entry, "J1", { t: "n", v: entryDateSerial, z: "yyyy-mm-dd" });

  setCell(entry, "B3", str("Counterparty"));   setCell(entry, "C3", str(bank.name));
  setCell(entry, "D3", str("Category"));        setCell(entry, "E3", str(bank.categoryLabel));
  setCell(entry, "B4", str("Principal (₹ Cr)"));setCell(entry, "C4", num(state.principalCr));
  setCell(entry, "D4", str("MSER Share %"));    setCell(entry, "E4", num(state.mserSharePct));

  // Scheme table (row 6 header, rows 7-9 data)
  const hdrs = ["Type", "Amt (₹ Cr)", "Proportion", "Tenure (m)", "Interest p.a. (%)", "Moratorium (m)", "Repmt. Freq."];
  hdrs.forEach((h, i) => setCell(entry, col(2 + i) + "6", bold(h)));

  // MSER row 7
  setCell(entry, "C7", str("MSER"));
  setCell(entry, "D7", f("C4*E4/100"));
  setCell(entry, "E7", f("D7/C4")); entry["E7"].z = "0.00%";
  setCell(entry, "F7", num(state.mser.tenureMonths));
  setCell(entry, "G7", num(state.mser.ratePct));
  setCell(entry, "H7", num(state.mser.moratoriumMonths));
  setCell(entry, "I7", str(state.repaymentFreq));

  // MSER Floating (unused but present for parity)
  setCell(entry, "C8", str("MSER Floating"));
  setCell(entry, "D8", num(0));
  setCell(entry, "E8", f("D8/C4")); entry["E8"].z = "0.00%";
  setCell(entry, "F8", num(0));
  setCell(entry, "G8", num(0));
  setCell(entry, "H8", num(0));
  setCell(entry, "I8", str("—"));

  // RMSE row 9
  setCell(entry, "C9", str("RMSE"));
  setCell(entry, "D9", f("C4-D7-D8"));
  setCell(entry, "E9", f("D9/C4")); entry["E9"].z = "0.00%";
  setCell(entry, "F9", num(state.rmse.tenureMonths));
  setCell(entry, "G9", num(state.rmse.ratePct));
  setCell(entry, "H9", num(state.rmse.moratoriumMonths));
  setCell(entry, "I9", str("Bullet"));

  // WAR / XIRR summary
  setCell(entry, "B12", bold("Weighted Avg Rate (WAR) & XIRR by MSER Repayment Frequency"));
  setCell(entry, "B13", bold("Frequency"));
  setCell(entry, "C13", bold("WAR %"));
  setCell(entry, "D13", bold("XIRR %"));

  const freqRows: [string, string][] = [
    ["Quarterly", "Qtly Princ Pmt."],
    ["Half-Yearly", "HY Princ Pmt"],
    ["Annual", "Annual Pmt"],
    ["Bullet", "Bullet Princ. Pmt"],
  ];
  freqRows.forEach(([label, sheet], i) => {
    const r = 14 + i;
    setCell(entry, `B${r}`, str(label));
    // Pull "Effective ROI" and "XIRR" from each schedule sheet.
    // Placement in schedule sheet: Effective ROI in C{totRow+4}, XIRR in C{totRow+5}.
    // totRow = 12 + nMonths + 2 = nMonths + 14. So Effective ROI is at row (nMonths+18)
    // and XIRR at (nMonths+19). We recompute per sheet below when we know nMonths.
    const nMonths = Math.max(state.mser.tenureMonths, state.rmse.tenureMonths);
    const effRow = nMonths + 14 + 4;
    const xirrRow = nMonths + 14 + 5;
    setCell(entry, `C${r}`, fPct(`'${sheet}'!C${effRow}`));
    setCell(entry, `D${r}`, fPct(`'${sheet}'!C${xirrRow}`));
  });

  // Wtd Avg Cost of Funds block
  setCell(entry, "B20", bold("Weighted Avg Cost of Funds (WACOF)"));
  setCell(entry, "B21", str("MSER interest (rate × tenure)"));
  setCell(entry, "C21", f("D7*G7/100*F7/12"));
  setCell(entry, "B22", str("RMSE interest (rate × tenure)"));
  setCell(entry, "C22", f("D9*G9/100*F9/12"));
  setCell(entry, "B23", str("Total interest"));
  setCell(entry, "C23", f("C21+C22"));
  setCell(entry, "B24", str("Wtd tenure denominator"));
  setCell(entry, "C24", f("D7*F7/12 + D9*F9/12"));
  setCell(entry, "B25", bold("WACOF %"));
  setCell(entry, "C25", fPct("C23/C24*100"));

  entry["!cols"] = [
    { wch: 3 }, { wch: 26 }, { wch: 16 }, { wch: 14 }, { wch: 14 },
    { wch: 14 }, { wch: 16 }, { wch: 14 }, { wch: 16 }, { wch: 14 },
  ];
  ensureRange(entry, 9, 26);
  XLSX.utils.book_append_sheet(wb, entry, "Entry Sheet");

  // ============================================================
  // 2-5. Amortisation schedule sheets (one per named frequency)
  // ============================================================
  XLSX.utils.book_append_sheet(wb, buildScheduleSheet(state, "quarterly",  entryDateSerial), "Qtly Princ Pmt.");
  XLSX.utils.book_append_sheet(wb, buildScheduleSheet(state, "halfyearly", entryDateSerial), "HY Princ Pmt");
  XLSX.utils.book_append_sheet(wb, buildScheduleSheet(state, "annual",     entryDateSerial), "Annual Pmt");
  XLSX.utils.book_append_sheet(wb, buildScheduleSheet(state, "bullet",     entryDateSerial), "Bullet Princ. Pmt");

  // ============================================================
  // 6. Working sheet — Effective RoI table across frequencies
  // ============================================================
  const working: XLSX.WorkSheet = {};
  setCell(working, "B1", bold("Effective RoI — cross-frequency"));
  setCell(working, "B3", bold("Frequency"));
  setCell(working, "C3", bold("MSER Interest"));
  setCell(working, "D3", bold("RMSE Interest"));
  setCell(working, "E3", bold("Total Interest"));
  setCell(working, "F3", bold("Effective RoI %"));
  freqRows.forEach(([label, sheet], i) => {
    const r = 4 + i;
    setCell(working, `B${r}`, str(label));
    const nMonths = Math.max(state.mser.tenureMonths, state.rmse.tenureMonths);
    const totRow = nMonths + 14;
    setCell(working, `C${r}`, f(`'${sheet}'!C${totRow}`));
    setCell(working, `D${r}`, f(`'${sheet}'!C${totRow+1}`));
    setCell(working, `E${r}`, f(`'${sheet}'!C${totRow+2}`));
    setCell(working, `F${r}`, fPct(`'${sheet}'!C${totRow+4}`));
  });
  working["!cols"] = [{wch:3},{wch:16},{wch:14},{wch:14},{wch:14},{wch:16}];
  ensureRange(working, 6, 8);
  XLSX.utils.book_append_sheet(wb, working, "Working");

  // ============================================================
  // 7. Floor Build-up — negotiation math
  // ============================================================
  const fb = mserFloor(state, bank.category, cofPct);
  const isSFB = bank.category === "SFB" || bank.category === "UCB";
  const minMarginBpsVal = isSFB ? 100 : 45;
  const maxDiscretionBpsVal = isSFB ? 35 : 15;

  const floorSheet: XLSX.WorkSheet = {};
  setCell(floorSheet, "B1", bold(`MSER Floor Build-up — ${bank.categoryLabel}`));
  setCell(floorSheet, "B3", str("Treasury Cost of Funds")); setCell(floorSheet, "C3", str(cofLabel));               setCell(floorSheet, "D3", num(fb.cof));
  setCell(floorSheet, "B4", str("+ Min Margin (bps)"));        setCell(floorSheet, "C4", num(minMarginBpsVal));            setCell(floorSheet, "D4", f("C4/100"));
  setCell(floorSheet, "B5", bold("= Standard Rate"));          setCell(floorSheet, "D5", f("D3+D4"));
  setCell(floorSheet, "B6", str("- Discretion (bps)"));        setCell(floorSheet, "C6", num(state.discretionBps));        setCell(floorSheet, "D6", f("C6/100"));
  setCell(floorSheet, "B7", str("Max discretion allowed (bps)"));setCell(floorSheet, "C7", num(maxDiscretionBpsVal));
  setCell(floorSheet, "B8", bold("= Final MSER Rate"));        setCell(floorSheet, "D8", f("MAX(D9, D5-D6)"));
  setCell(floorSheet, "B9", str("Treasury Cost of Funds (floor)")); setCell(floorSheet, "C9", str(cofLabel));              setCell(floorSheet, "D9", num(fb.cofFloor));
  setCell(floorSheet, "B10", str("Below CoF?"));               setCell(floorSheet, "D10", f(`IF(D5-D6<D9, "YES — requires ALCO", "No")`));
  setCell(floorSheet, "B12", bold("RMSE RBI Fund Cost"));       setCell(floorSheet, "D12", num(3.50));
  setCell(floorSheet, "B13", str("+ Margin (bps)"));            setCell(floorSheet, "C13", num(75));                        setCell(floorSheet, "D13", f("C13/100"));
  setCell(floorSheet, "B14", bold("Final RMSE Rate (fixed cap)")); setCell(floorSheet, "D14", f("D12+D13"));
  // silence unused fb.finalRate ref
  void fb.finalRate; void rmseFinalRate;
  floorSheet["!cols"] = [{wch:3},{wch:32},{wch:16},{wch:14}];
  ensureRange(floorSheet, 3, 15);
  XLSX.utils.book_append_sheet(wb, floorSheet, "Floor Build-up");

  // ============================================================
  // 8. Market Info — RBI live snapshot
  // ============================================================
  const mkt: (string | number | null)[][] = [
    ["Market Information — Live Snapshot"],
    ["Fetched", market?.fetchedAt ?? "—"],
    [],
    ["Rate", "Value %", "Source"],
    ["Policy Repo Rate",       market?.repo.value ?? "—",        market?.repo.source ?? "—"],
    ["Reverse Repo Rate",      market?.reverseRepo.value ?? "—", market?.reverseRepo.source ?? "—"],
    ["Standing Deposit Facility (SDF)", market?.sdf.value ?? "—", market?.sdf.source ?? "—"],
    ["Marginal Standing Facility (MSF)",market?.msf.value ?? "—", market?.msf.source ?? "—"],
    ["Bank Rate",              market?.bankRate.value ?? "—",    market?.bankRate.source ?? "—"],
    ["10Y G-Sec Yield",        market?.gsec10.value ?? "—",      market?.gsec10.source ?? "Feed pending (CCIL)"],
    ["T-Bill 3M",              market?.tbill3m.value ?? "—",     market?.tbill3m.source ?? "Feed pending (RBI WSS)"],
    ["Certificate of Deposit 1Y", market?.cd1y.value ?? "—",     market?.cd1y.source ?? "Feed pending (FBIL)"],
    ["Commercial Paper 1Y",       market?.cp1y.value ?? "—",     market?.cp1y.source ?? "Feed pending (FBIL)"],
    [],
    ["Sources:"],
    ["• RBI policy rates:  https://rbi.org.in"],
    ["• G-Sec / T-Bill:    https://www.ccilindia.com  (JS-only; needs headless feed)"],
    ["• CD / CP:           https://www.fbil.org.in    (JS-only; needs headless feed)"],
  ];
  const mktSheet = XLSX.utils.aoa_to_sheet(mkt);
  mktSheet["!cols"] = [{wch:34},{wch:14},{wch:60}];
  XLSX.utils.book_append_sheet(wb, mktSheet, "Market Info");

  // ============================================================
  // 9. Counterparty — deposits + past deals
  // ============================================================
  const cp: (string | number | null)[][] = [
    [`${bank.name} — Counterparty Snapshot`],
    ["Category", bank.categoryLabel],
    ["Relationship", bank.relationship],
    ["Official rate card", bank.bulkRateSourceUrl],
    [],
    ["Bulk Deposit Rates (≥ ₹2 Cr)"],
    ["Tenor", "Callable %", "Non-Callable %"],
  ];
  if (bank.deposits.length === 0) {
    cp.push(["— rate card not connected —", null, null]);
    cp.push([`See: ${bank.bulkRateSourceUrl}`, null, null]);
  } else {
    for (const d of bank.deposits) cp.push([d.tenor, d.callable ?? "—", d.nonCallable ?? "—"]);
  }
  cp.push([]);
  cp.push([`Past Negotiations with ${bank.name}`]);
  cp.push(["Date","Status","Principal (₹ Cr)","MSER (Cr)","RMSE (Cr)","MSER Tenure (m)","RMSE Tenure (m)","MSER Freq","CoF Structure","CoF %","Margin %","Discretion (bps)","MSER Rate %","RMSE Rate %","XIRR %","WAR %","Ext. Rating","Note"]);
  for (const d of bank.pastDeals) {
    cp.push([d.date, d.status, d.principalCr, d.mserCr, d.rmseCr, d.mserTenureMonths, d.rmseTenureMonths, d.mserFreq, d.cofStructure, d.cofPct, d.marginPct, d.discretionBps ?? "—", d.proposedRatePct, d.rmseRatePct, d.xirrPct ?? "—", d.warPct, d.externalRating ?? "", d.note ?? ""]);
  }
  cp.push([]);
  cp.push([`Negotiation rules (${bank.categoryLabel}):`]);
  cp.push([`• Minimum margin above benchmark: ${minMarginBpsVal} bps`]);
  cp.push([`• Discretion cap (Sub-Committee of ALCO): ${maxDiscretionBpsVal} bps`]);
  cp.push([`• Final rate cannot go below Treasury Cost of Funds without ALCO approval.`]);
  const cpSheet = XLSX.utils.aoa_to_sheet(cp);
  cpSheet["!cols"] = [{wch:22},{wch:14},{wch:18},{wch:12},{wch:10},{wch:12},{wch:12},{wch:14}];
  XLSX.utils.book_append_sheet(wb, cpSheet, "Counterparty");

  // ============================================================
  // Write file
  // ============================================================
  const fname = `SIDBI_Pricing_${bank.id}_${new Date().toISOString().slice(0,10)}.xlsx`;
  // cellStyles required for bold rendering
  XLSX.writeFile(wb, fname, { cellStyles: true });

  // silence unused imports
  void mserAmt; void rmseAmt;
}
