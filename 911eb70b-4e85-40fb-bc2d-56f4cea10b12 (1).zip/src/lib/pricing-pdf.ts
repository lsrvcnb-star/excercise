// Counterparty term-sheet PDF — simple, clean, tabular.
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import {
  resolveLegs,
  effectiveRateForFreq,
  effectiveRateWindow,
  combinedCashflows,
  schemeTotalInterest,
  xirr,
  irrAnnualPct,
  FREQUENCIES,
  type DealState,
  type Frequency,
} from "./pricing";
import type { BankProfile } from "./pricing-data";

const NAVY: [number, number, number] = [16, 42, 78];
const LIGHT: [number, number, number] = [239, 243, 248];

function freqLabel(f: Frequency): string {
  return FREQUENCIES.find((x) => x.key === f)?.label ?? f;
}

export interface PdfOpts {
  /** True when the MSER rate is linked to a floating benchmark. */
  floating?: boolean;
  /** Benchmark name, e.g. "3M T-Bill". */
  benchmarkName?: string;
  /** Current benchmark level (%) — used to express MSER rate as benchmark + spread. */
  benchmarkPct?: number;
  /** Spread over the benchmark, in bps (Treasury CoF spread). */
  spreadBps?: number;
  /** Tranche id selected for the base RMSE leg. */
  baseTrancheId?: string;
}

const TRANCHE_STORE_KEY = "sidbi.rmse.tranches.v4";

type StoredTranche = { id: string; label: string; date: string };

function trancheList(): StoredTranche[] {
  try {
    const raw = window.localStorage.getItem(TRANCHE_STORE_KEY);
    return raw ? (JSON.parse(raw) as StoredTranche[]) : [];
  } catch {
    return [];
  }
}

function fmtDate(iso?: string): string | null {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
}


export function exportDealToPdf(state: DealState, bank: BankProfile, opts: PdfOpts = {}) {
  const freq = state.repaymentFreq;
  const legs = resolveLegs(state, freq);
  const principal = state.principalCr || legs.reduce((t, l) => t + l.amountCr, 0);

  const eff = effectiveRateForFreq(state, freq);
  const war12 = effectiveRateWindow(state, freq, 12).effective;
  const xirrPct = xirr(combinedCashflows(state, freq));
  const irrPct = irrAnnualPct(state, freq);

  const interestOf = (l: (typeof legs)[number]) =>
    schemeTotalInterest(l.scheme_, l.amountCr, l.freq, l.customTailMonths);
  const totalInterest = legs.reduce((t, l) => t + interestOf(l), 0);

  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const M = 40;

  // ---- Header
  doc.setFillColor(...NAVY);
  doc.rect(0, 0, W, 62, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold").setFontSize(14);
  doc.text("SIDBI Refinance — Indicative Terms", M, 27);
  doc.setFont("helvetica", "normal").setFontSize(9);
  doc.text(
    `Generated ${new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}`,
    M,
    44,
  );

  doc.setTextColor(0, 0, 0);
  let y = 86;
  doc.setFont("helvetica", "bold").setFontSize(12);
  doc.text(bank.name, M, y);
  y += 20;
  doc.setFont("helvetica", "normal").setFontSize(9.5);
  const intro = doc.splitTextToSize(
    "The indicative terms for refinance are as under subject to approval by SIDBI sanctioning committee:",
    W - 2 * M,
  );
  doc.text(intro, M, y);
  y += intro.length * 13 + 8;

  // Maturity date per RMSE leg — base leg uses the selected tranche, splits their own.
  const tranches = trancheList();
  const rmseSplitTrancheIds = (state.splits ?? [])
    .filter((sp) => sp.scheme === "rmse")
    .map((sp) => sp.trancheId);
  let rmseSeen = -1;
  const maturityForLeg = (): string | null => {
    rmseSeen += 1;
    const id = rmseSeen === 0 ? opts.baseTrancheId : rmseSplitTrancheIds[rmseSeen - 1];
    const t = tranches.find((x) => x.id === id) ?? tranches[0];
    return fmtDate(t?.date);
  };
  const rmseMaturities: (string | null)[] = [];

  // MSER rate shown as "3M T-Bill + xx bps" when the CoF is linked to a benchmark.
  const rateCell = (scheme: "mser" | "rmse", ratePct: number) => {
    if (scheme === "mser" && opts.floating && opts.benchmarkName && opts.benchmarkPct !== undefined) {
      const spread = Math.round((ratePct - opts.benchmarkPct) * 100);
      return `${opts.benchmarkName} + ${spread} bps\n(${ratePct.toFixed(2)})`;
    }
    return ratePct.toFixed(2);
  };



  // ---- Deal composition
  autoTable(doc, {
    startY: y,
    head: [[
      "Scheme",
      "Amount\n(Rs Cr)",
      "Split\n%",
      "Rate of interest\n(% p.a.)",
      "Tenure\n(months)",
      "Moratorium\n(months)",
      "Principal repayment",
      "Interest amount\n(Rs Cr)",
    ]],

    body: legs.map((l) => {
      let tenure = String(l.scheme_.tenureMonths);
      if (l.scheme === "rmse") {
        const mat = maturityForLeg();
        rmseMaturities.push(mat);
        tenure = `${l.scheme_.tenureMonths} (approx.)`;
      }
      return [
        l.label.replace(/·/g, "-"),
        l.amountCr.toFixed(2),
        principal > 0 ? `${((l.amountCr / principal) * 100).toFixed(1)}%` : "-",
        rateCell(l.scheme, l.scheme_.ratePct),
        tenure,
        String(l.scheme_.moratoriumMonths),
        freqLabel(l.freq),
        interestOf(l).toFixed(2),
      ];
    }),

    foot: [[
      "Total",
      principal.toFixed(2),
      "100.0%",
      "", "", "", "",
      totalInterest.toFixed(2),
    ]],
    theme: "grid",
    styles: { font: "helvetica", fontSize: 8, cellPadding: 5, textColor: [20, 20, 20], lineColor: [210, 216, 224] },
    headStyles: { fillColor: NAVY, textColor: 255, fontStyle: "bold", fontSize: 8 },
    footStyles: { fillColor: LIGHT, textColor: [20, 20, 20], fontStyle: "bold", halign: "left" },
    didParseCell: (data) => {
      if (data.section === "foot") data.cell.styles.halign = "left";
    },
    columnStyles: {
      1: { halign: "right" }, 2: { halign: "right" }, 3: { halign: "right" },
      4: { halign: "right" }, 5: { halign: "right" }, 7: { halign: "right" },
    },
    margin: { left: M, right: M },

  });

  // @ts-expect-error autotable augments doc at runtime
  y = (doc.lastAutoTable?.finalY ?? y) + 16;

  // ---- Notes
  const notes: string[] = [];
  const uniqueMaturities = Array.from(new Set(rmseMaturities.filter((m): m is string => !!m)));
  if (uniqueMaturities.length > 0) {
    notes.push(
      `RMSE tenure is approximate and the facility is repayable on ${uniqueMaturities.join(" / ")} (the maturity date of the tranche chosen for this deal).`,
    );
  }
  const mserLeg = legs.find((l) => l.scheme === "mser");
  if (opts.floating && opts.benchmarkName && mserLeg) {
    const sp = opts.benchmarkPct !== undefined
      ? Math.round((mserLeg.scheme_.ratePct - opts.benchmarkPct) * 100)
      : (opts.spreadBps ?? 0);
    notes.push(
      `MSER: The interest rate (only benchmark) is subject to reset every quarter from the date of disbursement, while the spread of ${sp} bps over ${opts.benchmarkName} will remain unchanged.`,
    );
  }


  doc.setFont("helvetica", "normal").setFontSize(8.5);
  notes.forEach((n) => {
    const lines = doc.splitTextToSize(`- ${n}`, W - 2 * M);
    doc.text(lines, M, y);
    y += lines.length * 11 + 4;
  });
  y += 14;

  // ---- Pricing outcome
  doc.setFont("helvetica", "bold").setFontSize(10);
  doc.text("Pricing outcome", M, y);
  y += 10;
  autoTable(doc, {
    startY: y,
    head: [["Metric", "Value"]],
    body: [
      ["WAR", `${eff.effective.toFixed(2)}%`],
      ["WAR (12 month)", `${war12.toFixed(2)}%`],
      ["XIRR", `${Number.isFinite(xirrPct) ? xirrPct.toFixed(2) : "-"}%`],
      ["IRR", `${Number.isFinite(irrPct) ? irrPct.toFixed(2) : "-"}%`],
    ],
    theme: "grid",
    styles: { font: "helvetica", fontSize: 9, cellPadding: 6, lineColor: [210, 216, 224] },
    headStyles: { fillColor: NAVY, textColor: 255, fontStyle: "bold", fontSize: 8 },
    columnStyles: { 0: { cellWidth: 260 }, 1: { halign: "right", fontStyle: "bold" } },
    margin: { left: M, right: M },
    tableWidth: 380,
  });


  const safe = bank.name.replace(/[^a-z0-9]+/gi, "_");
  doc.save(`SIDBI_TermSheet_${safe}.pdf`);
}
