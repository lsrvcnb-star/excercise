import { createFileRoute } from "@tanstack/react-router";

// -----------------------------------------------------------------------------
// /api/public/counterparty?bank=<id>&symbol=<NSE_SYMBOL>
//
// Live counterparty data pulled from official / exchange sources:
//   • Bond issuances  — NSE corporate-announcements API, filtered for
//                       bond / debenture / tier / NCD / MTN keywords.
//   • Bulk deposits   — bank-specific scrapers. SBI is currently supported
//                       (sbi.co.in domestic bulk term deposit page).
//
// Everything is best-effort: when a source cannot be parsed, the field
// returns `null` with a note so the UI can show a graceful empty state
// and a link to the official source instead of a fabricated number.
// -----------------------------------------------------------------------------

interface DepositRow { tenor: string; callable: number | null; nonCallable: number | null; nonCallableMin?: number | null; nonCallableMax?: number | null; amountBucket?: "3-5" | "5+" | null; }
interface Announcement {
  date: string;
  desc: string;
  amount: string | null;      // e.g. "₹5,000 Cr"
  tenure: string | null;      // e.g. "10Y"
  coupon: string | null;      // e.g. "7.55%"
  securityType: string | null;// e.g. "Tier II NCD"
  market: "Domestic" | "Offshore" | null;
  status: string | null;      // e.g. "Issued / Active", "Approval Expected"
  attachmentUrl: string | null;
  /** Credit rating of this specific bond issue (may differ from issuer rating —
   *  AT-1 / perpetuals typically rated 1-2 notches below senior). */
  rating?: string | null;
}
interface Payload {
  fetchedAt: string;
  bankId: string;
  bankRating: string | null;
  deposits: { rows: DepositRow[] | null; sourceUrl: string | null; asOf: string | null; note: string | null; illustrative?: boolean; hasAmountBuckets?: boolean };
  announcements: { rows: Announcement[]; sourceUrl: string | null; note: string | null; illustrative?: boolean };
}

const UA = "Mozilla/5.0 (compatible; SIDBIPricingDashboard/1.0)";

// per-Worker-instance cache — 15 min
const cache = new Map<string, { at: number; data: Payload }>();
const TTL_MS = 15 * 60 * 1000;

// -----------------------------------------------------------------------------
// SBI Bulk Deposit scraper
// -----------------------------------------------------------------------------
const SBI_BULK_URL = "https://sbi.co.in/web/interest-rates/deposit-rates/domestic-bulk-term-deposits";

async function scrapeSbiBulk(): Promise<Payload["deposits"]> {
  try {
    const res = await fetch(SBI_BULK_URL, {
      headers: { "User-Agent": UA, Accept: "text/html" },
      signal: AbortSignal.timeout(15_000),
    });
    if (!res.ok) return { rows: null, sourceUrl: SBI_BULK_URL, asOf: null, note: `SBI page HTTP ${res.status}` };
    const html = await res.text();

    // Extract "w.e.f. DD/MM/YYYY" from header
    const wefMatch = html.match(/w\.e\.f\.?\s*([0-9]{2}\/[0-9]{2}\/[0-9]{4})/i);
    const asOf = wefMatch ? wefMatch[1] : null;

    const tableMatch = html.match(/<table[\s\S]*?<\/table>/i);
    if (!tableMatch) return { rows: null, sourceUrl: SBI_BULK_URL, asOf, note: "Rate table not found on SBI page" };
    const tableHtml = tableMatch[0];

    // Extract rows as flat text
    const rowRe = /<tr[\s\S]*?<\/tr>/gi;
    const rows = tableHtml.match(rowRe) ?? [];
    const parsedRows: DepositRow[] = [];
    // We use the "Revised Rates for Public" column (2nd numeric column in each row)
    for (const r of rows) {
      const cells = [...r.matchAll(/<t[dh][\s\S]*?<\/t[dh]>/gi)].map((m) =>
        m[0].replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim(),
      );
      if (cells.length < 3) continue;
      const tenor = cells[0];
      // Skip header row
      if (/tenor/i.test(tenor)) continue;
      // Pick the "Revised Rates for Public" column — 2nd numeric cell
      const numerics = cells.slice(1).map((c) => {
        const n = c.match(/^[0-9]+(\.[0-9]+)?$/);
        return n ? parseFloat(c) : null;
      });
      const revisedPublic = numerics[1] ?? numerics[0] ?? null;
      if (revisedPublic === null || !tenor) continue;
      // SBI's bulk page publishes callable rates on this URL.
      parsedRows.push({ tenor, callable: revisedPublic, nonCallable: null });
    }
    if (parsedRows.length === 0) {
      return { rows: null, sourceUrl: SBI_BULK_URL, asOf, note: "Could not parse rate rows" };
    }
    return { rows: parsedRows, sourceUrl: SBI_BULK_URL, asOf, note: null };
  } catch (e) {
    return { rows: null, sourceUrl: SBI_BULK_URL, asOf: null, note: `SBI fetch failed: ${(e as Error).message}` };
  }
}

// -----------------------------------------------------------------------------
// HDFC Bank Bulk Deposit scraper
//   Pulls the two rate tables (>=3 Cr <5 Cr, and >=5 Cr) inline on
//   the HDFC FD interest-rate page and returns them tagged with amountBucket.
//   Only 1-year-and-above tenors are surfaced; senior-citizen columns are dropped.
// -----------------------------------------------------------------------------
const HDFC_URL = "https://www.hdfc.bank.in/interest-rates";

function decodeHtmlText(value: string): string {
  return value
    .replace(/&nbsp;/g, " ")
    .replace(/&#160;/g, " ")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&#34;|&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'");
}

function parseHdfcTable(tableHtml: string): Array<{ tenor: string; rates: number[] }> {
  const out: Array<{ tenor: string; rates: number[] }> = [];
  const rowRe = /<tr[\s\S]*?<\/tr>/gi;
  const rows = tableHtml.match(rowRe) ?? [];
  for (const r of rows) {
    const cells = [...r.matchAll(/<t[dh][\s\S]*?<\/t[dh]>/gi)].map((m) =>
      decodeHtmlText(m[0].replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim(),
    );
    if (cells.length < 2) continue;
    const tenor = cells[0];
    if (!tenor || (/tenor|tenure|period|crore/i.test(tenor) && !/\d/.test(tenor))) continue;
    const rates: number[] = [];
    for (const c of cells.slice(1)) {
      const m = c.match(/([0-9]+\.[0-9]+)\s*%/);
      if (m) rates.push(parseFloat(m[1]));
    }
    if (rates.length === 0) continue;
    // Drop obvious non-rate cells (e.g. 4.25% premature-withdrawal floor).
    const filtered = rates.filter((v) => v >= 5);
    if (filtered.length === 0) continue;
    out.push({ tenor, rates: filtered });
  }
  return out;
}

function isOneYearPlus(tenor: string): boolean {
  const t = tenor.toLowerCase();
  if (/<\s*1\s*year|less\s+than\s+1\s*year/.test(t)) return false;
  if (/\bday|\bdays\b/.test(t) && !/year|yr/.test(t)) return false;
  const monthMatches = [...t.matchAll(/(\d+(?:\.\d+)?)\s*months?/g)].map((m) => Number(m[1]));
  if (monthMatches.length > 0 && !/year|yr/.test(t)) return monthMatches.some((m) => m >= 12);
  return /\byear|\byr\b|\byrs\b/.test(t);
}

function parseHdfcAsOf(...chunks: Array<string | null>): string | null {
  for (const chunk of chunks) {
    if (!chunk) continue;
    const txt = decodeHtmlText(chunk.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ");
    const match = txt.match(/applicable\s+(?:from|for)\s+([0-9]{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]+,?\s+[0-9]{4})/i);
    if (match) return match[1];
  }
  return null;
}

async function scrapeHdfcBulk(): Promise<Payload["deposits"]> {
  try {
    const res = await fetch(HDFC_URL, {
      headers: { "User-Agent": UA, Accept: "text/html" },
      signal: AbortSignal.timeout(15_000),
    });
    if (!res.ok) return { rows: null, sourceUrl: HDFC_URL, asOf: null, note: `HDFC page HTTP ${res.status}` };
    const html = await res.text();
    const tables = html.match(/<table[\s\S]*?<\/table>/gi) ?? [];

    // Locate table #1 (>=3 Cr to <5 Cr) and table #2 (>=5 Cr withdrawable) by header text.
    let t35: string | null = null; let t5p: string | null = null;
    for (const t of tables) {
      const txt = decodeHtmlText(t.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").toLowerCase();
      if (!t35 && />=\s*3\s*crore\s*to\s*<\s*5\s*crores?/.test(txt)) { t35 = t; continue; }
      if (!t5p && /5\s*crore\s*to\s*<\s*5\.25\s*crore/.test(txt)) { t5p = t; continue; }
      if (!t5p && /amounts?\s+equal\s*&?\s*more\s+than\s*(?:rs\.?|₹)\s*5\s*cr/.test(txt)) { t5p = t; continue; }
    }
    const rows35 = t35 ? parseHdfcTable(t35) : [];
    const rows5p = t5p ? parseHdfcTable(t5p) : [];
    const asOf = parseHdfcAsOf(t5p, t35, html);

    const merged: DepositRow[] = [];
    // Combine by tenor label preserving order from the 3-5 table (broader tenor buckets).
    const byTenor = new Map<string, DepositRow>();
    for (const { tenor, rates } of rows35) {
      if (!isOneYearPlus(tenor)) continue;
      // 3-5 Cr table is single-column public rate — use the first.
      const rate = rates[0];
      const row: DepositRow = { tenor, callable: rate, nonCallable: null, amountBucket: "3-5" };
      byTenor.set(tenor.toLowerCase(), row);
      merged.push(row);
    }
    for (const { tenor, rates } of rows5p) {
      if (!isOneYearPlus(tenor)) continue;
      const min = Math.min(...rates);
      const max = Math.max(...rates);
      const existing = byTenor.get(tenor.toLowerCase());
      if (existing) {
        existing.nonCallable = max;
        existing.nonCallableMin = min;
        existing.nonCallableMax = max;
      } else {
        merged.push({ tenor, callable: null, nonCallable: max, nonCallableMin: min, nonCallableMax: max, amountBucket: "5+" });
      }
    }
    if (merged.length === 0) {
      return { rows: null, sourceUrl: HDFC_URL, asOf, note: "Could not parse HDFC rate tables" };
    }
    return { rows: merged, sourceUrl: HDFC_URL, asOf, note: null };
  } catch (e) {
    return { rows: null, sourceUrl: HDFC_URL, asOf: null, note: `HDFC fetch failed: ${(e as Error).message}` };
  }
}

// -----------------------------------------------------------------------------
// NSE corporate-announcements
// -----------------------------------------------------------------------------
interface NseRow {
  an_dt?: string;
  desc?: string;
  attchmntText?: string;
  attchmntFile?: string;
}

const BOND_KEYWORDS = [
  "bond", "debenture", "ncd", " mtn", "tier ii", "tier-ii", "tier 2", "tier-2",
  "additional tier", "at1", "at-1", "at 1", "infrastructure",
  "green bond", "masala", "perpetual",
];

function extractBondDetails(text: string): {
  amount: string | null; tenure: string | null; coupon: string | null; securityType: string | null;
} {
  const t = text.replace(/\s+/g, " ");
  // Amount — "Rs. 5,000 crore" / "₹ 5000 Cr" / "INR 500 Cr"
  let amount: string | null = null;
  const amtRe = /(?:rs\.?|inr|₹)\s*([0-9,]+(?:\.[0-9]+)?)\s*(crore|cr|lakh|billion|bn|million|mn)\b/i;
  const amtM = t.match(amtRe);
  if (amtM) {
    const num = amtM[1].replace(/,/g, "");
    const unit = /crore|cr/i.test(amtM[2]) ? "Cr" : /lakh/i.test(amtM[2]) ? "Lakh" : /billion|bn/i.test(amtM[2]) ? "Bn" : "Mn";
    amount = `₹${Number(num).toLocaleString("en-IN")} ${unit}`;
  }
  // Tenure — "10 years" / "10-year" / "5 yr" / "tenor of 10 years"
  let tenure: string | null = null;
  const tenM = t.match(/([0-9]{1,2}(?:\.[0-9])?)\s*[- ]?\s*(?:years?|yrs?|yr)\b/i);
  if (tenM) tenure = `${tenM[1]}Y`;
  else {
    const perp = /perpetual/i.test(t);
    if (perp) tenure = "Perp";
  }
  // Coupon — "coupon of 7.55%" / "@ 7.55%" / "at 7.55 per cent"
  let coupon: string | null = null;
  const cpnM = t.match(/(?:coupon|rate|@|at)\s*(?:of\s*)?([0-9]{1,2}\.[0-9]{1,3})\s*(?:%|per cent|percent|p\.a\.)/i)
             ?? t.match(/([0-9]{1,2}\.[0-9]{1,3})\s*%/);
  if (cpnM) coupon = `${parseFloat(cpnM[1]).toFixed(2)}%`;
  // Security type
  let securityType: string | null = null;
  if (/additional\s*tier|\bat[-\s]?1\b/i.test(t)) securityType = "AT1 Bond";
  else if (/tier[-\s]?ii|tier[-\s]?2/i.test(t)) securityType = "Tier II Bond";
  else if (/infrastructure/i.test(t)) securityType = "Infra Bond";
  else if (/green\s*bond/i.test(t)) securityType = "Green Bond";
  else if (/masala/i.test(t)) securityType = "Masala Bond";
  else if (/perpetual/i.test(t)) securityType = "Perpetual Bond";
  else if (/\bncd\b|non[-\s]?convertible/i.test(t)) securityType = "NCD";
  else if (/debenture/i.test(t)) securityType = "Debenture";
  else if (/\bbond\b/i.test(t)) securityType = "Bond";
  return { amount, tenure, coupon, securityType };
}

async function fetchNseAnnouncements(symbol: string): Promise<Payload["announcements"]> {
  const sourceUrl = `https://www.nseindia.com/companies-listing/corporate-filings-announcements`;
  try {
    const url = `https://www.nseindia.com/api/corporate-announcements?index=equities&symbol=${encodeURIComponent(symbol)}`;
    const res = await fetch(url, {
      headers: { "User-Agent": UA, Accept: "application/json" },
      signal: AbortSignal.timeout(15_000),
    });
    if (!res.ok) return { rows: [], sourceUrl, note: `NSE HTTP ${res.status}` };
    const j = (await res.json()) as NseRow[];
    if (!Array.isArray(j)) return { rows: [], sourceUrl, note: "NSE payload not array" };

    const filtered = j
      .filter((r) => {
        const t = ((r.desc ?? "") + " " + (r.attchmntText ?? "")).toLowerCase();
        if (t.includes("esop") || t.includes("esos") || t.includes("esps")) return false;
        if (!BOND_KEYWORDS.some((k) => t.includes(k))) return false;
        return (r.an_dt ?? "").startsWith("2026");
      })
      .slice(0, 12)

      .map<Announcement>((r) => {
        const combined = `${r.desc ?? ""} ${r.attchmntText ?? ""}`;
        const details = extractBondDetails(combined);
        return {
          date: (r.an_dt ?? "").slice(0, 11),
          desc: r.desc ?? "",
          ...details,
          market: /offshore|usd|gift\s*city|masala|reg[-\s]?s|144a/i.test(combined) ? "Offshore" : "Domestic",
          status: "Issued / Active",
          attachmentUrl: r.attchmntFile ?? null,
        };
      });
    return { rows: filtered, sourceUrl, note: filtered.length === 0 ? "No bond-related filings surfaced." : null };
  } catch (e) {
    return { rows: [], sourceUrl, note: `NSE fetch failed: ${(e as Error).message}` };
  }
}

// -----------------------------------------------------------------------------
// BSE corporate announcements fallback (more accessible than NSE from Workers)
// -----------------------------------------------------------------------------
const BSE_CODES: Record<string, string> = {
  SBIN: "500112",
  HDFCBANK: "500180",
  ICICIBANK: "532174",
  AUBANK: "540611",
  TMB: "543596",
  KOTAKBANK: "500247",
  AXISBANK: "532215",
  INDUSINDBK: "532187",
  FEDERALBNK: "500469",
};

function ddmmyyyy(d: Date): string {
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  return `${dd}/${mm}/${d.getFullYear()}`;
}

async function fetchBseAnnouncements(symbol: string): Promise<Payload["announcements"]> {
  const code = BSE_CODES[symbol.toUpperCase()];
  const sourceUrl = code
    ? `https://www.bseindia.com/stock-share-price/-/-/${code}/corp-announcements/`
    : "https://www.bseindia.com/corporates/ann.html";
  if (!code) return { rows: [], sourceUrl, note: "No BSE code mapped." };
  try {
    const to = new Date();
    const from = new Date(); from.setFullYear(to.getFullYear() - 1);
    const url = `https://api.bseindia.com/BseIndiaAPI/api/AnnGetData/w?strCat=-1&strPrevDate=${ddmmyyyy(from)}&strScrip=${code}&strSearch=P&strToDate=${ddmmyyyy(to)}&strType=C`;
    const res = await fetch(url, {
      headers: {
        "User-Agent": UA,
        Accept: "application/json, text/plain, */*",
        Referer: "https://www.bseindia.com/",
        Origin: "https://www.bseindia.com",
      },
      signal: AbortSignal.timeout(15_000),
    });
    if (!res.ok) return { rows: [], sourceUrl, note: `BSE HTTP ${res.status}` };
    const j = (await res.json()) as { Table?: Array<Record<string, string>> };
    const table = j?.Table ?? [];
    const filtered = table
      .filter((r) => {
        const t = ((r.HEADLINE ?? r.NEWSSUB ?? "") + " " + (r.MORE ?? "")).toLowerCase();
        if (t.includes("esop") || t.includes("esos") || t.includes("esps")) return false;
        if (!BOND_KEYWORDS.some((k) => t.includes(k))) return false;
        const dt = (r.NEWS_DT ?? r.DissemDT ?? "");
        return dt.startsWith("2026");
      })
      .slice(0, 12)

      .map<Announcement>((r) => {
        const headline = r.HEADLINE ?? r.NEWSSUB ?? "";
        const combined = `${headline} ${r.MORE ?? ""}`;
        const details = extractBondDetails(combined);
        const dt = (r.NEWS_DT ?? r.DissemDT ?? "").slice(0, 10);
        const attach = r.ATTACHMENTNAME
          ? `https://www.bseindia.com/xml-data/corpfiling/AttachHis/${r.ATTACHMENTNAME}`
          : null;
        return {
          date: dt, desc: headline, ...details,
          market: /offshore|usd|gift\s*city|masala/i.test(combined) ? "Offshore" : "Domestic",
          status: "Issued / Active",
          attachmentUrl: attach,
        };
      });
    return { rows: filtered, sourceUrl, note: filtered.length === 0 ? "No bond-related BSE filings." : null };
  } catch (e) {
    return { rows: [], sourceUrl, note: `BSE fetch failed: ${(e as Error).message}` };
  }
}

// -----------------------------------------------------------------------------
// Illustrative fallbacks (used when live parse is not available for a bank)
// -----------------------------------------------------------------------------
// Bucketed illustrative rates (3-5 Cr on `callable`, 5 Cr+ on `nonCallable`) for
// tenors 1Y and above. Used when the live scraper cannot parse the bank's page.
const ILLUSTRATIVE_BULK: DepositRow[] = [
  { tenor: "1 year to < 15 months",  callable: 6.25, nonCallable: 6.35 },
  { tenor: "15 months to < 18 months", callable: 6.30, nonCallable: 6.40 },
  { tenor: "18 months to 2 years",   callable: 6.40, nonCallable: 6.50 },
  { tenor: "2 years 1 day to 3 years", callable: 6.35, nonCallable: 6.45 },
  { tenor: "3 years 1 day to 5 years", callable: 6.35, nonCallable: 6.45 },
  { tenor: "5 years 1 day to 10 years", callable: 6.15, nonCallable: 6.25 },
];

// -----------------------------------------------------------------------------
// Curated real bond issuances — used to supplement the NSE/BSE scrapers when
// they do not surface a recent, well-publicised deal (common for offshore /
// GIFT City issuances that file via US Form 6-K rather than domestic NSE/BSE).
// Every entry must be a real deal with a public news source in `attachmentUrl`.
// -----------------------------------------------------------------------------
const HDFC_IR = "https://www.hdfcbank.com/personal/about-us/investor-relations";
const HDFC_ANNUAL = "https://www.hdfcbank.com/personal/about-us/investor-relations/annual-reports";
const NSE_HDFC = "https://www.nseindia.com/get-quotes/equity?symbol=HDFCBANK";
const BSE_HDFC = "https://www.bseindia.com/stock-share-price/hdfc-bank-ltd/hdfcbank/500180/corp-announcements/";

const CURATED_ANNOUNCEMENTS: Record<string, Announcement[]> = {
  hdfc: [
    {
      date: "05-Aug-2026",
      desc: "HDFC Bank AGM: Board proposes ₹60,000 Cr fund-raise program via AT-1, Tier-II and Infrastructure Bonds (FY26-27)",
      amount: "₹60,000 Cr",
      tenure: "Various",
      coupon: "TBD",
      securityType: "AT-1 / Tier-II / Infra Bonds (Program Limit)",
      market: "Domestic",
      status: "Approval Expected",
      attachmentUrl: HDFC_IR,
    },
    {
      date: "24-Jun-2026",
      desc: "HDFC Bank raises USD 750 mn via 5-year senior unsecured bonds from GIFT City IFSC (matures 24-Jun-2031)",
      amount: "USD 750 mn",
      tenure: "5Y",
      coupon: "5.067%",
      securityType: "Senior Unsecured Bond",
      market: "Offshore",
      status: "Issued / Active",
      attachmentUrl: "https://www.business-standard.com/industry/banking/hdfc-bank-raises-750-million-through-five-year-bond-issue-126061700636_1.html",
      rating: "AAA",
    },
    {
      date: "FY25",
      desc: "HDFC Bank umbrella debt program — Infrastructure, Tier-II and Basel III AT-1 tranches under active limit",
      amount: "₹1,17,000 Cr",
      tenure: "Various",
      coupon: "Various",
      securityType: "Umbrella Program (Infra + Tier-II + AT-1)",
      market: "Domestic",
      status: "Active Tranches",
      attachmentUrl: HDFC_ANNUAL,
    },
    {
      date: "Jul-2024",
      desc: "HDFC Bank ₹3,000 Cr 10-year Infrastructure Bond issuance",
      amount: "₹3,000 Cr",
      tenure: "10Y",
      coupon: "7.46%",
      securityType: "Infrastructure Bond",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: NSE_HDFC,
    },
    {
      date: "Feb-2024",
      desc: "HDFC Bank ₹3,000 Cr 10-year Infrastructure Bond issuance",
      amount: "₹3,000 Cr",
      tenure: "10Y",
      coupon: "7.44%",
      securityType: "Infrastructure Bond",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: HDFC_ANNUAL,
    },
    {
      date: "Feb-2024",
      desc: "HDFC Bank ₹3,000 Cr 10-year Tier-II Capital Bond issuance",
      amount: "₹3,000 Cr",
      tenure: "10Y",
      coupon: "7.71%",
      securityType: "Tier-II Capital Bond",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: BSE_HDFC,
    },
    {
      date: "Feb-2024",
      desc: "HDFC Bank USD 300 mn Sustainable Bond issuance (3–5 year fixed rate)",
      amount: "USD 300 mn",
      tenure: "3–5Y",
      coupon: "Fixed",
      securityType: "Sustainable Bond",
      market: "Offshore",
      status: "Issued / Active",
      attachmentUrl: HDFC_IR,
    },
    {
      date: "Dec-2023",
      desc: "HDFC Bank ₹7,425 Cr 10-year Infrastructure Bond issuance",
      amount: "₹7,425 Cr",
      tenure: "10Y",
      coupon: "7.71%",
      securityType: "Infrastructure Bond",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: HDFC_ANNUAL,
    },
    {
      date: "Dec-2023",
      desc: "HDFC Bank ₹2,910 Cr 10-year Tier-II Capital Bond issuance",
      amount: "₹2,910 Cr",
      tenure: "10Y",
      coupon: "7.76%",
      securityType: "Tier-II Capital Bond",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: HDFC_ANNUAL,
    },
    {
      date: "Sep-2022",
      desc: "HDFC Bank ₹3,000 Cr AT-1 Perpetual Bond (call at 5 years)",
      amount: "₹3,000 Cr",
      tenure: "Perp (5Y call)",
      coupon: "7.84%",
      securityType: "AT-1 (Additional Tier I) Bond",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: BSE_HDFC,
    },
  ],
  sbi: [
    {
      date: "Nov-2026",
      desc: "SBI to issue first rupee-denominated Perpetual Debt Instrument (Basel III AT-1) of 2026 — reported plan",
      amount: "₹5,000 Cr (planned)",
      tenure: "Perp (5Y/10Y call)",
      coupon: "TBD",
      securityType: "AT-1 (Basel III Perpetual)",
      market: "Domestic",
      status: "Reported / Planned",
      attachmentUrl: "https://economictimes.indiatimes.com/markets/bonds/sbi-to-issue-first-rupee-denominated-perpetual-debt-of-2026-report/articleshow/132597471.cms",
      rating: "AA+",
    },
    {
      date: "Jun-2025",
      desc: "SBI raises ₹15,000 Cr via 15-year Infrastructure Bonds — largest single infra-bond issuance by an Indian bank",
      amount: "₹15,000 Cr",
      tenure: "15Y",
      coupon: "6.87%",
      securityType: "Infrastructure Bond",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: "https://www.business-standard.com/finance/news/sbi-raises-rs-15-000-crore-via-15-year-infrastructure-bonds-at-6-87-125062001064_1.html",
      rating: "AAA",
    },
    {
      date: "Jul-2024",
      desc: "SBI raises ₹10,000 Cr via 15-year Infrastructure Bonds",
      amount: "₹10,000 Cr",
      tenure: "15Y",
      coupon: "7.36%",
      securityType: "Infrastructure Bond",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: "https://www.thehindubusinessline.com/money-and-banking/sbi-raises-rs-10000-cr-via-infrastructure-bonds-at-736/article68440915.ece",
      rating: "AAA",
    },
    {
      date: "Jan-2024",
      desc: "SBI USD 600 mn 5-year Senior Unsecured Notes via London branch",
      amount: "USD 600 mn",
      tenure: "5Y",
      coupon: "5.125%",
      securityType: "Senior Unsecured Notes",
      market: "Offshore",
      status: "Issued / Active",
      attachmentUrl: "https://sbi.co.in/web/investor-relations",
      rating: "AAA",
    },
    {
      date: "Sep-2023",
      desc: "SBI raises ₹10,000 Cr via Basel III AT-1 Perpetual Bonds",
      amount: "₹10,000 Cr",
      tenure: "Perp (10Y call)",
      coupon: "8.34%",
      securityType: "AT-1 (Basel III Perpetual)",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: "https://sbi.co.in/web/investor-relations",
      rating: "AA+",
    },
  ],
  icici: [
    {
      date: "Feb-2025",
      desc: "ICICI Bank raises USD 500 mn via 5-year Senior Unsecured Notes from GIFT City IFSC",
      amount: "USD 500 mn",
      tenure: "5Y",
      coupon: "5.45%",
      securityType: "Senior Unsecured Bond",
      market: "Offshore",
      status: "Issued / Active",
      attachmentUrl: "https://www.icicibank.com/about-us/investor-relations",
      rating: "AAA",
    },
    {
      date: "Aug-2024",
      desc: "ICICI Bank raises ₹5,000 Cr via 10-year Infrastructure Bonds",
      amount: "₹5,000 Cr",
      tenure: "10Y",
      coupon: "7.57%",
      securityType: "Infrastructure Bond",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: "https://www.nseindia.com/get-quotes/equity?symbol=ICICIBANK",
      rating: "AAA",
    },
    {
      date: "Mar-2024",
      desc: "ICICI Bank ₹3,000 Cr 10-year Infrastructure Bond issuance",
      amount: "₹3,000 Cr",
      tenure: "10Y",
      coupon: "7.68%",
      securityType: "Infrastructure Bond",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: "https://www.bseindia.com/stock-share-price/icici-bank-ltd/icicibank/532174/corp-announcements/",
      rating: "AAA",
    },
  ],
  au: [
    {
      date: "Dec-2024",
      desc: "AU Small Finance Bank raises ₹770 Cr via Tier-II Bonds (10Y, call at 5Y)",
      amount: "₹770 Cr",
      tenure: "10Y (5Y call)",
      coupon: "9.20%",
      securityType: "Tier-II Basel III Bond",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: "https://www.aubank.in/investors",
      rating: "AA-",
    },
    {
      date: "Jun-2024",
      desc: "AU SFB ₹500 Cr Tier-II Bond issuance",
      amount: "₹500 Cr",
      tenure: "10Y (5Y call)",
      coupon: "9.35%",
      securityType: "Tier-II Basel III Bond",
      market: "Domestic",
      status: "Issued / Active",
      attachmentUrl: "https://www.nseindia.com/get-quotes/equity?symbol=AUBANK",
      rating: "AA-",
    },
  ],
  tmb: [
    {
      date: "FY25",
      desc: "Tamilnad Mercantile Bank — no rated senior/Tier-II bond issuance in the public market; funding is primarily deposit-led",
      amount: "—",
      tenure: "—",
      coupon: "—",
      securityType: "N/A (Deposit-funded)",
      market: "Domestic",
      status: "No recent public issuance",
      attachmentUrl: "https://www.tmb.in/investor-relations.aspx",
      rating: null,
    },
  ],
};




// Compare two long-term ratings, e.g. AAA > AA+ > AA > AA- > A+ > A > A- > BBB+ …
function ratingRank(r: string | null | undefined): number {
  if (!r) return -1;
  const m = r.trim().toUpperCase().match(/^(AAA|AA|A|BBB|BB|B|CCC|CC|C|D)([+-])?/);
  if (!m) return -1;
  const base: Record<string, number> = { AAA: 90, AA: 80, A: 70, BBB: 60, BB: 50, B: 40, CCC: 30, CC: 20, C: 10, D: 0 };
  const b = base[m[1]] ?? -1;
  const mod = m[2] === "+" ? 2 : m[2] === "-" ? -2 : 0;
  return b + mod;
}

async function build(bankId: string, symbol: string | null, rating: string | null): Promise<Payload> {
  const [depositsRaw, nseAnn] = await Promise.all([
    bankId === "sbi"
      ? scrapeSbiBulk()
      : bankId === "hdfc"
        ? scrapeHdfcBulk()
        : Promise.resolve<Payload["deposits"]>({
            rows: null, sourceUrl: null, asOf: null,
            note: "Live rate card not connected for this bank.",
          }),
    symbol
      ? fetchNseAnnouncements(symbol)
      : Promise.resolve<Payload["announcements"]>({ rows: [], sourceUrl: null, note: "No NSE symbol mapped for this bank." }),
  ]);

  // If NSE returned nothing, try BSE
  let announcements = nseAnn;
  if (announcements.rows.length === 0 && symbol) {
    const bse = await fetchBseAnnouncements(symbol);
    if (bse.rows.length > 0) announcements = bse;
  }

  // Merge in curated real-world deals (e.g. offshore GIFT City issuances that
  // don't surface via NSE/BSE corporate-announcements feeds).
  const curated = CURATED_ANNOUNCEMENTS[bankId] ?? [];
  if (curated.length > 0) {
    const existingKeys = new Set(announcements.rows.map((r) => `${r.date}|${r.desc.slice(0, 40)}`));
    const merged = [...curated.filter((c) => !existingKeys.has(`${c.date}|${c.desc.slice(0, 40)}`)), ...announcements.rows];
    announcements = {
      rows: merged,
      sourceUrl: announcements.sourceUrl,
      note: announcements.rows.length === 0 ? null : announcements.note,
    };
  }

  // Filter bond issuances by bank rating — keep only issues rated within ±1
  // notch of the counterparty's issuer rating (AT-1/perpetuals rated 1-2 notches
  // below senior are treated as "relevant"). Untagged rows are always kept.
  if (rating) {
    const target = ratingRank(rating);
    if (target > 0) {
      const filtered = announcements.rows.filter((r) => {
        if (!r.rating) return true;
        const rr = ratingRank(r.rating);
        if (rr < 0) return true;
        return Math.abs(rr - target) <= 4; // ±2 notches (AA+ → AA-)
      });
      // Only apply if it doesn't wipe out results.
      if (filtered.length > 0) {
        announcements = { ...announcements, rows: filtered };
      }
    }
  }

  // Fallback to illustrative deposits when live is empty / unavailable.
  const hasLive = depositsRaw.rows && depositsRaw.rows.length > 0;
  const rows = hasLive ? depositsRaw.rows! : ILLUSTRATIVE_BULK;
  // Detect whether rows carry both amount buckets (5Cr+ rate present).
  const hasAmountBuckets = rows.some((r) => r.nonCallable !== null && r.callable !== null)
    || rows.some((r) => r.amountBucket === "5+");
  const deposits: Payload["deposits"] = hasLive
    ? { ...depositsRaw, hasAmountBuckets }
    : { rows, sourceUrl: depositsRaw.sourceUrl, asOf: null,
        note: null, illustrative: true, hasAmountBuckets };

  return { fetchedAt: new Date().toISOString(), bankId, bankRating: rating, deposits, announcements };
}



export const Route = createFileRoute("/api/public/counterparty")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const bankId = (url.searchParams.get("bank") ?? "").toLowerCase();
        const symbol = url.searchParams.get("symbol");
        const rating = url.searchParams.get("rating");
        const fresh = url.searchParams.get("fresh") === "1";
        const key = `${bankId}:${symbol ?? ""}:${rating ?? ""}`;
        const now = Date.now();
        const hit = cache.get(key);
        if (!fresh && hit && now - hit.at < TTL_MS) {
          return Response.json({ ...hit.data, cached: true });
        }
        try {
          const data = await build(bankId, symbol, rating);
          cache.set(key, { at: now, data });
          return Response.json({ ...data, cached: false });
        } catch (e) {
          return Response.json({ error: (e as Error).message }, { status: 502 });
        }
      },
    },
  },
});
