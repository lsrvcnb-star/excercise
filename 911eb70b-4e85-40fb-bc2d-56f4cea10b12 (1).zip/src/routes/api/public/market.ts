import { createFileRoute } from "@tanstack/react-router";
import * as XLSX from "xlsx";

// -----------------------------------------------------------------------------
// /api/public/market
// Server-only endpoint that scrapes official rate sources and returns a
// unified snapshot. Cached per-Worker-instance for 30 minutes.
//
// Sources (all official):
//   • RBI homepage (rbi.org.in) — Policy Repo, Reverse Repo, SDF, MSF, Bank Rate
//   • FBIL (fbil.org.in) public JSON APIs — T-Bill (3M), CD (12M) benchmark rates
//   • FBIL Par Yield sheet — 10-year G-Sec par yield (XLSX parsed server-side)
//
// CP: FBIL does not publish a CP benchmark, so cp1y stays null with a note.
// -----------------------------------------------------------------------------

interface RatePoint { value: number | null; source: string | null; }
interface Snapshot {
  fetchedAt: string;
  repo: RatePoint; reverseRepo: RatePoint; sdf: RatePoint; msf: RatePoint;
  bankRate: RatePoint; gsec10: RatePoint; tbill3m: RatePoint;
  cd1y: RatePoint; cp1y: RatePoint;
  notes: string[];
}

// per-Worker-instance cache
let cache: { at: number; data: Snapshot } | null = null;
const TTL_MS = 30 * 60 * 1000;

const UA = "Mozilla/5.0 (compatible; SIDBIPricingDashboard/1.0)";
const nullPoint = (): RatePoint => ({ value: null, source: null });

async function scrapeRbi(): Promise<Partial<Snapshot>> {
  const res = await fetch("https://www.rbi.org.in/", {
    headers: { "User-Agent": UA, "Accept": "text/html,application/xhtml+xml" },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) throw new Error(`RBI ${res.status}`);
  const html = await res.text();

  const grab = (label: string): RatePoint => {
    const re = new RegExp(label.replace(/ /g, "\\s+") + "[\\s\\S]{0,300}?([0-9]+\\.[0-9]+)\\s*%");
    const m = html.match(re);
    return m ? { value: parseFloat(m[1]), source: "RBI" } : nullPoint();
  };

  // Government Securities Market table on rbi.org.in — pick the bond whose
  // maturity year is nearest to today + 10 years for the "10Y G-Sec" proxy.
  let gsec10: RatePoint = nullPoint();
  const gsMatches = [...html.matchAll(/([0-9]+\.[0-9]+)%\s*GS\s*(\d{4})[\s\S]{0,120}?:\s*([0-9]+\.[0-9]+)\s*%/g)];
  if (gsMatches.length > 0) {
    const targetYear = new Date().getFullYear() + 10;
    let best: { year: number; ytm: number } | null = null;
    for (const m of gsMatches) {
      const year = parseInt(m[2], 10);
      const ytm = parseFloat(m[3]);
      if (!best || Math.abs(year - targetYear) < Math.abs(best.year - targetYear)) {
        best = { year, ytm };
      }
    }
    if (best) gsec10 = { value: best.ytm, source: `RBI (GS ${best.year})` };
  }

  // 91-day T-bill cut-off from the same GSM table.
  let tbill3m: RatePoint = nullPoint();
  const tbillM = html.match(/91\s*day\s*T-?bills[\s\S]{0,400}?([0-9]+\.[0-9]+)\s*%/i);
  if (tbillM) tbill3m = { value: parseFloat(tbillM[1]), source: "RBI (91-day T-Bill cut-off)" };


  return {
    repo:        grab("Policy Repo Rate"),
    reverseRepo: grab("Reverse Repo Rate"),
    sdf:         grab("Standing Deposit"),
    msf:         grab("Marginal Standing"),
    bankRate:    grab("Bank Rate"),
    gsec10,
    tbill3m,
  };
}


interface FbilTenorRow { tenorName: string; rate: number; processRunDate: string; }

async function fetchFbilTenorRates(kind: "tbill" | "cd"): Promise<FbilTenorRow[] | null> {
  const res = await fetch(`https://www.fbil.org.in/wasdm/${kind}/fetch?authenticated=false`, {
    headers: { "User-Agent": UA, "Accept": "application/json" },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) return null;
  const j = await res.json() as FbilTenorRow[];
  return Array.isArray(j) ? j : null;
}

function pickTenor(rows: FbilTenorRow[] | null, tenor: string): RatePoint {
  if (!rows) return nullPoint();
  // Rows include multiple report dates; the latest date comes first.
  const latestDate = rows[0]?.processRunDate;
  const match = rows.find(
    (r) => r.processRunDate === latestDate && r.tenorName.trim().toLowerCase() === tenor.toLowerCase()
  );
  return match ? { value: +match.rate, source: "FBIL" } : nullPoint();
}

async function fetchGsec10Y(): Promise<RatePoint> {
  // Step 1: get the latest published date from the archive listing
  const listRes = await fetch("https://www.fbil.org.in/wasdm/gsec/fetch?authenticated=false", {
    headers: { "User-Agent": UA, "Accept": "application/json" },
    signal: AbortSignal.timeout(15_000),
  });
  if (!listRes.ok) return nullPoint();
  const list = await listRes.json() as Array<{ processRunDate: string }>;
  if (!Array.isArray(list) || !list[0]?.processRunDate) return nullPoint();
  const date = list[0].processRunDate.slice(0, 10);

  // Step 2: download the FBIL G-Sec XLSX for that date
  const xlsxRes = await fetch(
    `https://www.fbil.org.in/wasdm/gsec/downloadPublished?authenticated=false&date=${date}`,
    { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(20_000) },
  );
  if (!xlsxRes.ok) return nullPoint();
  const buf = new Uint8Array(await xlsxRes.arrayBuffer());
  const wb = XLSX.read(buf, { type: "array" });
  const parSheet = wb.Sheets["Par Yield"];
  if (!parSheet) return nullPoint();
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(parSheet, { header: 1, defval: null });
  // Header row is around index 4: ["Tenor (Year)", "YTM% p.a.(Semi-Annual)", "YTM % p.a.(Annualized)"]
  for (const raw of rows as unknown as unknown[][]) {
    const tenor = raw?.[0];
    if (typeof tenor === "number" && tenor === 10) {
      const annualised = raw[2];
      if (typeof annualised === "number") return { value: annualised, source: "FBIL" };
      const semi = raw[1];
      if (typeof semi === "number") return { value: semi, source: "FBIL" };
    }
  }
  return nullPoint();
}

async function buildSnapshot(): Promise<Snapshot> {
  const snap: Snapshot = {
    fetchedAt: new Date().toISOString(),
    repo: nullPoint(), reverseRepo: nullPoint(), sdf: nullPoint(), msf: nullPoint(),
    bankRate: nullPoint(), gsec10: nullPoint(), tbill3m: nullPoint(),
    cd1y: nullPoint(), cp1y: nullPoint(),
    notes: [],
  };

  const [rbi, tbillRows, cdRows, gsec10] = await Promise.allSettled([
    scrapeRbi(),
    fetchFbilTenorRates("tbill"),
    fetchFbilTenorRates("cd"),
    fetchGsec10Y(),
  ]);

  if (rbi.status === "fulfilled") {
    Object.assign(snap, rbi.value);
    snap.notes.push("Policy rates: rbi.org.in (official).");
  } else {
    snap.notes.push(`RBI fetch failed: ${(rbi.reason as Error).message}`);
  }

  // RBI GSM table is authoritative for gsec10 and tbill3m; FBIL only fills gaps.
  if (tbillRows.status === "fulfilled" && snap.tbill3m.value === null) {
    snap.tbill3m = pickTenor(tbillRows.value, "3 Months");
    if (snap.tbill3m.value !== null) snap.notes.push("T-Bill 3M: FBIL (fbil.org.in).");
  } else if (snap.tbill3m.value !== null) {
    snap.notes.push("T-Bill 3M: RBI GSM (91-day cut-off).");
  }
  if (cdRows.status === "fulfilled") {
    snap.cd1y = pickTenor(cdRows.value, "12 Months");
    if (snap.cd1y.value !== null) snap.notes.push("CD 1Y: FBIL (fbil.org.in).");
  }
  if (snap.gsec10.value !== null) {
    snap.notes.push(`10Y G-Sec: ${snap.gsec10.source}.`);
  } else if (gsec10.status === "fulfilled") {
    snap.gsec10 = gsec10.value;
    if (snap.gsec10.value !== null) snap.notes.push("10Y G-Sec: FBIL Par Yield (fbil.org.in).");
  } else {
    snap.notes.push(`G-Sec fetch failed: ${(gsec10.reason as Error).message}`);
  }


  snap.notes.push("CP: FBIL does not publish a Commercial Paper benchmark; add a manual override if needed.");
  return snap;
}

export const Route = createFileRoute("/api/public/market")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const forceFresh = url.searchParams.get("fresh") === "1";
        const now = Date.now();
        if (!forceFresh && cache && now - cache.at < TTL_MS) {
          return Response.json({ ...cache.data, cached: true }, {
            headers: { "Cache-Control": "public, max-age=1800" },
          });
        }
        try {
          const data = await buildSnapshot();
          cache = { at: now, data };
          return Response.json({ ...data, cached: false }, {
            headers: { "Cache-Control": "public, max-age=1800" },
          });
        } catch (e) {
          return Response.json(
            { error: (e as Error).message, fetchedAt: new Date().toISOString() },
            { status: 502 },
          );
        }
      },
    },
  },
});
