import { createFileRoute } from "@tanstack/react-router";
import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { Download, AlertTriangle, ExternalLink, RefreshCw, Info, TrendingUp, TrendingDown, CalendarIcon, FileSpreadsheet, FileText, ChevronDown, ChevronUp, ChevronRight, X, Trash2 } from "lucide-react";
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem,
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import sidbiLogoAsset from "@/assets/sidbi-logo.png.asset.json";
import {
  type DealState, type Frequency, type Scheme, type DealSplit, type DealLeg, FREQUENCIES,
  schemeAmounts, effectiveRateForFreq, effectiveRateWindow, combinedCashflows, xirr, irrAnnualPct, combinedMonthlyCashflows, irrPeriodic,
  mserFloor, rmseFinalRate, marginBps, discretionMaxBps,
  type BankCategory,
  schemeSchedule, schemeTotalInterest, weightedAvgRate,
  resolveLegs, legSchedules, baseLegAmount, splitTotal, withTenureMonths,
  RMSE_FIXED_RATE, RMSE_MARGIN_BPS,
} from "@/lib/pricing";

import {
  BANKS, BANK_TYPES, DEFAULT_DEAL, COF_OPTION_DEFS, BENCHMARK_OPTION_DEFS, COF_STATIC_RATES, COF_FLOATING_MAP,
  RMSE_MATURITY_DATE, roundedMonthsBetween,
  type CofOption, type BenchmarkOption, type PastDeal, type NegotiationStatus, type BankProfile, type BankType,
  type DealComponent,
} from "@/lib/pricing-data";
import { MARKET_INSTRUMENTS, type MarketInstrument } from "@/lib/market-history";
import { useMarket } from "@/lib/market-client";
import { useCounterparty, type LiveDepositRow, type LiveAnnouncement } from "@/lib/counterparty-client";
import { exportDealToExcel } from "@/lib/pricing-export";
import { exportDealToPdf } from "@/lib/pricing-pdf";
import { counterpartyMarketDeals, treasuryDeals } from "@/lib/market-deals";

/** A CoF row carries a spread over a benchmark: Treasury floating rows + custom floating. */
const isFloatingCofOpt = (c?: { type?: string; key?: string } | null) =>
  c?.type === "floating" || c?.key === "custom_float";
/** Resolved CoF % for a key = base rate (+ spread when the row is floating). */
const resolveCofPct = (
  key: string | undefined,
  opts: CofOption[],
  spreads: Record<string, number>,
) => {
  const o = opts.find((c) => c.key === key);
  const raw = o?.ratePct ?? null;
  const sp = isFloatingCofOpt(o) ? (spreads[key ?? ""] ?? 0) : 0;
  return raw !== null ? raw + sp / 100 : null;
};



import {
  LineChart, Line, XAxis, YAxis, Tooltip as RTooltip, ResponsiveContainer,
  BarChart, Bar, CartesianGrid, ReferenceLine, AreaChart, Area,
} from "recharts";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SIDBI Refinance — Pricing Negotiation Dashboard" },
      { name: "description", content: "Interactive pricing negotiation tool for SIDBI refinance deals — MSER/RMSE blended rates with independent tenures, XIRR, cost of funds, live RBI policy rates, and past-deal history." },
      { property: "og:title", content: "SIDBI Refinance Pricing Dashboard" },
      { property: "og:description", content: "MSER/RMSE blended pricing with live XIRR, floor build-up, and official market data." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const [s, setS] = useState<DealState>(DEFAULT_DEAL);
  const [openInstrument, setOpenInstrument] = useState<MarketInstrument | null>(null);
  const market = useMarket();

  // Treasury CoF list — seeded with the official 05–31 Jul 2025 IFV-Banks table.
  // Users can still override any row in the UI.
  const [cofList, setCofList] = useState<CofOption[]>(
    COF_OPTION_DEFS.map((c) => ({ ...c, ratePct: COF_STATIC_RATES[c.key] ?? null }))
  );
  // Overlay live market rates onto floating CoF rows so they always reflect the
  // latest Repo / 3M T-Bill from RBI/FBIL. User overrides on fixed rows are preserved.
  const [customCofPct, setCustomCofPct] = useState<number | null>(null);
  // Custom floating CoF — user picks the benchmark and types its value; the
  // spread over it (shared per-key store below) completes the CoF.
  const [customFloatBench, setCustomFloatBench] = useState<"repo" | "tbill3m">("repo");
  const [customFloatBase, setCustomFloatBase] = useState<number | null>(null);
  const cofListLive = useMemo<CofOption[]>(() => cofList.map((c) => {
    if (c.key === "custom_float") return { ...c, ratePct: customFloatBase, benchmark: customFloatBench };
    if (c.type === "custom") return { ...c, ratePct: customCofPct };
    if (c.type !== "floating") return c;
    const mk = c.benchmark ?? COF_FLOATING_MAP[c.key];
    if (!mk) return c;
    const v = market.data[mk]?.value ?? null;
    return { ...c, ratePct: v };
  }), [cofList, market.data, customCofPct, customFloatBase, customFloatBench]);
  const [cofKey, setCofKey] = useState<string>("1y3y_repo_float");
  const cof = cofListLive.find((c) => c.key === cofKey)!;
  const isFloatingCof = isFloatingCofOpt(cof);
  const isCustomCof = cof.key === "custom";
  const isCustomFloatCof = cof.key === "custom_float";
  // Spread over the floating benchmark (bps) — user-entered, blank by default.
  // Kept per key so switching options preserves each spread.
  const [floatingSpreadBps, setFloatingSpreadBps] = useState<Record<string, number>>({});
  const floatSpread = isFloatingCof ? (floatingSpreadBps[cofKey] ?? 0) : 0;
  const baseCofPct = cof.ratePct ?? 0;
  const cofPct = baseCofPct + floatSpread / 100;
  const cofSet = cof.ratePct !== null;


  // When floating spread changes, preserve the current margin over CoF by
  // shifting the MSER rate along with the new CoF.
  const setFloatingSpread = (bps: number, key: string = cofKey) => {
    const capped = Math.max(0, Math.min(1000, Math.round(bps)));
    const prevSpread = floatingSpreadBps[key] ?? 0;
    const delta = (capped - prevSpread) / 100;
    setFloatingSpreadBps((prev) => ({ ...prev, [key]: capped }));
    setS((prev) => ({
      ...prev,
      mser: key === cofKey && cofSet ? { ...prev.mser, ratePct: prev.mser.ratePct + delta } : prev.mser,
      splits: (prev.splits ?? []).map((sp) =>
        sp.scheme === "mser" && (sp.cofKey ?? cofKey) === key
          ? { ...sp, ratePct: +(sp.ratePct + delta).toFixed(2) }
          : sp,
      ),
    }));
  };


  // When custom CoF changes, shift MSER rate to preserve margin.
  const setCustomCof = (v: number | null) => {
    const prev = customCofPct ?? 0;
    const next = v ?? 0;
    const delta = next - prev;
    setCustomCofPct(v);
    if (v !== null) {
      setS((prevS) => ({ ...prevS, mser: { ...prevS.mser, ratePct: prevS.mser.ratePct + delta } }));
    }
  };

  // Custom floating: benchmark value typed by the user. Shift MSER rate to keep margin.
  const setCustomFloatValue = (v: number | null) => {
    const prev = customFloatBase ?? 0;
    const delta = (v ?? 0) - prev;
    setCustomFloatBase(v);
    if (v !== null && cofKey === "custom_float") {
      setS((prevS) => ({ ...prevS, mser: { ...prevS.mser, ratePct: prevS.mser.ratePct + delta } }));
    }
  };


  // If CoF is a fixed-tenor option, clamp MSER tenure to the CoF tenor.
  useEffect(() => {
    if (cof.type !== "fixed") return;
    setS((prev) => prev.mser.tenureMonths > cof.tenorMonths
      ? { ...prev, mser: { ...prev.mser, tenureMonths: cof.tenorMonths } }
      : prev);
  }, [cofKey, cof.type, cof.tenorMonths]);


  // Benchmark list — Policy Repo comes from RBI live, others editable.
  const benchmarkList: BenchmarkOption[] = useMemo(() => {
    return BENCHMARK_OPTION_DEFS.map((b) => {
      if (b.key === "repo")    return { ...b, ratePct: market.data.repo.value };
      if (b.key === "gsec10")  return { ...b, ratePct: market.data.gsec10.value };
      if (b.key === "tbill3m") return { ...b, ratePct: market.data.tbill3m.value };
      return { ...b, ratePct: null };
    });
  }, [market.data]);

  // Once RBI repo arrives, seed the deal's benchmark if user hasn't customised.
  useEffect(() => {
    if (market.data.repo.value !== null && s.benchmarkPct === 0 && s.benchmarkLabel === "Policy Repo Rate") {
      setS((prev) => ({ ...prev, benchmarkPct: market.data.repo.value! }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [market.data.repo.value]);

  const bank = BANKS.find((b) => b.id === s.bankId)!;
  const counterparty = useCounterparty(bank.id, bank.nseSymbol ?? null, bank.rating);
  const [deskQuotes] = useManualQuotes();





  const patch = (p: Partial<DealState>) => setS((prev) => ({ ...prev, ...p }));
  const patchScheme = (k: "mser" | "rmse", p: Partial<Scheme>) =>
    setS((prev) => ({ ...prev, [k]: { ...prev[k], ...p } }));

  // MSER rate ⇄ Discretion linkage.
  // The MSER Rate input is the source of truth for what we're quoting the borrower.
  // Editing it back-solves the discretion (clamped to [0, SCA max]); the rate itself
  // is accepted as typed even if it's below the achievable floor — the negotiation
  // card will flag "below floor" in that case.
  const patchMserScheme = (p: Partial<Scheme>) => {
    if (p.ratePct !== undefined && cofSet) {
      const minM = marginBps(bank.category) / 100;
      const standard = cofPct + minM;
      // Floor MSER rate at CoF — cannot go below Treasury cost.
      const clampedRate = Math.max(cofPct, p.ratePct);
      const discBps = Math.round((standard - clampedRate) * 100);
      const clampedDisc = Math.max(0, discBps);
      setS((prev) => ({
        ...prev,
        discretionBps: clampedDisc,
        mser: { ...prev.mser, ...p, ratePct: clampedRate },
      }));
      return;
    }
    patchScheme("mser", p);
  };


  // Discretion slider → drive MSER rate = cof + minMargin − disc/100.
  // Discretion is capped at min margin so rate never drops below CoF.
  const setDiscretion = (bps: number) => {
    if (!cofSet) { patch({ discretionBps: bps }); return; }
    const minMBps = marginBps(bank.category);
    const cappedBps = Math.min(bps, minMBps);
    const finalRate = cofPct + minMarginPct - cappedBps / 100;
    setS((prev) => ({ ...prev, discretionBps: cappedBps, mser: { ...prev.mser, ratePct: finalRate } }));
  };



  const onBankChange = (id: string) => {
    const b = BANKS.find((x) => x.id === id)!;
    const maxD = discretionMaxBps(b.category);
    const newDisc = Math.min(b.suggestedDiscretionBps, maxD);
    const newMinM = marginBps(b.category) / 100;
    setS((prev) => {
      const finalRate = cofSet
        ? Math.max(cofPct, cofPct + newMinM - newDisc / 100)
        : prev.mser.ratePct;
      return { ...prev, bankId: id, discretionBps: newDisc, mser: { ...prev.mser, ratePct: finalRate } };
    });
  };

  const setCofRate = (key: string, v: number | null) => {
    setCofList((prev) => prev.map((c) => (c.key === key ? { ...c, ratePct: v } : c)));
    // If the user is editing the currently-selected CoF tenor, retune MSER rate.
    if (key === cofKey && v !== null) {
      const finalRate = Math.max(v, v + minMarginPct - s.discretionBps / 100);
      setS((prev) => ({ ...prev, mser: { ...prev.mser, ratePct: finalRate } }));
    }
  };
  const setBenchmarkFromList = (label: string) => {
    const b = benchmarkList.find((x) => x.label === label);
    if (!b) return;
    patch({ benchmarkLabel: b.label, benchmarkPct: b.ratePct ?? s.benchmarkPct });
  };

  const { mserAmt, rmseAmt } = schemeAmounts(s);

  const compute = useMemo(() => {
    // WAR (12 month) — same deal structure re-cut with a 12-month tenor on every tranche.
    const war12Of = (freq: Frequency) => effectiveRateWindow(s, freq, 12).effective;
    const perFreq = FREQUENCIES.filter((f) => f.key !== "custom").map((f) => {
      const r = effectiveRateForFreq(s, f.key);
      const cf = combinedCashflows(s, f.key);
      const irr = xirr(cf);
      const irrA = irrAnnualPct(s, f.key);
      return { key: f.key, label: f.label, ...r, xirr: irr, irr: irrA, war12: war12Of(f.key) };
    });
    const chosen = s.repaymentFreq === "custom"
      ? (() => {
          const r = effectiveRateForFreq(s, "custom");
          const cf = combinedCashflows(s, "custom");
          const tail = s.customTailMonths ?? 3;
          return { key: "custom" as Frequency, label: `Custom · last ${tail}m`, ...r, xirr: xirr(cf), irr: irrAnnualPct(s, "custom"), war12: war12Of("custom") };
        })()
      : perFreq.find((r) => r.key === s.repaymentFreq)!;

    const floor = mserFloor(s, bank.category, cofPct);
    const rmseRate = s.rmse.ratePct;

    // MSER rate quoted to the borrower = user-controlled s.mser.ratePct (linked to discretion slider).
    const mserQuoted = s.mser.ratePct;
    const denom = Math.max(1e-9, mserAmt * (s.mser.tenureMonths / 12) + rmseAmt * (s.rmse.tenureMonths / 12));
    // Post-negotiation blended rate — weighted by Amt × Tenure_yr (Excel Entry Sheet D24 pattern).
    const blendedFinal =
      (mserQuoted * mserAmt * (s.mser.tenureMonths / 12) +
        rmseRate * rmseAmt * (s.rmse.tenureMonths / 12)) / denom;
    // WAR — weighted avg of the CURRENTLY QUOTED scheme rates (Excel "WAR" sheet).
    const war = weightedAvgRate(s);
    // MSER Cost of Funds (from Treasury). RMSE CoF is fixed by policy and excluded.
    const fundingCoF = cofPct;
    return { perFreq, chosen, floor, rmseRate, mserQuoted, blendedFinal, war: war.war, fundingCoF };
  }, [s, bank, cofPct, mserAmt, rmseAmt]);

  const maxDiscretion = discretionMaxBps(bank.category);
  const minMarginPct = marginBps(bank.category) / 100;

  // MSER rows (base + splits) with their own CoF — used for per-split rate pills
  // and per-split floor build-ups in Live Output.
  const mserRateRows = useMemo(() => {
    const mserSplits = (s.splits ?? []).filter((sp) => sp.scheme === "mser");
    const resolve = (k: string) => ({
      pct: resolveCofPct(k, cofListLive, floatingSpreadBps),
      label: cofListLive.find((c) => c.key === k)?.tenorLabel ?? "—",
    });

    const rows = [
      {
        id: "base",
        label: mserSplits.length > 0 ? "MSER 1" : "MSER",
        ratePct: s.mser.ratePct,
        cofPct: cofSet ? cofPct : null,
        cofLabel: cof.tenorLabel,
      },
      ...mserSplits.map((sp, i) => {
        const c = resolve(sp.cofKey ?? cofKey);
        return {
          id: sp.id,
          label: `MSER ${i + 2}`,
          ratePct: sp.ratePct,
          cofPct: c.pct,
          cofLabel: c.label,
        };
      }),
    ];
    return rows;
  }, [s, cofListLive, customCofPct, floatingSpreadBps, cofKey, cofPct, cofSet, cof]);

  // RMSE rows (base + splits) — each split draws from its own tranche, so the
  // rate can differ per leg. Used for per-leg rate pills in Live Output.
  const rmseRateRows = useMemo(() => {
    const rmseSplits = (s.splits ?? []).filter((sp) => sp.scheme === "rmse");
    return [
      {
        id: "rmse-base",
        label: rmseSplits.length > 0 ? "RMSE 1" : "RMSE",
        ratePct: s.rmse.ratePct,
        sub: rmseSplits.length > 0 ? "base tranche" : `fixed ${s.rmse.ratePct.toFixed(2)}%`,
      },
      ...rmseSplits.map((sp, i) => ({
        id: sp.id,
        label: `RMSE ${i + 2}`,
        ratePct: sp.ratePct,
        sub: sp.label || "tranche",
      })),
    ];
  }, [s]);



  // MSER rate is now user-editable and driven explicitly by the discretion slider,
  // CoF, and bank handlers above — no force-sync effect (that used to overwrite typed values).

  // RMSE rate is fixed by policy: 3.50% (RBI fund) + 75 bps = 4.25%. Hard cap.



  return (
    <div className="min-h-screen bg-mds-surface">
      <Tabs defaultValue="negotiation" className="space-y-0">
      {/* Header */}
      <header className="bg-white border-b border-border sticky top-0 z-20">
        <div className="max-w-[1400px] mx-auto px-6 py-3 flex items-center gap-6">
          <img src={sidbiLogoAsset.url} alt="SIDBI" width={128} height={64} className="h-12 w-auto" />
          <div className="border-l border-border pl-4">
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground">SIDBI Refinance</div>
            <h1 className="text-lg font-bold text-mds-navy leading-tight">Pricing Negotiation Dashboard</h1>
          </div>
          <TabsList className="ml-4">
            <TabsTrigger value="negotiation">Negotiation</TabsTrigger>
            <TabsTrigger value="calculations">Detailed Calculations</TabsTrigger>
          </TabsList>
          <div className="ml-auto flex items-center gap-3">
            
            <BankSelector bank={bank.id} onChange={onBankChange} />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" disabled={!cofSet} className="gap-2">
                  <Download className="h-4 w-4" /> Export <ChevronDown className="h-3 w-3 opacity-70" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem
                  className="gap-2 cursor-pointer"
                  onClick={() => exportDealToExcel(s, bank, cofPct, cof.label, market.data)}
                >
                  <FileSpreadsheet className="h-4 w-4 text-mds-success" /> Excel workbook
                </DropdownMenuItem>
                <DropdownMenuItem
                  className="gap-2 cursor-pointer"
                  onClick={() => exportDealToPdf(s, bank, {
                    floating: isFloatingCof,
                    benchmarkName: cof.benchmark === "tbill3m" ? "3M T-Bill" : cof.benchmark === "repo" ? "Repo Rate" : undefined,
                    benchmarkPct: isFloatingCof ? (cof.ratePct ?? undefined) : undefined,
                    spreadBps: floatSpread,
                    baseTrancheId: (() => {
                      try { return window.localStorage.getItem("sidbi.rmse.baseTranche") ?? undefined; }
                      catch { return undefined; }
                    })(),
                  })}

                >
                  <FileText className="h-4 w-4 text-mds-danger" /> Counterparty term sheet (PDF)
                </DropdownMenuItem>
                <DropdownMenuItem className="gap-2 cursor-pointer" onClick={() => window.print()}>
                  <FileText className="h-4 w-4 text-muted-foreground" /> Print current view
                </DropdownMenuItem>
              </DropdownMenuContent>

            </DropdownMenu>
          </div>
        </div>
      </header>



      <main className="max-w-[1400px] mx-auto px-6 py-6 space-y-6">
        {/* HERO STRIP */}
        <div className="grid grid-cols-1 gap-4">
          <Card className="bg-gradient-to-br from-mds-blue via-[oklch(0.48_0.16_255)] to-mds-purple text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-[10px] uppercase tracking-widest text-white/60">WAR · {compute.chosen.label}</div>
                  <div className="text-5xl font-bold tabular mt-2">
                    {cofSet ? compute.chosen.effective.toFixed(2) : "—"}
                    <span className="text-2xl text-white/70">%</span>
                  </div>
                  <div className="text-xs text-white/70 mt-1">
                    MSER {cofSet ? compute.mserQuoted.toFixed(2) : "—"}% · RMSE {compute.rmseRate.toFixed(2)}%
                  </div>
                  {cofSet && s.discretionBps === 0 && compute.mserQuoted > compute.floor.standard + 1e-6 && (
                    <div className="mt-2 inline-flex items-center gap-1.5 rounded-md bg-mds-success/25 border border-mds-success/40 px-2.5 py-1 text-[11px] font-medium text-white">
                      <TrendingUp className="h-3 w-3" />
                      Margin +{Math.round((compute.mserQuoted - compute.floor.standard) * 100)} bps above min prescribed
                    </div>
                  )}
                </div>
                <div className="flex flex-col items-end gap-2">
                  <Badge className="bg-white/15 hover:bg-white/15 text-white border-0">{bank.name}</Badge>
                </div>

              </div>
              <div className="mt-5 grid grid-cols-2 md:grid-cols-6 gap-4 text-white/90">
                <MiniStat label="WAR (12 MONTH)" value={cofSet ? `${compute.chosen.war12.toFixed(2)}%` : "—"} />
                <MiniStat label={`XIRR · ${compute.chosen.label}`} value={cofSet && isFinite(compute.chosen.xirr) ? `${compute.chosen.xirr.toFixed(2)}%` : "—"} />
                <MiniStat label={`IRR (ann.) · ${compute.chosen.label}`} value={cofSet && isFinite(compute.chosen.irr) ? `${compute.chosen.irr.toFixed(2)}%` : "—"} />
                <MiniStat label="MSER CoF" value={cofSet ? `${compute.fundingCoF.toFixed(2)}%` : "—"} />
                <MiniStat label="Margin over CoF" value={cofSet ? `${Math.round((compute.mserQuoted - compute.fundingCoF) * 100)} bps` : "—"} />
                <MiniStat
                  label="Spread + Margin"
                  value={cofSet ? `${Math.round(floatSpread + (compute.mserQuoted - compute.fundingCoF) * 100)} bps` : "—"}
                  note={
                    cofSet
                      ? `Spread ${Math.round(floatSpread)} bps · Margin ${Math.round((compute.mserQuoted - compute.fundingCoF) * 100)} bps`
                      : undefined
                  }
                />


              </div>










              {/* Deal composition — single block */}
              <div className="mt-5 pt-4 border-t border-white/15">
                <div className="rounded-md bg-white/5 px-3 py-2">
                  <div className="text-[11px] text-white/50 uppercase tracking-wider mb-1">Deal Composition</div>
                  <div className="divide-y divide-white/10">
                    {[
                      {
                        label: "MSER",
                        structure: compute.chosen.label,
                        amt: mserAmt,
                        share: s.mserSharePct,
                        rate: compute.mserQuoted,
                        tenure: s.mser.tenureMonths,
                        morat: s.mser.moratoriumMonths,
                        cof: cofSet ? `${cofPct.toFixed(2)}%` : "—",
                      },
                      {
                        label: "RMSE",
                        structure: "Bullet",
                        amt: rmseAmt,
                        share: 100 - s.mserSharePct,
                        rate: compute.rmseRate,
                        tenure: s.rmse.tenureMonths,
                        morat: s.rmse.moratoriumMonths,
                        cof: `${RMSE_FIXED_RATE.toFixed(2)}%`,
                      },
                    ].map((row) => (
                      <div
                        key={row.label}
                        className="py-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm font-semibold text-white tabular"
                      >
                        <span className="min-w-[140px]">
                          {row.label} · {row.structure}
                        </span>
                        <span className="min-w-[150px]">
                          ₹{row.amt.toFixed(2)} Cr <span className="text-white/70">· {row.share.toFixed(2)}%</span>
                        </span>
                        <div className="flex flex-wrap gap-x-4 gap-y-1 ml-auto">
                          <span>Rate <span>{row.rate.toFixed(2)}%</span></span>
                          <span>Tenure <span>{row.tenure}m</span></span>
                          <span>Morat <span>{row.morat}m</span></span>
                          <span>CoF <span>{row.cof}</span></span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>




              {/* Margin / Discretion / Approval status */}
              {(() => {
                const minMBps = marginBps(bank.category);
                const overBps = Math.max(0, s.discretionBps - maxDiscretion);
                const scaBps = Math.min(s.discretionBps, maxDiscretion);
                const quoted = compute.mserQuoted;
                const belowCof = cofSet && quoted < cofPct - 1e-6;
                const premiumBps = cofSet && s.discretionBps === 0
                  ? Math.round((quoted - compute.floor.standard) * 100)
                  : 0;
                const hasPremium = premiumBps > 0;

                let approval: { label: string; tone: "danger" | "warning" | "success" | "neutral" };
                if (belowCof) approval = { label: "ALCO + Treasury Approval", tone: "danger" };
                else if (overBps > 0) approval = { label: `ALCO Approval (+${overBps} bps over SCA)`, tone: "danger" };
                else if (scaBps > 0) approval = { label: `SCA Approval (${scaBps} bps discretion)`, tone: "warning" };
                else if (hasPremium) approval = { label: `Priced +${premiumBps} bps above Min Margin · no approval`, tone: "success" };
                else approval = { label: "Within Standard · no approval needed", tone: "neutral" };

                const toneCls =
                  approval.tone === "danger"  ? "bg-mds-danger/25  border-mds-danger/40  text-white" :
                  approval.tone === "warning" ? "bg-mds-warning/25 border-mds-warning/40 text-white" :
                  approval.tone === "success" ? "bg-mds-success/25 border-mds-success/40 text-white" :
                                                "bg-white/10 border-white/20 text-white/90";

                return (
                  <div className="mt-3 grid grid-cols-2 md:grid-cols-3 gap-3 text-[11px]">
                    <div className="rounded-md bg-white/5 px-3 py-2">
                      <div className="text-white/50 uppercase tracking-wider">Min Margin</div>
                      <div className="text-sm font-semibold text-white tabular">{minMBps} bps · {bank.categoryLabel}</div>
                    </div>
                    <div className="rounded-md bg-white/5 px-3 py-2">
                      <div className="text-white/50 uppercase tracking-wider">Discretion Applied</div>
                      <div className="text-sm font-semibold text-white tabular">
                        {s.discretionBps} / {maxDiscretion} bps
                        {overBps > 0 && <span className="ml-1 text-mds-danger">· +{overBps} over</span>}
                      </div>
                    </div>
                    <div className={cn("rounded-md px-3 py-2 border", toneCls)}>
                      <div className="text-white/60 uppercase tracking-wider">Approval Status</div>
                      <div className="text-sm font-semibold">{approval.label}</div>
                    </div>
                  </div>
                );
              })()}

              {/* Negotiation Range now lives in the Live Output column. */}

              {!cofSet && (
                <div className="mt-4 text-[11px] text-white/70 border-t border-white/15 pt-3">
                  Enter Treasury Cost of Funds below to see the negotiation floor and spread.
                </div>
              )}
            </CardContent>
          </Card>
        </div>




          {/* ================ NEGOTIATION ================ */}
          <TabsContent value="negotiation" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* ==================== LEFT — INPUTS ==================== */}
            <div className="lg:col-span-6 flex flex-col gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2">
                  <span className="w-1 h-4 bg-mds-blue rounded" /> Deal Structure
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">


                  {/* ---------- DEAL SIZE & MIX ---------- */}
                  <div className="grid grid-cols-3 gap-3">
                      <Field label="Principal (₹ Cr)">
                        <NumberField value={s.principalCr}
                          onCommit={(v) => patch({ principalCr: v ?? 0 })}
                          className="h-9 tabular" />
                      </Field>
                      <Field label="MSER Amount (₹ Cr)">
                        <NumberField
                          value={Number(mserAmt.toFixed(2))}
                          step="0.01" min={0} max={s.principalCr}
                          onCommit={(raw) => {
                            const v = Math.max(0, Math.min(s.principalCr, raw ?? 0));
                            patch({ mserSharePct: s.principalCr > 0 ? (v / s.principalCr) * 100 : 0 });
                          }}
                          className="h-9 tabular" />
                      </Field>
                      <Field label="RMSE Amount (₹ Cr)">
                        <NumberField
                          value={Number(rmseAmt.toFixed(2))}
                          step="0.01" min={0} max={s.principalCr}
                          onCommit={(raw) => {
                            const v = Math.max(0, Math.min(s.principalCr, raw ?? 0));
                            const mser = Math.max(0, s.principalCr - v);
                            patch({ mserSharePct: s.principalCr > 0 ? (mser / s.principalCr) * 100 : 0 });
                          }}
                          className="h-9 tabular" />
                      </Field>

                  </div>

                  {/* ---------- MSER ---------- */}
                  <section className="space-y-2">
                    <div className="flex items-center justify-between">
                      <SubHead title="MSER" />
                      <Badge variant="outline" className="text-[10px] font-normal">₹{mserAmt.toFixed(2)} Cr</Badge>
                    </div>

                    <MserLegs
                      state={s}
                      mserAmt={mserAmt}
                      cofOptions={cofListLive}
                      cofKey={cofKey}
                      setCofKey={setCofKey}
                      cofPct={cofPct}
                      cofSet={cofSet}
                      minMarginBps={marginBps(bank.category)}
                      maxDiscretionBps={maxDiscretion}
                      isFloatingCof={isFloatingCof}
                      isCustomCof={isCustomCof}
                      floatSpread={floatSpread}
                      floatingSpreadBps={floatingSpreadBps}
                      setFloatingSpread={setFloatingSpread}

                      customCofPct={customCofPct}
                      setCustomCof={setCustomCof}
                      customFloatBench={customFloatBench}
                      setCustomFloatBench={setCustomFloatBench}
                      customFloatBase={customFloatBase}
                      setCustomFloatValue={setCustomFloatValue}

                      benchmarkLabel={cof.benchmark === "repo" ? "Repo" : "3M T-Bill"}
                      cofTenorMax={cof.type === "fixed" ? cof.tenorMonths ?? undefined : undefined}
                      patch={patch}
                      patchMserScheme={patchMserScheme}
                      onAdd={() => patch({ splits: [...(s.splits ?? []), nextSplit(s, "mser", mserAmt, rmseAmt)] })}
                      canAdd={(s.splits ?? []).length < MAX_SPLITS}
                    />
                  </section>

                  {/* ---------- RMSE ---------- */}
                  <section className="space-y-2">
                    <div className="flex items-center justify-between">
                      <SubHead title="RMSE" />
                      <Badge variant="outline" className="text-[10px] font-normal">₹{rmseAmt.toFixed(2)} Cr</Badge>
                    </div>

                    <RmseLegs
                      state={s}
                      rmseAmt={rmseAmt}
                      patch={patch}
                      patchScheme={patchScheme}
                      onAdd={() => patch({ splits: [...(s.splits ?? []), nextSplit(s, "rmse", mserAmt, rmseAmt)] })}
                      canAdd={(s.splits ?? []).length < MAX_SPLITS}
                    />
                  </section>


                </CardContent>
              </Card>




              {/* ==================== MARKET RATES ==================== */}
              <Card className="flex-1 flex flex-col">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <span className="w-1 h-4 bg-mds-navy rounded" /> Market Rates
                      <span className="inline-block rounded bg-amber-100 text-amber-800 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5">Illustrative</span>
                    </span>

                    <span className="text-[10px] font-normal normal-case tracking-normal text-muted-foreground inline-flex items-center gap-1">
                      <Info className="h-3 w-3" /> Click for details
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col gap-4">
                  <CounterpartyActivitySection
                    bank={bank}
                    live={counterparty.data.deposits}
                    activity={counterparty.data.announcements}
                    loading={counterparty.loading}
                    fetchedAt={counterparty.data.fetchedAt}
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="h-1.5 w-1.5 rounded-full bg-mds-success" />
                      <span className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">Govt Securities</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      {MARKET_INSTRUMENTS.filter((m) => m.category !== "policy" && m.key !== "cd1y" && m.key !== "cp1y").map((m) => {
                        const live = (market.data as unknown as Record<string, { value: number | null; source: string | null } | undefined>)[m.key];
                        const displayValue = live?.value ?? null;
                        return (
                          <InstrumentTile key={m.key} inst={m} onOpen={() => setOpenInstrument(m)} accent="navy"
                            liveValue={displayValue} liveAsOf={market.data.fetchedAt} />
                        );
                      })}
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <span className="h-1.5 w-1.5 rounded-full bg-mds-blue" />
                      <span className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">Policy Corridor · RBI</span>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      {MARKET_INSTRUMENTS.filter((m) => m.category === "policy").map((m) => {
                        const live = (market.data as unknown as Record<string, { value: number | null; source: string | null } | undefined>)[m.key];
                        return (
                          <InstrumentTile key={m.key} inst={m} onOpen={() => setOpenInstrument(m)} accent="blue"
                            liveValue={live?.value ?? null} liveAsOf={market.data.fetchedAt} />
                        );
                      })}
                    </div>
                  </div>


                </CardContent>

              </Card>

              </div>


              {/* ==================== RIGHT — ALL OUTPUTS ==================== */}
              <div className="lg:col-span-6 flex flex-col gap-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2">
                      <span className="w-1 h-4 bg-mds-success rounded" /> Live Output
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {!cofSet && (
                      <div className="flex items-start gap-2 rounded-md bg-mds-warning/10 border border-mds-warning/30 p-3 text-xs">
                        <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0 text-mds-warning" />
                        <div>Enter Treasury <strong>Cost of Funds</strong> in the input panel to see the floor.</div>
                      </div>
                    )}

                    <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
                      <MultiRatePill
                        label="MSER Rate"
                        tone="blue"
                        rows={mserRateRows.map((r) => ({
                          id: r.id,
                          label: r.label,
                          sub: r.cofPct !== null ? `CoF ${r.cofPct.toFixed(2)}% · ${r.cofLabel}` : undefined,
                          value: r.cofPct !== null ? r.ratePct : null,
                        }))}
                      />

                      <MultiRatePill
                        label="RMSE Rate"
                        tone="navy"
                        rows={rmseRateRows.map((r) => ({ id: r.id, label: r.label, sub: r.sub, value: r.ratePct }))}
                      />

                      <FinalPill label="WAR" sub={compute.chosen.label} value={cofSet ? compute.chosen.effective : null} tone="success" />
                      <FinalPill label="WAR (12 month)" sub="12-month tenor" value={cofSet ? compute.chosen.war12 : null} tone="success" />
                      <FinalPill label="XIRR" sub="dated cashflows" value={cofSet && isFinite(compute.chosen.xirr) ? compute.chosen.xirr : null} tone="purple" />
                      <FinalPill label="IRR" sub="annualised" value={cofSet && isFinite(compute.chosen.irr) ? compute.chosen.irr : null} tone="purple" />
                    </div>




                    {mserRateRows.map((row) => (
                      <MserFloorPanel
                        key={row.id}
                        title={mserRateRows.length > 1 ? `${row.label} — Floor Build-up` : "MSER Floor Build-up"}
                        rateLabel={mserRateRows.length > 1 ? `Final ${row.label} Rate` : "Final MSER Rate"}
                        ratePct={row.ratePct}
                        cofPct={row.cofPct}
                        cofLabel={row.cofLabel}
                        minMarginBps={marginBps(bank.category)}
                        maxDiscretionBps={maxDiscretion}
                        categoryLabel={bank.categoryLabel}
                      />
                    ))}


                    {/* ============ SOLVE FOR TARGET — section, pops out ============ */}
                    <div className="rounded-lg border border-mds-purple/30 bg-mds-purple/5 px-3 py-2.5 flex items-center justify-between gap-3">
                      <div>
                        <div className="text-[11px] font-semibold uppercase tracking-wider text-mds-navy">Solve for target</div>
                        <div className="text-[10px] text-muted-foreground">
                          Reverse-solve deal parameters for a target XIRR or WAR
                        </div>
                      </div>
                      <GoalSeekLauncher
                        state={s}
                        chosenFreq={s.repaymentFreq}
                        currentXirr={compute.chosen.xirr}
                        currentWar={compute.war}
                        onApply={(variable, value, legId) => {
                          if (legId === "base") {
                            if (variable === "mserRate") patchMserScheme({ ratePct: value as number });
                            else if (variable === "mserShare") patch({ mserSharePct: value as number });
                            else if (variable === "mserTenure") patchScheme("mser", { tenureMonths: Math.round(value as number) });
                            else if (variable === "mserFreq") patch({ repaymentFreq: value as Frequency });
                            return;
                          }
                          const next = (s.splits ?? []).map((sp) => {
                            if (sp.id !== legId) return sp;
                            if (variable === "mserRate") return { ...sp, ratePct: value as number };
                            if (variable === "mserShare") return { ...sp, amountCr: value as number };
                            if (variable === "mserTenure") return { ...sp, tenureMonths: Math.round(value as number) };
                            return { ...sp, freq: value as Frequency };
                          });
                          patch({ splits: next });
                        }}
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* ============ NEGOTIATION RANGE ============ */}
                {cofSet && (() => {
                  const liveDepRates = (counterparty.data.deposits.rows ?? [])
                    .flatMap((d) => [d.callable, d.nonCallable, d.nonCallableMax ?? null])
                    .filter((v): v is number => v !== null && v !== undefined);
                  const staticDepRates = bank.deposits
                    .flatMap((d) => [d.nonCallable, d.callable])
                    .filter((v): v is number => v !== null && v !== undefined);
                  const depRates = liveDepRates.length ? liveDepRates : staticDepRates;
                  const maxBulk = depRates.length ? Math.max(...depRates) : null;
                  const gsecInst = MARKET_INSTRUMENTS.find((m) => m.key === "gsec10");
                  const cpInst = MARKET_INSTRUMENTS.find((m) => m.key === "cp1y");
                  const cdInst = MARKET_INSTRUMENTS.find((m) => m.key === "cd1y");
                  const gsec10 = market.data.gsec10.value ?? gsecInst?.latest ?? null;
                  const cp1y = market.data.cp1y.value ?? cpInst?.latest ?? null;
                  const cd1y = market.data.cd1y.value ?? cdInst?.latest ?? null;
                  const quote = latestQuoteRate(deskQuotes);
                  const standard = compute.floor.standard;
                  const upper = [maxBulk, cd1y, quote?.rate ?? null].filter((v): v is number => v !== null);
                  const ceiling = upper.length ? Math.max(...upper) : Math.max(standard + 1.5, cofPct + 2);
                  return (
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2">
                          <span className="w-1 h-4 bg-mds-blue rounded" /> Negotiation Range
                        </CardTitle>
                        <div className="text-[10px] text-muted-foreground mt-1">
                          Treasury cost of funds to bank funding alternative
                        </div>
                      </CardHeader>
                      <CardContent>
                        <NegotiationRangeBar
                          min={cofPct}
                          max={ceiling}
                          markers={[
                            { key: "cof", label: "Cost of Funds", value: cofPct, color: "var(--mds-success)", position: "top" },
                            { key: "current", label: "MSER Quote", value: compute.mserQuoted, color: "var(--mds-blue)", position: "top" },
                            { key: "war", label: `WAR · ${compute.chosen.label}`, value: compute.chosen.effective, color: "var(--mds-navy)", position: "top" },
                            ...(quote !== null ? [{ key: "deskquote", label: quote.label, value: quote.rate, color: "#B3202C", position: "bottom" as const }] : []),
                            ...(gsec10 !== null ? [{ key: "gsec", label: "10Y G-Sec", value: gsec10, color: "var(--mds-purple)", position: "bottom" as const }] : []),
                            ...(cd1y !== null ? [{ key: "cd", label: "CD 1Y (bulk)", value: cd1y, color: "#7C3AED", position: "bottom" as const }] : []),
                            ...(cp1y !== null ? [{ key: "cp", label: "CP 1Y", value: cp1y, color: "#0E7C66", position: "bottom" as const }] : []),
                            ...(maxBulk !== null ? [{ key: "bulkmax", label: "Bulk Deposit Max", value: maxBulk, color: "var(--mds-warning)", position: "bottom" as const }] : []),
                          ]}
                        />
                      </CardContent>

                    </Card>
                  );
                })()}

                <PastDealsCard deals={bank.pastDeals} bankName={bank.name} bankId={bank.id} bankCategory={bank.category} cofOptions={cofListLive} />

              </div>
            </div>
          </TabsContent>




          {/* ================ CALCULATIONS ================ */}
          <TabsContent value="calculations" className="space-y-4">
            <DetailedCalcs state={s} cofPct={cofPct} cofLabel={cof.label} chosenFreq={s.repaymentFreq} />

          </TabsContent>
      </main>
      </Tabs>


      <InstrumentDetail inst={openInstrument} onClose={() => setOpenInstrument(null)} />

      <footer className="max-w-[1400px] mx-auto px-6 py-6 text-xs text-muted-foreground space-y-1">
        <div>Indicative pricing tool · Policy rates scraped live from rbi.org.in · Treasury CoF entered by desk · Discretion beyond limits requires ALCO approval.</div>

      </footer>
    </div>
  );
}

// ============ Small components ============


function BankSelector({ bank, onChange }: { bank: string; onChange: (id: string) => void }) {
  const current = BANKS.find((b) => b.id === bank);
  const [type, setType] = useState<BankType>(current?.bankType ?? "PVT");
  useEffect(() => { if (current && current.bankType !== type) setType(current.bankType); }, [bank]);

  const inType = BANKS.filter((b) => b.bankType === type)
    .slice()
    .sort((a, b) => a.name.localeCompare(b.name));

  const onTypeChange = (t: string) => {
    const next = t as BankType;
    setType(next);
    const first = BANKS.filter((b) => b.bankType === next)
      .slice()
      .sort((a, b) => a.name.localeCompare(b.name))[0];
    if (first && first.id !== bank) onChange(first.id);
  };

  return (
    <div className="flex items-center gap-2">
      <Select value={type} onValueChange={onTypeChange}>
        <SelectTrigger className="h-9 w-[190px]"><SelectValue placeholder="Type of bank" /></SelectTrigger>
        <SelectContent>
          {BANK_TYPES.map((t) => (
            <SelectItem key={t.key} value={t.key}>{t.label}</SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Select value={bank} onValueChange={onChange}>
        <SelectTrigger className="h-9 w-[250px]"><SelectValue placeholder="Select bank" /></SelectTrigger>
        <SelectContent>
          {inType.map((bk) => (
            <SelectItem key={bk.id} value={bk.id}>
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-sm flex items-center justify-center text-[10px] font-bold text-white" style={{ background: bk.color }}>
                  {bk.logoText.slice(0, 3)}
                </span>
                <span>{bk.name}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

/* ============================================================
   Deal structure — up to 5 additional splits across MSER / RMSE.
   Each split is one compact row: scheme, basis, amount, rate, tenure,
   moratorium, repayment.
   ============================================================ */
const MAX_SPLITS = 5;

function nextSplit(state: DealState, scheme: "mser" | "rmse", mserAmt: number, rmseAmt: number): DealSplit {
  const base = scheme === "mser" ? state.mser : state.rmse;
  const room = Math.max(0, (scheme === "mser" ? mserAmt : rmseAmt) - splitTotal(state, scheme));
  const n = (state.splits ?? []).filter((s) => s.scheme === scheme).length + 2;
  return {
    id: `${scheme}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    scheme,
    label: `${scheme.toUpperCase()} ${n}`,
    basis: scheme === "mser" ? "floating" : undefined,
    amountCr: Math.round((room > 0 ? room / 2 : 0) * 100) / 100,
    ratePct: base.ratePct,
    tenureMonths: base.tenureMonths,
    moratoriumMonths: base.moratoriumMonths,
    freq: scheme === "mser" ? state.repaymentFreq : "bullet",
  };
}

const LEG_INPUT = "h-9 text-sm tabular bg-white";
const LEG_SELECT = "h-9 text-sm bg-white";

/** One labelled input inside a deal row — same format as Principal / MSER / RMSE amount. */
function Cell({ label, children, span }: { label: string; children: React.ReactNode; span?: string }) {
  return (
    <div className={cn("min-w-0 space-y-1.5", span)}>
      <Label className="text-xs text-muted-foreground leading-tight block">{label}</Label>
      {children}
    </div>
  );
}

/**
 * A single deal row. `label` (e.g. "MSER 2") is only shown when there is more
 * than one row of that scheme — a lone row needs no numbering.
 */
function LegRow({ label, right, onRemove, children }: {
  label?: string; right?: React.ReactNode; onRemove?: () => void; children: React.ReactNode;
}) {
  const showHeader = !!label || !!right || !!onRemove;
  return (
    <div className="py-3 first:pt-0 last:pb-0">
      {showHeader && (
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2 min-w-0">
            {label && (
              <span className="rounded bg-mds-blue/10 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wider text-mds-blue">
                {label}
              </span>
            )}
            {right}
          </div>
          {onRemove && (
            <button type="button" onClick={onRemove} aria-label={`Remove ${label ?? "row"}`}
              className="h-6 w-6 inline-flex items-center justify-center rounded text-muted-foreground hover:text-destructive">
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      )}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-3 gap-y-2.5">
        {children}
      </div>
    </div>
  );
}


function LegReadonly({ value }: { value: string }) {
  return (
    <div className="h-9 flex items-center px-2 rounded-md border border-border bg-secondary/40 text-sm tabular text-foreground">
      {value}
    </div>
  );
}

/* ============================================================
   MSER rows — first row plus splits, all rendered identically.
   ============================================================ */
function MserLegs({
  state, mserAmt, cofOptions, cofKey, setCofKey, cofPct, cofSet, minMarginBps, maxDiscretionBps,
  isFloatingCof, isCustomCof, floatSpread, floatingSpreadBps, setFloatingSpread, customCofPct, setCustomCof,
  customFloatBench, setCustomFloatBench, customFloatBase, setCustomFloatValue,
  benchmarkLabel, cofTenorMax, patch, patchMserScheme, onAdd, canAdd,
}: {
  state: DealState;
  mserAmt: number;
  cofOptions: CofOption[];
  cofKey: string;
  setCofKey: (v: string) => void;
  cofPct: number;
  cofSet: boolean;
  minMarginBps: number;
  maxDiscretionBps: number;
  isFloatingCof: boolean;
  isCustomCof: boolean;
  floatSpread: number;
  floatingSpreadBps: Record<string, number>;
  setFloatingSpread: (v: number, key?: string) => void;

  customCofPct: number | null;
  setCustomCof: (v: number | null) => void;
  customFloatBench: "repo" | "tbill3m";
  setCustomFloatBench: (v: "repo" | "tbill3m") => void;
  customFloatBase: number | null;
  setCustomFloatValue: (v: number | null) => void;

  benchmarkLabel: string;
  cofTenorMax?: number;
  patch: (p: Partial<DealState>) => void;
  patchMserScheme: (p: Partial<Scheme>) => void;
  onAdd: () => void;
  canAdd: boolean;
}) {
  const allSplits = state.splits ?? [];
  const splits = allSplits.filter((sp) => sp.scheme === "mser");
  const updateSplit = (id: string, p: Partial<DealSplit>) =>
    patch({ splits: allSplits.map((x) => (x.id === id ? { ...x, ...p } : x)) });
  const removeSplit = (id: string) => patch({ splits: allSplits.filter((x) => x.id !== id) });
  const cofRate = (k?: string) => cofOptions.find((c) => c.key === k)?.ratePct ?? null;

  const baseAmt = baseLegAmount(state, "mser");
  const baseMarginBps = cofSet ? Math.round((state.mser.ratePct - cofPct) * 100) : 0;
  const maxMarginBps = 500;


  // Margin over CoF per MSER row — read-only status, driven by the Margin input.
  const rowCof = (k: string) => resolveCofPct(k, cofOptions, floatingSpreadBps);

  const marginRows: { id: string; label: string; bps: number }[] = [
    ...(cofSet ? [{
      id: "base",
      label: splits.length > 0 ? "MSER 1" : "MSER",
      bps: Math.round((state.mser.ratePct - cofPct) * 100),
    }] : []),
    ...splits.flatMap((sp, i) => {
      const base = rowCof(sp.cofKey ?? cofKey);
      return base === null ? [] : [{
        id: sp.id,
        label: `MSER ${i + 2}`,
        bps: Math.round((sp.ratePct - base) * 100),
      }];
    }),
  ];
  const scaFloorBps = Math.max(0, minMarginBps - maxDiscretionBps);


  const over = splitTotal(state, "mser") > mserAmt + 1e-6;
  const showTail = state.repaymentFreq === "custom" || splits.some((sp) => (sp.freq ?? state.repaymentFreq) === "custom");
  void showTail;

  const cofSelect = (value: string, onChange: (v: string) => void) => (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className={LEG_SELECT}><SelectValue placeholder="CoF" /></SelectTrigger>
      <SelectContent>
        {cofOptions.map((c) => {
          const bench = c.benchmark === "repo" ? "Repo" : "3M T-Bill";
          const type = c.type === "fixed" ? "Fixed"
            : c.type === "floating" ? "Floating"
            : c.key === "custom_float" ? "Floating · user" : "Fixed · user";
          const rate = c.type === "floating" ? bench : c.ratePct !== null ? `${c.ratePct.toFixed(2)}%` : "—";

          return (
            <SelectItem key={c.key} value={c.key} className="text-xs">
              <span className="tabular">
                <span className="font-medium">{c.tenorLabel}</span>
                <span className="text-muted-foreground"> · {type}</span>
                <span> · {rate}</span>
              </span>
            </SelectItem>
          );
        })}
      </SelectContent>
    </Select>
  );

  return (
    <div className="space-y-3">
      <div className="divide-y divide-border/70">
        {/* Base MSER row */}
        <LegRow label={splits.length > 0 ? "MSER 1" : undefined}>
          <Cell label="Treasury CoF" span="col-span-2">{cofSelect(cofKey, setCofKey)}</Cell>

          {cofKey === "custom_float" && (
            <>
              <Cell label="Benchmark">
                <Select value={customFloatBench} onValueChange={(v) => setCustomFloatBench(v as "repo" | "tbill3m")}>
                  <SelectTrigger className={LEG_SELECT}><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="repo" className="text-sm">Repo</SelectItem>
                    <SelectItem value="tbill3m" className="text-sm">3M T-Bill</SelectItem>
                  </SelectContent>
                </Select>
              </Cell>
              <Cell label="Benchmark %">
                <NumberField value={customFloatBase} step="0.01" allowNull
                  onCommit={(v) => setCustomFloatValue(v)} className={LEG_INPUT} />
              </Cell>
            </>
          )}
          <Cell label="Spread (bps)">
            {isFloatingCof ? (
              <NumberField value={floatSpread} step="1" min={0}
                onCommit={(v) => setFloatingSpread(Math.max(0, Math.round(v ?? 0)))}
                className={LEG_INPUT} />
            ) : (
              <LegReadonly value="—" />
            )}
          </Cell>
          <Cell label="CoF %">
            {isCustomCof ? (
              <NumberField value={customCofPct} step="0.01" allowNull
                onCommit={(v) => setCustomCof(v)} className={LEG_INPUT} />
            ) : (
              <LegReadonly value={cofSet ? `${cofPct.toFixed(2)}%` : "—"} />
            )}
          </Cell>

          <Cell label="Margin (bps)">

            <NumberField value={baseMarginBps} step="1" min={0} max={maxMarginBps} disabled={!cofSet}
              onCommit={(v) => { if (cofSet) patchMserScheme({ ratePct: cofPct + Math.max(0, Math.round(v ?? 0)) / 100 }); }}
              className={LEG_INPUT} />
          </Cell>

          <Cell label="Rate %"><LegReadonly value={cofSet ? `${state.mser.ratePct.toFixed(2)}%` : "—"} /></Cell>
          <Cell label="Amount ₹Cr">
            <NumberField value={+baseAmt.toFixed(2)} step="0.01" min={0} max={state.principalCr}
              onCommit={(v) => {
                const amt = Math.max(0, Math.min(state.principalCr, v ?? 0));
                const newMser = Math.min(state.principalCr, amt + splitTotal(state, "mser"));
                patch({ mserSharePct: state.principalCr > 0 ? (newMser / state.principalCr) * 100 : 0 });
              }}
              className={LEG_INPUT} />
          </Cell>
          <Cell label="Repayment">
            <Select value={state.repaymentFreq} onValueChange={(v) => patch({ repaymentFreq: v as Frequency })}>
              <SelectTrigger className={LEG_SELECT}><SelectValue /></SelectTrigger>
              <SelectContent>
                {FREQUENCIES.map((f) => <SelectItem key={f.key} value={f.key} className="text-sm">{f.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </Cell>
          <Cell label="Tenure (mo)">
            <NumberField value={state.mser.tenureMonths} step="1" min={1} max={cofTenorMax}
              onCommit={(v) => patchMserScheme({ tenureMonths: Math.max(1, Math.round(v ?? 1)) })}
              className={LEG_INPUT} />
          </Cell>
          <Cell label="Moratorium (mo)">
            <NumberField value={state.mser.moratoriumMonths} step="1" min={0}
              onCommit={(v) => patchMserScheme({ moratoriumMonths: Math.max(0, Math.round(v ?? 0)) })}
              className={LEG_INPUT} />
          </Cell>
          {state.repaymentFreq === "custom" && (
            <Cell label="Repay last (mo)">
              <NumberField value={state.customTailMonths ?? 3} step="1" min={1} max={state.mser.tenureMonths}
                onCommit={(v) => patch({ customTailMonths: Math.max(1, Math.min(state.mser.tenureMonths, Math.round(v ?? 3))) })}
                className={LEG_INPUT} />
            </Cell>
          )}
        </LegRow>

        {/* MSER splits */}
        {splits.map((r, i) => {
          const key = r.cofKey ?? cofKey;
          const opt = cofOptions.find((c) => c.key === key);
          const isFloat = isFloatingCofOpt(opt);
          const isCustomFixed = key === "custom";
          const isCustomFloat = key === "custom_float";
          // Spread over the benchmark is tracked per CoF option, so each split
          // with a floating CoF can carry (and edit) its own spread.
          const rowSpread = isFloat ? (floatingSpreadBps[key] ?? 0) : 0;
          const base = resolveCofPct(key, cofOptions, floatingSpreadBps);
          const freq = r.freq ?? state.repaymentFreq;
          return (
            <LegRow key={r.id} label={`MSER ${i + 2}`}
              onRemove={() => removeSplit(r.id)}>
              <Cell label="Treasury CoF" span="col-span-2">
                {cofSelect(key, (v) => {
                  const rate = resolveCofPct(v, cofOptions, floatingSpreadBps);
                  updateSplit(r.id, {
                    cofKey: v,
                    ratePct: rate !== null ? +(rate + (r.marginBps ?? minMarginBps) / 100).toFixed(2) : r.ratePct,
                  });
                })}
              </Cell>
              {isCustomFloat && (
                <>
                  <Cell label="Benchmark">
                    <Select value={customFloatBench} onValueChange={(v) => setCustomFloatBench(v as "repo" | "tbill3m")}>
                      <SelectTrigger className={LEG_SELECT}><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="repo" className="text-sm">Repo</SelectItem>
                        <SelectItem value="tbill3m" className="text-sm">3M T-Bill</SelectItem>
                      </SelectContent>
                    </Select>
                  </Cell>
                  <Cell label="Benchmark %">
                    <NumberField value={customFloatBase} step="0.01" allowNull
                      onCommit={(v) => setCustomFloatValue(v)} className={LEG_INPUT} />
                  </Cell>
                </>
              )}
              <Cell label="Spread (bps)">
                {isFloat ? (
                  <NumberField value={rowSpread} step="1" min={0}
                    onCommit={(v) => setFloatingSpread(Math.max(0, Math.round(v ?? 0)), key)}
                    className={LEG_INPUT} />
                ) : (
                  <LegReadonly value="—" />
                )}
              </Cell>

              <Cell label="CoF %">
                {isCustomFixed ? (
                  <NumberField value={customCofPct} step="0.01" allowNull
                    onCommit={(v) => setCustomCof(v)} className={LEG_INPUT} />
                ) : (
                  <LegReadonly value={base !== null ? `${base.toFixed(2)}%` : "—"} />
                )}
              </Cell>

              <Cell label="Margin (bps)">
                <NumberField value={r.marginBps ?? minMarginBps} step="1" min={0}
                  onCommit={(v) => {
                    const bps = Math.max(0, Math.round(v ?? 0));
                    updateSplit(r.id, {
                      marginBps: bps,
                      ratePct: base !== null ? +(base + bps / 100).toFixed(2) : r.ratePct,
                    });
                  }}
                  className={LEG_INPUT} />
              </Cell>
              <Cell label="Rate %"><LegReadonly value={`${r.ratePct.toFixed(2)}%`} /></Cell>

              <Cell label="Amount ₹Cr">
                <NumberField value={r.amountCr} step="0.01" min={0} max={state.principalCr}
                  onCommit={(v) => {
                    const amt = Math.max(0, Math.min(state.principalCr, v ?? 0));
                    const others = splitTotal(state, "mser") - r.amountCr;
                    const needed = amt + others;
                    const p: Partial<DealState> = { splits: allSplits.map((x) => (x.id === r.id ? { ...x, amountCr: amt } : x)) };
                    if (needed > mserAmt + 1e-9 && state.principalCr > 0)
                      p.mserSharePct = (Math.min(needed, state.principalCr) / state.principalCr) * 100;
                    patch(p);
                  }}
                  className={LEG_INPUT} />
              </Cell>
              <Cell label="Repayment">
                <Select value={freq} onValueChange={(v) => updateSplit(r.id, { freq: v as Frequency })}>
                  <SelectTrigger className={LEG_SELECT}><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {FREQUENCIES.map((f) => <SelectItem key={f.key} value={f.key} className="text-sm">{f.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Cell>
              <Cell label="Tenure (mo)">
                <NumberField value={r.tenureMonths} step="1" min={1}
                  onCommit={(v) => updateSplit(r.id, { tenureMonths: Math.max(1, Math.round(v ?? 1)) })}
                  className={LEG_INPUT} />
              </Cell>
              <Cell label="Moratorium (mo)">
                <NumberField value={r.moratoriumMonths} step="1" min={0}
                  onCommit={(v) => updateSplit(r.id, { moratoriumMonths: Math.max(0, Math.round(v ?? 0)) })}
                  className={LEG_INPUT} />
              </Cell>
              {freq === "custom" && (
                <Cell label="Repay last (mo)">
                  <NumberField value={r.customTailMonths ?? 3} step="1" min={1} max={r.tenureMonths}
                    onCommit={(v) => updateSplit(r.id, { customTailMonths: Math.max(1, Math.min(r.tenureMonths, Math.round(v ?? 3))) })}
                    className={LEG_INPUT} />
                </Cell>
              )}
            </LegRow>
          );
        })}
      </div>




      <div className="flex items-center justify-between gap-2">
        <span className={cn("text-[10px] tabular", over ? "text-mds-danger font-semibold" : "text-muted-foreground")}>
          {over ? "Exceeds scheme amount" : ""}
        </span>

        <button type="button" onClick={onAdd} disabled={!canAdd}
          className="h-7 rounded bg-mds-blue px-2.5 text-[10px] font-semibold uppercase tracking-wider text-white disabled:opacity-40">
          + Add MSER split
        </button>

      </div>
    </div>
  );
}



function SubHead({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="h-4 w-1 shrink-0 rounded bg-mds-blue" />
      <span className="text-sm font-semibold uppercase tracking-wider text-mds-navy">{title}</span>
      {hint && <span className="text-[11px] text-muted-foreground truncate">· {hint}</span>}
    </div>
  );
}



function MicroField({ label, children }: { label: string; children: React.ReactNode }) {

  return (
    <div className="space-y-1">
      <Label className="text-[9px] uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}


function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}


function monthsBetween(from: Date, to: Date): number {
  return roundedMonthsBetween(from, to);
}

function toISODate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

type Tranche = {
  id: string;
  label: string;
  date: string;
  /** RBI fund rate for the tranche (%) — fixed once the tranche is announced. */
  fundRatePct: number;
  /** SIDBI margin over the fund rate (bps) — fixed for the tranche. */
  marginBps: number;
};

const TRANCHE_STORE_KEY = "sidbi.rmse.tranches.v4";

function defaultTranches(): Tranche[] {
  return [
    { id: "t1", label: "RMSE-XV-Regular", date: toISODate(RMSE_MATURITY_DATE), fundRatePct: 3.50, marginBps: 75 },
    { id: "t2", label: "RMSE-XIV-Regular", date: toISODate(new Date(2028, 6, 30)), fundRatePct: 3.74, marginBps: 75 },
    { id: "t3", label: "RMSE-XIII-Regular", date: toISODate(new Date(2028, 5, 4)), fundRatePct: 4.46, marginBps: 75 },
  ];
}

function parseISODate(s: string): Date {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1);
}

/* ============================================================
   RMSE rows — first row plus splits, all rendered identically.
   Owns the tranche master (add / delete) used by every RMSE row.
   ============================================================ */



function RmseLegs({
  state, rmseAmt, patch, patchScheme, onAdd, canAdd,
}: {
  state: DealState;
  rmseAmt: number;
  patch: (p: Partial<DealState>) => void;
  patchScheme: (k: "mser" | "rmse", p: Partial<Scheme>) => void;
  onAdd: () => void;
  canAdd: boolean;
}) {
  const today = useMemo(() => {
    const n = new Date();
    return new Date(n.getFullYear(), n.getMonth(), n.getDate());
  }, []);

  const [tranches, setTranches] = useState<Tranche[]>(defaultTranches);
  const [baseTrancheId, setBaseTrancheId] = useState<string>("t1");
  // Expose the selected base tranche so the term-sheet PDF can quote its maturity date.
  useEffect(() => {
    try { window.localStorage.setItem("sidbi.rmse.baseTranche", baseTrancheId); } catch { /* ignore */ }
  }, [baseTrancheId]);

  const [adjust, setAdjust] = useState<Record<string, number>>({});
  const [manageOpen, setManageOpen] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<Tranche | null>(null);
  const [newLabel, setNewLabel] = useState("");
  const [newDate, setNewDate] = useState<Date | null>(null);
  const [newFund, setNewFund] = useState("3.50");
  const [newMargin, setNewMargin] = useState("75");
  const [editId, setEditId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState<{ label: string; date: Date | null; fund: string; margin: string }>(
    { label: "", date: null, fund: "3.50", margin: "75" },
  );


  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(TRANCHE_STORE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Tranche[];
        if (Array.isArray(parsed) && parsed.length) {
          setTranches(parsed);
          setBaseTrancheId(parsed[0].id);
        }
      }
    } catch { /* ignore */ }
  }, []);

  const persist = (next: Tranche[]) => {
    setTranches(next);
    try { window.localStorage.setItem(TRANCHE_STORE_KEY, JSON.stringify(next)); } catch { /* ignore */ }
  };

  const trancheOf = (id?: string) => tranches.find((t) => t.id === id) ?? tranches[0];
  const baseTenureOf = (id: string | undefined) => {
    const t = trancheOf(id);
    return t ? roundedMonthsBetween(today, parseISODate(t.date)) : 12;
  };
  const derived = (id: string | undefined, legId: string) => {
    const t = trancheOf(id);
    const adj = adjust[legId] ?? 0;
    const baseTen = baseTenureOf(id);
    return {
      tranche: t,
      tenure: Math.max(1, baseTen + adj),
      rate: t ? +(t.fundRatePct + t.marginBps / 100).toFixed(2) : 0,
      adj,
      baseTen,
    };
  };

  const baseD = derived(baseTrancheId, "rmse-base");
  // Keep the base RMSE leg in sync with its tranche.
  useEffect(() => {
    if (baseD.tenure !== state.rmse.tenureMonths) patchScheme("rmse", { tenureMonths: baseD.tenure });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseD.tenure]);
  useEffect(() => {
    if (baseD.rate && baseD.rate !== state.rmse.ratePct) patchScheme("rmse", { ratePct: baseD.rate });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseD.rate]);

  const allSplits = state.splits ?? [];
  const splits = allSplits.filter((sp) => sp.scheme === "rmse");
  const updateSplit = (id: string, p: Partial<DealSplit>) =>
    patch({ splits: allSplits.map((x) => (x.id === id ? { ...x, ...p } : x)) });
  const removeSplit = (id: string) => patch({ splits: allSplits.filter((x) => x.id !== id) });

  const baseAmt = baseLegAmount(state, "rmse");
  const over = splitTotal(state, "rmse") > rmseAmt + 1e-6;
  const showTail = splits.some((sp) => (sp.freq ?? "bullet") === "custom");
  void showTail;

  // Tenure is derived from the tranche maturity but fully editable — typing a
  // value simply stores the offset from the tranche-implied tenure (no cap).
  const stepper = (legId: string, tenure: number, baseTen: number) => (
    <div className="flex items-center h-9 rounded-md border border-input bg-white pl-0.5 pr-0.5">
      <NumberField value={tenure} step="1" min={1}
        onCommit={(v) => {
          const t = Math.max(1, Math.round(v ?? 1));
          setAdjust((a) => ({ ...a, [legId]: t - baseTen }));
        }}
        className="h-8 border-0 shadow-none focus-visible:ring-0 px-1.5 text-sm tabular flex-1 bg-transparent" />
      <div className="flex flex-col">
        <button type="button" className="h-3 px-0.5 flex items-center text-muted-foreground hover:text-foreground"
          onClick={() => setAdjust((a) => ({ ...a, [legId]: (a[legId] ?? 0) + 1 }))}>
          <ChevronUp className="h-2.5 w-2.5" />
        </button>
        <button type="button" className="h-3 px-0.5 flex items-center text-muted-foreground hover:text-foreground disabled:opacity-30"
          disabled={tenure <= 1}
          onClick={() => setAdjust((a) => ({ ...a, [legId]: (a[legId] ?? 0) - 1 }))}>
          <ChevronDown className="h-2.5 w-2.5" />
        </button>
      </div>
    </div>
  );

  // Re-picking the SAME tranche must also reset the tenure back to the
  // tranche-implied value, so we handle the item click directly (Radix skips
  // onValueChange when the value is unchanged).
  const trancheSelect = (value: string, onChange: (v: string) => void) => (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className={LEG_SELECT}><SelectValue placeholder="Tranche" /></SelectTrigger>
      <SelectContent>
        {tranches.map((t) => (
          <SelectItem key={t.id} value={t.id} className="text-xs">
            <span onPointerDown={() => { if (t.id === value) setTimeout(() => onChange(t.id), 0); }}>
              {t.label} · {format(parseISODate(t.date), "dd MMM yyyy")} · {(t.fundRatePct + t.marginBps / 100).toFixed(2)}%
            </span>
          </SelectItem>

        ))}
      </SelectContent>
    </Select>
  );


  const addTranche = () => {
    if (!newDate) return;
    const id = `t${Date.now()}`;
    const label = newLabel.trim() || `RMSE-${tranches.length + 1}-Regular`;
    persist([...tranches, {
      id, label, date: toISODate(newDate),
      fundRatePct: Number(newFund) || 0,
      marginBps: Number(newMargin) || 0,
    }]);
    setBaseTrancheId(id);
    setAdjust((a) => ({ ...a, "rmse-base": 0 }));
    setNewLabel(""); setNewDate(null); setNewFund("3.50"); setNewMargin("75");
  };

  const startEdit = (t: Tranche) => {
    setEditId(t.id);
    setEditDraft({
      label: t.label,
      date: parseISODate(t.date),
      fund: t.fundRatePct.toFixed(2),
      margin: String(t.marginBps),
    });
  };

  const saveEdit = () => {
    if (!editId || !editDraft.date) return;
    const updated: Tranche = {
      id: editId,
      label: editDraft.label.trim() || "RMSE-Regular",
      date: toISODate(editDraft.date),
      fundRatePct: Number(editDraft.fund) || 0,
      marginBps: Number(editDraft.margin) || 0,
    };
    persist(tranches.map((x) => (x.id === editId ? updated : x)));
    // Re-sync any RMSE split drawing on this tranche.
    const rate = +(updated.fundRatePct + updated.marginBps / 100).toFixed(2);
    const tenure = roundedMonthsBetween(today, parseISODate(updated.date));
    const touched = allSplits.some((x) => x.scheme === "rmse" && (x.trancheId ?? baseTrancheId) === editId);
    if (touched) {
      patch({
        splits: allSplits.map((x) =>
          x.scheme === "rmse" && (x.trancheId ?? baseTrancheId) === editId
            ? { ...x, ratePct: rate, tenureMonths: tenure }
            : x,
        ),
      });
    }
    setEditId(null);
  };


  const deleteTranche = (t: Tranche) => {
    const next = tranches.filter((x) => x.id !== t.id);
    const final = next.length ? next : defaultTranches();
    persist(final);
    if (baseTrancheId === t.id) { setBaseTrancheId(final[0].id); setAdjust((a) => ({ ...a, "rmse-base": 0 })); }
    setPendingDelete(null);
  };

  return (
    <div className="space-y-3">
      <div className="divide-y divide-border/70">
        {/* First RMSE row */}
        <LegRow label={splits.length > 0 ? "RMSE 1" : undefined} right={<span className="text-xs tabular text-muted-foreground">Bullet</span>}>
          <Cell label="Tranche (maturity)" span="col-span-2 xl:col-span-3">
            {trancheSelect(baseTrancheId, (v) => { setBaseTrancheId(v); setAdjust((a) => ({ ...a, "rmse-base": 0 })); })}
          </Cell>
          <Cell label="Rate %"><LegReadonly value={`${state.rmse.ratePct.toFixed(2)}%`} /></Cell>
          <Cell label="Amount ₹Cr">
            <NumberField value={+baseAmt.toFixed(2)} step="0.01" min={0} max={state.principalCr}
              onCommit={(v) => {
                const amt = Math.max(0, Math.min(state.principalCr, v ?? 0));
                const newRmse = Math.min(state.principalCr, amt + splitTotal(state, "rmse"));
                patch({ mserSharePct: state.principalCr > 0 ? ((state.principalCr - newRmse) / state.principalCr) * 100 : 100 });
              }}
              className={LEG_INPUT} />
          </Cell>
          <Cell label="Tenure (mo)">{stepper("rmse-base", baseD.tenure, baseD.baseTen)}</Cell>

          <Cell label="Moratorium (mo)">
            <NumberField value={state.rmse.moratoriumMonths} step="1" min={0}
              onCommit={(v) => patchScheme("rmse", { moratoriumMonths: Math.max(0, Math.round(v ?? 0)) })}
              className={LEG_INPUT} />
          </Cell>
        </LegRow>

        {/* RMSE splits */}
        {splits.map((r, i) => {
          const d = derived(r.trancheId ?? baseTrancheId, r.id);
          if ((r.freq ?? "bullet") !== "bullet") queueMicrotask(() => updateSplit(r.id, { freq: "bullet" }));
          return (
            <LegRow key={r.id} label={`RMSE ${i + 2}`}
              right={<span className="text-[10px] tabular text-muted-foreground">₹{r.amountCr.toFixed(2)} Cr · Bullet</span>}
              onRemove={() => removeSplit(r.id)}>
              <Cell label="Tranche (maturity)" span="col-span-2 xl:col-span-3">
                {trancheSelect(r.trancheId ?? baseTrancheId, (v) => {
                  setAdjust((a) => ({ ...a, [r.id]: 0 }));
                  const t = trancheOf(v);
                  updateSplit(r.id, {
                    trancheId: v,
                    ratePct: t ? +(t.fundRatePct + t.marginBps / 100).toFixed(2) : r.ratePct,
                    tenureMonths: t ? roundedMonthsBetween(today, parseISODate(t.date)) : r.tenureMonths,
                  });
                })}
              </Cell>
              <Cell label="Rate %"><LegReadonly value={`${r.ratePct.toFixed(2)}%`} /></Cell>
              <Cell label="Amount ₹Cr">
                <NumberField value={r.amountCr} step="0.01" min={0} max={state.principalCr}
                  onCommit={(v) => {
                    const amt = Math.max(0, Math.min(state.principalCr, v ?? 0));
                    const others = splitTotal(state, "rmse") - r.amountCr;
                    const needed = amt + others;
                    const p: Partial<DealState> = { splits: allSplits.map((x) => (x.id === r.id ? { ...x, amountCr: amt } : x)) };
                    if (needed > rmseAmt + 1e-9 && state.principalCr > 0)
                      p.mserSharePct = ((state.principalCr - Math.min(needed, state.principalCr)) / state.principalCr) * 100;
                    patch(p);
                  }}
                  className={LEG_INPUT} />
              </Cell>
              <Cell label="Tenure (mo)">
                {(() => {
                  if (d.tenure !== r.tenureMonths) {
                    queueMicrotask(() => updateSplit(r.id, { tenureMonths: d.tenure }));
                  }
                  return stepper(r.id, d.tenure, d.baseTen);
                })()}
              </Cell>
              <Cell label="Moratorium (mo)">
                <NumberField value={r.moratoriumMonths} step="1" min={0}
                  onCommit={(v) => updateSplit(r.id, { moratoriumMonths: Math.max(0, Math.round(v ?? 0)) })}
                  className={LEG_INPUT} />
              </Cell>

            </LegRow>
          );
        })}
      </div>


      <div className="flex items-center justify-between gap-2">
        <span className={cn("text-[10px] tabular", over ? "text-mds-danger font-semibold" : "text-muted-foreground")}>
          {over ? "Exceeds scheme amount" : ""}
        </span>

        <div className="flex items-center gap-2">
          <button type="button" onClick={onAdd} disabled={!canAdd}
            className="h-7 rounded bg-mds-blue px-2.5 text-[10px] font-semibold uppercase tracking-wider text-white disabled:opacity-40">
            + Add RMSE split
          </button>
          <Button type="button" size="sm" onClick={() => setManageOpen(true)}
            className="h-7 px-2.5 text-[10px] font-semibold uppercase tracking-wider bg-mds-blue hover:bg-mds-blue-hover text-white">
            Manage tranches
          </Button>
        </div>
      </div>

      <Dialog open={manageOpen} onOpenChange={setManageOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-base text-mds-navy">RMSE tranche master</DialogTitle>
            <DialogDescription className="text-xs">
              Add a newly announced tranche once — it becomes available in the tranche dropdown. Remove tranches that are fully utilised.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-2">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Existing tranches</div>
            <div className="rounded-md border border-border divide-y">
              {tranches.map((t) => (
                editId === t.id ? (
                  <div key={t.id} className="space-y-2 px-3 py-2 bg-mds-blue/5">
                    <div className="grid grid-cols-2 gap-2">
                      <Input value={editDraft.label} onChange={(e) => setEditDraft((d) => ({ ...d, label: e.target.value }))}
                        className="h-9 text-sm bg-white" />
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" className="h-9 justify-start text-sm bg-white font-normal">
                            <CalendarIcon className="h-3.5 w-3.5 mr-2" />
                            {editDraft.date ? format(editDraft.date, "dd MMM yyyy") : "Maturity date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-2" align="start">
                          <Calendar
                            mode="single"
                            selected={editDraft.date ?? undefined}
                            onSelect={(dt) => {
                              if (!dt || dt <= today) return;
                              setEditDraft((d) => ({ ...d, date: new Date(dt.getFullYear(), dt.getMonth(), dt.getDate()) }));
                            }}
                            disabled={(dt) => dt <= today}
                            defaultMonth={editDraft.date ?? RMSE_MATURITY_DATE}
                            captionLayout="dropdown"
                            startMonth={new Date(today.getFullYear(), today.getMonth())}
                            endMonth={new Date(today.getFullYear() + 30, 11)}
                            className={cn("p-0 pointer-events-auto")}
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">RBI fund rate %</div>
                        <Input value={editDraft.fund} onChange={(e) => setEditDraft((d) => ({ ...d, fund: e.target.value }))}
                          inputMode="decimal" className="h-9 text-sm bg-white tabular" />
                      </div>
                      <div className="space-y-1">
                        <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Margin (bps)</div>
                        <Input value={editDraft.margin} onChange={(e) => setEditDraft((d) => ({ ...d, margin: e.target.value }))}
                          inputMode="numeric" className="h-9 text-sm bg-white tabular" />
                      </div>
                    </div>
                    <div className="text-[10px] text-muted-foreground tabular">
                      Tranche rate = {((Number(editDraft.fund) || 0) + (Number(editDraft.margin) || 0) / 100).toFixed(2)}%
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="sm" className="h-8 flex-1 text-xs" disabled={!editDraft.date} onClick={saveEdit}>Save changes</Button>
                      <Button size="sm" variant="ghost" className="h-8 text-xs" onClick={() => setEditId(null)}>Cancel</Button>
                    </div>
                  </div>
                ) : (
                <div key={t.id} className="flex items-center justify-between gap-2 px-3 py-2">
                  <div>
                    <div className="text-xs font-semibold text-mds-navy">{t.label}</div>
                    <div className="text-[10px] text-muted-foreground tabular">
                      Matures {format(parseISODate(t.date), "dd MMM yyyy")} · fund {t.fundRatePct.toFixed(2)}% + {t.marginBps} bps = {(t.fundRatePct + t.marginBps / 100).toFixed(2)}%
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="sm" className="h-7 text-[11px] text-mds-blue"
                      onClick={() => startEdit(t)}>
                      Edit
                    </Button>
                    <Button variant="ghost" size="sm"
                      className="h-7 text-[11px] text-destructive hover:text-destructive"
                      onClick={() => setPendingDelete(t)}>
                      Delete
                    </Button>
                  </div>
                </div>
                )
              ))}
            </div>
          </div>


          <div className="space-y-2 rounded-md border border-mds-blue/30 bg-mds-blue/5 p-3">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Add new tranche</div>
            <div className="grid grid-cols-2 gap-2">
              <Input value={newLabel} onChange={(e) => setNewLabel(e.target.value)} className="h-9 text-sm bg-white" />
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="h-9 justify-start text-sm bg-white font-normal">
                    <CalendarIcon className="h-3.5 w-3.5 mr-2" />
                    {newDate ? format(newDate, "dd MMM yyyy") : "Maturity date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-2" align="start">
                  <Calendar
                    mode="single"
                    selected={newDate ?? undefined}
                    onSelect={(dt) => {
                      if (!dt || dt <= today) return;
                      setNewDate(new Date(dt.getFullYear(), dt.getMonth(), dt.getDate()));
                    }}
                    disabled={(dt) => dt <= today}
                    defaultMonth={newDate ?? RMSE_MATURITY_DATE}
                    captionLayout="dropdown"
                    startMonth={new Date(today.getFullYear(), today.getMonth())}
                    endMonth={new Date(today.getFullYear() + 30, 11)}
                    className={cn("p-0 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">RBI fund rate %</div>
                <Input value={newFund} onChange={(e) => setNewFund(e.target.value)} inputMode="decimal" className="h-9 text-sm bg-white tabular" />
              </div>
              <div className="space-y-1">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Margin (bps)</div>
                <Input value={newMargin} onChange={(e) => setNewMargin(e.target.value)} inputMode="numeric" className="h-9 text-sm bg-white tabular" />
              </div>
            </div>
            <div className="text-[10px] text-muted-foreground tabular">
              Tranche rate = {((Number(newFund) || 0) + (Number(newMargin) || 0) / 100).toFixed(2)}% (fixed for this tranche)
            </div>
            <Button size="sm" className="h-8 w-full text-xs" disabled={!newDate} onClick={addTranche}>
              Add tranche
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!pendingDelete} onOpenChange={(o) => { if (!o) setPendingDelete(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-base">Delete this tranche?</AlertDialogTitle>
            <AlertDialogDescription className="text-xs">
              {pendingDelete
                ? `${pendingDelete.label} (matures ${format(parseISODate(pendingDelete.date), "dd MMM yyyy")}) will be removed from the tranche dropdown. This cannot be undone.`
                : ""}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="text-xs">Keep tranche</AlertDialogCancel>
            <AlertDialogAction
              className="text-xs bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => pendingDelete && deleteTranche(pendingDelete)}>
              Yes, delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}





function NumberField({
  value, onCommit, step, className, placeholder = "0", allowNull, disabled, max, min,
}: {
  value: number | null;
  onCommit: (v: number | null) => void;
  step?: number | string;
  className?: string;
  placeholder?: string;
  allowNull?: boolean;
  disabled?: boolean;
  max?: number;
  min?: number;
}) {
  const [draft, setDraft] = useState<string | null>(null);
  const display =
    value === null || value === undefined || value === 0
      ? ""
      : String(value);
  const shown = draft ?? display;
  const clamp = (n: number) => {
    let v = n;
    if (typeof max === "number" && v > max) v = max;
    if (typeof min === "number" && v < min) v = min;
    return v;
  };
  return (
    <Input
      type="number"
      step={step ?? "any"}
      max={max}
      min={min}
      value={shown}
      placeholder={placeholder}
      onFocus={(e) => {
        e.currentTarget.select();
      }}
      onChange={(e) => {
        const raw = e.target.value;
        if (raw === "" || raw === "-" || raw === ".") {
          setDraft(raw);
          return;
        }
        const n = parseFloat(raw);
        if (Number.isNaN(n)) { setDraft(raw); return; }
        const c = clamp(n);
        if (c !== n) {
          setDraft(String(c));
          onCommit(c);
        } else {
          setDraft(raw);
          onCommit(n);
        }
      }}
      onBlur={() => {
        if (draft === "" && allowNull) onCommit(null);
        setDraft(null);
      }}
      className={className}
      disabled={disabled}
    />
  );
}


function NumInput({ label, value, onChange, step, locked, max, hint }: { label: string; value: number; onChange: (v: number) => void; step?: number; locked?: boolean; max?: number; hint?: string }) {
  return (
    <div className="space-y-1">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground whitespace-nowrap flex items-center gap-1">
        <span>{label}</span>
        {hint && <span className="text-[10px] text-mds-blue/70 font-semibold">· {hint}</span>}
      </div>
      <NumberField
        value={value}
        step={step ?? 1}
        max={max}
        onCommit={(v) => {
          let n = v ?? 0;
          if (max !== undefined && n > max) n = max;
          onChange(n);
        }}
        disabled={locked}
        className={cn(
          "h-9 text-sm tabular px-2 w-full",
          locked
            ? "bg-white border-input text-black cursor-not-allowed opacity-100"
            : "bg-white border-input"
        )}
      />
    </div>
  );
}

function FixedDisplay({ label, value, hint, strong }: { label: string; value: string; hint?: string; strong?: boolean }) {
  return (
    <div className="space-y-1">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground whitespace-nowrap flex items-center gap-1">
        <span>{label}</span>
        {hint && <span className="text-[10px] text-mds-blue/70 font-semibold">· {hint}</span>}
      </div>
      <div className={cn(
        "h-9 rounded-md border flex items-center px-2 text-sm tabular",
        "bg-white border-input text-black"
      )}>

        {value}
      </div>
    </div>
  );
}




function MiniStat({ label, value, note }: { label: string; value: string; note?: string }) {

  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-white/60">{label}</div>
      <div className="text-lg font-bold tabular mt-0.5">{value}</div>
      {note ? <div className="text-[11px] text-white/70 mt-0.5">{note}</div> : null}
    </div>
  );
}


function MiniKV({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3 text-[11px]">
      <span className="text-muted-foreground">{k}</span>
      <span className="tabular text-mds-navy font-medium text-right">{v}</span>
    </div>
  );
}



interface RangeMarker { key: string; label: string; value: number; color: string; position: "top" | "bottom"; }

// Short badges shown directly on the bar. The full label + value lives in
// the legend below, so we only need a compact identifier per tick.
const SHORT_LABEL: Record<string, string> = {
  cof: "CoF",
  counterparty: "Bank-Alt",
  std: "Std",
  sug: "Sug",
  current: "MSER Quote",
  gsec: "G-Sec",
  cd: "CD",
  cp: "CP",
  dep: "Bulk Deposit",
  war: "WAR (Quote)",
  bulkmax: "Bulk Deposit",
  deskquote: "CP Quote",

};

// Stack overlapping badges into rows so they never collide.
function stackRows<T extends { pct: number }>(items: T[], minGap = 12) {
  const sorted = [...items].sort((a, b) => a.pct - b.pct);
  const lastPctInRow: number[] = [];
  return sorted.map((m) => {
    let row = 0;
    while (lastPctInRow[row] !== undefined && m.pct - lastPctInRow[row] < minGap) row++;
    lastPctInRow[row] = m.pct;
    return { ...m, row };
  });
}

function NegotiationRangeBar({ min, max, markers, onDark }:
  { min: number; max: number; markers: RangeMarker[]; onDark?: boolean }) {
  // Build a strictly left-to-right numerical domain from every visible value.
  // This makes marker position monotonic: a higher rate can never render to the
  // left of a lower rate, even when quotes exceed the bulk-deposit ceiling.
  const cleanMarkers = markers.filter((m) => Number.isFinite(m.value));
  const values = [min, max, ...cleanMarkers.map((m) => m.value)].filter((v) => Number.isFinite(v));
  const lo = Math.min(...values);
  const hi = Math.max(...values);
  const rawSpan = Math.max(0.01, hi - lo);
  const pad = Math.max(0.05, rawSpan * 0.08);
  const domainMin = lo - pad;
  const domainMax = hi + pad;
  const span = Math.max(0.01, domainMax - domainMin);
  const pct = (v: number) => Math.max(0, Math.min(100, ((v - domainMin) / span) * 100));

  // Auto-balance: if too many markers land on one side, push the densest
  // ones from bottom → top (or vice versa) to keep stack height compact.
  const rebalanced = (() => {
    const tops = cleanMarkers.filter((m) => m.position === "top");
    const bots = cleanMarkers.filter((m) => m.position === "bottom");
    // No rebalance needed if already fairly split
    if (Math.abs(tops.length - bots.length) <= 1) return cleanMarkers;
    return cleanMarkers;
  })();

  const enriched = rebalanced.map((m) => ({
    ...m,
    pct: pct(m.value),
    short: SHORT_LABEL[m.key] ?? m.label.slice(0, 4),
  }));

  const chipTranslate = (positionPct: number) => {
    if (positionPct <= 8) return "translateX(0)";
    if (positionPct >= 92) return "translateX(-100%)";
    return "translateX(-50%)";
  };
  const chipAlign = (positionPct: number) => {
    if (positionPct <= 8) return "items-start";
    if (positionPct >= 92) return "items-end";
    return "items-center";
  };

  // Chip is ~72px wide; require at least that much horizontal gap between
  // chips on the same row. Convert to a % of the bar so stacking is
  // container-aware. Assume ~560px typical bar width → ~13%.
  const MIN_GAP_PCT = 14;
  const topItems = stackRows(enriched.filter((m) => m.position === "top"), MIN_GAP_PCT);
  const bottomItems = stackRows(enriched.filter((m) => m.position === "bottom"), MIN_GAP_PCT);
  const topRows = Math.max(1, ...topItems.map((m) => m.row + 1));
  const bottomRows = Math.max(1, ...bottomItems.map((m) => m.row + 1));
  const ROW_H = 22;

  const chip = (m: typeof enriched[number]) => (
    <div
      className="px-1.5 py-0.5 rounded text-[10px] font-semibold leading-none whitespace-nowrap text-white shadow-sm flex items-center gap-1"
      style={{ background: m.color }}
      title={`${m.label}: ${m.value.toFixed(2)}%`}
    >
      <span>{m.short}</span>
      <span className="tabular opacity-90">{m.value.toFixed(2)}</span>
    </div>
  );

  return (
    <div className="px-1">
      {/* Top chips */}
      <div className="relative mb-1.5" style={{ height: topRows * ROW_H }}>
        {topItems.map((m) => {
          const bottom = m.row * ROW_H;
          return (
            <div
              key={m.key}
              className={cn("absolute flex flex-col", chipAlign(m.pct))}
              style={{ left: `${m.pct}%`, bottom, transform: chipTranslate(m.pct) }}
            >
              {chip(m)}
              <div className={cn("w-px", onDark ? "bg-white/40" : "bg-border")} style={{ height: bottom + 2 }} />
            </div>
          );
        })}
      </div>

      {/* Bar */}
      <div className={cn("relative h-4 rounded-full bg-gradient-to-r from-mds-success/30 via-mds-warning/40 to-mds-danger/40 border",
        onDark ? "border-white/25" : "border-border/40")}>
        {/* Domain end labels */}
        <div className={cn("absolute -bottom-4 left-0 text-[10px] tabular", onDark ? "text-white/60" : "text-muted-foreground")}>{domainMin.toFixed(2)}%</div>
        <div className={cn("absolute -bottom-4 right-0 text-[10px] tabular", onDark ? "text-white/60" : "text-muted-foreground")}>{domainMax.toFixed(2)}%</div>
        {enriched.map((m) => (
          <div
            key={`tick-${m.key}`}
            className="absolute -top-1 h-6 w-0.5 rounded"
            style={{ left: `${m.pct}%`, background: m.color }}
          />
        ))}
      </div>

      {/* Bottom chips */}
      <div className="relative mt-5" style={{ height: bottomRows * ROW_H }}>
        {bottomItems.map((m) => {
          const top = m.row * ROW_H;
          return (
            <div
              key={m.key}
              className={cn("absolute flex flex-col", chipAlign(m.pct))}
              style={{ left: `${m.pct}%`, top: 0, transform: chipTranslate(m.pct) }}
            >
              <div className={cn("w-px", onDark ? "bg-white/40" : "bg-border")} style={{ height: top + 2 }} />
              {chip(m)}
            </div>
          );
        })}
      </div>

    </div>
  );
}

function RangeStat({ label, value, tone, swatch }: { label: string; value: string; tone?: "warning" | "success" | "navy" | "blue"; swatch?: string }) {
  const color = tone === "warning" ? "text-mds-warning"
    : tone === "success" ? "text-mds-success"
    : tone === "navy" ? "text-mds-navy"
    : tone === "blue" ? "text-mds-blue"
    : "text-mds-navy";
  return (
    <div className="rounded-md border border-border bg-secondary/30 p-2">
      <div className="flex items-center gap-1.5">
        {swatch && <span className="w-2 h-2 rounded-sm shrink-0" style={{ background: swatch }} />}
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground truncate">{label}</div>
      </div>
      <div className={cn("text-sm font-bold tabular mt-0.5", color)}>{value}</div>
    </div>
  );
}





/** Floor build-up + approval status for one MSER row (base or split). */
function MserFloorPanel({
  title, rateLabel, ratePct, cofPct, cofLabel, minMarginBps, maxDiscretionBps, categoryLabel,
}: {
  title: string;
  rateLabel: string;
  ratePct: number;
  cofPct: number | null;
  cofLabel: string;
  minMarginBps: number;
  maxDiscretionBps: number;
  categoryLabel: string;
}) {
  if (cofPct === null) return null;
  const marginBpsRow = Math.round((ratePct - cofPct) * 100);
  const standard = cofPct + minMarginBps / 100;
  const premiumBps = Math.max(0, marginBpsRow - minMarginBps);
  const discBps = Math.max(0, minMarginBps - marginBpsRow);
  const belowCof = marginBpsRow < 0;
  const overSca = discBps > maxDiscretionBps || belowCof;
  const needsScaOnly = discBps > 0 && !overSca;
  const hasPremium = premiumBps > 0;
  return (
    <div className={cn(
      "rounded-lg border p-4",
      overSca ? "border-mds-danger/40 bg-mds-danger/5"
        : needsScaOnly ? "border-mds-warning/40 bg-mds-warning/5"
        : hasPremium ? "border-mds-success/40 bg-mds-success/5"
        : "border-border bg-secondary/40"
    )}>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">{title}</div>
      <FloorRow label="Cost of Funds" sub={`Treasury · ${cofLabel}`} value={cofPct} />
      <FloorRow label="+ Min Margin" sub={`${minMarginBps} bps · ${categoryLabel}`} value={minMarginBps / 100} plus />
      <div className="border-t border-border my-2" />
      <FloorRow label="Standard Rate" value={standard} strong />
      {hasPremium && (
        <FloorRow label="+ Margin" sub={`+${premiumBps} bps above min prescribed margin\u00a0`} value={premiumBps / 100} plus />
      )}
      {needsScaOnly && (
        <FloorRow label="− Discretion (SCA)" sub={`${discBps} of ${maxDiscretionBps} bps · SCA approval required`} value={discBps / 100} minus />
      )}
      {overSca && (
        <FloorRow
          label="− Discretion (ALCO)"
          sub={belowCof
            ? `${discBps} bps · rate below Cost of Funds · ALCO approval required`
            : `${discBps} bps · exceeds SCA limit of ${maxDiscretionBps} bps · ALCO approval required`}
          value={discBps / 100}
          minus
          danger
        />
      )}
      <div className="border-t border-border my-2" />
      <FloorRow label={rateLabel} sub={`margin ${marginBpsRow} bps over CoF`} value={ratePct} big danger={overSca} />
      <div className={cn("text-[11px] font-semibold mt-2 pt-2 border-t border-border uppercase tracking-wider",
        overSca ? "text-mds-danger"
          : needsScaOnly ? "text-mds-warning"
          : hasPremium ? "text-mds-success"
          : "text-muted-foreground")}>
        {belowCof
          ? "ALCO + Treasury approval required · below Cost of Funds"
          : overSca
            ? "ALCO approval required"
            : needsScaOnly
              ? "SCA approval required"
              : hasPremium
                ? `Margin above min prescribed margin · +${premiumBps} bps`
                : "Within standard · no approval required"}
      </div>
    </div>
  );
}


function FloorRow({ label, sub, value, plus, minus, strong, big, danger }:


  { label: string; sub?: string; value: number; plus?: boolean; minus?: boolean; strong?: boolean; big?: boolean; danger?: boolean }) {
  return (
    <div className={cn("flex items-baseline justify-between py-1.5", big && "py-2")}>
      <div>
        <span className={cn("text-sm", strong && "font-semibold", big && "font-bold", big && (danger ? "text-mds-danger" : "text-mds-navy"))}>{label}</span>
        {sub && <span className={cn("text-[11px] ml-2", danger && !big ? "text-mds-danger font-semibold" : "text-muted-foreground")}>{sub}</span>}
      </div>
      <span className={cn("tabular text-sm font-medium",
        plus && "text-mds-success",
        minus && !danger && "text-mds-danger",
        minus && danger && "text-mds-danger font-semibold",
        big && "text-2xl font-bold",
        big && (danger ? "text-mds-danger" : "text-mds-blue"))}>
        {plus && "+ "}{minus && "− "}{value.toFixed(2)}%
      </span>
    </div>
  );
}


function FinalPill({ label, sub, value, tone }: { label: string; sub?: string; value: number | null; tone: "blue" | "navy" | "success" | "purple" }) {
  const bg = tone === "blue" ? "bg-mds-blue/10 text-mds-blue"
    : tone === "success" ? "bg-mds-success/10 text-mds-success"
    : tone === "purple" ? "bg-mds-purple/10 text-mds-purple"
    : "bg-mds-navy/10 text-mds-navy";
  return (
    <div className={cn("rounded-md p-3", bg)}>
      <div className="text-[10px] uppercase tracking-wider opacity-80">{label}</div>
      <div className="text-xl font-bold tabular mt-1">{value !== null ? `${value.toFixed(2)}%` : "—"}</div>
      {sub && <div className="text-[10px] mt-0.5 opacity-70 truncate">{sub}</div>}
    </div>
  );
}

function MultiRatePill({ label, rows, tone }: {
  label: string;
  tone: "blue" | "navy" | "success";
  rows: { id: string; label: string; sub?: string; value: number | null }[];
}) {
  if (rows.length === 0) return null;
  if (rows.length === 1) {
    return <FinalPill label={label} sub={rows[0].sub} value={rows[0].value} tone={tone} />;
  }
  const bg = tone === "blue" ? "bg-mds-blue/10 text-mds-blue"
    : tone === "success" ? "bg-mds-success/10 text-mds-success"
    : "bg-mds-navy/10 text-mds-navy";
  return (
    <div className={cn("rounded-md p-3", bg)}>
      <div className="text-[10px] uppercase tracking-wider opacity-80">{label}</div>
      <div className="mt-1 space-y-1">
        {rows.map((r) => (
          <div key={r.id}>
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-[11px] font-medium opacity-80 truncate">{r.label}</span>
              <span className="text-base font-bold tabular">{r.value !== null ? `${r.value.toFixed(2)}%` : "—"}</span>
            </div>
            {r.sub && <div className="text-[10px] opacity-70 truncate">{r.sub}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}



function MarketTile({ name, point, loading, sourceLabel, compact, pending }:
  { name: string; point: { value: number | null; source: string | null }; loading: boolean; sourceLabel: string; compact?: boolean; pending?: boolean }) {
  const hasValue = point.value !== null;
  return (
    <Card className={cn(pending && !hasValue && "border-dashed bg-secondary/20")}>
      <CardContent className={cn("p-4", compact && "p-3")}>
        <div className="flex items-center justify-between">
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{name}</div>
          <span className="text-[10px] tabular text-muted-foreground">{point.source ?? sourceLabel}</span>
        </div>
        <div className={cn("font-bold tabular text-mds-navy mt-1", compact ? "text-xl" : "text-2xl")}>
          {loading && !hasValue ? "…" : hasValue ? point.value!.toFixed(2) : "—"}
          <span className="text-sm text-muted-foreground">%</span>
        </div>
        {!hasValue && !loading && (
          <div className="text-[10px] text-muted-foreground mt-1">
            {pending ? "Feed pending" : "Not available"}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ============ Market Instrument Tile ============
function InstrumentTile({ inst, onOpen, accent = "navy", liveValue = null, liveAsOf = null }: { inst: MarketInstrument; onOpen: () => void; accent?: "blue" | "navy"; liveValue?: number | null; liveAsOf?: string | null }) {
  const stroke = accent === "blue" ? "var(--mds-blue)" : "var(--mds-success)";
  const gradId = `grad-${inst.key}`;
  const shown = liveValue ?? inst.latest;
  const isLive = liveValue !== null && liveValue !== undefined;
  // If live, splice latest live value onto the tail of the sparkline
  const trendData = isLive
    ? [...inst.trend.slice(0, -1), { ...inst.trend[inst.trend.length - 1], value: liveValue as number }]
    : inst.trend;
  const asOfLabel = isLive && liveAsOf
    ? new Date(liveAsOf).toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" })
    : inst.asOf;
  return (
    <button
      onClick={onOpen}
      style={{ ["--tile-accent" as string]: stroke }}
      className="relative text-left rounded-lg border border-border bg-white hover:border-[var(--tile-accent)] hover:shadow-md hover:-translate-y-0.5 transition-all p-3 group overflow-hidden"

    >
      <span
        className="absolute inset-x-0 top-0 h-0.5"
        style={{ background: stroke }}
      />
      <div className="flex items-start justify-between gap-2">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground truncate font-semibold">{inst.short}</div>
        <div className="flex items-center gap-1 shrink-0">
          {isLive && <span className="w-1.5 h-1.5 rounded-full bg-mds-success animate-pulse" title="Live" />}
          <Info className="h-3 w-3 text-muted-foreground/60 group-hover:text-[var(--tile-accent)] mt-0.5" />
        </div>
      </div>
      <div className="mt-1.5 flex items-baseline gap-0.5">
        <span className="text-xl font-bold tabular text-mds-navy leading-none">{shown.toFixed(2)}</span>
        <span className="text-[11px] text-muted-foreground">%</span>
      </div>
      <div className="h-10 mt-2 -mx-1">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={trendData} margin={{ top: 2, right: 2, bottom: 0, left: 2 }}>
            <defs>
              <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={stroke} stopOpacity={0.28} />
                <stop offset="100%" stopColor={stroke} stopOpacity={0} />
              </linearGradient>
            </defs>
            <Area type="monotone" dataKey="value" stroke={stroke} strokeWidth={1.5} fill={`url(#${gradId})`} dot={false} isAnimationActive={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div className="text-[10px] text-muted-foreground/70 mt-1 truncate">{isLive ? `Live · ${asOfLabel}` : asOfLabel}</div>
    </button>
  );
}


// ============ Market Instrument Detail Dialog ============
function InstrumentDetail({ inst, onClose }: { inst: MarketInstrument | null; onClose: () => void }) {
  return (
    <Dialog open={inst !== null} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-auto">
        {inst && (
          <>
            <DialogHeader>
              <DialogTitle className="text-mds-navy flex items-center gap-3">
                {inst.name}
                <Badge variant="outline" className="text-[10px] font-normal">{inst.source}</Badge>
              </DialogTitle>
              <DialogDescription className="text-xs">
                Latest <span className="font-semibold text-mds-navy tabular">{inst.latest.toFixed(2)}%</span> · {inst.asOf} ·{" "}
                <button type="button" onClick={() => window.open(inst.sourceUrl, "_blank", "noopener,noreferrer")}
                  className="text-mds-blue underline inline-flex items-center gap-0.5 cursor-pointer">
                  source <ExternalLink className="h-3 w-3" />
                </button>
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 text-sm">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="rounded-md bg-secondary/40 p-3">
                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">What it is</div>
                  <div className="text-xs leading-relaxed text-mds-navy">{inst.what}</div>
                </div>
                <div className="rounded-md bg-mds-blue/5 border border-mds-blue/20 p-3">
                  <div className="text-[10px] uppercase tracking-wider text-mds-blue mb-1">Implication for pricing</div>
                  <div className="text-xs leading-relaxed text-mds-navy">{inst.implication}</div>
                </div>
              </div>

              {/* Trend */}
              <div className="rounded-lg border border-border p-3">
                <div className="text-[10px] uppercase tracking-widest text-mds-navy font-semibold mb-2">12-Month Trend</div>
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={inst.trend} margin={{ top: 8, right: 12, bottom: 4, left: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                      <XAxis dataKey="month" tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" />
                      <YAxis tick={{ fontSize: 10 }} stroke="var(--muted-foreground)" domain={["auto","auto"]} tickFormatter={(v) => `${v.toFixed(2)}%`} />
                      <RTooltip formatter={(v: number) => `${v.toFixed(2)}%`} contentStyle={{ fontSize: 11 }} />
                      <ReferenceLine y={inst.latest} stroke="var(--mds-navy)" strokeDasharray="4 2" strokeWidth={1} />
                      <Line type="monotone" dataKey="value" stroke="var(--mds-blue)" strokeWidth={2} dot={{ r: 2 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Term structure (curve) */}
              {inst.curve && !inst.ratingCurves && (
                <div className="rounded-lg border border-border p-3">
                  <div className="text-[10px] uppercase tracking-widest text-mds-navy font-semibold mb-2">Term Structure (Yield Curve)</div>
                  <div className="h-52">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={inst.curve} margin={{ top: 8, right: 12, bottom: 4, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                        <XAxis dataKey="tenor" tick={{ fontSize: 10 }} />
                        <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `${v.toFixed(1)}%`} domain={["auto","auto"]} />
                        <RTooltip formatter={(v: number) => `${v.toFixed(2)}%`} contentStyle={{ fontSize: 11 }} />
                        <Bar dataKey="value" fill="var(--mds-blue)" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

              {/* Rating-band curves (CP) */}
              {inst.ratingCurves && (
                <div className="rounded-lg border border-border p-3">
                  <div className="text-[10px] uppercase tracking-widest text-mds-navy font-semibold mb-2">Term Structure by Rating</div>
                  <div className="h-56">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart margin={{ top: 8, right: 12, bottom: 4, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                        <XAxis dataKey="tenor" type="category" allowDuplicatedCategory={false} tick={{ fontSize: 10 }} />
                        <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `${v.toFixed(1)}%`} domain={["auto","auto"]} />
                        <RTooltip formatter={(v: number) => `${v.toFixed(2)}%`} contentStyle={{ fontSize: 11 }} />
                        {inst.ratingCurves.map((rc, i) => (
                          <Line
                            key={rc.rating}
                            data={rc.points}
                            type="monotone"
                            dataKey="value"
                            name={rc.rating}
                            stroke={["var(--mds-blue)","var(--mds-navy)","var(--mds-warning)","var(--mds-danger)"][i % 4]}
                            strokeWidth={2}
                            dot={{ r: 3 }}
                          />
                        ))}
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex flex-wrap gap-3 mt-2 text-[10px]">
                    {inst.ratingCurves.map((rc, i) => (
                      <span key={rc.rating} className="inline-flex items-center gap-1">
                        <span className="w-2.5 h-2.5 rounded-sm" style={{ background: ["var(--mds-blue)","var(--mds-navy)","var(--mds-warning)","var(--mds-danger)"][i % 4] }} />
                        {rc.rating}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Curve table */}
              {inst.curve && (
                <div className="rounded-lg border border-border overflow-hidden">
                  <Table className="text-xs">
                    <TableHeader>
                      <TableRow>
                        <TableHead>Tenor</TableHead>
                        <TableHead className="text-right">Yield (% p.a.)</TableHead>
                        <TableHead className="text-right">vs 1Y</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {inst.curve.map((c) => {
                        const base = inst.curve!.find((x) => x.months === 12)?.value ?? inst.curve![0].value;
                        const spread = (c.value - base) * 100;
                        return (
                          <TableRow key={c.tenor}>
                            <TableCell className="font-medium">{c.tenor}</TableCell>
                            <TableCell className="text-right tabular text-mds-navy font-semibold">{c.value.toFixed(2)}%</TableCell>
                            <TableCell className="text-right tabular text-muted-foreground">{spread >= 0 ? "+" : ""}{spread.toFixed(0)} bps</TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}


// ============ Live Bulk Deposit Card ============
/** 1Y-and-above tenor filter shared by the counterparty deposit views. */
function only1yPlus(rows: LiveDepositRow[] | null): LiveDepositRow[] | null {
  return rows?.filter((r) => {
    const t = r.tenor.toLowerCase();
    if (/<\s*1\s*year|less\s+than\s+1\s*year/.test(t)) return false;
    if (/\bday|\bdays\b/.test(t) && !/year|yr/.test(t)) return false;
    const monthMatches = [...t.matchAll(/(\d+(?:\.\d+)?)\s*months?/g)].map((m) => Number(m[1]));
    if (monthMatches.length > 0 && !/year|yr/.test(t)) return monthMatches.some((m) => m >= 12);
    return /\byear|\byr\b|\byrs\b/.test(t);
  }) ?? null;
}

function depositAmountLabel(bank: BankProfile, hasBuckets?: boolean): string {
  if (hasBuckets) return "≥ ₹3 Cr (bucketed)";
  if (bank.id === "sbi") return "≥ ₹3 Cr (Domestic Bulk Term Deposits)";
  if (bank.id === "tmb") return "≥ ₹2 Cr";
  return "≥ ₹2 Cr (Bulk)";
}

/** Tile matching the market-instrument tile styling, used for counterparty cards. */
function CounterpartyTile({
  label, value, unit = "%", meta, sub, accent, onOpen, loading,
}: {
  label: string;
  value: number | null;
  unit?: string;
  meta: string;
  sub: string;
  accent: string;
  onOpen: () => void;
  loading?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onOpen}
      style={{ ["--tile-accent" as string]: accent }}
      className="relative text-left rounded-lg border border-border bg-white hover:border-[var(--tile-accent)] hover:shadow-md hover:-translate-y-0.5 transition-all p-3 group overflow-hidden"
    >
      <span className="absolute inset-x-0 top-0 h-0.5" style={{ background: accent }} />
      <div className="flex items-start justify-between gap-2">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground truncate font-semibold">{label}</div>
        <Info className="h-3 w-3 shrink-0 text-muted-foreground/60 group-hover:text-[var(--tile-accent)] mt-0.5" />

      </div>
      <div className="mt-1.5 flex items-baseline gap-0.5">
        <span className="text-xl font-bold tabular text-mds-navy leading-none">
          {loading && value === null ? "…" : value !== null ? value.toFixed(2) : "—"}
        </span>
        {value !== null && <span className="text-[11px] text-muted-foreground">{unit}</span>}
      </div>
      <div className="mt-2 text-[10px] text-mds-navy leading-snug line-clamp-2 min-h-[26px]">{meta}</div>
      <div className="text-[10px] text-muted-foreground/70 mt-1 truncate">{sub}</div>
    </button>
  );
}

/** Counterparty section inside Market Rates — bulk deposit, money-market CD and bond tiles. */
function CounterpartyActivitySection({
  bank, live, activity, loading, fetchedAt,
}: {
  bank: BankProfile;
  live: { rows: LiveDepositRow[] | null; sourceUrl: string | null; asOf: string | null; note: string | null; illustrative?: boolean; hasAmountBuckets?: boolean };
  activity: ActivityLive;
  loading: boolean;
  fetchedAt: string | null;
}) {
  const [open, setOpen] = useState<null | "deposit" | "mm" | "bond">(null);
  const rows = only1yPlus(live.rows);
  const bucketLabel = depositAmountLabel(bank, live.hasAmountBuckets);

  const peak = useMemo(() => {
    let best: { rate: number; tenor: string; bucket: string } | null = null;
    for (const r of rows ?? []) {
      const cands: Array<{ v: number | null | undefined; bucket: string }> = live.hasAmountBuckets
        ? [
            { v: r.callable, bucket: "≥ ₹3 Cr < ₹5 Cr" },
            { v: r.nonCallableMax ?? r.nonCallable, bucket: "≥ ₹5 Cr" },
          ]
        : [
            { v: r.callable, bucket: bucketLabel },
            { v: r.nonCallable, bucket: bucketLabel },
          ];
      for (const c of cands) {
        if (c.v === null || c.v === undefined) continue;
        if (!best || c.v > best.rate) best = { rate: c.v, tenor: r.tenor, bucket: c.bucket };
      }
    }
    return best;
  }, [rows, live.hasAmountBuckets, bucketLabel]);

  const { latestMm, latestBond, mmCount, bondCount } = useMemo(() => {
    const all = baseActivityRows(bank, activity).sort((a, b) => actTime(b.date) - actTime(a.date));
    const mm = all.filter((r) => r.group === "mm");
    const bd = all.filter((r) => r.group === "bond");
    // Prefer the most recent bond print that carries a quotable coupon.
    const bondPick = bd.find((r) => actRateNum(r.rate) !== null) ?? bd[0] ?? null;
    return { latestMm: mm[0] ?? null, latestBond: bondPick, mmCount: mm.length, bondCount: bd.length };

  }, [bank, activity]);

  return (
    <div>
      <div className="flex items-center gap-2 mb-2">
        <span className="h-1.5 w-1.5 rounded-full bg-mds-navy" />
        <span className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">
          Counterparty · {bank.name}
        </span>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <CounterpartyTile
          label="Money market"
          value={actRateNum(latestMm?.rate ?? null)}
          meta={latestMm ? `${latestMm.instrument}${latestMm.tenor ? ` · ${fmtActTenor(latestMm.tenor)}` : ""}` : "No recent prints"}
          sub={latestMm ? `${fmtActDate(latestMm.date)} · ${latestMm.source}` : "Treasury / Bloomberg"}
          accent="var(--mds-purple)"
          loading={loading}
          onOpen={() => setOpen("mm")}
        />
        <CounterpartyTile
          label="Bonds · latest"
          value={actRateNum(latestBond?.rate ?? null)}
          meta={latestBond ? `${latestBond.instrument}${latestBond.tenor ? ` · ${fmtActTenor(latestBond.tenor)}` : ""}` : "No recent issuance"}
          sub={latestBond ? `${fmtActDate(latestBond.date)} · ${latestBond.source}` : "News / filings"}
          accent="var(--mds-purple)"
          loading={loading}
          onOpen={() => setOpen("bond")}
        />
        <CounterpartyTile
          label="Bulk deposit · max"
          value={peak?.rate ?? null}
          meta={peak ? `${peak.tenor} · ${peak.bucket}` : `Applicable amount ${bucketLabel}`}
          sub={live.asOf ? `Rate card · ${live.asOf}` : "Published rate card"}
          accent="var(--mds-purple)"
          loading={loading}
          onOpen={() => setOpen("deposit")}
        />

      </div>

      {/* Bulk deposit — full rate card */}
      <Dialog open={open === "deposit"} onOpenChange={(v) => !v && setOpen(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="text-mds-navy text-base flex items-center gap-2">
              Bulk Deposit Rates — 1Y &amp; Above
              {live.illustrative && <span className="inline-block rounded bg-amber-100 text-amber-800 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5">Illustrative</span>}
            </DialogTitle>
            <DialogDescription className="text-xs">
              {bank.name} · applicable amount {bucketLabel}
              {live.asOf ? ` · as of ${live.asOf}` : ""}
            </DialogDescription>
          </DialogHeader>
          {rows && rows.length > 0 ? (
            <Table className="text-xs">
              <TableHeader>
                <TableRow>
                  <TableHead>Tenor</TableHead>
                  {live.hasAmountBuckets ? (
                    <>
                      <TableHead className="text-right">≥ ₹3 Cr &lt; ₹5 Cr (%)</TableHead>
                      <TableHead className="text-right">≥ ₹5 Cr (%)</TableHead>
                    </>
                  ) : (
                    <TableHead className="text-right">Rate (%)</TableHead>
                  )}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((d, i) => (
                  <TableRow key={i} className={peak && d.tenor === peak.tenor ? "bg-mds-navy/5" : undefined}>
                    <TableCell>{d.tenor}</TableCell>
                    {live.hasAmountBuckets ? (
                      <>
                        <TableCell className="text-right tabular">{d.callable !== null ? d.callable.toFixed(2) : "—"}</TableCell>
                        <TableCell className="text-right tabular">
                          {d.nonCallableMax != null ? d.nonCallableMax.toFixed(2) : d.nonCallable !== null ? d.nonCallable.toFixed(2) : "—"}
                        </TableCell>
                      </>
                    ) : (
                      <TableCell className="text-right tabular">
                        {d.callable !== null ? d.callable.toFixed(2) : d.nonCallable !== null ? d.nonCallable.toFixed(2) : "—"}
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="rounded border border-dashed p-4 text-xs text-muted-foreground">
              {live.note ?? "No 1Y+ rates available for this bank."}
            </div>
          )}
          <div className="pt-1">
            <button type="button"
              onClick={() => window.open(live.sourceUrl ?? bank.bulkRateSourceUrl, "_blank", "noopener,noreferrer")}
              className="text-[11px] text-mds-blue inline-flex items-center gap-1 hover:underline cursor-pointer">
              Official source <ExternalLink className="h-3 w-3" />
            </button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Money market and bond activity — detailed tables */}
      <Dialog open={open === "mm" || open === "bond"} onOpenChange={(v) => !v && setOpen(null)}>
        <DialogContent className="max-w-5xl max-h-[85vh] overflow-auto p-0">
          <DialogHeader className="sr-only">
            <DialogTitle>{open === "bond" ? "Bond activity" : "Money market activity"}</DialogTitle>
            <DialogDescription>Recent counterparty market activity</DialogDescription>
          </DialogHeader>
          {open && open !== "deposit" && (
            <MarketActivityCard
              bank={bank}
              live={activity}
              loading={loading}
              fetchedAt={fetchedAt}
              groupFilter={open}
              title={open === "bond" ? "Bond activity" : "Money market activity"}
              bare
            />
          )}
          <div className="px-6 pb-4 text-[10px] text-muted-foreground">
            {open === "bond" ? `${bondCount} bond entries` : `${mmCount} money-market entries`}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}


function LiveBulkDepositCard({
  bank, live, loading, fetchedAt,
}: {
  bank: BankProfile;
  live: { rows: LiveDepositRow[] | null; sourceUrl: string | null; asOf: string | null; note: string | null; illustrative?: boolean; hasAmountBuckets?: boolean };
  loading: boolean;
  fetchedAt: string | null;
}) {
  const allRows = live.rows;
  // Show only 1-year-and-above tenors
  const rows = allRows?.filter((r) => {
    const t = r.tenor.toLowerCase();
    if (/<\s*1\s*year|less\s+than\s+1\s*year/.test(t)) return false;
    if (/\bday|\bdays\b/.test(t) && !/year|yr/.test(t)) return false;
    const monthMatches = [...t.matchAll(/(\d+(?:\.\d+)?)\s*months?/g)].map((m) => Number(m[1]));
    if (monthMatches.length > 0 && !/year|yr/.test(t)) return monthMatches.some((m) => m >= 12);
    return /\byear|\byr\b|\byrs\b/.test(t);
  }) ?? null;
  const sourceUrl = live.sourceUrl ?? bank.bulkRateSourceUrl;
  // Applicable amount range per bank's published bulk-deposit rate card.
  const amountRangeLabel: string = live.hasAmountBuckets
    ? "≥ ₹3 Cr (bucketed)"
    : bank.id === "sbi"
      ? "≥ ₹3 Cr (Domestic Bulk Term Deposits)"
      : bank.id === "tmb"
        ? "≥ ₹2 Cr"
        : "≥ ₹2 Cr (Bulk)";
  return (
    <Card className="lg:col-span-2">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center justify-between">
          <span className="flex items-center gap-2">
            <span className="w-1 h-4 bg-mds-navy rounded" /> Bulk Deposit Rates — 1Y & Above
            {live.illustrative && <span className="inline-block rounded bg-amber-100 text-amber-800 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5">Illustrative</span>}
          </span>
          <button type="button"
            onClick={() => window.open(sourceUrl, "_blank", "noopener,noreferrer")}
            className="text-[11px] text-mds-blue font-normal normal-case tracking-normal inline-flex items-center gap-1 hover:underline cursor-pointer">
            Official source <ExternalLink className="h-3 w-3" />
          </button>
        </CardTitle>
        <div className="text-[11px] text-muted-foreground mt-1">
          Applicable amount: <span className="font-medium text-mds-navy">{amountRangeLabel}</span>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {loading && !rows ? (
          <div className="text-xs text-muted-foreground py-6">Fetching live rate card…</div>
        ) : rows && rows.length > 0 ? (
          <>
            <Table className="text-xs">
              <TableHeader>
                <TableRow>
                  <TableHead>Tenor</TableHead>
                  {live.hasAmountBuckets ? (
                    <>
                      <TableHead className="text-right">≥ ₹3 Cr &lt; ₹5 Cr (%)</TableHead>
                      <TableHead className="text-right">≥ ₹5 Cr (%)</TableHead>
                    </>
                  ) : (
                    <TableHead className="text-right">Rate (%)</TableHead>
                  )}
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((d, i) => (
                  <TableRow key={i}>
                    <TableCell>{d.tenor}</TableCell>
                    {live.hasAmountBuckets ? (
                      <>
                        <TableCell className="text-right tabular">
                          {d.callable !== null ? d.callable.toFixed(2) : "—"}
                        </TableCell>
                        <TableCell className="text-right tabular">
                          {d.nonCallableMax != null
                            ? d.nonCallableMax.toFixed(2)
                            : d.nonCallable !== null ? d.nonCallable.toFixed(2) : "—"}
                        </TableCell>
                      </>
                    ) : (
                      <TableCell className="text-right tabular">
                        {d.callable !== null ? d.callable.toFixed(2) : (d.nonCallable !== null ? d.nonCallable.toFixed(2) : "—")}
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>



          </>
        ) : (
          <div className="rounded border border-dashed p-4 text-xs text-muted-foreground">
            <div className="font-medium text-mds-navy mb-1">No 1Y+ rates available</div>
            <div>
              {live.note ?? "This bank's bulk deposit page uses a format that isn't parsed yet."}
              {" "}Open the official source to view current rates.
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}


// ============ Market Activity — money market + bonds (Bloomberg / news) ============
type ActivityRow = {
  date: string;
  group: "mm" | "bond";
  instrument: string;
  tenor: string | null;
  rate: string | null;
  amount: string | null;
  status: string | null;
  side: string | null;
  counterparty: string | null;
  rating: string | null;
  market: string | null;
  desc: string | null;
  url: string | null;
  source: string;
  illustrative: boolean;
};

const BOND_RX = /bond|debenture|ncd|tier[- ]?2|tier[- ]?ii|at1|infra|perpetual|msf|notes/i;

/** Consistent display formatters so live and tape rows read identically. */
const MONTHS_SHORT = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function fmtActDate(v: string | null): string {
  if (!v) return "—";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(v.trim());
  if (m) return `${m[3]} ${MONTHS_SHORT[+m[2] - 1]} ${m[1].slice(2)}`;
  const d = new Date(v);
  if (!isNaN(d.getTime())) return `${String(d.getDate()).padStart(2, "0")} ${MONTHS_SHORT[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`;
  return v;
}
/** Sortable timestamp from any date string ("2026-08-03", "24-Jun-2026", "FY25"). */
function actTime(v: string | null): number {
  if (!v) return 0;
  const s = v.trim();
  const iso = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (iso) return Date.UTC(+iso[1], +iso[2] - 1, +iso[3]);
  const dmy = /^(\d{1,2})[-/\s]([A-Za-z]{3,})[-/\s](\d{2,4})/.exec(s);
  if (dmy) {
    const mi = MONTHS_SHORT.findIndex((m) => m.toLowerCase() === dmy[2].slice(0, 3).toLowerCase());
    const yr = +dmy[3] < 100 ? 2000 + +dmy[3] : +dmy[3];
    if (mi >= 0) return Date.UTC(yr, mi, +dmy[1]);
  }
  const my = /^([A-Za-z]{3,})[-/\s](\d{2,4})/.exec(s);
  if (my) {
    const mi = MONTHS_SHORT.findIndex((m) => m.toLowerCase() === my[1].slice(0, 3).toLowerCase());
    const yr = +my[2] < 100 ? 2000 + +my[2] : +my[2];
    if (mi >= 0) return Date.UTC(yr, mi, 1);
  }
  const fy = /^FY\s?(\d{2,4})/i.exec(s);
  if (fy) {
    const yr = +fy[1] < 100 ? 2000 + +fy[1] : +fy[1];
    return Date.UTC(yr, 2, 31);
  }
  const d = new Date(s);
  return isNaN(d.getTime()) ? 0 : d.getTime();
}

/** Any amount string / number → "₹X,XXX Cr". */
function fmtActAmount(v: string | number | null): string {
  if (v == null) return "—";
  if (typeof v === "number") return `₹${Math.round(v).toLocaleString("en-IN")} Cr`;
  const txt = v.replace(/,/g, "");
  const num = parseFloat((/-?\d+(\.\d+)?/.exec(txt) ?? [""])[0]);
  if (isNaN(num)) return v;
  const cr = /cr/i.test(txt) ? num : /lakh|lac/i.test(txt) ? num / 100 : /\bbn|billion/i.test(txt) ? num * 100 : num;
  return `₹${Math.round(cr).toLocaleString("en-IN")} Cr`;
}
/** Any rate string / number → "X.XX%". */
function fmtActRate(v: string | number | null): string {
  if (v == null) return "—";
  if (typeof v === "number") return `${v.toFixed(2)}%`;
  const num = parseFloat((/-?\d+(\.\d+)?/.exec(v.replace(/,/g, "")) ?? [""])[0]);
  return isNaN(num) ? v : `${num.toFixed(2)}%`;
}
/** Tenor strings → compact, uppercase units (e.g. "10Y (call 5Y)", "3M"). */
function fmtActTenor(v: string | null): string {
  if (!v) return "—";
  const t = v.trim().replace(/\s*years?/gi, "Y").replace(/\s*months?/gi, "M").replace(/\s*days?/gi, "D");
  return t.replace(/(\d)\s*([ymd])/gi, (_, d: string, u: string) => `${d}${u.toUpperCase()}`);
}
const titleCase = (s: string) => s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();

type ManualQuote = {
  id: string;
  date: string;        // ISO
  instrument: string;
  tenor: string;
  ratePct: string;
  amountCr: string;
  source: string;      // Treasury / Bloomberg / News / Desk
  notes: string;
};

const QUOTES_KEY = "sidbi.marketQuotes.v1";
const QUOTE_SOURCES = ["Treasury", "Bloomberg", "News", "Desk quote"];

/** Money-market instruments the desk quotes on — CDs across tenors, incl. bulk. */
const QUOTE_INSTRUMENTS: { label: string; tenor: string }[] = [
  { label: "Certificate of Deposit (CD)", tenor: "1M" },
  { label: "Certificate of Deposit (CD)", tenor: "3M" },
  { label: "Certificate of Deposit (CD)", tenor: "6M" },
  { label: "Certificate of Deposit (CD)", tenor: "9M" },
  { label: "Certificate of Deposit (CD)", tenor: "1Y" },
  { label: "Certificate of Deposit (CD)", tenor: "2Y" },
  { label: "CD · bulk (₹3 Cr+)", tenor: "1Y" },
  { label: "CD · bulk (₹5 Cr+)", tenor: "1Y" },
  { label: "Commercial Paper (CP)", tenor: "3M" },
  { label: "Term money", tenor: "3M" },
];
const quoteKey = (i: { label: string; tenor: string }) => `${i.label} · ${i.tenor}`;

function emptyQuote(): ManualQuote {
  return {
    id: `q${Date.now()}`,
    date: new Date().toISOString().slice(0, 10),
    instrument: "", tenor: "", ratePct: "", amountCr: "",
    source: "Treasury", notes: "",
  };
}

const QUOTES_EVENT = "sidbi-quotes-changed";

/** Shared manual-quote store (localStorage) so the range bar reflects new quotes. */
function useManualQuotes(): [ManualQuote[], (next: ManualQuote[]) => void] {
  const [quotes, setQuotes] = useState<ManualQuote[]>([]);
  useEffect(() => {
    const load = () => {
      try {
        const raw = window.localStorage.getItem(QUOTES_KEY);
        setQuotes(raw ? (JSON.parse(raw) as ManualQuote[]) : []);
      } catch { /* ignore */ }
    };
    load();
    window.addEventListener(QUOTES_EVENT, load);
    return () => window.removeEventListener(QUOTES_EVENT, load);
  }, []);
  const persist = (next: ManualQuote[]) => {
    setQuotes(next);
    try { window.localStorage.setItem(QUOTES_KEY, JSON.stringify(next)); } catch { /* ignore */ }
    window.dispatchEvent(new Event(QUOTES_EVENT));
  };
  return [quotes, persist];
}

/** Short instrument form for range-bar labels: "1Y CD (bulk ₹5 Cr+)", "3M CP". */
function shortInstrument(instrument: string, tenor: string): string {
  const i = instrument.toLowerCase();
  let base = instrument;
  if (i.includes("bulk")) {
    const cr = instrument.match(/₹\s*\d+\s*Cr\+?/i)?.[0];
    base = cr ? `CD bulk ${cr}` : "CD bulk";
  } else if (i.includes("certificate of deposit") || i.startsWith("cd")) base = "CD";
  else if (i.includes("commercial paper") || i.startsWith("cp")) base = "CP";
  else if (i.includes("term money")) base = "Term money";
  return [tenor, base].filter(Boolean).join(" ");
}

/** Most recent counterparty quote carrying a numeric rate. */
function latestQuoteRate(quotes: ManualQuote[]): { rate: number; label: string } | null {
  const sorted = [...quotes].sort((a, b) => (a.date < b.date ? 1 : -1));
  for (const q of sorted) {
    const n = actRateNum(q.ratePct);
    if (n !== null) {
      const short = shortInstrument(q.instrument, q.tenor);
      return { rate: n, label: short ? `CP Quote · ${short}` : "CP Quote" };
    }
  }
  return null;
}




type ActivityLive = { rows: LiveAnnouncement[]; sourceUrl: string | null; note: string | null; illustrative?: boolean };

/** Bond filings + Bloomberg tape + Treasury prints, unsorted. Shared by tiles and the table. */
function baseActivityRows(bank: BankProfile, live: ActivityLive): ActivityRow[] {
  const bonds: ActivityRow[] = live.rows.map((r) => ({
    date: r.date,
    group: "bond",
    instrument: r.securityType ?? "Bond",
    tenor: r.tenure,
    rate: r.coupon,
    amount: r.amount,
    status: r.status,
    side: "Issued",
    counterparty: null,
    rating: r.rating ?? null,
    market: r.market,
    desc: r.desc,
    url: r.attachmentUrl ?? live.sourceUrl,
    source: "News",
    illustrative: !!live.illustrative,
  }));
  const tape: ActivityRow[] = counterpartyMarketDeals(bank).map((d) => ({
    date: d.date,
    group: BOND_RX.test(d.instrument) ? "bond" : "mm",
    instrument: d.instrument,
    tenor: d.tenor,
    rate: `${d.ratePct.toFixed(2)}%`,
    amount: `₹${d.amountCr} Cr`,
    status: "Settled",
    side: d.side,
    counterparty: d.counterpartyType,
    rating: bank.rating,
    market: "Domestic",
    desc: null,
    url: null,
    source: "Bloomberg",
    illustrative: true,
  }));
  const treasury: ActivityRow[] = treasuryDeals().map((d) => ({
    date: d.date,
    group: BOND_RX.test(d.instrument) ? "bond" : "mm",
    instrument: d.instrument,
    tenor: d.tenor,
    rate: `${d.ratePct.toFixed(2)}%`,
    amount: `₹${d.amountCr} Cr`,
    status: "Settled",
    side: null,
    counterparty: d.counterparty,
    rating: null,
    market: "Domestic",
    desc: d.note ?? null,
    url: null,
    source: d.source,
    illustrative: true,
  }));
  return [...bonds, ...tape, ...treasury];
}

/** Numeric rate from a display string like "7.35%". */
function actRateNum(v: string | null): number | null {
  if (!v) return null;
  const m = /(\d+(?:\.\d+)?)/.exec(v);
  return m ? Number(m[1]) : null;
}

function MarketActivityCard({
  bank, live, loading, fetchedAt, groupFilter, title, bare,
}: {
  bank: BankProfile;
  live: ActivityLive;
  loading: boolean;
  fetchedAt: string | null;
  groupFilter?: "mm" | "bond";
  title?: string;
  bare?: boolean;
}) {

  const [openIdx, setOpenIdx] = useState<string | null>(null);
  const [quotes, persistQuotes] = useManualQuotes();
  const [addOpen, setAddOpen] = useState(false);
  const [draft, setDraft] = useState<ManualQuote>(emptyQuote);


  const rows: ActivityRow[] = useMemo(() => {
    const manual: ActivityRow[] = quotes.map((q) => ({
      date: q.date,
      group: BOND_RX.test(q.instrument) ? "bond" : "mm",
      instrument: q.instrument || "Quote",
      tenor: q.tenor || null,
      rate: q.ratePct || null,
      amount: q.amountCr || null,
      status: "Quoted",
      side: null,
      counterparty: bank.name,
      rating: null,
      market: null,
      desc: q.notes || null,
      url: null,
      source: q.source,
      illustrative: false,
    }));
    const all = [...baseActivityRows(bank, live), ...manual]
      .sort((a, b) => actTime(b.date) - actTime(a.date));
    return groupFilter ? all.filter((r) => r.group === groupFilter) : all;
  }, [live, bank, quotes, groupFilter]);


  const [showAll, setShowAll] = useState(false);
  const shown = showAll ? rows : rows.slice(0, 5);

  const saveQuote = () => {
    if (!draft.instrument.trim()) return;
    persistQuotes([{ ...draft, id: `q${Date.now()}` }, ...quotes]);
    setDraft(emptyQuote());
    setAddOpen(false);
  };

  return (
    <Card className={bare ? "border-0 shadow-none" : undefined}>
      <CardHeader className="pb-3">
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
          <div className="min-w-0">
            <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2 flex-wrap">
              <span className="w-1 h-4 bg-mds-blue rounded" /> {title ?? "Recent Market Activity"}

              <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-mds-navy/10 text-mds-navy text-[10px] font-semibold tracking-normal">
                {bank.rating}
              </span>
              <span className="inline-block rounded bg-amber-100 text-amber-800 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5">Illustrative</span>
            </CardTitle>
            <div className="mt-1 text-[10px] text-muted-foreground">
              Funds raised, money-market prints and CD quotes · Treasury, Bloomberg &amp; news{fetchedAt ? ` · ${fetchedAt}` : ""}
            </div>
          </div>
          {groupFilter !== "bond" && (
            <Button size="sm" className="h-8 shrink-0 bg-mds-blue text-white hover:bg-mds-blue/90 text-[11px]"
              onClick={() => { setDraft(emptyQuote()); setAddOpen(true); }}>
              Add quote
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {loading && rows.length === 0 ? (
          <div className="p-6 text-xs text-muted-foreground">Fetching market activity…</div>
        ) : shown.length === 0 ? (
          <div className="p-6 text-xs text-muted-foreground">
            {live.note ?? "No recent market activity surfaced for this counterparty."}
          </div>
        ) : (
          <>
            <Table className="text-xs">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[32px]"></TableHead>
                  <TableHead className="w-[85px]">Date</TableHead>
                  {!groupFilter && <TableHead className="w-[95px]">Type</TableHead>}
                  <TableHead>Instrument</TableHead>
                  <TableHead className="w-[140px]">Counterparty</TableHead>
                  <TableHead className="text-right w-[100px]">Amount</TableHead>
                  <TableHead className="text-center w-[100px]">Tenor</TableHead>
                  <TableHead className="text-right w-[75px]">Rate</TableHead>
                  <TableHead className="w-[95px]">Status</TableHead>
                  <TableHead className="w-[95px]">Source</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {shown.map((r, i) => {
                  const key = `${r.group}-${r.date}-${i}`;
                  const open = openIdx === key;
                  return (
                    <Fragment key={key}>
                      <TableRow className="cursor-pointer hover:bg-mds-blue/5" onClick={() => setOpenIdx(open ? null : key)}>
                        <TableCell className="w-[32px] p-2">
                          <ChevronDown className={`h-3 w-3 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
                        </TableCell>
                        <TableCell className="tabular whitespace-nowrap">{fmtActDate(r.date)}</TableCell>
                        {!groupFilter && (
                          <TableCell>
                            <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-medium whitespace-nowrap ${
                              r.group === "bond" ? "bg-mds-blue/10 text-mds-blue" : "bg-mds-navy/10 text-mds-navy"
                            }`}>
                              {r.group === "bond" ? "Bond" : "Money mkt"}
                            </span>
                          </TableCell>
                        )}
                        <TableCell className="font-medium text-mds-navy">{r.instrument}</TableCell>
                        <TableCell className="whitespace-nowrap text-mds-navy">{r.counterparty ?? "—"}</TableCell>
                        <TableCell className="text-right tabular whitespace-nowrap">{fmtActAmount(r.amount)}</TableCell>
                        <TableCell className="text-center tabular whitespace-nowrap">{fmtActTenor(r.tenor)}</TableCell>
                        <TableCell className="text-right tabular font-semibold whitespace-nowrap">{fmtActRate(r.rate)}</TableCell>
                        <TableCell className="whitespace-nowrap">
                          {r.status ? (
                            <span className={`inline-flex items-center gap-1 ${
                              /approval|expected|proposed|quoted/i.test(r.status) ? "text-mds-warning"
                                : /active|issued|settled|closed/i.test(r.status) ? "text-mds-success"
                                : "text-muted-foreground"
                            }`}>
                              <span className="w-1.5 h-1.5 rounded-full bg-current" />
                              {titleCase(r.status)}
                            </span>
                          ) : "—"}
                        </TableCell>
                        <TableCell className="whitespace-nowrap text-muted-foreground">{r.source}</TableCell>
                      </TableRow>

                      {open && (
                        <TableRow className="bg-mds-blue/5 hover:bg-mds-blue/5">
                          <TableCell colSpan={groupFilter ? 9 : 10} className="p-4">
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                              {([
                                ["Date", fmtActDate(r.date)],
                                ["Segment", r.group === "bond" ? "Bonds / primary issuance" : "Money market"],
                                ["Instrument", r.instrument],
                                ["Side", r.side ? titleCase(r.side) : "—"],
                                ["Amount", fmtActAmount(r.amount)],
                                ["Tenor / maturity", fmtActTenor(r.tenor)],
                                ["Rate / coupon", fmtActRate(r.rate)],
                                ["Rating", r.rating ?? "—"],
                                ["Market", r.market ?? "—"],
                                ["Counterparty", r.counterparty ?? "—"],
                                ["Status", r.status ? titleCase(r.status) : "—"],
                                ["Source", r.source],
                              ] as const).map(([label, val]) => (
                                <div key={label}>
                                  <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">{label}</div>
                                  <div className="text-mds-navy tabular">{val}</div>
                                </div>
                              ))}
                            </div>
                            {r.desc && (
                              <div className="mt-3">
                                <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1">Notes</div>
                                <div className="text-xs text-mds-navy whitespace-pre-wrap break-words leading-relaxed">{r.desc}</div>
                              </div>
                            )}
                            {r.url && (
                              <div className="mt-3">
                                <a href={r.url} target="_blank" rel="noopener noreferrer"
                                  className="text-[11px] text-mds-blue inline-flex items-center gap-1 hover:underline">
                                  Open source <ExternalLink className="h-3 w-3" />
                                </a>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      )}
                    </Fragment>
                  );
                })}
              </TableBody>
            </Table>
            {rows.length > 5 && (
              <div className="border-t border-border p-2 flex justify-center">
                <Button variant="ghost" size="sm" className="h-7 text-[11px] text-mds-blue hover:bg-mds-blue/5"
                  onClick={() => setShowAll((v) => !v)}>
                  {showAll
                    ? <>Show less <ChevronDown className="h-3 w-3 ml-1 rotate-180" /></>
                    : <>Show all {rows.length} entries <ChevronDown className="h-3 w-3 ml-1" /></>}
                </Button>
              </div>
            )}
          </>
        )}
      </CardContent>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-sm uppercase tracking-wider text-mds-navy">Add market quote · {bank.name}</DialogTitle>
            <DialogDescription className="text-xs">
              Record a quote or print picked up from Treasury, Bloomberg or news. Counterparty is the bank selected above.
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <MicroField label="Date">
              <Input type="date" value={draft.date} max={new Date().toISOString().slice(0, 10)}
                onChange={(e) => {
                  const t = new Date().toISOString().slice(0, 10);
                  setDraft({ ...draft, date: e.target.value > t ? t : e.target.value });
                }}
                className="h-8 text-xs bg-white tabular" />
            </MicroField>
            <MicroField label="Source">
              <Select value={draft.source} onValueChange={(v) => setDraft({ ...draft, source: v })}>
                <SelectTrigger className="h-8 text-xs bg-white"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {QUOTE_SOURCES.map((sr) => <SelectItem key={sr} value={sr} className="text-xs">{sr}</SelectItem>)}
                </SelectContent>
              </Select>
            </MicroField>
            <div className="col-span-2">
              <MicroField label="Instrument">
                <Select
                  value={draft.instrument ? quoteKey({ label: draft.instrument, tenor: draft.tenor }) : undefined}
                  onValueChange={(v) => {
                    const opt = QUOTE_INSTRUMENTS.find((i) => quoteKey(i) === v);
                    if (opt) setDraft({ ...draft, instrument: opt.label, tenor: opt.tenor });
                  }}>
                  <SelectTrigger className="h-8 text-xs bg-white"><SelectValue placeholder="Select instrument" /></SelectTrigger>
                  <SelectContent>
                    {QUOTE_INSTRUMENTS.map((i) => (
                      <SelectItem key={quoteKey(i)} value={quoteKey(i)} className="text-xs">
                        {i.label} · {i.tenor}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </MicroField>
            </div>
            <MicroField label="Rate %">
              <Input value={draft.ratePct} inputMode="decimal" onChange={(e) => setDraft({ ...draft, ratePct: e.target.value })}
                className="h-8 text-xs bg-white tabular" />
            </MicroField>
            <MicroField label="Tenor">
              <Input value={draft.tenor} onChange={(e) => setDraft({ ...draft, tenor: e.target.value })}
                className="h-8 text-xs bg-white" />
            </MicroField>

            <MicroField label="Amount (₹ Cr)">
              <Input value={draft.amountCr} inputMode="decimal" onChange={(e) => setDraft({ ...draft, amountCr: e.target.value })}
                className="h-8 text-xs bg-white tabular" />
            </MicroField>
            <div className="col-span-2">
              <MicroField label="Notes">
                <Input value={draft.notes} onChange={(e) => setDraft({ ...draft, notes: e.target.value })}
                  className="h-8 text-xs bg-white" />
              </MicroField>
            </div>
          </div>
          {quotes.length > 0 && (
            <div className="space-y-1 border-t border-border pt-3">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Saved quotes</div>
              {quotes.map((q) => (
                <div key={q.id} className="flex items-center justify-between text-[11px] text-mds-navy">
                  <span className="truncate">{fmtActDate(q.date)} · {q.instrument} · {fmtActRate(q.ratePct)}</span>
                  <button type="button" onClick={() => persistQuotes(quotes.filter((x) => x.id !== q.id))}
                    className="text-muted-foreground hover:text-mds-danger shrink-0" aria-label="Delete quote">
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button size="sm" className="h-8 text-xs bg-mds-blue text-white hover:bg-mds-blue/90"
              disabled={!draft.instrument.trim()} onClick={saveQuote}>
              Save quote
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}





const NEGOTIATION_STATUSES: NegotiationStatus[] = ["closed", "quoted", "proposed", "on hold", "declined"];

function statusClass(s: NegotiationStatus) {
  if (s === "closed") return "border-mds-success/40 text-mds-success";
  if (s === "quoted" || s === "proposed") return "border-mds-blue/40 text-mds-blue";
  if (s === "on hold") return "border-amber-400 text-amber-700";
  return "border-destructive/40 text-destructive";
}

const NEGOTIATION_STORE_PREFIX = "sidbi.pastNegotiations.";

/** Repayment options mirror the dashboard exactly. */
const NEGO_FREQS = FREQUENCIES.map((f) => f.label);

/** One row of the row-wise component editor — mirrors the dashboard input build-up. */
type CompRow = {
  scheme: "MSER" | "RMSE";
  /** MSER: CoF option key + rate + margin + discretion (rate is derived). */
  cofKey: string;
  cofPct: string;
  marginBps: string;
  discretionBps: string;
  /** RMSE: tranche id + name + RBI fund rate + tranche margin (rate is derived). */
  trancheId: string;
  trancheName: string;
  fundRatePct: string;
  amountCr: string;
  freq: string;
  moratoriumMonths: string;
  tenureMonths: string;
};

/** First CoF option that actually carries a live/static rate. */
function pickCof(cofOptions: CofOption[]): CofOption | undefined {
  return cofOptions.find((c) => c.ratePct !== null) ?? cofOptions[0];
}

function newRow(scheme: "MSER" | "RMSE", minMarginBps: number, cofOptions: CofOption[], tranche?: Tranche, today?: Date): CompRow {
  const c = pickCof(cofOptions);
  const t = tranche;
  const tenure = t && today ? roundedMonthsBetween(today, parseISODate(t.date)) : 0;
  return {
    scheme,
    cofKey: c?.key ?? COF_OPTION_DEFS[2]?.key ?? "1y3y_fixed",
    cofPct: c?.ratePct != null ? c.ratePct.toFixed(2) : "",
    marginBps: String(scheme === "RMSE" ? (t?.marginBps ?? RMSE_MARGIN_BPS) : minMarginBps),
    discretionBps: "0",
    trancheId: scheme === "RMSE" ? (t?.id ?? "") : "",
    trancheName: scheme === "RMSE" ? (t?.label ?? "") : "",
    fundRatePct: scheme === "RMSE" && t ? t.fundRatePct.toFixed(2) : "",
    amountCr: "",
    freq: scheme === "RMSE" ? "Bullet" : "Quarterly",
    moratoriumMonths: "",
    tenureMonths: scheme === "RMSE" && tenure > 0 ? String(tenure) : "",
  };

}

/** Derived rate for a row, exactly as the dashboard builds it. */
function rowRate(r: CompRow): number {
  const n = (s: string) => (s.trim() === "" ? 0 : Number(s) || 0);
  if (r.scheme === "RMSE") return n(r.fundRatePct) + n(r.marginBps) / 100;
  const cof = n(r.cofPct);
  return Math.max(cof, cof + n(r.marginBps) / 100 - n(r.discretionBps) / 100);
}

type NegoDraft = {
  date: string; status: NegotiationStatus;
  principalCr: string;
  rows: CompRow[];
  counterpartyAskPct: string; proposedRatePct: string; warPct: string; note: string;
};

function emptyDraft(minMarginBps: number, cofOptions: CofOption[], tranches: Tranche[], today: Date): NegoDraft {
  return {
    date: toISODate(new Date()), status: "quoted",
    principalCr: "",
    rows: [
      newRow("MSER", minMarginBps, cofOptions),
      newRow("RMSE", RMSE_MARGIN_BPS, cofOptions, tranches[0], today),
    ],
    counterpartyAskPct: "", proposedRatePct: "", warPct: "", note: "",
  };
}




function PastDealsCard({ deals, bankName, bankId, bankCategory, cofOptions }: { deals: PastDeal[]; bankName: string; bankId: string; bankCategory: BankCategory; cofOptions: CofOption[] }) {
  const minMargin = marginBps(bankCategory);
  const maxDisc = discretionMaxBps(bankCategory);
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  const [added, setAdded] = useState<PastDeal[]>([]);
  const [addOpen, setAddOpen] = useState(false);
  const [pendingDeal, setPendingDeal] = useState<PastDeal | null>(null);

  const today = useMemo(() => {
    const n = new Date();
    return new Date(n.getFullYear(), n.getMonth(), n.getDate());
  }, []);

  // Same RMSE tranche master the dashboard inputs use.
  const [tranches, setTranches] = useState<Tranche[]>(defaultTranches);
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(TRANCHE_STORE_KEY);
      const parsed = raw ? (JSON.parse(raw) as Tranche[]) : null;
      if (parsed && parsed.length) setTranches(parsed);
    } catch { /* keep defaults */ }
  }, [addOpen]);

  const [draft, setDraft] = useState<NegoDraft>(() => emptyDraft(minMargin, cofOptions, defaultTranches(), today));

  const storeKey = NEGOTIATION_STORE_PREFIX + bankId;

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(storeKey);
      setAdded(raw ? (JSON.parse(raw) as PastDeal[]) : []);
    } catch { setAdded([]); }
  }, [storeKey]);

  const allDeals = useMemo(
    () => [...added, ...deals].sort((a, b) => (a.date < b.date ? 1 : -1)),
    [added, deals],
  );
  const open = openIdx !== null ? allDeals[openIdx] : null;

  const num = (s: string) => (s.trim() === "" ? 0 : Number(s) || 0);

  const setRow = (i: number, patch: Partial<CompRow>) =>
    setDraft((d) => ({ ...d, rows: d.rows.map((r, j) => (j === i ? { ...r, ...patch } : r)) }));
  const addRow = (scheme: "MSER" | "RMSE") =>
    setDraft((d) => ({ ...d, rows: [...d.rows, newRow(scheme, minMargin, cofOptions, tranches[0], today)] }));
  const removeRow = (i: number) =>
    setDraft((d) => ({ ...d, rows: d.rows.filter((_, j) => j !== i) }));

  /** Reset the draft with fresh live CoF / tranche values each time the dialog opens. */
  const openAdd = () => {
    setDraft(emptyDraft(minMargin, cofOptions, tranches, today));
    setAddOpen(true);
  };


  const draftTotal = draft.rows.reduce((s, r) => s + num(r.amountCr), 0);

  // Blended offer implied by the rows (amount-weighted).
  const impliedWar = useMemo(() => {
    const t = draft.rows.reduce((s, r) => s + num(r.amountCr), 0);
    if (t <= 0) return null;
    return draft.rows.reduce((s, r) => s + num(r.amountCr) * rowRate(r), 0) / t;
  }, [draft.rows]);

  const offerPct = draft.proposedRatePct.trim() === "" ? impliedWar : num(draft.proposedRatePct);
  const askPct = draft.counterpartyAskPct.trim() === "" ? null : num(draft.counterpartyAskPct);
  const gapBps = offerPct !== null && askPct !== null ? Math.round((offerPct - askPct) * 100) : null;
  const matched = gapBps !== null && Math.abs(gapBps) <= 1;
  // A deal can only be closed when what we offered meets the counterparty ask.
  const statusOptions = matched
    ? NEGOTIATION_STATUSES
    : NEGOTIATION_STATUSES.filter((s) => s !== "closed");

  useEffect(() => {
    if (!matched && draft.status === "closed") setDraft((d) => ({ ...d, status: "quoted" }));
  }, [matched, draft.status]);

  const saveDraft = () => {
    const comps: DealComponent[] = draft.rows
      .filter((r) => num(r.amountCr) > 0 || rowRate(r) > 0)
      .map((r) => ({
        scheme: r.scheme,
        label: r.scheme === "RMSE"
          ? (r.trancheName.trim() || undefined)
          : (COF_OPTION_DEFS.find((c) => c.key === r.cofKey)?.label ?? undefined),
        amountCr: num(r.amountCr),
        freq: r.scheme === "RMSE" ? "Bullet" : (r.freq || "—"),
        ratePct: rowRate(r),
        moratoriumMonths: num(r.moratoriumMonths),
        tenureMonths: num(r.tenureMonths),
        cofLabel: r.scheme === "MSER" ? (COF_OPTION_DEFS.find((c) => c.key === r.cofKey)?.label ?? null) : null,
        cofPct: r.scheme === "MSER" ? num(r.cofPct) : null,
        marginBps: num(r.marginBps),
        discretionBps: r.scheme === "MSER" ? num(r.discretionBps) : null,
        fundRatePct: r.scheme === "RMSE" ? num(r.fundRatePct) : null,
      }));
    const mserRows = comps.filter((c) => c.scheme === "MSER");
    const rmseRows = comps.filter((c) => c.scheme === "RMSE");
    const sum = (xs: DealComponent[]) => xs.reduce((s, c) => s + c.amountCr, 0);
    const wAvg = (xs: DealComponent[]) => {
      const t = sum(xs);
      return t > 0 ? xs.reduce((s, c) => s + c.amountCr * c.ratePct, 0) / t : (xs[0]?.ratePct ?? 0);
    };
    const mser = sum(mserRows);
    const rmse = sum(rmseRows);
    const rec: PastDeal = {
      date: draft.date,
      status: matched ? draft.status : (draft.status === "closed" ? "quoted" : draft.status),
      counterpartyAskPct: askPct,
      principalCr: draft.principalCr.trim() === "" ? mser + rmse : num(draft.principalCr),
      mserCr: mser,
      rmseCr: rmse,
      mserTenureMonths: mserRows[0]?.tenureMonths ?? 0,
      rmseTenureMonths: rmseRows[0]?.tenureMonths ?? 0,
      mserFreq: mserRows[0]?.freq ?? "—",
      cofPct: mserRows[0]?.cofPct ?? 0,
      cofStructure: mserRows[0]?.cofLabel ?? "—",
      marginPct: (mserRows[0]?.marginBps ?? 0) / 100,
      discretionBps: mserRows[0]?.discretionBps ?? null,
      proposedRatePct: draft.proposedRatePct.trim() === "" ? wAvg(mserRows) : num(draft.proposedRatePct),
      rmseRatePct: rmseRows.length ? wAvg(rmseRows) : RMSE_FIXED_RATE,
      xirrPct: null,
      warPct: draft.warPct.trim() === "" ? wAvg(comps) : num(draft.warPct),
      note: draft.note.trim() || undefined,
      components: comps,
    };
    const next = [rec, ...added];
    setAdded(next);
    try { window.localStorage.setItem(storeKey, JSON.stringify(next)); } catch { /* ignore */ }
    setDraft(emptyDraft(minMargin, cofOptions, tranches, today));
    setAddOpen(false);
  };

  const deleteDeal = (rec: PastDeal) => {
    const next = added.filter((d) => d !== rec);
    setAdded(next);
    try { window.localStorage.setItem(storeKey, JSON.stringify(next)); } catch { /* ignore */ }
    setPendingDeal(null);
    setOpenIdx(null);
  };

  const D = ({ label, k, placeholder, mode = "decimal" }: { label: string; k: "counterpartyAskPct" | "proposedRatePct" | "warPct" | "note"; placeholder?: string; mode?: "decimal" | "numeric" | "text" }) => (
    <div className="space-y-1">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <Input
        value={draft[k]}
        placeholder={placeholder}
        inputMode={mode === "text" ? undefined : mode}
        onChange={(e) => setDraft((d) => ({ ...d, [k]: e.target.value }))}
        className="h-9 text-sm bg-white tabular"
      />
    </div>
  );



  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center justify-between">
            <span className="flex items-center gap-2">
              <span className="w-1 h-4 bg-mds-navy rounded" /> Past Negotiations
              <span className="inline-block rounded bg-amber-100 text-amber-800 text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5">Illustrative</span>
            </span>
            <span className="flex items-center gap-3">
              <span className="text-[10px] font-normal normal-case tracking-normal text-muted-foreground">Click a row for full detail</span>
              <Button
                type="button"
                size="sm"
                className="h-8 text-xs bg-mds-blue hover:bg-mds-blue-hover text-white normal-case tracking-normal"
                onClick={openAdd}
              >
                Add negotiation
              </Button>
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {allDeals.length === 0 ? (
            <div className="p-6 text-sm text-muted-foreground">No prior negotiations on record for this counterparty.</div>
          ) : (
            <Table className="text-xs">
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Principal (Cr)</TableHead>
                  <TableHead>Mix (MSER / RMSE)</TableHead>
                  <TableHead>MSER Tenure / Freq</TableHead>
                  <TableHead className="text-right">Our Offer</TableHead>
                  <TableHead className="text-right">CP Ask</TableHead>
                  <TableHead className="text-right">Gap</TableHead>
                  <TableHead className="text-right">WAR</TableHead>
                  <TableHead className="w-8" />

                </TableRow>
              </TableHeader>
              <TableBody>
                {allDeals.map((d, i) => {
                  const gap = d.counterpartyAskPct != null
                    ? Math.round((d.proposedRatePct - d.counterpartyAskPct) * 100) : null;
                  return (
                  <TableRow key={i} onClick={() => setOpenIdx(i)} className="cursor-pointer hover:bg-mds-blue/5">
                    <TableCell className="tabular">{d.date}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={cn("capitalize", statusClass(d.status))}>{d.status}</Badge>
                    </TableCell>
                    <TableCell className="text-right tabular font-medium">{d.principalCr}</TableCell>
                    <TableCell className="tabular">
                      ₹{d.mserCr} / ₹{d.rmseCr} Cr
                    </TableCell>
                    <TableCell className="tabular">
                      {d.mserTenureMonths}m · {d.mserFreq}
                    </TableCell>
                    <TableCell className="text-right tabular text-muted-foreground">{d.proposedRatePct.toFixed(2)}%</TableCell>
                    <TableCell className="text-right tabular">
                      {d.counterpartyAskPct != null ? `${d.counterpartyAskPct.toFixed(2)}%` : "—"}
                    </TableCell>
                    <TableCell className={cn("text-right tabular",
                      gap === null ? "text-muted-foreground"
                        : Math.abs(gap) <= 1 ? "text-mds-success font-semibold" : "text-amber-700")}>
                      {gap === null ? "—" : `${gap > 0 ? "+" : ""}${gap} bps`}
                    </TableCell>
                    <TableCell className="text-right tabular font-semibold text-mds-blue">{d.warPct.toFixed(2)}%</TableCell>
                    <TableCell className="p-1 text-right">
                      {added.includes(d) ? (
                        <button
                          type="button"
                          aria-label="Delete negotiation"
                          title="Delete negotiation"
                          className="inline-flex h-7 w-7 items-center justify-center rounded text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                          onClick={(e) => { e.stopPropagation(); setPendingDeal(d); }}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      ) : null}
                    </TableCell>
                  </TableRow>

                  );
                })}

              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={!!pendingDeal} onOpenChange={(o) => { if (!o) setPendingDeal(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-base">Delete this negotiation?</AlertDialogTitle>
            <AlertDialogDescription>
              {pendingDeal
                ? `${pendingDeal.date} · ₹${pendingDeal.principalCr} Cr · WAR ${pendingDeal.warPct.toFixed(2)}% will be removed permanently.`
                : ""}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => pendingDeal && deleteDeal(pendingDeal)}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>



      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="text-base text-mds-navy">Add negotiation · {bankName}</DialogTitle>
            <DialogDescription className="text-xs">
              Enter one row per fund component. Total principal is the sum of the rows below.
            </DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Date</div>
              <Input
                type="date"
                value={draft.date}
                max={new Date().toISOString().slice(0, 10)}
                onChange={(e) => setDraft((d) => {
                  const t = new Date().toISOString().slice(0, 10);
                  return { ...d, date: e.target.value > t ? t : e.target.value };
                })}
                className="h-9 text-sm bg-white tabular"
              />
            </div>
            <div className="space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Status</div>
              <Select value={draft.status} onValueChange={(v) => setDraft((d) => ({ ...d, status: v as NegotiationStatus }))}>
                <SelectTrigger className="h-9 text-sm bg-white"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {statusOptions.map((s) => (
                    <SelectItem key={s} value={s} className="text-xs capitalize">{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Total principal (Cr)</div>
              <Input
                value={draft.principalCr}
                inputMode="decimal"
                placeholder={draftTotal > 0 ? draftTotal.toFixed(2) : ""}
                onChange={(e) => setDraft((d) => ({ ...d, principalCr: e.target.value }))}
                className="h-9 text-sm bg-white tabular"
              />
              {(() => {
                const stated = draft.principalCr.trim() === "" ? null : num(draft.principalCr);
                if (stated === null) return (
                  <div className="text-[10px] text-muted-foreground tabular">Split total ₹{draftTotal.toFixed(2)} Cr</div>
                );
                const diff = +(stated - draftTotal).toFixed(2);
                return (
                  <div className={cn("text-[10px] tabular", Math.abs(diff) > 0.01 ? "text-mds-warning font-semibold" : "text-muted-foreground")}>
                    {Math.abs(diff) > 0.01
                      ? `Unallocated ₹${diff.toFixed(2)} Cr across splits`
                      : `Fully allocated across splits`}
                  </div>
                );
              })()}
            </div>

          </div>

          {/* One clean row per component — build-up mirrors the dashboard inputs */}
          <div className="rounded-lg border border-border overflow-hidden">
            <div className="overflow-x-auto max-h-[45vh]">
              <div className="min-w-[1080px]">
                <div className="grid grid-cols-[28px_74px_1.4fr_76px_72px_78px_76px_84px_104px_68px_68px_28px] gap-2 px-3 py-2 bg-secondary/50 text-[10px] uppercase tracking-wider font-semibold text-mds-navy">
                  <div>#</div>
                  <div>Scheme</div>
                  <div>Funding basis</div>
                  <div>CoF / fund %</div>
                  <div>Margin bps</div>
                  <div>Discr. bps</div>
                  <div>Rate %</div>
                  <div>Amount (Cr)</div>
                  <div>Repayment</div>
                  <div>Morat.</div>
                  <div>Tenure</div>
                  <div />
                </div>
                {draft.rows.map((r, i) => (
                  <div key={i} className="grid grid-cols-[28px_74px_1.4fr_76px_72px_78px_76px_84px_104px_68px_68px_28px] gap-2 px-3 py-2 border-t border-border/60 items-center">
                    <div className="text-[11px] tabular text-muted-foreground">{i + 1}</div>
                    <div>
                      <Select value={r.scheme} onValueChange={(v) => {
                        const scheme = v as "MSER" | "RMSE";
                        const fresh = newRow(scheme, minMargin, cofOptions, tranches[0], today);
                        setRow(i, { ...fresh, amountCr: r.amountCr, moratoriumMonths: r.moratoriumMonths });
                      }}>
                        <SelectTrigger className="h-8 text-xs bg-white"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="MSER" className="text-xs">MSER</SelectItem>
                          <SelectItem value="RMSE" className="text-xs">RMSE</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      {r.scheme === "MSER" ? (
                        <Select value={r.cofKey} onValueChange={(v) => {
                          const c = cofOptions.find((o) => o.key === v);
                          setRow(i, {
                            cofKey: v,
                            cofPct: c?.ratePct != null ? c.ratePct.toFixed(2) : "",
                          });
                        }}>
                          <SelectTrigger className="h-8 text-xs bg-white"><SelectValue placeholder="Select CoF" /></SelectTrigger>
                          <SelectContent>
                            {cofOptions.map((c) => (
                              <SelectItem key={c.key} value={c.key} className="text-xs">
                                {c.label}{c.ratePct != null ? ` · ${c.ratePct.toFixed(2)}%` : ""}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Select value={r.trancheId || undefined} onValueChange={(v) => {
                          const t = tranches.find((x) => x.id === v);
                          if (!t) return;
                          const tenure = roundedMonthsBetween(today, parseISODate(t.date));
                          setRow(i, {
                            trancheId: t.id,
                            trancheName: t.label,
                            fundRatePct: t.fundRatePct.toFixed(2),
                            marginBps: String(t.marginBps),
                            tenureMonths: String(tenure),
                          });
                        }}>
                          <SelectTrigger className="h-8 text-xs bg-white"><SelectValue placeholder="Select tranche" /></SelectTrigger>
                          <SelectContent>
                            {tranches.map((t) => (
                              <SelectItem key={t.id} value={t.id} className="text-xs">{t.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    </div>

                    <div>
                      <Input
                        value={r.scheme === "MSER" ? r.cofPct : r.fundRatePct}
                        inputMode="decimal"
                        onChange={(e) => setRow(i, r.scheme === "MSER" ? { cofPct: e.target.value } : { fundRatePct: e.target.value })}
                        className="h-8 text-xs bg-white tabular"
                      />
                    </div>
                    <div>
                      <Input value={r.marginBps} inputMode="numeric" onChange={(e) => setRow(i, { marginBps: e.target.value })}
                        className="h-8 text-xs bg-white tabular" />
                    </div>
                    <div>
                      {r.scheme === "MSER" ? (
                        <Input value={r.discretionBps} inputMode="numeric" onChange={(e) => setRow(i, { discretionBps: e.target.value })}
                          className="h-8 text-xs bg-white tabular" />
                      ) : (
                        <div className="h-8 flex items-center px-2 rounded-md border border-border bg-secondary/40 text-xs text-muted-foreground">—</div>
                      )}
                    </div>
                    <div className="h-8 flex items-center px-2 rounded-md border border-border bg-secondary/40 text-xs tabular font-semibold text-mds-navy">
                      {rowRate(r).toFixed(2)}
                    </div>
                    <div>
                      <Input value={r.amountCr} inputMode="decimal" onChange={(e) => setRow(i, { amountCr: e.target.value })}
                        className="h-8 text-xs bg-white tabular" />
                    </div>
                    <div>
                      {r.scheme === "RMSE" ? (
                        <div className="h-8 flex items-center px-2 rounded-md border border-border bg-secondary/40 text-xs text-mds-navy">Bullet</div>
                      ) : (
                        <Select value={r.freq} onValueChange={(v) => setRow(i, { freq: v })}>
                          <SelectTrigger className="h-8 text-xs bg-white"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {NEGO_FREQS.map((f) => <SelectItem key={f} value={f} className="text-xs">{f}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                    <div>
                      <Input value={r.moratoriumMonths} inputMode="numeric" onChange={(e) => setRow(i, { moratoriumMonths: e.target.value })}
                        className="h-8 text-xs bg-white tabular" />
                    </div>
                    <div>
                      <Input value={r.tenureMonths} inputMode="numeric" onChange={(e) => setRow(i, { tenureMonths: e.target.value })}
                        className="h-8 text-xs bg-white tabular" />
                    </div>
                    <button type="button" aria-label="Remove row" onClick={() => removeRow(i)}
                      disabled={draft.rows.length <= 1}
                      className="h-6 w-6 inline-flex items-center justify-center rounded text-muted-foreground hover:text-destructive disabled:opacity-30">
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
            <div className="px-3 py-2 border-t border-border bg-secondary/30">
              <button type="button" onClick={() => addRow("MSER")} className="text-[11px] text-mds-blue hover:underline">
                + Add row
              </button>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-3">
            <D label="Counterparty ask %" k="counterpartyAskPct" />
            <D label="SIDBI Offer %" k="proposedRatePct" />
            <div className="space-y-1">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground">WAR %</div>
              <Input
                value={draft.warPct === "" && impliedWar !== null ? impliedWar.toFixed(2) : draft.warPct}
                inputMode="decimal"
                onChange={(e) => setDraft((d) => ({ ...d, warPct: e.target.value }))}
                className="h-9 text-sm bg-white tabular"
              />
            </div>
            <D label="Status note" k="note" mode="text" placeholder="Why it closed / where it stands" />
          </div>


          <div className={cn(
            "rounded-md border px-3 py-2 text-xs",
            gapBps === null ? "border-border bg-secondary/30 text-muted-foreground"
              : matched ? "border-mds-success/40 bg-mds-success/5 text-mds-success"
              : "border-amber-400 bg-amber-50 text-amber-800",
          )}>
            {gapBps === null ? (
              "Enter the counterparty ask to check whether the offer matches — a deal can only be marked closed when offer = ask."
            ) : matched ? (
              <>Offer {offerPct!.toFixed(2)}% matches ask {askPct!.toFixed(2)}% — this negotiation can be marked <span className="font-semibold">closed</span>.</>
            ) : (
              <>Offer {offerPct!.toFixed(2)}% vs ask {askPct!.toFixed(2)}% — gap of <span className="font-semibold tabular">{gapBps > 0 ? "+" : ""}{gapBps} bps</span>. Not closed; record it as quoted / proposed / on hold / declined.</>
            )}
          </div>



          <DialogFooter>
            <Button variant="outline" size="sm" className="h-8 text-xs" onClick={() => setAddOpen(false)}>Cancel</Button>
            <Button size="sm" className="h-8 text-xs bg-mds-blue hover:bg-mds-blue-hover text-white" onClick={saveDraft}>
              Save negotiation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>


      <Dialog open={open !== null} onOpenChange={(v) => !v && setOpenIdx(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-mds-navy">
              Deal detail · {bankName} · {open?.date}
            </DialogTitle>
            <DialogDescription>
              {open?.status === "closed"
                ? "Closed — our offer met the counterparty ask."
                : "Open negotiation — offer and ask have not met yet."}
            </DialogDescription>
          </DialogHeader>
          {open && (
            <div className="space-y-4 text-sm">
              <div className="grid grid-cols-3 gap-3">
                <StatBlock label="Total Principal" value={`₹${open.principalCr} Cr`} />
                <StatBlock label="External Rating" value={open.externalRating ?? "—"} />
                <StatBlock label="WAR" value={`${open.warPct.toFixed(2)}%`} accent />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <StatBlock label="SIDBI Offer" value={`${open.proposedRatePct.toFixed(2)}%`} />
                <StatBlock label="Counterparty ask" value={open.counterpartyAskPct != null ? `${open.counterpartyAskPct.toFixed(2)}%` : "—"} />
                <StatBlock
                  label="Gap (offer − ask)"
                  value={open.counterpartyAskPct != null
                    ? `${Math.round((open.proposedRatePct - open.counterpartyAskPct) * 100) > 0 ? "+" : ""}${Math.round((open.proposedRatePct - open.counterpartyAskPct) * 100)} bps`
                    : "—"}
                />
              </div>


              {open.components && open.components.length > 0 ? (
                <div className="rounded-lg border border-border overflow-hidden">
                  <div className="grid grid-cols-[70px_1fr_90px_100px_70px_70px_80px] gap-2 px-3 py-2 bg-secondary/50 text-[10px] uppercase tracking-wider text-muted-foreground">
                    <div>Scheme</div><div>Build-up</div><div className="text-right">Amount</div><div>Repayment</div>
                    <div className="text-right">Rate</div><div className="text-right">Morat.</div><div className="text-right">Tenure</div>
                  </div>
                  {open.components.map((c, i) => (
                    <div key={i} className="grid grid-cols-[70px_1fr_90px_100px_70px_70px_80px] gap-2 px-3 py-2 text-xs border-t border-border/60 items-center">
                      <div className="font-semibold text-mds-navy">{c.scheme}</div>
                      <div className="text-mds-navy">
                        <div className="truncate">{c.label ?? "—"}</div>
                        <div className="text-[10px] text-muted-foreground tabular">
                          {c.scheme === "MSER"
                            ? `CoF ${c.cofPct != null ? c.cofPct.toFixed(2) + "%" : "—"} + ${c.marginBps ?? "—"} bps margin − ${c.discretionBps ?? 0} bps discretion`
                            : `Fund ${c.fundRatePct != null ? c.fundRatePct.toFixed(2) + "%" : "—"} + ${c.marginBps ?? "—"} bps margin`}
                        </div>
                      </div>
                      <div className="text-right tabular">₹{c.amountCr} Cr</div>
                      <div className="text-mds-navy">{c.freq}</div>
                      <div className="text-right tabular font-semibold text-mds-blue">{c.ratePct.toFixed(2)}%</div>
                      <div className="text-right tabular">{c.moratoriumMonths} mo</div>
                      <div className="text-right tabular">{c.tenureMonths} mo</div>
                    </div>
                  ))}

                </div>
              ) : (
                <>
                  <div className="rounded-lg border border-border p-3 space-y-2 bg-secondary/20">
                    <div className="text-[10px] uppercase tracking-wider text-mds-navy font-semibold">MSER Scheme</div>
                    <div className="grid grid-cols-4 gap-2 text-xs">
                      <KV k="Amount" v={`₹${open.mserCr} Cr`} />
                      <KV k="Tenure" v={`${open.mserTenureMonths} mo`} />
                      <KV k="Repayment" v={open.mserFreq} />
                      <KV k="Rate" v={`${open.proposedRatePct.toFixed(2)}%`} strong />
                    </div>
                    <div className="grid grid-cols-4 gap-2 text-xs pt-1 border-t border-border">
                      <KV k="CoF" v={`${open.cofPct.toFixed(2)}%`} />
                      <KV k="CoF Structure" v={open.cofStructure} />
                      <KV k="Margin" v={`${(open.marginPct * 100).toFixed(0)} bps`} />
                      <KV k="Discretion" v={open.discretionBps === null ? "nil" : `${open.discretionBps} bps`} />
                    </div>
                  </div>

                  {open.rmseCr > 0 && (
                    <div className="rounded-lg border border-border p-3 space-y-2 bg-secondary/20">
                      <div className="text-[10px] uppercase tracking-wider text-mds-navy font-semibold">RMSE Scheme</div>
                      <div className="grid grid-cols-4 gap-2 text-xs">
                        <KV k="Amount" v={`₹${open.rmseCr} Cr`} />
                        <KV k="Tenure" v={`${open.rmseTenureMonths} mo`} />
                        <KV k="Repayment" v="Bullet" />
                        <KV k="Rate" v={`${open.rmseRatePct.toFixed(2)}%`} strong />
                      </div>
                    </div>
                  )}
                </>
              )}


              <div className="grid grid-cols-2 gap-3">
                <StatBlock label="XIRR" value={open.xirrPct !== null ? `${open.xirrPct.toFixed(2)}%` : "—"} />
                <StatBlock label="Spread over CoF" value={`${((open.proposedRatePct - open.cofPct) * 100).toFixed(0)} bps`} />
              </div>

              {open.note && (
                <div className="text-xs text-muted-foreground border-l-2 border-mds-blue pl-3 py-1">
                  {open.note}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

function StatBlock({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className={cn("rounded-md p-3", accent ? "bg-mds-blue/10" : "bg-secondary/40")}>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={cn("text-lg font-bold tabular mt-0.5", accent ? "text-mds-blue" : "text-mds-navy")}>{value}</div>
    </div>
  );
}

function KV({ k, v, strong }: { k: string; v: string; strong?: boolean }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{k}</div>
      <div className={cn("tabular", strong ? "font-bold text-mds-blue" : "text-mds-navy")}>{v}</div>
    </div>
  );
}


// ============ Detailed Calculations — mirrors WAR_Sheet.xlsx methodology ============
// Sources: Entry Sheet C6:I9 (deal composition), C16:D24 (WAR), Working I11/O11/C23/I23
// (Effective RoI), Qtly/HY/Annual/Bullet Princ Pmt sheets (amortisation).

/**
 * The monthly cash flows WAR is built from: interest = opening × rate/12 on every
 * leg, principal per the chosen repayment structure. Σ interest ÷ (Σ opening ÷ 12)
 * is exactly the WAR shown below the table.
 */
function WarCashflowSchedule({ state, freq, caption }: { state: DealState; freq: Frequency; caption: string }) {
  const legs = legSchedules(state, freq);
  const maxN = legs.reduce((m, l) => Math.max(m, l.rows.length), 0);
  const rows = Array.from({ length: maxN }, (_, i) => {
    const m = i + 1;
    let opening = 0, interest = 0, principal = 0, closing = 0;
    for (const l of legs) {
      const r = l.rows[i];
      if (!r) continue;
      opening += r.opening; interest += r.interest; principal += r.principal; closing += r.closing;
    }
    return { m, opening, interest, principal, closing };
  });
  const sumInt = rows.reduce((t, r) => t + r.interest, 0);
  const sumOpen = rows.reduce((t, r) => t + r.opening, 0);
  const sumPrin = rows.reduce((t, r) => t + r.principal, 0);

  return (
    <div className="mx-4 space-y-2">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{caption}</div>
      <div className="text-[10px] text-muted-foreground">
        {legs.map((l) => `${l.leg.label} · ₹${l.leg.amountCr.toFixed(2)} Cr @ ${l.leg.scheme_.ratePct.toFixed(2)}% · ${Math.round(l.leg.scheme_.tenureMonths)}m`).join("  |  ")}
      </div>
      <div className="rounded-md border max-h-72 overflow-auto">
        <Table className="text-xs">
          <TableHeader className="sticky top-0 bg-background z-10">
            <TableRow>
              <TableHead className="w-14">Month</TableHead>
              <TableHead className="text-right">Opening (Cr)</TableHead>
              <TableHead className="text-right">Interest (Cr)</TableHead>
              <TableHead className="text-right">Principal (Cr)</TableHead>
              <TableHead className="text-right">Closing (Cr)</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.m} className={r.principal > 1e-9 ? "bg-mds-blue/5" : ""}>
                <TableCell className="tabular">{r.m}</TableCell>
                <TableCell className="text-right tabular">{r.opening.toFixed(2)}</TableCell>
                <TableCell className="text-right tabular">{r.interest.toFixed(4)}</TableCell>
                <TableCell className="text-right tabular">{r.principal > 1e-9 ? r.principal.toFixed(2) : "—"}</TableCell>
                <TableCell className="text-right tabular text-muted-foreground">{r.closing.toFixed(2)}</TableCell>
              </TableRow>
            ))}
            <TableRow className="border-t-2 bg-secondary/40 sticky bottom-0">
              <TableCell className="font-semibold">Σ</TableCell>
              <TableCell className="text-right tabular font-semibold">{sumOpen.toFixed(2)}</TableCell>
              <TableCell className="text-right tabular font-semibold">{sumInt.toFixed(2)}</TableCell>
              <TableCell className="text-right tabular font-semibold">{sumPrin.toFixed(2)}</TableCell>
              <TableCell />
            </TableRow>
          </TableBody>
        </Table>
      </div>
      <div className="text-[10px] text-muted-foreground">
        Σ Interest = {sumInt.toFixed(2)} Cr · Weighted principal = Σ Opening ÷ 12 = {sumOpen.toFixed(2)} ÷ 12 = {(sumOpen / 12).toFixed(2)} Cr-yrs
        {" "}→ WAR = {sumOpen > 0 ? ((sumInt / (sumOpen / 12)) * 100).toFixed(2) : "—"}%. Rows shaded blue = principal repayment months.
      </div>
    </div>
  );
}


type SeekVar = "mserRate" | "mserShare" | "mserTenure" | "mserFreq";
/** Which MSER leg the solver adjusts: the base leg or one of the MSER splits. */
type SeekLeg = string; // "base" | split.id

const CONT_SEEK_META: Record<Exclude<SeekVar, "mserFreq">, { label: string; unit: string; min: number; max: number; step: number; fmt: (v: number) => string }> = {
  mserRate:   { label: "MSER Rate",   unit: "%",  min: 0.5,  max: 20,  step: 0.001, fmt: (v) => `${v.toFixed(2)} %` },
  mserShare:  { label: "MSER Share",  unit: "%",  min: 1,    max: 99,  step: 0.01,  fmt: (v) => `${v.toFixed(2)} %` },
  mserTenure: { label: "MSER Tenure", unit: "mo", min: 6,    max: 120, step: 1,     fmt: (v) => `${Math.round(v)} months` },
};

const SEEK_LABELS: Record<SeekVar, string> = {
  mserRate: "Rate (%)",
  mserShare: "Share of principal (%)",
  mserTenure: "Tenure (months)",
  mserFreq: "Principal repayment frequency",
};
const SEEK_LABELS_SPLIT: Record<SeekVar, string> = {
  ...SEEK_LABELS,
  mserShare: "Amount (₹ Cr)",
};

type SeekMetric = "xirr" | "war";

/** Bounds for the chosen lever, widened for split amounts (₹ Cr, not %). */
function seekMeta(variable: Exclude<SeekVar, "mserFreq">, legId: SeekLeg, principalCr: number) {
  const base = CONT_SEEK_META[variable];
  if (variable === "mserShare" && legId !== "base") {
    return { ...base, label: "Amount", unit: "₹ Cr", min: 0.01, max: Math.max(0.02, principalCr), step: 0.01, fmt: (v: number) => `₹${v.toFixed(2)} Cr` };
  }
  return base;
}

function evalMetric(state: DealState, freq: Frequency, metric: SeekMetric): number {
  // WAR here matches the "WAR (Quote)" chip on the negotiation range bar and
  // the hero's blended-final rate — the Excel WAR sheet formula
  //   Σ (Amt × Rate × Tenure_yr) ÷ Σ (Amt × Tenure_yr).
  // Frequency-independent (unlike effectiveRateForFreq).
  return metric === "war"
    ? weightedAvgRate(state).war
    : xirr(combinedCashflows(state, freq));
}

/** Apply a candidate lever value to a copy of the deal state for the chosen leg. */
function applySeek(state: DealState, legId: SeekLeg, variable: SeekVar, v: number | Frequency): DealState {
  const s: DealState = { ...state, mser: { ...state.mser }, rmse: { ...state.rmse }, splits: (state.splits ?? []).map((x) => ({ ...x })) };
  if (legId === "base") {
    if (variable === "mserRate") s.mser.ratePct = v as number;
    else if (variable === "mserShare") s.mserSharePct = v as number;
    else if (variable === "mserTenure") s.mser.tenureMonths = Math.round(v as number);
    else s.repaymentFreq = v as Frequency;
    return s;
  }
  s.splits = (s.splits ?? []).map((sp) => {
    if (sp.id !== legId) return sp;
    if (variable === "mserRate") return { ...sp, ratePct: v as number };
    if (variable === "mserShare") return { ...sp, amountCr: v as number };
    if (variable === "mserTenure") return { ...sp, tenureMonths: Math.round(v as number) };
    return { ...sp, freq: v as Frequency };
  });
  return s;
}

function solveContinuous(state: DealState, freq: Frequency, variable: Exclude<SeekVar, "mserFreq">, target: number, metric: SeekMetric = "xirr", legId: SeekLeg = "base"): { value: number | null; achieved: number } {
  const meta = seekMeta(variable, legId, state.principalCr);
  const snap = (v: number): number => {
    if (variable === "mserTenure") return Math.max(meta.min, Math.min(meta.max, Math.round(v)));
    const clamped = Math.max(meta.min, Math.min(meta.max, v));
    return Math.round(clamped / meta.step) * meta.step;
  };
  const evalAt = (v: number): number => evalMetric(applySeek(state, legId, variable, v), freq, metric);

  // Tenure is discrete — enumerate integer months and pick the closest match.
  if (variable === "mserTenure") {
    let best: { v: number; x: number } | null = null;
    for (let m = meta.min; m <= meta.max; m += 1) {
      const x = evalAt(m);
      if (!isFinite(x)) continue;
      if (!best || Math.abs(x - target) < Math.abs(best.x - target)) best = { v: m, x };
    }
    if (!best) return { value: null, achieved: NaN };
    const reachable = Math.abs(best.x - target) < 0.01;
    return reachable ? { value: best.v, achieved: best.x } : { value: null, achieved: best.x };
  }

  let lo = meta.min, hi = meta.max;
  const fLo = evalAt(lo), fHi = evalAt(hi);
  if (!isFinite(fLo) || !isFinite(fHi)) return { value: null, achieved: NaN };
  const increasing = fHi > fLo;
  const lower = increasing ? fLo : fHi;
  const upper = increasing ? fHi : fLo;
  if (Math.abs(upper - lower) < 1e-6) {
    return { value: null, achieved: fLo };
  }
  if (target < lower - 1e-6 || target > upper + 1e-6) {
    const boundary = target < lower ? (increasing ? lo : hi) : (increasing ? hi : lo);
    return { value: null, achieved: evalAt(boundary) };
  }
  for (let i = 0; i < 200; i++) {
    const mid = (lo + hi) / 2;
    const fMid = evalAt(mid);
    if (!isFinite(fMid)) break;
    const goHigher = increasing ? fMid < target : fMid > target;
    if (goHigher) lo = mid; else hi = mid;
    if ((hi - lo) < meta.step / 100) break;
  }
  const rawMid = (lo + hi) / 2;
  const snapped = snap(rawMid);
  const achieved = evalAt(snapped);
  return { value: snapped, achieved };
}

function solveFrequency(state: DealState, target: number, metric: SeekMetric = "xirr", legId: SeekLeg = "base", chosenFreq: Frequency = "quarterly"): { value: Frequency | null; achieved: number; all: { freq: Frequency; value: number }[] } {
  const all = FREQUENCIES.filter((f) => f.key !== "custom").map((f) => ({
    freq: f.key,
    value: evalMetric(applySeek(state, legId, "mserFreq", f.key), legId === "base" ? f.key : chosenFreq, metric),
  }));
  const valid = all.filter((r) => isFinite(r.value));
  if (valid.length === 0) return { value: null, achieved: NaN, all };
  const best = valid.reduce((a, b) => Math.abs(b.value - target) < Math.abs(a.value - target) ? b : a);
  return { value: best.freq, achieved: best.value, all };
}



/** Compact solver summary in the output column; opens the full solver in a dialog. */
function GoalSeekLauncher(props:
  { state: DealState; chosenFreq: Frequency; currentXirr: number; currentWar: number; onApply?: (variable: SeekVar, value: number | Frequency, legId: SeekLeg) => void }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button size="sm" className="h-8 shrink-0 bg-mds-purple text-white hover:bg-mds-purple/90 text-[11px]"
        onClick={() => setOpen(true)}>
        Open solver
      </Button>


      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-4xl max-h-[85vh] overflow-auto p-0">
          <DialogHeader className="sr-only">
            <DialogTitle>Solve for target</DialogTitle>
            <DialogDescription>Reverse-solve deal parameters for a target XIRR or WAR</DialogDescription>
          </DialogHeader>
          <GoalSeek {...props} bare />
        </DialogContent>
      </Dialog>
    </>
  );
}

function GoalSeek({ state, chosenFreq, currentXirr, currentWar, onApply, bare }:
  { state: DealState; chosenFreq: Frequency; currentXirr: number; currentWar: number; onApply?: (variable: SeekVar, value: number | Frequency, legId: SeekLeg) => void; bare?: boolean }) {

  const [metric, setMetric] = useState<SeekMetric>("xirr");
  const currentValue = metric === "war" ? currentWar : currentXirr;
  // Target is a string so the user can freely edit / clear the field.
  const [targetStr, setTargetStr] = useState<string>(() => currentValue.toFixed(2));
  // When the metric toggles, reset the target to the current value of that metric.
  useEffect(() => { setTargetStr(currentValue.toFixed(2)); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [metric]);
  const parsed = parseFloat(targetStr);
  const target = Number.isFinite(parsed) ? parsed : currentValue;
  const [variable, setVariable] = useState<SeekVar>("mserRate");

  const { mserAmt, rmseAmt } = schemeAmounts(state);
  const allSplits = state.splits ?? [];
  const mserSplits = allSplits.filter((sp) => sp.scheme === "mser");

  // Only MSER parameters are negotiable, so the leg picker lists the base MSER
  // leg plus every MSER split. One leg, one lever at a time.
  const legs = useMemo(() => [
    { id: "base", label: mserSplits.length > 0 ? "MSER 1" : "MSER", amountCr: baseLegAmount(state, "mser") },
    ...mserSplits.map((sp, i) => ({ id: sp.id, label: `MSER ${i + 2}`, amountCr: sp.amountCr })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
  ], [state]);
  const [legId, setLegId] = useState<SeekLeg>("base");
  useEffect(() => {
    if (!legs.some((l) => l.id === legId)) setLegId("base");
  }, [legs, legId]);
  const legLabel = legs.find((l) => l.id === legId)?.label ?? "MSER";
  const labels = legId === "base" ? SEEK_LABELS : SEEK_LABELS_SPLIT;

  // WAR (Amt×Rate×Tenure) is frequency-independent, so the Frequency
  // lever cannot move it — hide that option in WAR mode.
  useEffect(() => {
    if (metric === "war" && variable === "mserFreq") setVariable("mserRate");
  }, [metric, variable]);

  const stateRef = useRef(state);
  const freqRef = useRef(chosenFreq);
  useEffect(() => { stateRef.current = state; freqRef.current = chosenFreq; });

  const [contSolved, setContSolved] = useState<{ value: number | null; achieved: number } | null>(null);
  const [freqSolved, setFreqSolved] = useState<{ value: Frequency | null; achieved: number } | null>(null);
  const [solvedSnapshot, setSolvedSnapshot] = useState<{
    principalCr: number; mserSharePct: number;
  } | null>(null);

  // Re-solve whenever the target, leg, lever, metric, OR the underlying deal state
  // changes, so the recommendation stays in sync with the live inputs.
  const stateKey = JSON.stringify({
    p: state.principalCr, sh: state.mserSharePct,
    m: state.mser, r: state.rmse, f: chosenFreq, tail: state.customTailMonths,
    sp: allSplits,
  });
  useEffect(() => {
    const s = stateRef.current;
    const f = freqRef.current;
    if (variable === "mserFreq") {
      setContSolved(null);
      setFreqSolved(solveFrequency(s, target, metric, legId, f));
    } else {
      setFreqSolved(null);
      setContSolved(solveContinuous(s, f, variable, target, metric, legId));
    }
    setSolvedSnapshot({ principalCr: s.principalCr, mserSharePct: s.mserSharePct });
  }, [target, variable, metric, legId, stateKey]);


  const currentFreqLabel = FREQUENCIES.find((f) => f.key === chosenFreq)?.label ?? chosenFreq;
  const freqLabelOf = (f: Frequency) => FREQUENCIES.find((x) => x.key === f)?.label ?? f;

  // Solved cells only decorate the selected leg — every other row stays "current only".
  const solvedRate =
    variable === "mserRate" && contSolved?.value != null ? `${contSolved.value.toFixed(2)} %` : null;
  const solvedShare =
    variable === "mserShare" && contSolved?.value != null
      ? (legId === "base" ? `${contSolved.value.toFixed(2)} %`
        : `${state.principalCr > 0 ? ((contSolved.value / state.principalCr) * 100).toFixed(2) : "0.00"} %`)
      : null;
  const solvedAmt =
    variable === "mserShare" && contSolved?.value != null
      ? (legId === "base" && solvedSnapshot
        ? `₹${((solvedSnapshot.principalCr * contSolved.value) / 100).toFixed(2)} Cr`
        : `₹${contSolved.value.toFixed(2)} Cr`)
      : null;
  const solvedTenure =
    variable === "mserTenure" && contSolved?.value != null ? `${Math.round(contSolved.value)} months` : null;
  const solvedFreq =
    variable === "mserFreq" && freqSolved?.value ? freqLabelOf(freqSolved.value) : null;

  const outOfRange = variable !== "mserFreq" && contSolved != null && contSolved.value === null;
  const solvedAchieved = variable === "mserFreq" ? (freqSolved?.achieved ?? NaN) : (contSolved?.achieved ?? NaN);
  // "Not exact" = solver returned a value but it can't hit the target to within 1 bp.
  const notExact = isFinite(solvedAchieved) && Math.abs(solvedAchieved - target) > 0.01;
  const unreachable = outOfRange || notExact;

  // Manual apply — user reviews the solved value and clicks Apply.
  const contValue = contSolved?.value ?? null;
  const freqValue = freqSolved?.value ?? null;
  const legFreq = legId === "base"
    ? chosenFreq
    : (mserSplits.find((sp) => sp.id === legId)?.freq ?? state.repaymentFreq);
  // Allow applying the nearest-achievable value even when not exact; only block when truly out of range.
  const canApply = !outOfRange && (
    variable === "mserFreq"
      ? !!freqValue && freqValue !== legFreq
      : contValue != null
  );

  const handleApply = () => {
    if (!onApply || !canApply) return;
    if (variable === "mserFreq") {
      if (freqValue) onApply(variable, freqValue, legId);
    } else if (contValue != null) {
      const next = variable === "mserTenure" ? Math.round(contValue) : contValue;
      onApply(variable, next, legId);
    }
  };



  const COLS = ["Scheme", "Share", "Amount", "Rate", "Tenure", "Moratorium", "Principal Repayment"] as const;
  type Col = Exclude<typeof COLS[number], "Scheme">;
  type Cell = { current: string; solved: string | null };

  const pct = (amt: number) => state.principalCr > 0 ? (amt / state.principalCr) * 100 : 0;
  const sel = (id: string) => id === legId;

  const rows: { id: string; label: string; accent: string; cells: Record<Col, Cell> }[] = [
    {
      id: "base",
      label: legs[0]!.label,
      accent: "bg-mds-blue",
      cells: {
        Share:      { current: `${pct(baseLegAmount(state, "mser")).toFixed(2)} %`, solved: sel("base") ? solvedShare : null },
        Amount:     { current: `₹${baseLegAmount(state, "mser").toFixed(2)} Cr`,    solved: sel("base") ? solvedAmt : null },
        Rate:       { current: `${state.mser.ratePct.toFixed(2)} %`,                solved: sel("base") ? solvedRate : null },
        Tenure:     { current: `${state.mser.tenureMonths} months`,                 solved: sel("base") ? solvedTenure : null },
        Moratorium: { current: `${state.mser.moratoriumMonths} months`,             solved: null },
        "Principal Repayment": { current: currentFreqLabel,                         solved: sel("base") ? solvedFreq : null },
      },
    },
    ...mserSplits.map((sp, i) => ({
      id: sp.id,
      label: `MSER ${i + 2}`,
      accent: "bg-mds-blue/60",
      cells: {
        Share:      { current: `${pct(sp.amountCr).toFixed(2)} %`,   solved: sel(sp.id) ? solvedShare : null },
        Amount:     { current: `₹${sp.amountCr.toFixed(2)} Cr`,      solved: sel(sp.id) ? solvedAmt : null },
        Rate:       { current: `${sp.ratePct.toFixed(2)} %`,         solved: sel(sp.id) ? solvedRate : null },
        Tenure:     { current: `${sp.tenureMonths} months`,          solved: sel(sp.id) ? solvedTenure : null },
        Moratorium: { current: `${sp.moratoriumMonths} months`,      solved: null },
        "Principal Repayment": { current: freqLabelOf(sp.freq ?? state.repaymentFreq), solved: sel(sp.id) ? solvedFreq : null },
      } as Record<Col, Cell>,
    })),
    {
      id: "rmse",
      label: "RMSE",
      accent: "bg-mds-purple",
      cells: {
        Share:      { current: `${pct(rmseAmt).toFixed(2)} %`,             solved: null },
        Amount:     { current: `₹${rmseAmt.toFixed(2)} Cr`,                solved: null },
        Rate:       { current: `${state.rmse.ratePct.toFixed(2)} %`,       solved: null },
        Tenure:     { current: `${state.rmse.tenureMonths} months`,        solved: null },
        Moratorium: { current: `${state.rmse.moratoriumMonths} months`,    solved: null },
        "Principal Repayment": { current: "Bullet",                        solved: null },
      },
    },
  ];
  void mserAmt;

  const renderCell = (c: Cell) => (
    <div className="tabular text-mds-navy leading-tight">
      <div>{c.current}</div>
      {c.solved && (
        <div className="mt-0.5 text-mds-purple font-bold">→ {c.solved}</div>
      )}
    </div>
  );

  const GRID = "grid grid-cols-[0.9fr_0.8fr_0.9fr_0.9fr_0.9fr_1fr_1.2fr]";

  return (
    <Card className={bare ? "border-0 shadow-none" : undefined}>

      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2">
          <span className="w-1 h-4 bg-mds-purple rounded" />
          Solve for Target {metric === "war" ? "WAR" : "XIRR"}
        </CardTitle>
        <div className="pt-1 text-[11px] text-muted-foreground">
          {legs.length > 1 ? "Pick the MSER split and the single parameter to solve." : "Pick the single MSER parameter to solve."} The solved value is shown in purple next to the current value.
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Metric toggle */}
        <div className="px-2">
          <div className="inline-flex rounded-md border border-border bg-white p-0.5" role="tablist" aria-label="Target metric">
            {(["xirr", "war"] as SeekMetric[]).map((m) => (
              <button
                key={m}
                type="button"
                role="tab"
                aria-selected={metric === m}
                onClick={() => setMetric(m)}
                className={`px-3 py-1.5 text-xs font-semibold uppercase tracking-wider rounded ${
                  metric === m ? "bg-mds-navy text-white" : "text-muted-foreground hover:text-mds-navy"
                }`}
              >
                {m === "war" ? "WAR" : "XIRR"}
              </button>
            ))}
          </div>
        </div>

        {/* Controls */}
        <div className={cn("grid grid-cols-1 gap-4 px-2", legs.length > 1 ? "md:grid-cols-3" : "md:grid-cols-2")}>
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Target {metric === "war" ? "WAR" : "XIRR"} (%)</Label>
            <Input
              type="number"
              step={0.01}
              value={targetStr}
              onChange={(e) => setTargetStr(e.target.value)}
              onBlur={() => { if (!Number.isFinite(parseFloat(targetStr))) setTargetStr(currentValue.toFixed(2)); }}
              className="tabular font-semibold text-lg h-11"
            />
            <div className="text-[10px] text-muted-foreground">
              Current {metric === "war" ? "WAR" : `XIRR (${currentFreqLabel})`}: <span className="tabular font-semibold text-mds-navy">{currentValue.toFixed(2)}%</span>
              {isFinite(solvedAchieved) && !unreachable && (
                <>  ·  Target: <span className="tabular font-semibold text-mds-blue">{solvedAchieved.toFixed(2)}%</span></>
              )}
            </div>
          </div>
          {legs.length > 1 && (
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">MSER split</Label>
            <Select value={legId} onValueChange={(v) => setLegId(v)}>
              <SelectTrigger className="h-11 bg-white"><SelectValue /></SelectTrigger>
              <SelectContent>
                {legs.map((l) => (
                  <SelectItem key={l.id} value={l.id}>
                    {l.label} · ₹{l.amountCr.toFixed(2)} Cr
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          )}

          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Solve for parameter</Label>
            <Select value={variable} onValueChange={(v) => setVariable(v as SeekVar)}>
              <SelectTrigger className="h-11 bg-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.keys(labels) as SeekVar[])
                  .filter((k) => !(metric === "war" && k === "mserFreq"))
                  .map((k) => (
                  <SelectItem key={k} value={k}>
                    {labels[k]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>



        {/* Deal Structure table: one row per MSER leg + RMSE */}
        <div className="mx-2 rounded-md border border-border overflow-hidden">
          <div className={cn(GRID, "bg-mds-navy/5 text-[10px] uppercase tracking-wider text-muted-foreground px-3 py-2 font-semibold")}>
            {COLS.map((c) => <div key={c}>{c}</div>)}
          </div>
          {rows.map((r) => (
            <div key={r.id}
              className={cn(GRID, "px-3 py-2.5 text-xs border-t border-border items-center",
                r.id === legId && "bg-mds-purple/5")}>
              <div className="flex items-center gap-2 font-semibold text-mds-navy">
                <span className={cn("w-1 h-4 rounded", r.accent)} />{r.label}
              </div>
              {(COLS.filter((c) => c !== "Scheme") as Col[]).map((c) => (
                <div key={c}>{renderCell(r.cells[c])}</div>
              ))}
            </div>
          ))}
        </div>

        {unreachable && (
          <div className="mx-2 rounded-md border border-mds-warning/40 bg-mds-warning/5 p-3 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-mds-warning mt-0.5 shrink-0" />
            <div className="text-xs text-mds-navy">
              Target {metric === "war" ? "WAR" : "XIRR"} of <span className="tabular font-semibold">{target.toFixed(2)}%</span> {outOfRange ? "is outside the reachable range" : "can't be hit exactly"} by adjusting <span className="font-semibold">{legLabel} · {labels[variable]}</span> alone.
              Nearest achievable: <span className="tabular font-semibold text-mds-blue">{isFinite(solvedAchieved) ? `${solvedAchieved.toFixed(2)}%` : "—"}</span>{outOfRange ? ". Try a different split or parameter." : "."}
            </div>
          </div>
        )}


        <div className="flex justify-end px-2">
          <Button
            type="button"
            onClick={handleApply}
            disabled={!canApply}
            className="bg-mds-blue hover:bg-mds-blue-hover text-white"
          >
            Apply to inputs
          </Button>
        </div>



      </CardContent>
    </Card>
  );
}




function DetailedCalcs({ state, cofPct, cofLabel, chosenFreq }:
  { state: DealState; cofPct: number; cofLabel: string; chosenFreq: Frequency }) {



  const { mserAmt, rmseAmt } = schemeAmounts(state);
  const total = state.principalCr;
  const mYr = state.mser.tenureMonths / 12;
  const rYr = state.rmse.tenureMonths / 12;

  const customTail = Math.max(1, Math.min(state.mser.tenureMonths, Math.round(state.customTailMonths ?? 3)));
  const freqLabelBase = FREQUENCIES.find((f) => f.key === chosenFreq)?.label ?? chosenFreq;
  const freqLabel = chosenFreq === "custom" ? `Custom · last ${customTail}m` : freqLabelBase;

  // WAR (Entry Sheet C16:D24 methodology)
  const war = weightedAvgRate(state);

  // Funding Cost of Funds (Treasury for MSER, RBI fund for RMSE)

  // Effective RoI per frequency
  const basePerFreq = FREQUENCIES.filter((f) => f.key !== "custom").map((f) => {
    const r = effectiveRateForFreq(state, f.key);
    const cf = combinedCashflows(state, f.key);
    return { key: f.key, label: f.label, ...r, xirr: xirr(cf), irr: irrAnnualPct(state, f.key) };
  });
  const customRow = (() => {
    const r = effectiveRateForFreq(state, "custom");
    const cf = combinedCashflows(state, "custom");
    const tail = customTail;
    return { key: "custom" as Frequency, label: `Custom · last ${tail}m`, ...r, xirr: xirr(cf), irr: irrAnnualPct(state, "custom") };
  })();
  const perFreq = chosenFreq === "custom" ? [...basePerFreq, customRow] : basePerFreq;
  const chosen = chosenFreq === "custom" ? customRow : basePerFreq.find((r) => r.key === chosenFreq)!;


  // XIRR is inspectable under any MSER principal-repayment structure.
  const [xirrFreq, setXirrFreq] = useState<Frequency>(chosenFreq);
  // Follow the dashboard's selected repayment schedule; users can still override via the toggle below.
  useEffect(() => { setXirrFreq(chosenFreq); }, [chosenFreq]);
  const cf = combinedCashflows(state, xirrFreq);
  const irr = xirr(cf);
  const monthlyCf = combinedMonthlyCashflows(state, xirrFreq);
  const irrMonthly = irrPeriodic(monthlyCf);
  const irrAnn = isFinite(irrMonthly) ? (Math.pow(1 + irrMonthly, 12) - 1) * 100 : NaN;
  const xirrFreqBase = FREQUENCIES.find((f) => f.key === xirrFreq)?.label ?? xirrFreq;
  const xirrFreqLabel = xirrFreq === "custom" ? `Custom · last ${customTail}m` : xirrFreqBase;

  const mserSched = schemeSchedule(state.mser, mserAmt, xirrFreq, state.customTailMonths);
  const rmseSched = schemeSchedule(state.rmse, rmseAmt, "bullet");

  const propMser = total > 0 ? (mserAmt / total) * 100 : 0;
  const propRmse = total > 0 ? (rmseAmt / total) * 100 : 0;

  // WAR intermediate step — chosen frequency
  const mserWtdPrin = chosen.denom - (rmseAmt * rYr); // approximation split
  // Better: compute exactly
  const rmseWtdPrin = rmseAmt * rYr; // bullet: opening constant → Σopen/12 = amt × yrs
  const mserWtdPrinExact = chosen.denom - rmseWtdPrin;

  return (
    <div className="space-y-4">

      {/* Deal Composition moved to the hero card at the top of the dashboard. */}






      {/* ============ 4. WAR per frequency ============ */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2">
            <span className="w-1 h-4 bg-mds-success rounded" />
            WAR — Weighted Average Rate
          </CardTitle>
          <div className="pt-1 text-[11px] text-muted-foreground">
            Total interest accrued over the loan life, divided by the weighted-principal (Σ opening balance ÷ 12).
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Cash flows first — WAR is derived from these monthly rows */}
          <div className="pt-2">
            <WarCashflowSchedule state={state} freq={chosenFreq} caption={`Step 1 · Monthly cash flows (${freqLabel}) — all tranches combined`} />
          </div>

          {/* Per-scheme contribution for chosen freq */}
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground px-4 pt-2">Step 2 · Chosen frequency ({freqLabel}) — per-scheme breakdown</div>

          <div className="mx-4">
          <Table className="text-xs">
            <TableHeader>
              <TableRow>
                <TableHead>Scheme</TableHead>
                <TableHead className="text-right">Amount (Cr)</TableHead>
                <TableHead className="text-right">Rate</TableHead>
                <TableHead className="text-right">Interest accrued (Σ monthly)</TableHead>
                <TableHead className="text-right">Weighted principal (Σ open ÷ 12)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>MSER ({freqLabel})</TableCell>
                <TableCell className="text-right tabular">{mserAmt.toFixed(2)}</TableCell>
                <TableCell className="text-right tabular">{state.mser.ratePct.toFixed(2)}%</TableCell>
                <TableCell className="text-right tabular">{chosen.mserInt.toFixed(2)}</TableCell>
                <TableCell className="text-right tabular">{mserWtdPrinExact.toFixed(2)}</TableCell>
              </TableRow>
              <TableRow>
                <TableCell>RMSE (Bullet)</TableCell>
                <TableCell className="text-right tabular">{rmseAmt.toFixed(2)}</TableCell>
                <TableCell className="text-right tabular">{state.rmse.ratePct.toFixed(2)}%</TableCell>
                <TableCell className="text-right tabular">{chosen.rmseInt.toFixed(2)}</TableCell>
                <TableCell className="text-right tabular">{rmseWtdPrin.toFixed(2)}</TableCell>
              </TableRow>
              <TableRow className="border-t-2 bg-secondary/30">
                <TableCell className="font-semibold" colSpan={3}>Σ Total</TableCell>
                <TableCell className="text-right tabular font-semibold">{chosen.total.toFixed(2)}</TableCell>
                <TableCell className="text-right tabular font-semibold">{chosen.denom.toFixed(2)}</TableCell>
              </TableRow>
            </TableBody>
          </Table>
          </div>

          {/* Formula & result for chosen freq */}
          <div className="rounded-md bg-mds-success/10 p-4 space-y-2 mx-4 border border-mds-success/30">
            <div className="font-mono text-[11px] text-mds-navy leading-relaxed space-y-1">
              <div>WAR = ( Σ Interest ÷ Σ Weighted Principal ) × 100</div>
              <div>
                &nbsp;&nbsp;&nbsp;= ( {chosen.mserInt.toFixed(2)} + {chosen.rmseInt.toFixed(2)} ) ÷ ( {mserWtdPrinExact.toFixed(2)} + {rmseWtdPrin.toFixed(2)} ) × 100
              </div>
              <div>
                &nbsp;&nbsp;&nbsp;= {chosen.total.toFixed(2)} ÷ {chosen.denom.toFixed(2)} × 100
              </div>
            </div>
            <div className="text-2xl font-bold tabular text-mds-success">= {chosen.effective.toFixed(2)}%</div>
          </div>

          {/* All frequencies comparison */}
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground px-4 pt-2">All frequencies (sensitivity)</div>
          <div className="mx-4 mb-4">



          {/* Per-scheme breakdown removed — refer to Entry Sheet — Deal Composition above. */}
          <Table className="text-xs">
            <TableHeader>
              <TableRow>
                <TableHead>Principal Repmt.</TableHead>
                <TableHead className="text-right">MSER Interest</TableHead>
                <TableHead className="text-right">RMSE Interest</TableHead>
                <TableHead className="text-right">Total Interest</TableHead>
                <TableHead className="text-right">÷ Wtd. Principal</TableHead>
                <TableHead className="text-right">WAR</TableHead>
                <TableHead className="text-right">IRR (ann.)</TableHead>
                <TableHead className="text-right">XIRR</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {perFreq.map((r) => (
                <TableRow key={r.key} className={r.key === chosenFreq ? "bg-mds-blue/5" : ""}>
                  <TableCell className="font-medium">{r.label}</TableCell>
                  <TableCell className="text-right tabular">{r.mserInt.toFixed(2)}</TableCell>
                  <TableCell className="text-right tabular">{r.rmseInt.toFixed(2)}</TableCell>
                  <TableCell className="text-right tabular font-semibold">{r.total.toFixed(2)}</TableCell>
                  <TableCell className="text-right tabular text-muted-foreground">{r.denom.toFixed(2)}</TableCell>
                  <TableCell className="text-right tabular font-bold text-mds-success">{r.effective.toFixed(2)}%</TableCell>
                  <TableCell className="text-right tabular font-semibold text-mds-navy">{isFinite(r.irr) ? `${r.irr.toFixed(2)}%` : "—"}</TableCell>
                  <TableCell className="text-right tabular font-semibold text-mds-blue">{r.xirr.toFixed(2)}%</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </div>
          <div className="text-[10px] text-muted-foreground px-4 pb-3">
            Row highlighted in blue = currently selected principal-repayment frequency ({freqLabel}).
          </div>

        </CardContent>
      </Card>

      {/* ============ 4b. WAR — 12 month ============ */}
      {(() => {
        const w = effectiveRateWindow(state, chosenFreq, 12);
        const state12 = withTenureMonths(state, 12);
        return (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2">
                <span className="w-1 h-4 bg-mds-success rounded" />
                WAR (12 month)
              </CardTitle>
              <div className="pt-1 text-[11px] text-muted-foreground">
                The same deal structure (amounts, mix, rates, repayment frequency) re-cut with a 12-month tenor
                on every tranche, then priced with the same WAR formula: Σ interest ÷ weighted principal.
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="pt-2">
                <WarCashflowSchedule state={state12} freq={chosenFreq} caption={`Step 1 · Updated monthly cash flows (${freqLabel}) — every tranche re-cut to 12 months`} />
              </div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground px-4 pt-2">Step 2 · Per-tranche breakdown</div>
              <div className="mx-4">

                <Table className="text-xs">
                  <TableHeader>
                    <TableRow>
                      <TableHead>Tranche ({freqLabel}) · 12-month tenor</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead className="text-right">Rate</TableHead>
                      <TableHead className="text-right">Interest</TableHead>
                      <TableHead className="text-right">Wtd. principal (Cr-yrs)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {w.legs.map((l) => (
                      <TableRow key={l.leg.id}>
                        <TableCell className="font-medium">{l.leg.label}</TableCell>
                        <TableCell className="text-right tabular">{l.leg.amountCr.toFixed(2)} Cr</TableCell>
                        <TableCell className="text-right tabular">{l.leg.scheme_.ratePct.toFixed(2)}%</TableCell>
                        <TableCell className="text-right tabular">{l.interest.toFixed(2)} Cr</TableCell>
                        <TableCell className="text-right tabular">{l.weightedPrincipal.toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                    <TableRow className="border-t-2 bg-secondary/30">
                      <TableCell className="font-semibold">Total</TableCell>
                      <TableCell />
                      <TableCell />
                      <TableCell className="text-right tabular font-semibold">{w.interest.toFixed(2)} Cr</TableCell>
                      <TableCell className="text-right tabular font-semibold">{w.weightedPrincipal.toFixed(2)}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              <div className="rounded-md bg-mds-success/10 p-4 space-y-2 mx-4 border border-mds-success/30">
                <div className="font-mono text-[11px] text-mds-navy leading-relaxed space-y-1">
                  <div>Every tranche tenor set to 12 months (moratorium clamped to ≤ 11m)</div>
                  <div>WAR (12 month) = Σ Interest ÷ Σ Weighted principal = {w.interest.toFixed(2)} ÷ {w.weightedPrincipal.toFixed(2)}</div>
                </div>
                <div className="text-2xl font-bold tabular text-mds-success">= {w.effective.toFixed(2)}%</div>
                <div className="text-[10px] text-muted-foreground">
                  Full-life WAR {chosen.effective.toFixed(2)}% · difference {(w.effective - chosen.effective).toFixed(2)} pp
                </div>
              </div>

              <div className="text-[10px] uppercase tracking-wider text-muted-foreground px-4 pt-1">All frequencies</div>
              <div className="mx-4 mb-4">
                <Table className="text-xs">
                  <TableHeader>
                    <TableRow>
                      <TableHead>Principal Repmt.</TableHead>
                      <TableHead className="text-right">Interest (12m tenor)</TableHead>
                      <TableHead className="text-right">WAR (full life)</TableHead>
                      <TableHead className="text-right">WAR (12 month)</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {perFreq.map((r) => {
                      const wf = effectiveRateWindow(state, r.key, 12);
                      return (
                        <TableRow key={r.key} className={r.key === chosenFreq ? "bg-mds-blue/5" : ""}>
                          <TableCell className="font-medium">{r.label}</TableCell>
                          <TableCell className="text-right tabular">{wf.interest.toFixed(2)} Cr</TableCell>
                          <TableCell className="text-right tabular">{r.effective.toFixed(2)}%</TableCell>
                          <TableCell className="text-right tabular font-bold text-mds-success">{wf.effective.toFixed(2)}%</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        );
      })()}


      {/* ============ 5. XIRR — with frequency toggle ============ */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2">
            <span className="w-1 h-4 bg-mds-blue rounded" />
            XIRR — Dated Cashflow IRR
          </CardTitle>
          <div className="pt-1 text-[11px] text-muted-foreground">
            Toggle the MSER principal-repayment structure to see how the dated cashflow schedule and XIRR shift. RMSE always pays bullet.
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Frequency toggle */}
          <div className="px-4 pt-2 space-y-1.5">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
              MSER Repayment Structure — click to recompute XIRR
            </div>
            <ToggleGroup
              type="single"
              value={xirrFreq}
              onValueChange={(v) => v && setXirrFreq(v as Frequency)}
              className="justify-start flex-wrap gap-1"
            >
              {FREQUENCIES.map((f) => {
                const tail = state.customTailMonths ?? 3;
                const label = f.key === "custom" ? `Custom · last ${tail}m` : f.label;
                return (
                  <ToggleGroupItem
                    key={f.key}
                    value={f.key}
                    className="text-xs border border-border bg-background hover:bg-mds-blue/5 hover:border-mds-blue/40 data-[state=on]:bg-mds-blue data-[state=on]:text-white data-[state=on]:border-mds-blue cursor-pointer transition-colors"
                  >
                    {label}
                  </ToggleGroupItem>
                );
              })}
            </ToggleGroup>
          </div>

          {/* Inputs */}
          <div className="rounded-md border border-border p-3 space-y-2 mx-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-[11px]">
              <div><div className="text-muted-foreground">Initial outflow (t=0)</div><div className="tabular font-semibold text-mds-danger">−{state.principalCr.toFixed(2)} Cr</div></div>
              <div><div className="text-muted-foreground">MSER structure</div><div className="tabular font-semibold">{state.mser.tenureMonths} mo · {xirrFreqLabel}</div></div>
              <div><div className="text-muted-foreground">RMSE structure</div><div className="tabular font-semibold">{state.rmse.tenureMonths} mo · Bullet</div></div>
              <div><div className="text-muted-foreground"># cashflows</div><div className="tabular font-semibold">{cf.length}</div></div>
            </div>
          </div>

          {/* Formula */}
          <div className="rounded-md bg-secondary/40 p-3 font-mono text-[11px] leading-relaxed text-mds-navy mx-4">
            XIRR(values, dates) → solve&nbsp;0 = Σ CF<sub>i</sub> / (1 + r)<sup>(date<sub>i</sub> − date<sub>0</sub>) / 365</sup>,&nbsp;&nbsp;date<sub>0</sub> = today
          </div>

          {/* Schedule */}
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground px-4">Cashflow schedule ({xirrFreqLabel}) — dated from today</div>
          <div className="rounded-md border border-border max-h-72 overflow-auto mx-4">
            <Table className="text-xs">
              <TableHeader>
                <TableRow>
                  <TableHead>#</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Months from t₀</TableHead>
                  <TableHead className="text-right">Year frac</TableHead>
                  <TableHead className="text-right">Cash flow (Cr)</TableHead>
                  <TableHead className="text-right">PV @ {irr.toFixed(2)}%</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {cf.map((f, i) => (
                  <TableRow key={i}>
                    <TableCell className="tabular">{i}</TableCell>
                    <TableCell className="tabular">{f.date.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}</TableCell>
                    <TableCell className="text-right tabular">{Math.round(f.t * 12)}</TableCell>
                    <TableCell className="text-right tabular">{f.t.toFixed(2)}</TableCell>
                    <TableCell className={cn("text-right tabular", f.cf < 0 ? "text-mds-danger" : "text-mds-navy")}>
                      {f.cf.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right tabular text-muted-foreground">
                      {(f.cf / Math.pow(1 + irr / 100, f.t)).toFixed(2)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>


          {/* Result */}
          <div className="rounded-md bg-mds-blue/10 p-3 space-y-1 mx-4 mb-4">
            <div className="font-mono text-[11px] text-mds-navy">Newton-Raphson converged (Σ PV ≈ 0)</div>
            <div className="text-2xl font-bold tabular text-mds-blue">XIRR ({xirrFreqLabel}) = {isFinite(irr) ? `${irr.toFixed(2)}%` : "—"}</div>
          </div>
        </CardContent>
      </Card>

      {/* ============ 5b. IRR — periodic monthly, annualised ============ */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2">
            <span className="w-1 h-4 bg-mds-navy rounded" />
            IRR — ANNUALISED
          </CardTitle>
          <div className="pt-1 text-[11px] text-muted-foreground">
            Classic Excel IRR on equally-spaced monthly cashflows for the currently toggled MSER structure
            (<span className="font-semibold">{xirrFreqLabel}</span>). Solves for the monthly rate <em>r<sub>m</sub></em>,
            then annualises as (1 + r<sub>m</sub>)<sup>12</sup> − 1. Ignores exact calendar days (unlike XIRR above).
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Formula */}
          <div className="rounded-md bg-secondary/40 p-3 font-mono text-[11px] leading-relaxed text-mds-navy mx-4">
            IRR: solve&nbsp;0 = Σ CF<sub>t</sub> / (1 + r<sub>m</sub>)<sup>t</sup>,&nbsp;&nbsp;t = 0, 1, …, N months&nbsp;&nbsp;→&nbsp;&nbsp;
            IRR<sub>annual</sub> = (1 + r<sub>m</sub>)<sup>12</sup> − 1
          </div>

          {/* Monthly schedule */}
          <div className="text-[10px] uppercase tracking-wider text-muted-foreground px-4">
            Monthly cashflow vector ({xirrFreqLabel}) — {monthlyCf.length} periods
          </div>
          <div className="rounded-md border border-border max-h-72 overflow-auto mx-4">
            <Table className="text-xs">
              <TableHeader>
                <TableRow>
                  <TableHead>Month (t)</TableHead>
                  <TableHead className="text-right">Cash flow (Cr)</TableHead>
                  <TableHead className="text-right">
                    PV @ {isFinite(irrMonthly) ? `${(irrMonthly * 100).toFixed(4)}%/mo` : "—"}
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {monthlyCf.map((c, t) => (
                  <TableRow key={t}>
                    <TableCell className="tabular">{t}</TableCell>
                    <TableCell className={cn("text-right tabular", c < 0 ? "text-mds-danger" : c > 0 ? "text-mds-navy" : "text-muted-foreground")}>
                      {c.toFixed(4)}
                    </TableCell>
                    <TableCell className="text-right tabular text-muted-foreground">
                      {isFinite(irrMonthly) ? (c / Math.pow(1 + irrMonthly, t)).toFixed(4) : "—"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Result */}
          <div className="rounded-md bg-mds-navy/5 p-3 space-y-1 mx-4 mb-4 border border-mds-navy/10">
            <div className="font-mono text-[11px] text-mds-navy">
              Monthly r<sub>m</sub> = {isFinite(irrMonthly) ? `${(irrMonthly * 100).toFixed(4)}%` : "—"}
              &nbsp;→&nbsp;(1 + r<sub>m</sub>)<sup>12</sup> − 1
            </div>
            <div className="text-2xl font-bold tabular text-mds-navy">
              IRR ({xirrFreqLabel}) = {isFinite(irrAnn) ? `${irrAnn.toFixed(2)}%` : "—"}
            </div>
          </div>
        </CardContent>
      </Card>





      {/* ============ 6. Cashflow Structure — MSER + RMSE side by side ============ */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2">
            <span className="w-1 h-4 bg-mds-navy rounded" />
            Cashflow Structure
          </CardTitle>
          <div className="pt-1 text-[11px] text-muted-foreground">
            {legSchedules(state, xirrFreq).map((l, i) => (
              <span key={l.leg.id}>
                {i > 0 && <span className="mx-2">+</span>}
                <span className={`font-semibold ${l.leg.scheme === "mser" ? "text-mds-blue" : "text-mds-success"}`}>
                  {l.leg.label} · {FREQUENCIES.find((f) => f.key === l.leg.freq)?.label}
                </span>
              </span>
            ))}
            <span className="mx-2">·</span>
            Interest paid <span className="tabular font-semibold text-mds-navy">monthly (all legs)</span>
          </div>
        </CardHeader>
        <CardContent>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* One schedule per leg (base MSER/RMSE plus every split) */}
        {legSchedules(state, xirrFreq).map((l) => {
          const isMser = l.leg.scheme === "mser";
          const legFreqLabel = FREQUENCIES.find((f) => f.key === l.leg.freq)?.label ?? "";
          return (
            <Card key={l.leg.id}>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold uppercase tracking-wider text-mds-navy flex items-center gap-2">
                  <span className={`w-1 h-4 rounded ${isMser ? "bg-mds-blue" : "bg-mds-success"}`} />
                  {l.leg.label} — {legFreqLabel}
                  {l.leg.basis && (
                    <span className="text-[10px] normal-case tracking-normal text-muted-foreground">({l.leg.basis})</span>
                  )}
                </CardTitle>
                <div className="pt-2 grid grid-cols-2 gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
                  <div>Loan Amt <span className="tabular text-mds-navy font-medium">{l.leg.amountCr.toFixed(2)}</span></div>
                  <div>Int p.a. <span className="tabular text-mds-navy font-medium">{l.leg.scheme_.ratePct.toFixed(2)}%</span></div>
                  <div>Int/month <span className="tabular text-mds-navy font-medium">{(l.leg.scheme_.ratePct / 12).toFixed(2)}%</span></div>
                  <div>Tenure (months) <span className="tabular text-mds-navy font-medium">{Math.round(l.leg.scheme_.tenureMonths)}</span></div>
                </div>
              </CardHeader>
              <CardContent className="p-0 max-h-[440px] overflow-auto border-t">
                <Table className="text-xs">
                  <TableHeader>
                    <TableRow>
                      <TableHead>Period</TableHead>
                      <TableHead className="text-right">Opening Bal</TableHead>
                      <TableHead className="text-right">Interest paid</TableHead>
                      <TableHead className="text-right">Principal Paid</TableHead>
                      <TableHead className="text-right">Balance</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {l.rows.map((m, i) => (
                      <TableRow key={i}>
                        <TableCell className="tabular">{i + 1}</TableCell>
                        <TableCell className="text-right tabular">{m.opening.toFixed(2)}</TableCell>
                        <TableCell className="text-right tabular">{m.interest.toFixed(2)}</TableCell>
                        <TableCell className="text-right tabular">{m.principal.toFixed(2)}</TableCell>
                        <TableCell className="text-right tabular">{m.closing.toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                    <TableRow className="bg-secondary/40 border-t-2">
                      <TableCell className="font-semibold">Total</TableCell>
                      <TableCell></TableCell>
                      <TableCell className="text-right tabular font-semibold">
                        {l.rows.reduce((s, x) => s + x.interest, 0).toFixed(2)}
                      </TableCell>
                      <TableCell className="text-right tabular font-semibold">
                        {l.rows.reduce((s, x) => s + x.principal, 0).toFixed(2)}
                      </TableCell>
                      <TableCell></TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          );
        })}
        </div>

        </CardContent>
      </Card>

    </div>
  );
}
