import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environments/environment';

export interface AuthorizationResponse {
  role: string;        // BM / BC / RM / RC / ...
  branchCd: string;
  branchName: string;
  token: string;
}

export const ROLES = {
  BM: 'Branch Maker',
  BC: 'Branch Checker',
  RM: 'RO Maker',
  RC: 'RO Checker',
  HM: 'HO Maker',
  HC: 'HO Checker',
  AM: 'Admin Maker',
  AC: 'Admin Checker',
  VW: 'View Only'
};

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private LOGIN_TOKEN_KEY = 'authToken';
  private AUTH_TOKEN_KEY = 'appJwtToken';
  private USERNAME_KEY = 'username';
  private USER_INFO_KEY = 'authUser';
  private baseURL = environment.api;

  constructor(private http: HttpClient) { }

  /* ================= LOGIN SESSION ================= */

  setSession(username: string, loginToken: any): void {
    localStorage.setItem(this.USERNAME_KEY, username);
    localStorage.setItem(this.LOGIN_TOKEN_KEY, loginToken);
    sessionStorage.setItem('loggedIn', 'true');
  }

  /* ================= AUTH TOKEN API ================= */

  getAuthorizationToken(username: string): Observable<AuthorizationResponse> {
    const formData = new FormData();
    formData.append('username', username.toUpperCase());

    return this.http.post<AuthorizationResponse>(
      `${this.baseURL}v1/auth/gettoken`,
      formData
    );
  }

  /* ================= SAVE AUTH SESSION ================= */

  setAuthorizationSession(response: AuthorizationResponse): void {
    const token = String(response?.token ?? '').trim();
    const role = String(response?.role ?? '').trim().toUpperCase();
    const allowedRoles = ['AM', 'AC', 'BM', 'BC', 'RM', 'RC', 'HM', 'HC', 'VW'];

    const validToken =
      token !== '' &&
      token !== 'NULL' &&
      token !== 'UNDEFINED';

    if (!validToken || !allowedRoles.includes(role)) {
      this.clearSession();
      return;
    }

    // ✅ Store exact role directly
    localStorage.setItem(this.AUTH_TOKEN_KEY, token);
    localStorage.setItem('tokenRole', role); // BM / BC / RM / etc.

    localStorage.setItem(this.USER_INFO_KEY, JSON.stringify({
      role,
      branchCode: response.branchCd,
      branchName: response.branchName
    }));
  }



  /* ================= GETTERS ================= */

  isLoggedIn(): boolean {
    const token = localStorage.getItem(this.AUTH_TOKEN_KEY);
    const role = localStorage.getItem('tokenRole');
    const allowedRoles = ['AM', 'AC', 'BM', 'BC', 'RM', 'RC', 'HM', 'HC', 'VW'];

    const validToken =
      !!token &&
      token.trim() !== '' &&
      token !== 'null' &&
      token !== 'undefined';

    const validRole =
      !!role &&
      allowedRoles.includes(role.trim().toUpperCase());

    return sessionStorage.getItem('loggedIn') === 'true'
      && validToken
      && validRole;
  }

  getUsername(): string | null {
    return localStorage.getItem(this.USERNAME_KEY);
  }

  getUserBranchDetails(): AuthorizationResponse | null {
    const localData = localStorage.getItem(this.USER_INFO_KEY) ?? '';
    const authorize = JSON.parse(localData)
    return authorize;
  }




  getToken(): string | null {
    return localStorage.getItem(this.AUTH_TOKEN_KEY);
  }

  /* ================= LOGOUT ================= */

  clearSession(): void {
    localStorage.clear();
    sessionStorage.clear();
  }

  getRole(): string | null {
    return localStorage.getItem('tokenRole');
  }

}
