import { Routes } from '@angular/router';

import { LoginComponent } from './login/login';
import { MainLayoutComponent } from './layout/main-layout/main-layout';
import { AuthGuard } from './auth.guard';

import { GrievanceListComponent } from './grievance-list/grievance-list';
import { GrievanceEntryComponent } from './grievance_Entry/grievance_Entry';
import { NodalOfficerComponent } from './nodal-officer/nodal-officer.component';
import { GrievanceRevertComponent } from './grievance-revert/grievance-revert';
import { GrievanceViewQueryComponent } from './grievance-view-query/grievance-view-query';
import { GrievanceCicUpdateComponent } from './grievance-cic-update/grievance-cic-update';
import { GrievanceReportsComponent } from './grievance-reports/grievance-reports';
import { GrievanceResolutionFileViewComponent } from './grievance-resolution-file-view/grievance-resolution-file-view';

export const routes: Routes = [

 /* ✅ Default route → login */
 {
   path: '',
   redirectTo: 'login',
   pathMatch: 'full'
 },

 /* 🔐 Login page (NO layout, NO guard) */
 {
   path: 'login',
   component: LoginComponent
 },

 /* ✅ Secured application (WITH layout) */
 {
   path: '',
   component: MainLayoutComponent,
   canActivateChild: [AuthGuard],   // ✅ IMPORTANT
   children: [

     {
     path: 'grievance-list',
       component: GrievanceListComponent,
       data: { roles: ['AM', 'AC', 'BM', 'BC', 'RM', 'RC', 'HM', 'HC'] }
      
     },

     {
       path: 'grievance-entry',
       component: GrievanceEntryComponent,
       data: { roles: ['AM'] }
     },
     {
       path: 'grievance-update/:grvNo',
       component: GrievanceEntryComponent,
       data: { roles: ['AM'], mode: 'update' }
     },
     {
       path: 'grievance-review/:grvNo',
       component: GrievanceEntryComponent,
       data: { roles: ['AC'], mode: 'review' }
     },
     {
       path: 'grievance-entry/:grvNo',
       component: GrievanceEntryComponent,
       data: { roles: ['AM', 'AC'], mode: 'legacy' }
     },

     {
     path: 'nodal-officer',
       component: NodalOfficerComponent,
       data: { roles: ['AM', 'AC'] }
     },
     {
     path: 'grievance-revert',
       component: GrievanceRevertComponent,
       data: { roles: ['AM', 'AC'] }
     },
     {
     path: 'grievance-view-query',
       component: GrievanceViewQueryComponent,
       data: { roles: ['AM', 'AC', 'BM', 'BC', 'RM', 'RC', 'HM', 'HC', 'VW'] }
       
     },
     {
     path: 'grievance-cic-update',
       component: GrievanceCicUpdateComponent,
       data: { roles: ['AM', 'AC', 'BM', 'BC', 'RM', 'RC', 'HM', 'HC'] }
     },
     {
     path: 'grievance-reports',
       component: GrievanceReportsComponent,
       data: { roles: ['AM', 'AC', 'BM', 'BC', 'RM', 'RC', 'HM', 'HC', 'VW'] }
     },
     {
     path: 'grievance-resolution-file-view',
       component: GrievanceResolutionFileViewComponent,
       data: { roles: ['AM', 'AC', 'BM', 'BC', 'RM', 'RC', 'HM', 'HC', 'VW'] }
     },

     /* ✅ Default after login */
     {
       path: '',
       redirectTo: 'grievance-list',
       pathMatch: 'full'
     }
   ]
 },

 /* 🔁 Fallback → login */
 {
   path: '**',
   redirectTo: 'login'
 }
];

