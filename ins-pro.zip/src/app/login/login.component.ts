import { Component, ElementRef, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CookieService } from 'ngx-cookie-service';
import { AccountService } from '../account.service';
import { AuthserviceService } from '../authservice.service';
import { UserInterface } from '../app.userInterface';
import { EncryptDecryptService } from '../encrypt-decrypt.service';

@Component({
  templateUrl: 'login.component.html',
  styleUrls: ['login.component.scss']
})
export class LoginComponent implements OnInit, AfterViewInit {
  form: FormGroup;
  loading = false;
  submitted = false;
  loginError = false;
  captcha_data: any;

  user: UserInterface | null = null;

  @ViewChild('captcha') public canvas: ElementRef;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private accountService: AccountService,
    private _snackBar: MatSnackBar,
    private cookieservice: CookieService,
    private authService: AuthserviceService,
    private encryptService: EncryptDecryptService
  ) {
  }

  ngOnInit() {
    let selectedUser = this.cookieservice.get('UserID');

    // const userSelect = this.accountService.testUsers(selectedUser);
    /*  if (userSelect) {
 
       this.authService.validateUser().subscribe(
         (isValid: boolean) => {
           if (!isValid) {
             //this.router.navigate(['/login']);
           } else {
             //this.authService.setUser();
             this.router.navigate(['/home']);
           }
         }
       )
     }
     else { */
    this.authService.user$.subscribe({
      next: (response) => {
        if (response || response !== null) {
          this.user = { user: response?.user, token: response?.token }
          this.accountService.user_valid(this.user?.user, this.user?.token).subscribe({
            next: (res: any) => {
              if (res["apiResponse"] === "Valid") {
                this.router.navigate(['/home']);
              } else {
                // do something
              }

            },
            error: (error) => {
              console.log("Error validating user, ", error);
              this.authService.userSubject.next(null);
            }
          })

        } else {
          // do nothing
        }
      }, error: () => {
        console.log("Something went wrong at '/login' page");
      }
    })
    // }



    // get form fields
    this.form = this.formBuilder.group({
      username: ['', [Validators.required]],
      password: ['', Validators.required],
      captcha: ['', Validators.required]
    });
  }


  ngAfterViewInit(): void {
    this.captcha_load();
  }



  // convenience getter for easy access to form fields
  get f() { return this.form.controls; }

  async onSubmit() {
    this.submitted = true;

    if (this.form.invalid) {
      return;
    }

    this.loading = true;
    const encryptedUserName = await this.encryptService.encryptSSO(this.f['username'].value);
    const encryptedPassword = await this.encryptService.encryptSSO(this.f['password'].value);

    let login_data = {
      'userName': this.f['username'].value,
      'password': encryptedPassword,
      'capText': this.f['captcha'].value,
      'capId': this.captcha_data.capId
    }
    this.accountService.login(login_data)
      .subscribe((data: any) => {
        if (data && data.apiResponse) {
          if (data.apiResponse == "Auth Success" ||
            data.apiResponse == 'User Already Logged In') {
            this.loginError = false;
            this.loading = false;
            let dateTime = new Date();
            dateTime.setHours(dateTime.getHours() + 8);
            this.cookieservice.set("UserID",
              this.f['username'].value,
              {
                path: '/', expires: dateTime,
                domain: 'sidbi.in'
              });
            this.cookieservice.set("authToken",
              data["authToken"],
              {
                path: '/', expires: dateTime,
                domain: 'sidbi.in'
              });
            this.authService.userSubject.next({ user: this.f["username"].value, token: data["authToken"] })
            this.router.navigate(["/home"]);
          }
          else if (data.apiResponse.indexOf("49") != -1) {
            this.captcha_load();
            this.loading = false;
            this._snackBar.open("Authentication Failed. Username or Password incorrect.", "Close", {
              duration: 10000
            });
          }
          else if (data.apiResponse.indexOf("775") != -1) {
            this.captcha_load();
            this.loading = false;
            this._snackBar.open("Authentication Failed. User locked out. Please contact your system adminitstrator.", "Close", {
              duration: 10000
            });
          }
          else if (data.apiResponse.indexOf("532") != -1) {
            this.captcha_load();
            this.loading = false;
            this._snackBar.open("Authentication Failed. User Password expired. Please contact your system adminitstrator.", "Close", {
              duration: 10000
            });
          }
          else if (data.apiResponse.indexOf("533") != -1) {
            this.captcha_load();
            this.loading = false;
            this._snackBar.open("Authentication Failed. User account is disabled. Please contact your system adminitstrator.", "Close", {
              duration: 10000
            });
          }
          else if (data.apiResponse.indexOf("525") != -1) {
            this.captcha_load();
            this.loading = false;
            this._snackBar.open("Authentication Failed. User not found. Please contact your system adminitstrator.", "Close", {
              duration: 10000
            });
          }
          else if (data.apiResponse == 'Invalid Captcha') {
            this.captcha_load();
            this.loading = false;
            this._snackBar.open("Invalid Captcha", "Close", {
              duration: 10000
            });
          }
          else if (data.apiResponse == "Auth Failed") {
            this.captcha_load();
            this.loading = false;
            this._snackBar.open("Authentication Failed. Username or Password incorrect.", "Close", {
              duration: 10000
            });
          }
          else {
            this.captcha_load();
            this.loading = false;
            this._snackBar.open("Something went wrong. Please retry after sometime.", "Close", {
              duration: 10000
            });
          }
        }
      },
        error => {
          if (error.error.apiResponse == "Auth Failed") {
            this.loading = false;
            this.captcha_load();
            this._snackBar.open("Authentication Failed. Username or Password incorrect.", "Close", {
              duration: 10000
            });
          }
          else {
            this.loading = false;
            this.captcha_load();
            this._snackBar.open("Something went wrong. Please retry after sometime.", "Close", {
              duration: 10000
            });
          }
        });
  }

  captcha_load() {
    let captcha = this.canvas.nativeElement;
    let ctx = captcha.getContext('2d');
    ctx.clearRect(0, 0, captcha.width, captcha.height);
    this.accountService.captcha().subscribe({
      next: (data: any) => {
        this.captcha_data = data;
        let font_size = "25";
        ctx.font = `${font_size}px serif`;

        let min = 0;
        let max = 10;
        let angle = Math.random() * (max - min) + min;
        angle *= Math.round(Math.random()) ? 1 : -1;
        angle = angle * Math.PI / 180;
        ctx.transform(1, 0, Math.tan(angle), 1, 0, 0);
        ctx.fillText(data.capText, 15, 35);
      },
      error: () => {
        console.log("Error fetching captcha.")
      }
    })
  }
}
