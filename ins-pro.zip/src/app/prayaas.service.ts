import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, Observable, switchMap, throwError } from 'rxjs';
import configData from '../assets/keys.json';
import { environment } from 'src/environments/environment';
import { embedDashboard } from '@superset-ui/embedded-sdk';

@Injectable({
  providedIn: 'root'
})
export class PrayaasService {
  private apiUrl: string = ''
  private urls: any = configData;
  selectedDashboard: any;
  constructor(private http: HttpClient, private router: Router) {
    this.apiUrl = environment.prayaasAPI;
  }

  fetchGuestToken(accessToken: any): Observable<any> {
    const body = {
      "resources": [
        {
          "id": this.selectedDashboard,
          "type": "dashboard"
        }
      ],
      "rls": [
        {
          "clause": "user = vishnu@superset.com",
          "dataset": 1
        }
      ],
      "user": {
        "first_name": "vishnu",
        "last_name": "vardhan",
        "username": "vishnu@superset.com"
      }
    };

    const acc = accessToken["access_token"];

    const headers = new HttpHeaders({
      "Content-Type": "application/json",
      "Authorization": `Bearer ${acc}`,
    });

    return this.http.post<any>(`${this.apiUrl}api/v1/security/guest_token/`, body, { headers });

  }


  embedDashboard(htmlEle: HTMLElement, page: string): Observable<void> {


console.log(page)

    const domain = window.location.hostname;


      this.selectedDashboard = this.urls.prod[page];


    return new Observable((observer) => {
      this.getGuestToken().subscribe(
        (token) => {

          embedDashboard({
            id: this.selectedDashboard, // Replace with your dashboard ID
            supersetDomain: this.apiUrl,
            mountPoint: htmlEle,
            fetchGuestToken: () => token["token"],
            dashboardUiConfig: {
              hideTitle: true,
              hideChartControls: true,
              hideTab: true,
              filters: {
                expanded: false,
              }
            },
          });
          observer.next();
          observer.complete();

        },
        (error) => {
          observer.error(error);
        }
      );
    });
  }

  getGuestToken(): Observable<any> {
    return this.fetchAccessToken().pipe(
      catchError((error) => {
        console.error(error);
        return throwError(error);
      }),
      switchMap((accessToken: any) => this.fetchGuestToken(accessToken))
    );
  }

  fetchAccessToken(): Observable<any> {
    const body = {
      "username": "admin",
      "password": "admin",
      "provider": "db",
      "refresh": true
    };

    return this.http.post(`${this.apiUrl}api/v1/security/login`, body, { headers: { "Content-Type": "application/json", 'Accept': 'application/json' } })
  }

}
