import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { AccountService } from '../account.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AuthserviceService } from '../authservice.service';
import { UserInterface } from '../app.userInterface';
import { environment } from 'src/environments/environment';
import { DashboardServiceService } from '../dashboard-service.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  appTitle: string = '';
  user: UserInterface | null = null;
  isLoggedIn = false;
  isHomeEnabled: boolean;
  myReferer: string;
  appIconSrc: string;

  constructor(
    public router: Router,
    private cookieservice: CookieService,
    private AccountService: AccountService,
    private authService: AuthserviceService,
    private _snackBar: MatSnackBar,
    private dashboardService: DashboardServiceService
  ) {
    this.setAppIcon(this.router.url);
  }



  ngOnInit(): void {
    this.myReferer = document.referrer;
    let selectedUser = this.cookieservice.get('UserID');
    let selectedUserAuth = this.cookieservice.get('authToken');
    console.log('referrer', document.referrer)



    this.authService.user$.subscribe({
      next: (response) => {
        if (response !== null) {
          this.user = { user: response?.user, token: response?.token }
          if (document.referrer == 'https://info.sidbi.in/') {
            this.isHomeEnabled = true;
          } else {
            this.isHomeEnabled = false;
          }
          this.isLoggedIn = true;
        } else {
          // do something
          this.isLoggedIn = false;
        }
      },
      error: () => {
        console.log("Error fetching user data at header component")
        this.authService.userSubject.next(null);
        this.isLoggedIn = false;
      }
    })

    this.dashboardService.currentTitle.subscribe((data) => {
      this.appTitle = data;
    }
    )

    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.setAppIcon(event.urlAfterRedirects);
      }
    });

  }

  setAppIcon(url: string) {
      const cleanUrl = url.split('?')[0];
    switch (cleanUrl) {
      case '/dcv':
        this.appIconSrc = '../../assets/dcv.png';
        break;
      case '/pnd':
        this.appIconSrc = '../../assets/pnd.png';
        break;
      case '/nbfc':
        this.appIconSrc = '../../assets/nbfc.png';
        break;
      case '/sfmc':
        this.appIconSrc = '../../assets/sfmc.png';
        break;


      case '/committee':
        this.appIconSrc = '../../assets/Meeting-Minutes.png';
        break;
      case '/grievance':
        this.appIconSrc = '../../assets/grievance-icon.png';
        break;

      case '/dcv-performance':
        this.appIconSrc = '../../assets/performance.png';
        break;

      case '/compliance':
        this.appIconSrc = '../../assets/compliance.png';
        break;

      case '/visitMonitor':
        this.appIconSrc = '../../assets/visitIcon.png';
        break;

      case '/arv':
        this.appIconSrc = '../../assets/arv-icon.png';
        break;
        
      case '/dorm':
        this.appIconSrc = '../../assets/dorm-icon.png';
        break;

        case '/ebo':
        this.appIconSrc = '../../assets/ebo-icon.png';
        break;

           case '/anchor-investment':
        this.appIconSrc = '../../assets/anchor-investment-icon.png';
        break;

        case '/venture-debts':
        this.appIconSrc = '../../assets/venture-debts-icon.png';
        break;

        case '/incubator':
        this.appIconSrc = '../../assets/incubator-icon.png';
        break;
        case '/itv-ops':
        this.appIconSrc = '../../assets/itvOperations-icon.png';
        break;

        case '/elsc':
        this.appIconSrc = '../../assets/elsc-icon.png';
        break;
        case '/ifv-portfolio':
        this.appIconSrc = '';
        break;


      default:
        this.appIconSrc = '../../assets/app_icon_default.png';
        break;
    }
  }


  logout() {
    this.appTitle = '';


    this.AccountService.logout().subscribe((data: any) => {
      this.AccountService.deleteCookies();
      this.authService.userSubject.next(null);
      this.isLoggedIn = false;
      this.AccountService.clearWindowRefs();
      if (document.referrer == 'https://info.sidbi.in/') {
        window.open('https://info.sidbi.in/', '_self');
      } else {
        this.router.navigate(["/login"]);
      }

    },
      (error) => {
        this._snackBar.open("", "Close", {
          duration: 10000
        });
      })

  }


    home() {

    if(this.router.url.startsWith('/home')){
       window.open('https://info.sidbi.in/', '_self');
       return
    }
    const home =
      this.router.routerState.snapshot.root.firstChild
        ?.queryParams?.['home'];

    this.router.navigate(['/home'], {
      queryParams: { tab: home || 'dcv' }
    });

    this.appTitle = '';
  }
}
