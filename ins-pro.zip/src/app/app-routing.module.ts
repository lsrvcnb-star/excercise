import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { SupersetComponent } from './superset/superset.component';
import { SupersetPrayaasComponent } from './superset-prayaas/superset-prayaas.component';
import { ComplianceComponent } from './compliance/compliance.component';
import { CommitteeComponent } from './committee/committee.component';
import { PowebiComponent } from './powebi/powebi.component';
import { Component } from 'ag-grid-community';
import { GrievanceComponent } from './grievance/grievance.component';
import { GrievancePowerbiComponent } from './grievance-powerbi/grievance-powerbi.component';
import { NbfcHomeComponent } from './nbfc-home/nbfc-home.component';
import { DcvPerformanceComponent } from './dcv-performance/dcv-performance.component';
import { CompliancePowerbiComponent } from './compliance-powerbi/compliance-powerbi.component';
import { CommitteePbiComponent } from './committee-pbi/committee-pbi.component';
import { NbfcHomePowerbiComponent } from './nbfc-home-powerbi/nbfc-home-powerbi.component';
import { VisitMonitorComponent } from './visit-monitor/visit-monitor.component';
import { ArvComponent } from './arv/arv.component';
import { DormComponent } from './dorm/dorm.component';
import { EboComponent } from './ebo/ebo.component';
import { AccessGuard } from './shared/access.guard';
import { VentureDebtsComponent } from './venture-debts/venture-debts.component';
import { IncubatorComponent } from './incubator/incubator.component';
import { AnchorInvestmentComponent } from './anchor-investment/anchor-investment.component';
import { ItvOpsComponent } from './itv-ops/itv-ops.component';
import { ElseComponent } from './else/else.component';
import { IfvPortfolioDashboardComponent } from './ifv-portfolio-dashboard/ifv-portfolio-dashboard.component';

const routes: Routes = [

  { path: 'login', component: LoginComponent, },
  { path: 'home', component: HomeComponent },
  { path: 'sfmc', component: SupersetPrayaasComponent, canActivate: [AccessGuard] },
  { path: 'committee', component: CommitteePbiComponent, canActivate: [AccessGuard] },
  { path: 'dcv', component: PowebiComponent, canActivate: [AccessGuard] },
  { path: 'grievance', component: GrievancePowerbiComponent, canActivate: [AccessGuard] },
  { path: 'dcv-performance', component: DcvPerformanceComponent, canActivate: [AccessGuard] },
  { path: 'compliance', component: CompliancePowerbiComponent, canActivate: [AccessGuard] },
  { path: 'nbfc', component: NbfcHomePowerbiComponent, canActivate: [AccessGuard] },
  { path: 'visitMonitor', component: VisitMonitorComponent, canActivate: [AccessGuard] },
  { path: 'arv', component: ArvComponent, canActivate: [AccessGuard] },
  { path: 'dorm', component: DormComponent, canActivate: [AccessGuard] },
  { path: 'ebo', component: EboComponent, canActivate: [AccessGuard] },
  { path: 'venture-debts', component: VentureDebtsComponent, canActivate: [AccessGuard] },
  { path: 'incubator', component: IncubatorComponent, canActivate: [AccessGuard] },
  { path: 'anchor-investment', component: AnchorInvestmentComponent, canActivate: [AccessGuard] },
  { path: 'itv-ops', component: ItvOpsComponent, canActivate: [AccessGuard]},
  { path: 'elsc', component: ElseComponent, canActivate: [AccessGuard]},
   { path: 'ifv-portfolio', component: IfvPortfolioDashboardComponent, canActivate: [AccessGuard] },

  { path: '**', component: LoginComponent },


];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
