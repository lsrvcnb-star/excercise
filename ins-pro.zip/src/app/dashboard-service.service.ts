import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable, catchError, switchMap, throwError } from 'rxjs';
import * as jwt from 'jsonwebtoken';
import * as createHmac from 'crypto-js'
import { embedDashboard } from '@superset-ui/embedded-sdk';
import configData from '../assets/keys.json';
import { environment } from 'src/environments/environment';

export interface MasterAccessUser {
  ACCESS_ID: number;
  USER_ID: string;
  EMP_ID: string;
  ACCESS_TO: string;        // e.g. "Compliance, Report" or "All"
  ROLE: string;
  VERTICAL: string;
  DESIGNATION: string;
  IS_ACTIVE: 'Y' | 'N';
}

export interface MasterAccessResponse {
  authorized: boolean;
  user?: MasterAccessUser;
}

@Injectable({
  providedIn: 'root'
})
export class DashboardServiceService {
  private iframeurl = new BehaviorSubject<string>('home');
  currenturl = this.iframeurl.asObservable();
  private apiUrl = 'https://insights.sidbi.in/api/v1/security';
  selectedDashboard: any;
  private urls: any = configData;
  private appTitle = new BehaviorSubject('');
  currentTitle = this.appTitle.asObservable();
  constructor(private http: HttpClient, private router: Router) { }

updateTitle(title: string){
  this.appTitle.next(title);
}

  changeURL(url: string) {
    this.iframeurl.next(url);
  }

  fetchAccessToken(): Observable<any> {
    const body = {
      "username": "admin",
      "password": "admin",
      "provider": "db",
      "refresh": true
    };



    return this.http.post(`${this.apiUrl}/login`, body, { headers: { "Content-Type": "application/json", 'Accept': 'application/json' } })


  }


  fetchGuestToken(accessToken: any): Observable<any> {
    const body = {
      "resources": [
        {
          "id": this.selectedDashboard,
          "type": "dashboard"
        }
      ],
      "rls": [
        {
          "clause": "user = vishnu@superset.com",
          "dataset": 1
        }
      ],
      "user": {
        "first_name": "vishnu",
        "last_name": "vardhan",
        "username": "vishnu@superset.com"
      }
    };

    const acc = accessToken["access_token"];

    const headers = new HttpHeaders({
      "Content-Type": "application/json",
      "Authorization": `Bearer ${acc}`,
    });

    return this.http.post<any>(`${this.apiUrl}/guest_token/`, body, { headers });

  }

  getGuestToken(): Observable<any> {
    return this.fetchAccessToken().pipe(
      catchError((error) => {
        console.error(error);
        return throwError(error);
      }),
      switchMap((accessToken: any) => this.fetchGuestToken(accessToken))
    );
  }

  embedDashboard(htmlEle: HTMLElement, page: string): Observable<void> {
    this.selectedDashboard = this.urls.prod[page];
    return new Observable((observer) => {
      this.getGuestToken().subscribe(
        (token) => {
          embedDashboard({
            id: this.selectedDashboard, // Replace with your dashboard ID
            supersetDomain: 'https://insights.sidbi.in/',
            mountPoint: htmlEle,
            fetchGuestToken: () => token["token"],
            dashboardUiConfig: {
              hideTitle: true,
              hideChartControls: true,
              hideTab: true,
              filters: {
                expanded: false,
              }
            },
          });
          observer.next();
          observer.complete();
        },
        (error) => {
          observer.error(error);
        }
      );
    });
  }

  check(userId: string): Observable<MasterAccessResponse> {
    const params = new HttpParams().set('userId', userId);
    return this.http.get<MasterAccessResponse>(`${environment.acessManagementApp}/check`, { params });
  }

}
