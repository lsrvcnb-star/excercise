import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MatTableModule } from '@angular/material/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { BnNgIdleService } from 'bn-ng-idle';
import { MatSnackBarModule } from '@angular/material/snack-bar';

import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';

import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AgGridModule } from 'ag-grid-angular';

import { AppRoutingModule } from './app-routing.module';
import { CookieService } from 'ngx-cookie-service';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { HttpLoaderComponent } from './http-loader/http-loader.component';
import { LoaderService } from './loader.service';
import { HttpInterceptorService } from './http-interceptor.service';
import { SupersetComponent } from './superset/superset.component';
import { SupersetPrayaasComponent } from './superset-prayaas/superset-prayaas.component';
import { ComplianceComponent } from './compliance/compliance.component';
import { CommitteeComponent } from './committee/committee.component';
import { PowebiComponent } from './powebi/powebi.component';
import { GrievanceComponent } from './grievance/grievance.component';
import { GrievancePowerbiComponent } from './grievance-powerbi/grievance-powerbi.component';
import { NbfcHomeComponent } from './nbfc-home/nbfc-home.component';
import { NbfcComponent } from './nbfc/nbfc.component';
import { DcvPerformanceComponent } from './dcv-performance/dcv-performance.component';
import { FooterComponent } from './footer/footer.component';
import { SfmcComponent } from './sfmc/sfmc.component';
import { CompliancePowerbiComponent } from './compliance-powerbi/compliance-powerbi.component';
import { CommitteePbiComponent } from './committee-pbi/committee-pbi.component';
import { CommonModule } from '@angular/common';
import { NbfcHomePowerbiComponent } from './nbfc-home-powerbi/nbfc-home-powerbi.component';
import { NbfcPowerbiComponent } from './nbfc-powerbi/nbfc-powerbi.component';
import { VisitMonitorComponent } from './visit-monitor/visit-monitor.component';
import { ArvComponent } from './arv/arv.component';
import { DormComponent } from './dorm/dorm.component';
import { EboComponent } from './ebo/ebo.component';
import { ElseComponent } from './else/else.component';
import { IfvPortfolioDashboardComponent } from './ifv-portfolio-dashboard/ifv-portfolio-dashboard.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    LogoutComponent,
    HomeComponent,
    HttpLoaderComponent,
    SupersetComponent,
    SupersetPrayaasComponent,
    ComplianceComponent,
    CommitteeComponent,
    PowebiComponent,
    GrievanceComponent,
    GrievancePowerbiComponent,
    NbfcHomeComponent,
    NbfcComponent,
    DcvPerformanceComponent,
    FooterComponent,
    SfmcComponent,
    CompliancePowerbiComponent,
    CommitteePbiComponent,
    NbfcHomePowerbiComponent,
    NbfcPowerbiComponent,
    VisitMonitorComponent,
    ArvComponent,
    DormComponent,
    EboComponent,
    ElseComponent,
    IfvPortfolioDashboardComponent
  ],
  imports: [
    HttpClientModule,
    MatNativeDateModule,
    MatSelectModule,
    BrowserModule,
    AppRoutingModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatCardModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatAutocompleteModule,
    MatInputModule,
    MatSnackBarModule,
    CommonModule,
    AgGridModule.withComponents([])
  ],
  providers: [CookieService, BnNgIdleService, LoaderService,
    {
      provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService, multi: true
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
