import { Component, ElementRef, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { DashboardServiceService } from '../dashboard-service.service';

@Component({
  selector: 'app-superset',
  templateUrl: './superset.component.html',
  styleUrls: ['./superset.component.scss']
})
export class SupersetComponent implements OnInit {
  selected_page: string = 'home';
  isDashboardEnable: boolean = true;

  constructor(private dashboardServiceService: DashboardServiceService,  private router: Router, private titleService: Title, private elementRef: ElementRef,) { }

  ngOnInit(): void {

    this.selected_page = 'home';
    this.updateSuperset( this.selected_page);
    this.dashboardServiceService.updateTitle('DCV Executive Dashboard');
  }



  updateSuperset(page: string){
    this.selected_page = page;
    this.embedSupersetDashboard(page);
  }

  embedSupersetDashboard(selected: string): void {
    const dashboardElement = this.elementRef.nativeElement.querySelector('#dashboard');

    if (dashboardElement) {
      if(selected !== 'elsc'){
        this.isDashboardEnable = true;
        this.dashboardServiceService.embedDashboard(dashboardElement, selected).subscribe(
        () => {
          // Adjust the size of the embedded iframe
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%';
            if (selected == 'home') {
              iframe.style.height = '4450px';
            } else if (selected == 'express') {
              iframe.style.height = '2010px';
            } else if (selected == 'topTenexpress') {
              iframe.style.height = '950px';
            } else if (selected == 'top10') {
              iframe.style.height = '1770px';
            } else if (selected == 'leads') {
              iframe.style.height = '2850px';
            } else if (selected == 'gstSahay') {
              iframe.style.height = '1700px';
            }

          }
        },
        (error) => {
          console.error(error);
        }
      );
      } else{
        this.isDashboardEnable = false;
      }

    }
  }

}
