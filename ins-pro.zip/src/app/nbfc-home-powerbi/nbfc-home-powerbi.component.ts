import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { AccountService } from '../account.service';
import { PowerBiService, TrackVisitPayload } from '../power-bi.service';
import * as pbi from 'powerbi-client';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-nbfc-home-powerbi',
  templateUrl: './nbfc-home-powerbi.component.html',
  styleUrls: ['./nbfc-home-powerbi.component.scss']
})
export class NbfcHomePowerbiComponent implements OnInit, AfterViewInit {
  selected_page: string = 'co-lending-powerbi';
  errorMessage: any[] = [];
  borderClass: string = 'nbfcBorderClass';
  isDashboardEnable: boolean = true;
  isNBFCenabled: boolean = false;
  
  @ViewChild('reportContainer', { static: true }) reportContainer!: ElementRef;
  dbName: string;

  constructor(private powerBiService: PowerBiService,
    private router: Router, private titleService: Title, private elementRef: ElementRef,
    private renderer: Renderer2, private accountService: AccountService, private cdr: ChangeDetectorRef,
    private dashboardServiceService: DashboardServiceService,
  private cookieService: CookieService) { }

  ngOnInit(): void {
    this.selected_page = 'nbfc';
    this.dashboardServiceService.updateTitle('Non-Banking Financial Company (NBFC) - Dashboard');
    
  }


  ngAfterViewInit(): void {
    // Wait for DOM to be ready
    this.cdr.detectChanges();
    this.updateSuperset('nbfc');
  }


  updateSuperset(page: string) {

    this.selected_page = page;
    this.embedReport(page);


  }


  embedReport(reportId): void {

    if (reportId == 'nbfc') {
      this.dbName = 'NBFC';
    } else if (reportId == 'co-lending-powerbi') {
      this.dbName = 'Co-Lending';
    } else if (reportId == 'directAssignment-powerbi') {
      this.dbName = 'Direct Assignment';
    } else if (reportId == 'cda-powerbi') {
      this.dbName = 'CDA';
    }

    this.clearExistingPowerBiEmbed();
    this.powerBiService.getEmbedToken(reportId).subscribe(
      (embedData) => {
        this.tracking();
        const models = pbi.models;
        const reportLoadConfig: pbi.IEmbedConfiguration = {
          type: 'report',
          tokenType: models.TokenType.Embed,
          accessToken: embedData.embedToken,
          embedUrl: embedData.embedReports[0].embedUrl,
          settings: {
            navContentPaneEnabled: false,
            panes: {
              filters: {
                visible: true,
              },
              pageNavigation: {
                visible: false,
              },

            },
            background: pbi.models.BackgroundType.Transparent,
            layoutType: pbi.models.LayoutType.Custom,
            customLayout: {
              displayOption: models.DisplayOption.FitToPage,
            }
          }
        };

        // Embed Power BI report
        const powerbi = new pbi.service.Service(
          pbi.factories.hpmFactory,
          pbi.factories.wpmpFactory,
          pbi.factories.routerFactory // Add this argument
        );
        const report = powerbi.embed(
          this.reportContainer.nativeElement,
          reportLoadConfig
        );
        // Handle events
        report.on('loaded', () => console.log('Report loaded successfully'));
        report.on('rendered', () => {
          console.log('Report rendered successfully');
          this.reportContainer.nativeElement.querySelector("iframe").style.height = '2500px';
        });
        // Adjust the size of the embedded iframe
        report.on('error', (event: any) => {
          this.errorMessage = event.detail.split('\r\n');
          console.error('Power BI Error:', event.detail);
        });
      },
      (error) => {
        console.error('Error fetching embed token', error);
        this.errorMessage = ['Failed to fetch Power BI Embed Token.'];
      }
    );
  }

  clearExistingPowerBiEmbed(): void {
    const powerbi = new pbi.service.Service(
      pbi.factories.hpmFactory,
      pbi.factories.wpmpFactory,
      pbi.factories.routerFactory // Add this argument
    );
    powerbi.reset(this.reportContainer?.nativeElement);
    this.reportContainer.nativeElement.innerHTML = ''; // Clear any previous content
  }

    tracking() {
    const user = this.cookieService.get('UserID').toLowerCase();
    const payload: TrackVisitPayload = {
      userId: user + '@sidbi.in',
      empId: user,
      dbVertical: 'IFV',
      dbName: this.dbName
    };

    this.powerBiService.trackVisit(payload).subscribe({
      next: () => console.log('Visit tracked'),
      error: (err) => console.error('Track failed', err)
    });
  }

}
