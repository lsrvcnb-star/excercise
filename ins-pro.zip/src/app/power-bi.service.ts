import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import configData from '../assets/keys.json';


export interface TrackVisitPayload {
  userId: string;
  empId: string;
  dbVertical: string;
  dbName: string;
}


@Injectable({
  providedIn: 'root'
})
export class PowerBiService {
  private urls: any = configData
  powerBIEndpoint = `${environment.powerbiApi}`

  private apiUrl = `${this.powerBIEndpoint}power-bi/dashboard/getembedinfo`
  private trackVisitUrl = `${this.powerBIEndpoint}power-bi/dashboard/track-visit`;

  // private apiUrl = environment.api + 'getEmbedToken'; // API endpoint
  constructor(private http: HttpClient) { }
  getEmbedToken(page): Observable<any> {
    const body = {
      reportId: this.urls.prod[page]
    }
    return this.http.post<any>(this.apiUrl, body);


  }

  /** Log dashboard visit to backend */

  trackVisit(payload: TrackVisitPayload): Observable<string> {
    return this.http.post(
      this.trackVisitUrl,
      payload,
      { responseType: 'text' } // return type will be Observable<string>
    );
  }


}
