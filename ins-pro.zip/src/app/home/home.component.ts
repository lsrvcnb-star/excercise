import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { AccountService } from '../account.service';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthserviceService } from '../authservice.service';
import { UserInterface } from '../app.userInterface';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  @ViewChild('dcvDashboard') dcvDashboard: ElementRef
  loanjourneyURL: string = "https://Loanjourney.sidbi.in/";
  user: UserInterface | null = null;

  // for compliance dash
  hasComplianceAccess = false;
  modalTitle: string = '';

  // for loan journey
 activeTab: string = 'dcv';
  constructor(
    private CookieService: CookieService,
    private router: Router,
    private AccountService: AccountService,
    private authService: AuthserviceService,
     private route: ActivatedRoute,
  ) { }

  ngOnInit(): void {
    this.hasComplianceAccess = false;
    const user = this.CookieService.get("UserID");

     this.route.queryParams.subscribe(params => {
      this.activeTab = params['tab'] || 'dcv';
    });

    //  const selectedUser = this.AccountService.testUsers(user);
    //  if (selectedUser) {
    /*  this.authService.validateUser().subscribe(
       (isValid: boolean) => {
         if (!isValid) {
           this.router.navigate(['/login']);
         } else {
           this.authService.setUser();
           this.router.navigate(['/home']);
           this.authService.user$.subscribe((response) => {
               if (response !== null) {
                 this.user = { user: response?.user, token: response?.token }
               }

             })
         }
       }
     )
   } else { */
    this.authService.user$.subscribe({
      next: (response) => {
        if (response !== null) {
          this.user = { user: response?.user, token: response?.token }
          this.AccountService.user_valid(this.user?.user, this.user?.token).subscribe({
            next: (res: any) => {
              if (res["apiResponse"] === "In Valid") {
                this.AccountService.deleteCookies();
                this.authService.userSubject.next(null);
                this.router.navigate(['/login']);
                alert("Session Invalid. Please login again.")
              } else {
                // do something
              }

            },
            error: (error) => {
              console.log("Error validating user, ", error);
              this.authService.userSubject.next(null);
              this.router.navigate(['/login']);
            }
          })
        } else {
          console.log("Error validating user, ip");

          this.router.navigate(['/login']);
        }
      },
      error: () => {
        console.log("Error fetching user data at header component")
        this.authService.userSubject.next(null);
        this.router.navigate(['/login']);
      }
    })

    //  }


  }

  // open comp in a new tab
  openNewTab(url: string, routeName: string): void {
    let winRef = window.open(url, routeName);
    // push window references of dashboards opened to an array
    this.AccountService.windowReferences(winRef);
  }

  // conditionally navigate urls
  navigateToUrl(route: string): void {

    let selectedUser = this.CookieService.get('UserID');
    let selectedUserAuth = this.CookieService.get('authToken');

    if (route === 'loanJourney') {      
      this.modalTitle = 'NBFC';
      let userId = this.user?.user
      let boroAccess = false;
      let managerAccess = false;
      let otherUserAccess = false;


      const user = this.CookieService.get("UserID");

      this.AccountService.testUsers(user).subscribe((selectedUser: any) => {
        if (selectedUser && selectedUser['responseMessage'] == 'Valid') {
          /*         this.authService.validateUser().subscribe(
                    (isValid: boolean) => {
                      if (!isValid) {
          
                      } else { */

          window.open('https://loanjourney.sidbi.in/', '_self');
          // }
          //  }
          // )


        } else {
          this.authService.authorizeUser(user).subscribe({
            next: (res: any) => {
              if (res.status === 200) {
                if (res.token) {
                  let authToken = res.token;
                  this.CookieService.set('userToken', authToken); // bearer token set in cookies
                  //this.authCookieService.setCookies(userName, data['authToken'], dateTime);
                  window.open('https://loanjourney.sidbi.in/', '_self');
                }
              } else {
                alert("Authorization denied for Direct Credit Loan Journey");
                console.log("Error responded with authorizing user ", res);
              }
            },
            error: (err: any) => {
              console.log("error at authorizing user ", err);
            }
          })
        }
      });



    }
   
    else if (route === 'application journey') {
      window.open('https://onlineloanjourney.sidbi.in/online-loan-monitoring/dashbord', '_self');
    }
    else {

      // Internal routes → let AuthguardGuard + AccessGuard decide
      this.router.navigate([`/${route}`], {
        queryParams: { home: this.activeTab }
      });

    }
  }

  
callAccessListAPI(user: string, routeLower: string, deptRouteMap: { [key: string]: string[] }) {
  this.AccountService.getAccessList(user).subscribe({
    next: (res: any) => {
      const dept = res?.dept?.toLowerCase();
      const accessList = dept?.split(',').map(item => item.trim().toLowerCase()) || [];

      const allowedRoutesForUser = accessList.flatMap(deptKey => deptRouteMap[deptKey] || []);

      // ✅ New: allow 'dcv' if any dept starts with 'dcv' (case-insensitive)
      const hasDcvPrefix = this.hasDeptPrefix(accessList, 'dcv');
      const hasAccess = hasDcvPrefix
        ? (routeLower === 'dcv' || allowedRoutesForUser.includes(routeLower))
        : allowedRoutesForUser.includes(routeLower);

      if (hasAccess) {
        this.router.navigate([`/${routeLower}`]);
      } else {
        alert(`You don't have access to ${routeLower} Dashboard`);
      }
    },
    error: (err) => {
      if (err.status === 401) {
        alert('Unauthorized access - Unable Indentified User\'s Vertical');
      } else if (err.status === 404) {
        alert('User not found.');
      } else if (err.status === 409) {
        alert('Duplicate data found for the user.');
      } else {
        alert('An error occurred while checking access. Please try again later.');
      }
    }
  });
}


  
private hasDeptPrefix(accessList: string[] | null | undefined, prefix: string): boolean {
  if (!Array.isArray(accessList)) return false;
  const p = prefix.toLowerCase();
  return accessList.some(item => item?.trim()?.toLowerCase().startsWith(p));
}


  closeModal() {
    const modal = document.querySelector('#dcvDashboard');
    if (modal) {
      modal.classList.remove('show');
      document.body.classList.remove('modal-open');
      const backdrop = document.querySelector('.modal-backdrop');
      if (backdrop) {
        backdrop.remove();
      }
    }
  }

  selectTab(tab: string) {
    this.activeTab = tab;

    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { tab },
      queryParamsHandling: 'merge'
    });
  }

}
