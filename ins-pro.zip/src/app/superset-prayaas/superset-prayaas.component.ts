import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { PrayaasService } from '../prayaas.service';
import { PowerBiService, TrackVisitPayload } from '../power-bi.service';
import * as pbi from 'powerbi-client';
import { CookieService } from 'ngx-cookie-service';


@Component({
  selector: 'app-superset-prayaas',
  templateUrl: './superset-prayaas.component.html',
  styleUrls: ['./superset-prayaas.component.scss']
})
export class SupersetPrayaasComponent implements OnInit {
  selected_page: any;
@ViewChild('reportContainer', { static: true }) reportContainer!: ElementRef;
errorMessage: any[] = [];
  selected: string = 'Portfolio Summary';
  constructor(private dashboardServiceService: DashboardServiceService, private powerBiService: PowerBiService, private prayaasService: PrayaasService,  
    private router: Router, private titleService: Title, 
    private elementRef: ElementRef, private cookieService: CookieService) { }
  borderClass: string = ' c';
  pages: pbi.Page[] = [];
  ngOnInit(): void {
   // this.embedSupersetDashboard('prayaas');
   this.embedReport('prayaas');
    this.dashboardServiceService.updateTitle('SIDBI foundation for Microcredit (SFMC) - Executive Dashboard');
  }

  embedSupersetDashboard(selected: string): void {
    this.selected_page = selected;
    setTimeout(() => {
    const dashboardElement = this.elementRef.nativeElement.querySelector('#prayaas');

    if (dashboardElement && selected == 'prayaas') {
      this.prayaasService.embedDashboard(dashboardElement, selected).subscribe(
        () => {
          // Adjust the size of the embedded iframe
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%';
            iframe.style.height = '3070px';
          }
        },
        (error) => {
          console.error(error);
        }
      );
    }
  }, 500)
  }


embedReport(reportId): void {
    this.selected_page = reportId;
    this.clearExistingPowerBiEmbed();
    this.powerBiService.getEmbedToken(reportId).subscribe(
      (embedData) => {
        this.tracking();
        const models = pbi.models;
        const reportLoadConfig: pbi.IEmbedConfiguration = {
          type: 'report',
          tokenType: models.TokenType.Embed,
          accessToken: embedData.embedToken,
          embedUrl: embedData.embedReports[0].embedUrl,
          settings: {
            navContentPaneEnabled:false,
            panes: {
              filters: {
                visible: true,
              },
              pageNavigation: {
                visible: false,
              },

            },
            background: pbi.models.BackgroundType.Transparent,
            layoutType: pbi.models.LayoutType.Custom,
            customLayout: {
              displayOption: models.DisplayOption.FitToPage,
            }
          }
        };

        // Embed Power BI report
        const powerbi = new pbi.service.Service(
          pbi.factories.hpmFactory,
          pbi.factories.wpmpFactory,
          pbi.factories.routerFactory // Add this argument
        );
        const report = powerbi.embed(
          this.reportContainer.nativeElement,
          reportLoadConfig
        )as pbi.Report;

        if(reportId == 'mfi'){
          report.on('loaded', () => {
          report.getPages().then(pages => {

            this.pages = pages.filter((res) => {
              return res.displayName;;
            });
            console.log(this.pages)
          });
        });
        }
        // Handle events
        report.on('loaded', () => console.log('Report loaded successfully'));
        report.on('rendered', () => {
          console.log('Report rendered successfully');
          this.reportContainer.nativeElement.querySelector("iframe").style.height = this.selected_page == 'prayaas' ? '3300px' : '3500px';
        });
        // Adjust the size of the embedded iframe
        report.on('error', (event: any) => {
          this.elementRef.nativeElement.innerHTML = `<div class="text-center text-danger p-5">Error loading Power BI report</div>`;
          this.errorMessage = event.detail.split('\r\n');
          console.error('Power BI Error:', event.detail);
        });
      },
      (error) => {
        this.reportContainer.nativeElement.innerHTML = `<div class="text-center text-danger p-5">Error loading Power BI report</div>`;
        console.error('Error fetching embed token', error);
        this.errorMessage = ['Failed to fetch Power BI Embed Token.'];
      }
    );
  }

   clearExistingPowerBiEmbed(): void {
      const powerbi = new pbi.service.Service(
        pbi.factories.hpmFactory,
        pbi.factories.wpmpFactory,
        pbi.factories.routerFactory // Add this argument
      );
      powerbi.reset(this.reportContainer.nativeElement);
      this.reportContainer.nativeElement.innerHTML = ''; // Clear any previous content
    }


      switchPage(pageName: string): void {
    const targetPage = this.pages.find(p => p.name === pageName);
    if (targetPage) {
      this.selected = targetPage.displayName;
      targetPage.setActive();
    }
  }

      tracking() {
      const user = this.cookieService.get('UserID').toLowerCase();
      const payload: TrackVisitPayload = {
        userId: user + '@sidbi.in',
        empId: user,
        dbVertical: 'IFV',
        dbName: this.selected_page == 'mfi' ? 'MFI ASSISTANCE' : 'Prayaas'
      };
  
      this.powerBiService.trackVisit(payload).subscribe({
        next: () => console.log('Visit tracked'),
        error: (err) => console.error('Track failed', err)
      });
    }

}
