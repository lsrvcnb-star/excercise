import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import { EncryptDecryptService } from './encrypt-decrypt.service';
import { from, switchMap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  private winRefs: Array<Window> = [];

  constructor(
    private httpClient: HttpClient,
    private cookieservice: CookieService,
    private encryptDecryptService: EncryptDecryptService
  ) { }

  login(login_data: any) {

    return this.httpClient.post(environment.url + "login-1.0/login", {
      "userName": login_data['userName'],
      "password": login_data['password'],
      "capId": login_data['capId'],
      "capText": login_data['capText'],
      "redirectUrl": "http://localhost:8443/"
    });
  }

  logout() {
    const user = this.cookieservice.get("UserID");
    // const selectedUser = this.testUsers(user);
    /*     if (selectedUser) {
          return this.logoutTestUser(selectedUser);
        } else { */
    // return this.httpClient.post(environment.infoUserValid + 'auth/deluser', 
    //   { 'userName': this.encryptDecryptService.decryptMIS(user) })
    // }

    return from(this.encryptDecryptService.encryptMIS(user)).pipe(
      switchMap(encryptedUser => {
        const payload = {
          userName: encryptedUser,
        };

        const url = environment.infoUserValid + 'auth/deluser';
        return this.httpClient.post(url, payload);
      })
    )


  }

  /*   logoutTestUser(user: any) {
      return this.httpClient.post(environment.loginUrl + 'otp/logout',
        {
          "userName": this.encryptDecryptService.encrypt(user.user),
        })
  
  
    } */

  captcha() {
    return this.httpClient.post(environment.url + 'login-1.0/getCaptcha', {
      'userName': ''
    })
  }

  getConfig() {
    return this.httpClient.get('assets/config.json');

  }

  user_valid(username: string, token: string) {
    // const encrypt = this.encryptDecryptService.encryptMIS(username)
    // this.encryptDecryptService.encryptMIS(username)
    // return this.httpClient.post(environment.infoUserValid + 'auth/uservalid', {
    //   'userName': this.encryptDecryptService.encryptMIS(username),
    //   'authToken': token
    // })

    return from(this.encryptDecryptService.encryptMIS(username)).pipe(
      switchMap(encryptedUser => {
        const payload = {
          userName: encryptedUser,
          authToken: token
        };

        const url = environment.infoUserValid + 'auth/uservalid';
        return this.httpClient.post(url, payload);
      })
    )
  }

  // compliance authorization
  user_access() {
    return this.httpClient.get(environment.api + 'users', {});
  }

  // returns winRefs array
  getWindowReferences(): Array<Window> {
    return this.winRefs;
  }

  // push window references of dashboards opened to winRefs array
  windowReferences(winRef: Window) {
    this.winRefs.push(winRef);
  }

  clearWindowRefs() {
    let winRefs = this.winRefs;

    if (winRefs && winRefs.length > 0) {
      winRefs.forEach((ref: Window) => {
        ref.close();
      })
    }

  }

  deleteCookies(): void {
    this.cookieservice.set("UserID", '',
      {
        expires: new Date('Thu, 01 Jan 1970 00:00:01 GMT'),
        path: '/',
        domain: 'sidbi.in'
      });
    this.cookieservice.set("authToken", '',
      {
        expires: new Date('Thu, 01 Jan 1970 00:00:01 GMT'),
        path: '/',
        domain: 'sidbi.in'
      });
    if (this.cookieservice.get('username') && this.cookieservice.get('lmsAuthToken')) {
      this.cookieservice.delete('username', '/', 'sidbi.in');
      this.cookieservice.delete('lmsAuthToken', '/', 'sidbi.in');
    }
    if (this.cookieservice.get('userToken')) {
      this.cookieservice.delete('userToken');
    }
  }

  getUserIP() {
    return this.httpClient.get(environment.url + 'login-1.0/getClientIp',);
  }

  testUsers(userName: string) {
    return from(this.encryptDecryptService.encryptUserValid(userName)).pipe(
      switchMap(encryptedUser => {
        const payload = {
          user: encryptedUser,
        };

        const url = environment.loginUrl + 'auth/userAuthenticate';
        return this.httpClient.post(url, payload);
      })
    )


  }

  getMasterAccessList(user: string) {
    //  return this.httpClient.post(environment.infoUserValid + 'auth/getMasterAccessList',  {
    //     "userName": this.encryptDecryptService.encryptMIS(user),
    //   }); 
    // return of({
    //   dept: "ALL",
    //   userName: "nisg_salamonraja"
    // }).pipe(delay(400));

    return from(this.encryptDecryptService.encryptMIS(user)).pipe(
      switchMap(encryptedUser => {
        const payload = {
          userName: encryptedUser,
        };

        const url = environment.infoUserValid + 'auth/getMasterAccessList';
        return this.httpClient.post(url, payload);
      })
    );
  }

  getAccessList(user: string) {
    //  return this.httpClient.post(environment.infoUserValid + 'auth/getAccessList',  {
    //     "userName": this.encryptDecryptService.encryptMIS(user),
    //   }); 
    // return of({
    //   dept: "ALL",
    //   userName: "nisg_salamonraja"
    // }).pipe(delay(400));
    return from(this.encryptDecryptService.encryptMIS(user)).pipe(
      switchMap(encryptedUser => {
        const payload = {
          userName: encryptedUser,
        };

        const url = environment.infoUserValid + 'auth/getAccessList';
        return this.httpClient.post(url, payload);
      })
    );
  }



}
