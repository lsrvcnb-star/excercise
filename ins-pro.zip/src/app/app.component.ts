import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from "@angular/router"
import { CookieService } from 'ngx-cookie-service';
import { AccountService } from './account.service';
import { AuthserviceService } from './authservice.service';

declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {



  constructor(
    private AccountService: AccountService,
    private router: Router,
    private cookieservice: CookieService,
    private authService: AuthserviceService
  ) { }

  ngOnInit(): void {

    const user = this.cookieservice.get("UserID");
    const token = this.cookieservice.get("authToken");
/*     const selectedUser = this.AccountService.testUsers(user);
    if (selectedUser) {


        this.authService.validateUser().subscribe(
          (isValid: boolean) => {
            if (!isValid) {
              this.router.navigate(['/login']);
            } else {
              this.authService.setUser();
              this.router.navigate(['/home']);
            }
          }
        )

    } else { */
      if (user && token) {
        this.AccountService.user_valid(user, token).subscribe({
          next: (response: any) => {
            if (response && response?.apiResponse === "Valid") {
              this.authService.userSubject.next({ user: user, token: token });
              this.router.navigate(['/home']);
            } else {
              this.AccountService.deleteCookies();
              this.authService.userSubject.next(null);
              this.router.navigate(['/login']);
            }
          },
          error: (err) => {
            console.log("Error validating user");
            this.router.navigate(['/login'])
          }
        })
      }

   // }

  }
}
