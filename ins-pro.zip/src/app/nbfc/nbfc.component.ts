import { Component, ElementRef, OnInit } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-nbfc',
  templateUrl: './nbfc.component.html',
  styleUrls: ['./nbfc.component.scss']
})
export class NbfcComponent implements OnInit {
  selected_page: string = 'L1'
  currentRoute: string;
  constructor(private dashboardServiceService: DashboardServiceService, private router: Router, private titleService: Title,
    private elementRef: ElementRef,) { }

  ngOnInit(): void {
    this.currentRoute = this.router.url
    this.currentRoute == '/nbfc' ? this.onClickOfNBFCmenu(this.selected_page): this.onClickOfNBFCmenu('test');

  }

  onClickOfNBFCmenu(menuName: string) {
    this.selected_page = menuName;
    this.embedSupersetDashboard(menuName);
    this.dashboardServiceService.updateTitle('Non-Banking Financial Company (NBFC) - Dashboard');
  }


  embedSupersetDashboard(selected: string): void {
    const dashboardElement = this.elementRef.nativeElement.querySelector('#dashboard');

    if (dashboardElement) {
      this.dashboardServiceService.embedDashboard(dashboardElement, selected).subscribe(
        () => {
          // Adjust the size of the embedded iframe
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%';
            if (selected == 'L1') {
              iframe.style.height = '1500px';
            }
            if (selected == 'test') {
              iframe.style.height = '2000px';
            }
            if (selected == 'L2') {
              iframe.style.height = '4650px';
            }
            if (selected == 'L3') {
              iframe.style.height = '1100px';
            }


          }
        },
        (error) => {
          console.error(error);
        }
      );
    }
  }

}
