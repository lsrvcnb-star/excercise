import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { PowerBiService, TrackVisitPayload } from '../power-bi.service';
import { DashboardServiceService } from '../dashboard-service.service';
import { CookieService } from 'ngx-cookie-service';
import * as pbi from 'powerbi-client';

@Component({
  selector: 'app-visit-monitor',
  templateUrl: './visit-monitor.component.html',
  styleUrls: ['./visit-monitor.component.scss']
})
export class VisitMonitorComponent implements OnInit {
 @ViewChild('reportContainerARV', { static: true }) reportContainer!: ElementRef;
  errorMessage: any[] = [];
  constructor(private powerBiService: PowerBiService, private elementRef: ElementRef, private dashboardServiceService: DashboardServiceService, private cookieService: CookieService,) { }

  ngOnInit(): void {
      this.embedReport();
    this.dashboardServiceService.updateTitle('Visits Monitoring Dashboard');
  }


    embedReport(): void {
        this.clearExistingPowerBiEmbed();
        this.powerBiService.getEmbedToken('visitMonitor').subscribe(
          (embedData) => {
            this.tracking();
            const models = pbi.models;
            const reportLoadConfig: pbi.IEmbedConfiguration = {
              type: 'report',
              tokenType: models.TokenType.Embed,
              accessToken: embedData.embedToken,
              embedUrl: embedData.embedReports[0].embedUrl,
              settings: {
                navContentPaneEnabled:false,
                panes: {
                  filters: {
                    visible: true,
                  },
                  pageNavigation: {
                    visible: false,
                  },
  
                },
                background: pbi.models.BackgroundType.Transparent,
                layoutType: pbi.models.LayoutType.Custom,
                customLayout: {
                  displayOption: models.DisplayOption.FitToPage,
                }
              }
            };
  
            // Embed Power BI report
            const powerbi = new pbi.service.Service(
              pbi.factories.hpmFactory,
              pbi.factories.wpmpFactory,
              pbi.factories.routerFactory // Add this argument
            );
            const report = powerbi.embed(
              this.reportContainer.nativeElement,
              reportLoadConfig
            );
            // Handle events
            report.on('loaded', () => console.log('Report loaded successfully'));
            report.on('rendered', () => {
              console.log('Report rendered successfully');
              this.reportContainer.nativeElement.querySelector("iframe").style.height = '1400px';
            });
            // Adjust the size of the embedded iframe
            report.on('error', (event: any) => {
              this.errorMessage = event.detail.split('\r\n');
              console.error('Power BI Error:', event.detail);
            });
          },
          (error) => {
            this.elementRef.nativeElement.innerHTML = `<div class="text-center text-danger p-5">Error loading Power BI report</div>`;
            console.error('Error fetching embed token', error.error);
            this.errorMessage = ['Failed to fetch Power BI Embed Token.'];
          }
        );
      }
  
      clearExistingPowerBiEmbed(): void {
          const powerbi = new pbi.service.Service(
            pbi.factories.hpmFactory,
            pbi.factories.wpmpFactory,
            pbi.factories.routerFactory // Add this argument
          );
          powerbi.reset(this.reportContainer.nativeElement);
          this.reportContainer.nativeElement.innerHTML = ''; // Clear any previous content
        }

        tracking() {        
                const user = this.cookieService.get('UserID').toLowerCase();
                const payload: TrackVisitPayload = {
                  userId: user + '@sidbi.in',
                  empId: user,
                  dbVertical: 'DCV',
                  dbName: 'Visits Monitoring'
                };
            
                this.powerBiService.trackVisit(payload).subscribe({
                  next: () => console.log('Visit tracked'),
                  error: (err) => console.error('Track failed', err)
                });
              }

}
