import { Component, ElementRef, OnInit } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { CookieService } from 'ngx-cookie-service';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-committee',
  templateUrl: './committee.component.html',
  styleUrls: ['./committee.component.scss']
})
export class CommitteeComponent implements OnInit {

  constructor(private dashboardServiceService: DashboardServiceService, private router: Router,
    private titleService: Title,
    private elementRef: ElementRef,
    private cookie:CookieService, private accountService: AccountService) { }

  ngOnInit(): void {
    this.embedComplianceDashboard('committee');
    this.dashboardServiceService.updateTitle('Meetings Dashboard');
  }



  embedComplianceDashboard(selected: string): void {
    const dashboardElement = this.elementRef.nativeElement.querySelector('#committee-dashboard');

    if (dashboardElement) {
      this.dashboardServiceService.embedDashboard(dashboardElement, selected).subscribe(
        () => {
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%';
            iframe.style.height = '3400px';
          }
        },
          (error) => {
          console.error(error);
        }
      );
    }
  }

}
