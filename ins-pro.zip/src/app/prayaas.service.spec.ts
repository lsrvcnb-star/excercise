import { TestBed } from '@angular/core/testing';

import { PrayaasService } from './prayaas.service';

describe('PrayaasService', () => {
  let service: PrayaasService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PrayaasService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
