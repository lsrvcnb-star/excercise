import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { PowerBiService, TrackVisitPayload } from '../power-bi.service';
import { DashboardServiceService } from '../dashboard-service.service';
import { CookieService } from 'ngx-cookie-service';
import * as pbi from 'powerbi-client';

@Component({
  selector: 'app-ifv-portfolio-dashboard',
  templateUrl: './ifv-portfolio-dashboard.component.html',
  styleUrls: ['./ifv-portfolio-dashboard.component.scss']
})
export class IfvPortfolioDashboardComponent implements OnInit {
  @ViewChild('reportContainer', { static: true }) reportContainer!: ElementRef;
  errorMessage: any[] = [];
  selectedMenu: string = 'dashboard';
  iframeHeight: string = '2000px';

  private menuConfig: { [key: string]: { reportKey: string; height: string; dbName: string } } = {
    dashboard: { reportKey: 'ifvPortfolioDashboard', height: '2000px', dbName: 'IFV Portfolio Dashboard' },
    funds: { reportKey: 'ifvFunds', height: '1100px', dbName: 'IFV Funds' },
    reports: { reportKey: 'ifvReports', height: '1400px', dbName: 'IFV Reports' },
    marketNews: {
      reportKey: '',
      height: '800px',
      dbName: 'Market News'
    }

  };

  constructor(
    private powerBiService: PowerBiService,
    private elementRef: ElementRef,
    private dashboardServiceService: DashboardServiceService,
    private cookieService: CookieService
  ) { }

  ngOnInit(): void {
    this.dashboardServiceService.updateTitle('IFV Portfolio Dashboard');
    this.embedReport('dashboard');
  }



  selectMenu(menu: string): void {
    if (this.selectedMenu === menu) {
      return;
    }

    this.selectedMenu = menu;


    if (menu === 'marketNews') {
      this.showMarketNewsPlaceholder();
      return;
    }

    this.iframeHeight = this.menuConfig[menu].height;
    this.embedReport(menu);
  }

  showMarketNewsPlaceholder(): void {

    this.clearExistingPowerBiEmbed();

    this.reportContainer.nativeElement.innerHTML = `
    <div class="market-news-placeholder text-center">
      <i class="bi bi-newspaper"></i>
      <h2>Market News</h2>
      <p>Coming Soon</p>
      
    </div>
  `;
  }

  embedReport(menu: string): void {
    const config = this.menuConfig[menu];
    this.selectedMenu = menu;
    this.iframeHeight = config.height;
    this.clearExistingPowerBiEmbed();

    this.powerBiService.getEmbedToken(config.reportKey).subscribe(
      (embedData) => {
        this.tracking(config.dbName);
        const models = pbi.models;
        const reportLoadConfig: pbi.IEmbedConfiguration = {
          type: 'report',
          tokenType: models.TokenType.Embed,
          accessToken: embedData.embedToken,
          embedUrl: embedData.embedReports[0].embedUrl,
          settings: {
            navContentPaneEnabled: false,
            panes: {
              filters: { visible: true },
              pageNavigation: { visible: false }
            },
            background: pbi.models.BackgroundType.Transparent,
            layoutType: pbi.models.LayoutType.Custom,
            customLayout: {
              displayOption: models.DisplayOption.FitToPage
            }
          }
        };

        const powerbi = new pbi.service.Service(
          pbi.factories.hpmFactory,
          pbi.factories.wpmpFactory,
          pbi.factories.routerFactory
        );
        const report = powerbi.embed(
          this.reportContainer.nativeElement,
          reportLoadConfig
        );

        report.on('loaded', () => console.log('Report loaded successfully'));
        report.on('rendered', () => {
          console.log('Report rendered successfully');
          this.reportContainer.nativeElement.querySelector('iframe').style.height = this.iframeHeight;
        });
        report.on('error', (event: any) => {
          this.errorMessage = event.detail.split('\r\n');
          console.error('Power BI Error:', event.detail);
        });
      },
      (error) => {
        this.elementRef.nativeElement.innerHTML = `<div class="text-center text-danger p-5">Error loading Power BI report</div>`;
        console.error('Error fetching embed token', error.error);
        this.errorMessage = ['Failed to fetch Power BI Embed Token.'];
      }
    );
  }

  clearExistingPowerBiEmbed(): void {
    const powerbi = new pbi.service.Service(
      pbi.factories.hpmFactory,
      pbi.factories.wpmpFactory,
      pbi.factories.routerFactory
    );
    powerbi.reset(this.reportContainer.nativeElement);
    this.reportContainer.nativeElement.innerHTML = '';
  }

  tracking(dbName: string): void {
    const user = this.cookieService.get('UserID').toLowerCase();
    const payload: TrackVisitPayload = {
      userId: user + '@sidbi.in',
      empId: user,
      dbVertical: 'IFV',
      dbName: dbName
    };

    this.powerBiService.trackVisit(payload).subscribe({
      next: () => console.log('Visit tracked'),
      error: (err) => console.error('Track failed', err)
    });
  }
}
