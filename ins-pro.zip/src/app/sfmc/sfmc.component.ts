import { Component, ElementRef, OnInit } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-sfmc',
  templateUrl: './sfmc.component.html',
  styleUrls: ['./sfmc.component.scss']
})
export class SfmcComponent implements OnInit {
  selected_page: string = 'L1_MFI'
  currentRoute: string;

  constructor(private dashboardServiceService: DashboardServiceService, private router: Router, private titleService: Title,
    private elementRef: ElementRef) { }

  ngOnInit(): void {

    this.currentRoute = this.router.url
this.onClickOfSFMCmenu(this.selected_page);

  }

  onClickOfSFMCmenu(menuName: string) {
    this.selected_page = menuName;
    this.embedSupersetDashboard(menuName);
    this.dashboardServiceService.updateTitle('SIDBI foundation for Microcredit (SFMC) - Executive Dashboard');
  }

  embedSupersetDashboard(selected: string): void {
    const dashboardElement = this.elementRef.nativeElement.querySelector('#dashboard');

    if (dashboardElement) {
      this.dashboardServiceService.embedDashboard(dashboardElement, selected).subscribe(
        () => {
          // Adjust the size of the embedded iframe
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%';
            if (selected == 'L1_MFI') {
              iframe.style.height = '1500px';
            }

            if (selected == 'L2_MFI') {
              iframe.style.height = '4650px';
            }
            if (selected == 'L3_MFI') {
              iframe.style.height = '1100px';
            }


          }
        },
        (error) => {
          console.error(error);
        }
      );
    }
  }


}
