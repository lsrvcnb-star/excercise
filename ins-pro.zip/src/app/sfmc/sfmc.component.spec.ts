import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SfmcComponent } from './sfmc.component';

describe('SfmcComponent', () => {
  let component: SfmcComponent;
  let fixture: ComponentFixture<SfmcComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SfmcComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SfmcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
