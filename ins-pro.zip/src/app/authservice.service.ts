import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, map, Observable, of, tap } from 'rxjs';
import { UserInterface } from './app.userInterface';
import { environment } from 'src/environments/environment';
import * as CryptoJS from 'crypto-js';
import { CookieService } from 'ngx-cookie-service';
import { EncryptDecryptService } from './encrypt-decrypt.service';


@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {

  public userSubject: BehaviorSubject<UserInterface | null>
  public user$: Observable<UserInterface | null>

  url: string = environment.lmsbeURL;
  encryptKey: string = environment.encryptKey;

  constructor(
    private httpClient: HttpClient, private cookieService: CookieService, private encryptDecryptService: EncryptDecryptService
  ) {
    this.userSubject = new BehaviorSubject<UserInterface | null>(null);
    this.user$ = this.userSubject.asObservable();
  }


  /* validateUser() {
    const user = this.cookieService.get("UserID");
    const authToken = this.cookieService.get("authToken");
    if (user && authToken) {
      return this.user_validTestUser(user, authToken).pipe(
        map((res: any) => {
          return res?.apiResponse === 'Valid'
        }),
        tap((isValid: boolean) => {
          if (!isValid) {
            this.removeCookies();
          }
        })
      )
    } else {
      return of(false);
    }
  } */

/*   user_validTestUser(userName: string, authToken: string) {

    return this.httpClient.post(environment.loginUrl + 'otp/userValid',
      {
        "userName": this.encryptDecryptService.encrypt(userName),
        "authToken": authToken
      })


  } */


  setUser() {
    const user = this.cookieService.get("UserID");
    const authToken = this.cookieService.get("authToken");
    this.userSubject.next({ user: user, token: authToken });
  }


  removeCookies(): void {
    this.cookieService.set("UserID", '',
      {
        expires: new Date('Thu, 01 Jan 1970 00:00:01 GMT'),
        path: '/',
        domain: 'sidbi.in'
      });
    this.cookieService.set("authToken", '',
      {
        expires: new Date('Thu, 01 Jan 1970 00:00:01 GMT'),
        path: '/',
        domain: 'sidbi.in'
      });
    this.userSubject.next(null);
  }




  // // loan journey authorization

  // getBOROAccess(userId: string) {
  //   return this.httpClient.get(this.url + 'lmsbe/getBOROAccess?userId=' + userId, { headers: { "Content-Type": "application/json", 'Accept': 'application/json' } })
  // }
  // getManagerLevel() {
  //   return this.httpClient.get(this.url + 'lmsbe/getManagerLevel', { headers: { "Content-Type": "application/json", 'Accept': 'application/json' } })
  // }

  // getOtherUsers() {
  //   return this.httpClient.get(this.url + 'lmsbe/users', { headers: { "Content-Type": "application/json", 'Accept': 'application/json' } })
  // }

  encryptUserData = (data) => {
    const encryptedString = CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptKey).toString();
    return encryptedString;
  }

  authorizeUser(userId: string) {
    return this.httpClient.post(this.url + 'lmsbe/authorizeLogin', { 'userId': this.encryptUserData(userId) }, { headers: { "Content-Type": "application/json", 'Accept': 'application/json' } })
  }


}
