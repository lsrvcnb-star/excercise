import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { Observable } from 'rxjs';
import { AccountService } from '../account.service';
import { AuthserviceService } from '../authservice.service';

@Injectable({
  providedIn: 'root'
})
export class AuthguardGuard implements CanActivate {
  isAccess: boolean = false;
  constructor(private cookieService: CookieService,
    private accountService: AccountService,
    private authService: AuthserviceService,
    private router: Router,) {

  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    this.accountService.getUserIP().subscribe((ip) => {

      if (ip['clientIp'] == '172.20.100.174') {
        this.isAccess = true;
      } else {
        const user = this.cookieService.get("UserID");
        const token = this.cookieService.get("authToken");

        if (user && token) {
          this.isAccess = true;
        } else {
          this.isAccess = false;
          this.router.navigate(['/login'])
        }
      }
    })

    return this.isAccess;
  }

}
