export const environment = {
  production: true,
  uat: false,
  url: 'https://sso.sidbi.in:8443/',
  lmsbeURL: "https://loanjourney.sidbi.in/",
  api: 'https://insights.sidbi.in/dashboardbe/',
  encryptKey: "SIBDILMS@89*97",
  dashboard_url: 'https://dashboard-prod.sidbi.in/',
  loginUrl: 'https://visitapp.sidbi.in/otp-mfa/',
  aesSecretkey_MIS: "z6zfsr8eoMI1a47zXR8EvEucFILicA36veTLB3cjWZA=",
  aesSecretkey_SSO: 'E8gKS9eSUvcCCXUgoVy0hjHToVQlJ5ZcrgI6Mia5xNQ=',
  aesSecretKey_UserValidate:"z6zfsr8eoMI1a47zXR8EvEucFILicA36veTLB3cjWZA=",
  referrerUrl: '',
  powerbiApi: 'https://insights.sidbi.in/',
  prayaasAPI: 'https://insights-prayaas.sidbi.in/',
  infoUserValid: 'https://insights.sidbi.in/sso/',
  acessManagementApp: 'https://pnd-dashboard.sidbi.in/prod/master-access'
};
