export const environment = {
  production: false,
  uat:true,
  url:'https://ssouat.sidbi.in:8443/',
  encryptKey : "SIBDILMS@89*97",
  prayaasAPI: 'https://insights-prayaas.sidbi.in/',
 infoUserValid: 'https://info.sidbi.in/sso/',
 acessManagementApp: 'https://pnd-dashboard.sidbi.in/api/master-access'
};
