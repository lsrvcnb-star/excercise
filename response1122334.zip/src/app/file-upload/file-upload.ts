import { Component, Input, OnInit, OnDestroy, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GrievanceService } from '../services/grievance.service';
import { AppAlertService } from '../shared/app-alert/app-alert.service';
import { AppLoaderService } from '../shared/app-loader/app-loader.service';
import { finalize } from 'rxjs';

export interface UploadRow {
file?: File;
fileName?: string;
uploaded?: boolean;
uploading?: boolean;
previewUrl?: string;
}

@Component({
selector: 'app-file-upload',
standalone: true,
imports: [CommonModule],
templateUrl: './file-upload.html',
styleUrls: ['./file-upload.css']
})
export class FileUploadComponent implements OnInit, OnDestroy {

@Input() srNo!: number;
@Input() documentType!: 'G' | 'C' | 'R';
@Output() uploadCompleted = new EventEmitter<void>();

uploadRows: UploadRow[] = [];

constructor(
  private grievanceService: GrievanceService,
  private cd: ChangeDetectorRef,
  private alert: AppAlertService,
  private loader: AppLoaderService
) {}

ngOnInit(): void {
  // ✅ Initialize with 3 rows
  this.uploadRows = Array.from({ length: 1 }, () => ({}));
}

/* ================= FILE SELECT ================= */
onFileSelected(event: Event, index: number): void {
 const input = event.target as HTMLInputElement;
 if (!input.files || input.files.length === 0) return;

 const file = input.files[0];
 const maxSize = 10 * 1024 * 1024;

 if (file.type !== 'application/pdf') {
   this.alert.error('Only PDF files are allowed');
   input.value = '';
   return;
 }

 if (file.size > maxSize) {
   this.alert.error('File size must be less than 10 MB');
   input.value = '';
   return;
 }

 this.uploadRows[index] = {
   file,
   fileName: file.name,
   uploaded: false,
   uploading: false,
   previewUrl: URL.createObjectURL(file)
 };
}

/* ================= UPLOAD ================= */
uploadFile(index: number): void {
const row = this.uploadRows[index];
if (!row.file || row.uploading) return;

row.uploading = true;
this.loader.show();

const formData = new FormData();
formData.append('gfSrNo', this.srNo.toString());
formData.append('gfFileType', this.documentType);
formData.append('file', row.file);

this.grievanceService.uploadFile(formData).pipe(
  finalize(() => this.loader.hide())
).subscribe({
  next: () => {
    row.uploaded = true;
    row.uploading = false;
    this.uploadCompleted.emit();
    this.cd.detectChanges();
    // ✅ release file reference (optional)
    row.file = undefined;
  },
  error: () => {
    row.uploading = false;
    this.alert.error('Upload failed');
  }
});
}

/* ================= PREVIEW ================= */
previewFile(index: number): void {
  const url = this.uploadRows[index].previewUrl;
  if (url) {
    window.open(url, '_blank');
  }
}

/* ================= REMOVE PENDING FILE ================= */
removeFile(index: number, input: HTMLInputElement): void {
  const row = this.uploadRows[index];

  // Uploaded files are persisted by the server and must not be removed here.
  if (!row || row.uploaded || row.uploading) return;

  if (row.previewUrl) {
    URL.revokeObjectURL(row.previewUrl);
  }

  this.uploadRows[index] = {};
  input.value = '';
  this.cd.detectChanges();
}

/* ================= ADD ROW ================= */
addRow(): void {
  this.uploadRows.push({});
}

/* ================= CLEANUP ================= */
ngOnDestroy(): void {
  this.uploadRows.forEach(r => {
    if (r.previewUrl) {
      URL.revokeObjectURL(r.previewUrl);
    }
  });
}
}



