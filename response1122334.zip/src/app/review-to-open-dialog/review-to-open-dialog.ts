import { Component, Inject, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpResponse } from '@angular/common/http';
import { finalize } from 'rxjs';

import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import { GrievanceService } from '../services/grievance.service';
import { AppAlertService } from '../shared/app-alert/app-alert.service';
import { AppLoaderService } from '../shared/app-loader/app-loader.service';
import { dateAtStartOfDay, dateOnly, stripHtml } from '../shared/utils';
import { FileUploadComponent } from '../file-upload/file-upload';

@Component({
selector: 'app-review-to-open-dialog',
standalone: true,
imports: [
  CommonModule,
  FormsModule,
  MatDialogModule,
  MatFormFieldModule,
  MatInputModule,
  MatSelectModule,
  MatButtonModule,
  MatIconModule,
  FileUploadComponent
],
templateUrl: './review-to-open-dialog.html',
styleUrls: ['./review-to-open-dialog.css']
})
export class ReviewToOpenDialogComponent implements OnInit {

role: string;
grievance: any;
grievanceSrNo: number | null = null;
today = dateOnly(new Date());
closureDate = '';

resolutionText = '';
isResolutionSaved = false;

boRemarksText = '';
isBoRemarksSaved = false;
hasPrePopulatedRemarks = false;

complaintFiles: any[] = [];
resolutionFiles: any[] = [];

constructor(
  public dialogRef: MatDialogRef<ReviewToOpenDialogComponent>,
  @Inject(MAT_DIALOG_DATA) public data: any,
  private grievanceService: GrievanceService,
  private alert: AppAlertService,
  private loader: AppLoaderService,
  private cdr: ChangeDetectorRef
) {
  this.role = (data?.role ?? '').toUpperCase();
  const grievance = data?.grievance ?? {};
  const row = data?.row ?? {};
  this.grievance = {
    ...grievance,
    gdComplaint: grievance.gdComplaint || row.complaint || '',
    gdSrNo: grievance.gdSrNo || row.grvNo || '',
  };
  // AC closure popup defaults to today's local date; the user may change it.
  this.closureDate = dateOnly(new Date());
}

ngOnInit(): void {
  this.grievanceSrNo = this.grievance?.gdSrNo ?? null;
  this.resolutionText = this.grievance?.gdResolution || '';
  if (this.role === 'BC' || this.role === 'BM' || ((this.role === 'AM' || this.role === 'AC') && this.grievance.gdBranchVertical == 'B')) {
    this.boRemarksText = this.grievance?.gdResolutionBoinchRemarks || '';
  } else if (this.role === 'RC' || this.role === 'RM' || ((this.role === 'AM' || this.role === 'AC') && this.grievance.gdBranchVertical == 'R')) {
    this.boRemarksText = this.role === 'AM' ||  this.role === 'RM' ? this.grievance?.gdResolutionRoinchRemarks : this.role === 'AC' ? this.grievance?.gdResolutionHoinchRemarks: '';
  } else if (this.role === 'HC' || this.role == 'HM' || ((this.role === 'AM' || this.role === 'AC') && this.grievance.gdBranchVertical == 'V')) {
    this.boRemarksText = this.grievance?.gdResolutionHoinchRemarks || '';
  } else {
    this.boRemarksText = this.grievance?.gdBoVerticalRemarks || '';
  }
  this.hasPrePopulatedRemarks = !!this.boRemarksText?.trim();
  this.categorizeFiles();
}

private categorizeFiles(): void {
  const files: any[] = this.data?.files ?? [];
  this.complaintFiles = files.filter((f: any) => f.gfFileType === 'G');
  this.resolutionFiles = files.filter((f: any) => f.gfFileType === 'R');
}

get isMaker(): boolean {
  return ['BM', 'RM', 'HM'].includes(this.role);
}

get isChecker(): boolean {
  return ['AM', 'AC'].includes(this.role);
}

get isCheckerACtionBtn(): boolean {
  return ['BC', 'RC', 'HC', 'AM', 'AC'].includes(this.role);
}

get isPrimarySaved(): boolean {
  return this.isChecker ? (this.isBoRemarksSaved || this.hasPrePopulatedRemarks) : this.isResolutionSaved;
}

get canUploadResolutionFiles(): boolean {
  return this.isChecker
    ? (this.isBoRemarksSaved || this.hasPrePopulatedRemarks || this.resolutionFiles.length > 0)
    : (this.isResolutionSaved || this.resolutionFiles.length > 0);
}

get showSavePrompt(): boolean {
  return this.isChecker
    ? (!this.isBoRemarksSaved && !this.hasPrePopulatedRemarks && this.resolutionFiles.length === 0)
    : (!this.isResolutionSaved && this.resolutionFiles.length === 0);
}

get saveButtonLabel(): string {
  return this.isChecker ? 'Save Remarks' : 'Save';
}

get currentStatus(): string {
  return this.grievance?.gdStatus || '01';
}

get isAdminCheckerClosure(): boolean {
  return this.role === 'AC' && String(this.grievance?.gdStatus ?? '') === '10';
}

get isClosureDateValid(): boolean {
  if (!this.isAdminCheckerClosure) return true;
  return !!this.closureDate && this.closureDate <= this.today;
}

get submitLabel(): string {
  const labels: Record<string, string> = {
    BM: 'Submit to BO Checker',
    RM: 'Submit to RO Checker',
    HM: 'Submit to Vertical Checker',
    BC: 'Approve and Forward to GC',
    RC: 'Approve and Forward to GC',
    HC: 'Approve and Forward to GC',
    AM: 'Approve and Forward to GC',
    AC: 'Approve and Close Resolution'
  };
  return labels[this.role] ?? 'Submit';
}

get sendBackLabel(): string {
  const labels: Record<string, string> = {
    BC: 'Send Back to Branch Maker',
    RC: 'Send Back to RO Maker',
    HC: 'Send Back to HO Maker'
  };
  return labels[this.role] ?? 'Send Back';
}

 get canDelete(): boolean {
    return this.role === 'AC' && this.grievance?.gdStatus === '10';
  }

  get showBoRemarks(): boolean {
   return this.isCheckerACtionBtn;
 }

 get isBoRemarksReadonly(): boolean{
  return this.isMaker;
 }

 get showSendBack(): boolean {
   return this.isCheckerACtionBtn && this.role !== 'AM';
 }

get submitStatus(): string {
  const statusMap: Record<string, string> = {
    BM: '04',
    RM: '06',
    HM: '08',
    BC: '09',
    RC: '09',
    HC: '09',
    AM: '10',
    AC: '11'
  };
  return statusMap[this.role] ?? '00';
}

get sendBackStatus(): string {
  const statusMap: Record<string, string> = {
    BC: '03',
    RC: '05',
    HC: '07',
    AC: '09',
    AM: this.grievance?.gdBranchVertical == 'B' ? '04' : this.grievance?.gdBranchVertical == 'R' ? '06': this.grievance?.gdBranchVertical == 'V' ? '08': '00'
  };
  return statusMap[this.role] ?? '00';
}

private buildPayload(status: string): any {
  const created = localStorage.getItem("username")?.toUpperCase();
  const formatDateTime = (d: string | Date) => {
    if (!d) return null;
    const dateObj = typeof d === 'string' ? new Date(d) : d;
    return dateObj.toISOString().split('.')[0];
  };
  const now = new Date();

   const payload: any = {
     ...this.grievance,
     gdResolution: stripHtml(this.resolutionText),
     gdStatus: status
   };

  switch (this.role) {
    case 'BM':
      payload.gdResolutionBomkrId = created;
      payload.gdResolutionBomkrDt = formatDateTime(now);
      break;
    case 'BC':
      payload.gdResolutionBoinchId = created;
      payload.gdResolutionBoinchDt = formatDateTime(now);
      payload.gdResolutionBoinchRemarks = this.boRemarksText;
   
      payload.gdResolutionHomkrId = created;
      payload.gdResolutionHomkrDt = formatDateTime(now);
   
      break;
     case 'AM':
       if (this.grievance?.gdBranchVertical !== 'R') {
         payload.gdResolutionBoinchId = created;
         payload.gdResolutionBoinchDt = formatDateTime(now);
         payload.gdResolutionBoinchRemarks = stripHtml(this.boRemarksText);
       }
       payload.gdResolutionHomkrId = created;
       payload.gdResolutionHomkrDt = formatDateTime(now);
       break;

     case 'AC':
       payload.gdResolutionHoinchId = created;
       payload.gdResolutionHoinchDt = formatDateTime(now);
       payload.gdResolutionHoinchRemarks = this.boRemarksText;
       if (this.isAdminCheckerClosure) {
         payload.gdApprovedBy = created;
         payload.gdApprovedDt = dateAtStartOfDay(this.closureDate);
       } else if (this.grievance?.gdBranchVertical !== 'R') {
         payload.gdApprovedBy = created;
         payload.gdApprovedDt = formatDateTime(now);
       }
       break;
    case 'RM':
      payload.gdResolutionRomkrId = created;
      payload.gdResolutionRomkrDt = formatDateTime(now);
      break;
     case 'RC':
       payload.gdResolutionRoinchId = created;
       payload.gdResolutionRoinchDt = formatDateTime(now);
       payload.gdResolutionRoinchRemarks = this.boRemarksText;
       break;
    case 'HM':
      payload.gdResolutionHomkrId = created;
      payload.gdResolutionHomkrDt = formatDateTime(now);
      break;
    case 'HC':
      payload.gdResolutionHoinchId = created;
      payload.gdResolutionHoinchDt = formatDateTime(now);
      payload.gdResolutionHoinchRemarks = this.boRemarksText;
      break;
  }

  return payload;
}

close(): void {
  this.dialogRef.close();
}

onSave(): void {
  if (!this.grievanceSrNo) {
    this.alert.warning('Grievance serial number is missing');
    return;
  }

  if (this.isChecker) {
    if (!this.boRemarksText.trim()) {
      this.alert.warning('Please enter BO/RO/Vertical Remarks before saving');
      return;
    }
  } else {
    if (!this.resolutionText.trim()) {
      this.alert.warning('Please enter resolution before saving');
      return;
    }
  }

  const payload = this.buildPayload(this.currentStatus);

  this.loader.show();

  this.grievanceService.updateGrievance(payload, this.grievanceSrNo).pipe(
    finalize(() => this.loader.hide())
  ).subscribe({
    next: () => {
      if (this.isChecker) {
        this.isBoRemarksSaved = true;
        this.grievance.gdBoVerticalRemarks = this.boRemarksText;
        this.alert.success('BO/RO/Vertical Remarks saved successfully');
      } else {
        this.isResolutionSaved = true;
        this.grievance.gdResolution = this.resolutionText;
        this.alert.success('Resolution saved successfully');
      }
      this.cdr.markForCheck();
    },
    error: () => {
      this.alert.error('Unable to save');
    }
  });
}

onSubmit(): void {
  if (!this.isClosureDateValid) {
    this.alert.warning('Please enter a valid Closure Date that is not in the future');
    return;
  }

  if (!this.grievanceSrNo) {
    this.alert.warning('Grievance serial number is missing');
    return;
  }

  const payload = this.buildPayload(this.submitStatus);

  this.loader.show();

  this.grievanceService.updateGrievance(payload, this.grievanceSrNo).pipe(
    finalize(() => this.loader.hide())
  ).subscribe({
    next: () => {
      this.alert.success('Grievance updated successfully');
      this.dialogRef.close({ action: 'submit', role: this.role });
    },
    error: () => {
      this.alert.error('Unable to update grievance');
    }
  });
}

onSendBack(): void {
  if (!this.grievanceSrNo) {
    this.alert.warning('Grievance serial number is missing');
    return;
  }

  const payload = this.buildPayload(this.sendBackStatus);

  this.loader.show();

  this.grievanceService.updateGrievance(payload, this.grievanceSrNo).pipe(
    finalize(() => this.loader.hide())
  ).subscribe({
    next: () => {
      this.alert.success('Grievance sent back successfully');
      this.dialogRef.close({ action: 'sendBack', role: this.role });
    },
    error: () => {
      this.alert.error('Unable to send back grievance');
    }
  });
}

onDeleteDuplicate(): void {
    if (!this.grievanceSrNo) return;

    this.alert.confirm(
      'Are you sure you want to delete this duplicate complaint?',
      'Delete Duplicate',
      'OK',
      'Cancel',
      'warning'
    ).then(confirmed => {
      if (!confirmed) return;

      this.loader.show();
      this.grievanceService.deleteGrievance(this.grievanceSrNo).pipe(
        finalize(() => this.loader.hide())
      ).subscribe({
        next: () => {
          this.alert.success('Duplicate complaint deleted successfully');
          this.dialogRef.close({ action: 'deleted' });
        },
        error: () => {
          this.alert.error('Unable to delete grievance');
        }
      });
    });
  }

downloadFile(file: any): void {
  this.grievanceService.downloadGrievancefile(file?.gfSno).subscribe({
    next: (response: HttpResponse<Blob>) => {
      const blob = response.body as Blob;
      const srNo = file?.gfSrNo || this.grievanceSrNo || '';
      const fileName = `FILE_${srNo}_${file?.gfSno || ''}`;
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    },
    error: () => {
      this.alert.error('Download failed');
    }
  });
}

viewFile(file: any): void {
  this.grievanceService.downloadGrievancefile(file?.gfSno).subscribe({
    next: (response: HttpResponse<Blob>) => {
      const blob = response.body as Blob;
      const url = window.URL.createObjectURL(blob);
      window.open(url, '_blank');
      setTimeout(() => window.URL.revokeObjectURL(url), 60000);
    },
    error: () => {
      this.alert.error('Unable to view file');
    }
  });
}

getAttachmentFileName(file: any): string {
  const srNo = file?.gfSrNo || this.grievanceSrNo || '';
  const fileNo = file?.gfSno || '';
  return `FILE_${srNo}_${fileNo}`;
}

onResolutionUploaded(): void {
  if (this.grievanceSrNo) {
    this.grievanceService.getGrievancefiles(this.grievanceSrNo).subscribe({
      next: (response: any) => {
        const files = Array.isArray(response) ? response : [];
        this.resolutionFiles = files.filter((f: any) => f.gfFileType === 'R');
      }
    });
  }
}
}







