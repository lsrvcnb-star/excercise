import axios from "axios";
import { getJwtToken } from "./utils/JwtUtil";

let API_URL = process.env.REACT_APP_API_ENDPOINT;

// if (location.hostname === "localhost" || location.hostname === "127.0.0.1") {
//     API_URL = Api.getIfvLocalBaseUrl();
// } else {
//     API_URL = Api.getIfvUatBaseUrl();
// }

const onSubmitOfMettingDetails = (data) => {
  const token = getJwtToken();
  return axios.post(
    API_URL + "api/sanction-minutes/saveSanctionMinutes",
    data,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getSanctionMinutesById = (mtCode) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "api/sanction-minutes/getSanctionMinutesById/" + mtCode,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getCount = (committeeCode) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/sanction-minutes/getCount/" + committeeCode, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getMemberDetails = (cmtCode) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/masters/getHrmsEmpDetails/" + cmtCode, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllMeetingDetails = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/sanction-minutes/getAll", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getLoiAndMinsCount = (ofrType, ofrEmpId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "api/sanction-minutes/status-counts/" + ofrType + "/" + ofrEmpId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const deleteMeetingDetails = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "api/sanction-minutes-dtl/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const uploadAgendaFile = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/filerepo/save", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteAgendaFile = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/filerepo/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getFileDetails = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/filerepo/findBySancMinDetailId/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const circulateAgenda = (id) => {
  const token = getJwtToken();
  return axios.post(
    API_URL + "api/sanction-minutes-dtl/circulateAgenda/" + id,
    null,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const circulateAllInOne = (id) => {
  const token = getJwtToken();
  return axios.post(
    API_URL + "api/sanction-minutes/circulateAllInOne/" + id,
    null,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const saveOrUpdateMinutes = (data) => {
  const token = getJwtToken();
  return axios.post(
    API_URL + "api/sanction-minutes-dtl/update/" + data.sancDtlCode,
    data,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getSanctionMinutesDtlById = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/sanction-minutes-dtl/get/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllAlcoAppsByStatus = (status) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "ifv/alcoproposal/getAllOnAppStatusAndAlCode/" + status,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const updateSanctionMinutes = (data) => {
  const token = getJwtToken();
  return axios.post(
    API_URL + "api/sanction-minutes/update/" + data.sanctDetailCode,
    data,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getAllAlcoMinutesDataBySancDtlCode = (id) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "api/sanction-minutes-dtl/getAllAlcoMinutesDataBySancDtlCode/" +
      id,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getAllOnAppId = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/alcodata/getAllOnAppId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveAllAlcoMinutesData = (data) => {
  const token = getJwtToken();
  return axios.post(
    API_URL + "api/sanction-minutes-dtl/saveAllAlcoMinutesData",
    data,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const saveAllAppraisalMinutesData = (data) => {
  const token = getJwtToken();
  return axios.post(
    API_URL + "api/sanction-minutes-dtl/saveAllAppraisalMinutesData",
    data,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getAllAppraisalMinutesDataBySancDtlCode = (id) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "api/sanction-minutes-dtl/getAllAppraisalMinutesDataBySancDtlCode/" +
      id,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getAllSchemesOnAppId = (appId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "api/propschema-details/getAllSchemesOnAppId/" + appId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getAllAppraisalsOnAgendaIdAndAppId = (agendaId, appId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "api/sanction-minutes-dtl/getAllAppraisalMinutesDataByAgendaIdAndAppId/" +
      agendaId +
      "/" +
      appId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getAllAlcoOnAgendaIdAndAppId = (agendaId, appId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "api/sanction-minutes-dtl/getAllAlcoMinutesDataByAgendaIdAndAppId/" +
      agendaId +
      "/" +
      appId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const approveSanction = (mtCode, userId) => {
  const token = getJwtToken();
  return axios.post(
    API_URL + "api/sanction-minutes/approveSanction/" + mtCode + "/" + userId,
    null,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const checkMeetingNoExistence = (meetingNo, committeeCode) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "api/sanction-minutes/checkMeetingNoExistence/" +
      meetingNo +
      "/" +
      committeeCode,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const generateFlashMinutesReport = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/pdfreport/flashMinutes/" + id, {
    headers: { Authorization: `Bearer ${token}` },
    // responseType: 'arraybuffer'
  });
};

const generateLOIReport = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/pdfreport/generateLOIReport/" + id, {
    headers: { Authorization: `Bearer ${token}` },
    // responseType: 'arraybuffer'
  });
};

const findBySancId = (sancId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "loi-details/findBySancId/" + sancId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const findLoIBySancIdAndSancDetailCode = (sancId, sancDtlCode, minuteId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "loi-details/findLoIBySancIdAndSancDetailCode/" +
      sancId +
      "/" +
      sancDtlCode +
      "/" +
      minuteId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const saveLoiDetails = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "loi-details/save", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const loadCheckers = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/users/findAllCheckers", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllAppraisalMinutesDataBySancId = (id) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "api/sanction-minutes/getAllAppraisalMinutesDataBySancId/" + id,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const findBankDetailsByAppNumber = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcapp/findBankDetailsByAppNumber/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const findByloiId = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/loi-termconditions/findByloiId/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getSanctionTermConditionsByAppNoAndPrId = (appNo, prId, loiId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "api/sanctiontermconditions/findByAppNumberAndPrId/" +
      appNo +
      "/" +
      prId +
      "/" +
      loiId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const saveLoiSanctionTermsConditions = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "api/loi-termconditions/save", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAppraisalDateByAppId = (appNo, minuteId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "api/sanction-minutes/getAppraisalDateByAppId/" +
      appNo +
      "/" +
      minuteId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const forwardMinutes = (id, stage, user) => {
  const token = getJwtToken();
  return axios.post(
    API_URL +
      "api/sanction-minutes/forwardMinutes/" +
      id +
      "/" +
      stage +
      "/" +
      user,
    null,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const rejectMinutes = (id) => {
  const token = getJwtToken();
  return axios.post(
    API_URL + "api/sanction-minutes/rejectMinutes/" + id,
    null,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const findByLoiId = (loiId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/filerepo/findByLoiId/" + loiId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getDocumentByMinuteId = (id) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "api/sanction-minutes/getDocumentByMinuteId/" + id,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getMinuteIdByLoiIdAndPrId = (loiId, prId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "api/sanction-minutes/getMinuteIdByLoiIdAndPrId/" +
      loiId +
      "/" +
      prId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const findByloiIdAndPrId = (loiId, prId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "api/loi-termconditions/findByloiIdAndPrId/" + loiId + "/" + prId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const generateFinalMinutesWord = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/pdfreport/final-minutes-word/" + id, {
    headers: { Authorization: `Bearer ${token}` },
    responseType: "blob",
  });
};

const fetchLoIDetails = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv-proposals-loi/findAllLoIByIfvId/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveLoiDetailsForProposals = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv-proposals-loi/save", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const generateLOIReportForAppraisal = (id) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "api/pdfreport/generateLOIReportForAppraisal/" + id,
    {
      headers: { Authorization: `Bearer ${token}` },
      // responseType: 'arraybuffer'
    }
  );
};

const getLoIDocumentByPropLoIId = (id) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "ifv-proposals-loi/getLoIDocumentByPropLoIId/" + id,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const fetchLoIDetailsByPropId = (id) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "ifv-proposals-loi/fetchLoIDetailsByPropId/" + id,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const fwdOrRejMinutes = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "api/sanction-minutes/fwdOrRejMinutes", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getMinutesFwdRejDetails = (id) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "api/sanction-minutes/getMinutesFwdRejDetails/" + id,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getUserListForRejectingMinutes = (id) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "api/sanction-minutes/getUserListForRejectingMinutes/" + id,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const generateLoIReportWord = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/pdfreport/loi-report-word/" + id, {
    headers: { Authorization: `Bearer ${token}` },
    responseType: "blob",
  });
};

const dmsLogin = (credentials) => {
  const token = getJwtToken();
  const params = new URLSearchParams();
  params.append("username", credentials.username);
  params.append("password", credentials.password);
  //if (credentials.folderId) params.append('folderId', credentials.folderId);
  if (credentials.localAddress)
    params.append("localAddress", credentials.localAddress);
  return axios({
    method: "POST",
    url: `${API_URL}loi-details/dmsLogin?${params.toString()}`,
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
};

const getIFVNo = (data) => {
  const token = getJwtToken();
  return axios({
    method: "POST",
    url: `${API_URL}loi-details/getLoINoFromDMS`,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    data: data,
  });
};

const submitSignedLoI = (file, request) => {
  const token = getJwtToken();
  const formData = new FormData();

  formData.append("file", file);

  formData.append(
    "request",
    new Blob([JSON.stringify(request)], { type: "application/json" })
  );

  return axios.post(`${API_URL}loi-details/submitSignedLoI`, formData, {
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "multipart/form-data",
    },
  });
};

const getSignedLoIDocument = (loiDetailsId) => {
  const token = getJwtToken();

  return axios({
    method: "GET",
    url: `${API_URL}loi-details/signed-loi/${loiDetailsId}`,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
  });
};

const downloadSignedLoIDocument = (filePath) => {

    const token = getJwtToken();

    return axios({
        method: "POST",
        url: `${API_URL}loi-details/downloadSignedLoI`,
        headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
        },
        responseType: "blob",
        data: {
            filePath: filePath,
            action: "DOWNLOAD"
        }
    });
};

const fetchSignedLoiSummary = (data) => {

    const token = getJwtToken();

    return axios({
        method: "POST",
        url: `${API_URL}loi-details/signed-loi-summary`,
        headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
        },
        data: data,
    }).then((response) => response.data);
};

const MinutesService = {
  onSubmitOfMettingDetails,
  getSanctionMinutesById,
  getCount,
  getMemberDetails,
  getAllMeetingDetails,
  deleteMeetingDetails,
  uploadAgendaFile,
  deleteAgendaFile,
  getFileDetails,
  circulateAgenda,
  circulateAllInOne,
  saveOrUpdateMinutes,
  getSanctionMinutesDtlById,
  getAllAlcoAppsByStatus,
  updateSanctionMinutes,
  getAllAlcoMinutesDataBySancDtlCode,
  getAllOnAppId,
  saveAllAlcoMinutesData,
  saveAllAppraisalMinutesData,
  getAllAppraisalMinutesDataBySancDtlCode,
  getAllSchemesOnAppId,
  getAllAppraisalsOnAgendaIdAndAppId,
  getAllAlcoOnAgendaIdAndAppId,
  approveSanction,
  checkMeetingNoExistence,
  generateFlashMinutesReport,
  generateLOIReport,
  findBySancId,
  saveLoiDetails,
  loadCheckers,
  findLoIBySancIdAndSancDetailCode,
  getAllAppraisalMinutesDataBySancId,
  findBankDetailsByAppNumber,
  findByloiId,
  getSanctionTermConditionsByAppNoAndPrId,
  saveLoiSanctionTermsConditions,
  getAppraisalDateByAppId,
  forwardMinutes,
  rejectMinutes,
  getLoiAndMinsCount,
  findByLoiId,
  getDocumentByMinuteId,
  getMinuteIdByLoiIdAndPrId,
  findByloiIdAndPrId,
  generateFinalMinutesWord,
  fetchLoIDetails,
  saveLoiDetailsForProposals,
  generateLOIReportForAppraisal,
  getLoIDocumentByPropLoIId,
  fetchLoIDetailsByPropId,
  fwdOrRejMinutes,
  getMinutesFwdRejDetails,
  getUserListForRejectingMinutes,
  generateLoIReportWord,
  dmsLogin,
  getIFVNo,
  submitSignedLoI,
  getSignedLoIDocument,
  downloadSignedLoIDocument,
  fetchSignedLoiSummary
};

export default MinutesService;
