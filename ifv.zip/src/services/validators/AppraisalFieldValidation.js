import CommonUtil from "services/utils/CommonUtil";

const AppraisalFieldValidation = {
    numberValidation: {
        required: "Field is required",
        validate: (value) =>{
            if (value < 0) return "Negative numbers are not allowed";
            //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
            if (!/^\d{1,8}(\.\d{1,2})?$/.test(value)) return "Enter up to 8 digits with up to 2 decimals";
            return true;
        },
        onBlur: (e) => CommonUtil.setTwoDecimalPlaces(e)
    },

    textAreaValidation: {
        required: "Field is required",
       
        maxLength: {
            value: 4000,
            message: "The maximum length of the field is 4000"
        },
    },
}
export default AppraisalFieldValidation;