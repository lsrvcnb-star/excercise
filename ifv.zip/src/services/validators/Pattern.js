
const validateHtmlTags = () => {
    return /<[^>]*>/i;
}

const sanitizeInput = (e) => {
    let value = e.target.value;
    value = value.replace(/[<>{}\[\]]/g, '');
    e.target.value = value;
}

const sanitizeValue = (value = '') => {
  if (typeof value !== 'string') return value;
  return value.replace(/[<>{}\[\]]/g, '');
};

const Pattern = {
    validateHtmlTags,
    sanitizeInput,
    sanitizeValue
}
export default Pattern;