import axios from "axios";
import { getJwtToken } from "services/utils/JwtUtil";

const API_BASE_URL = process.env.REACT_APP_API_ENDPOINT;

class bankRefinanceApi {
  /**
   * Fetch Refinance Applications
   */
  static async fetchBankApplications(payload) {
    const response = await axios.post(
      `${API_BASE_URL}bank/refinance/fetchBankApplications`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;
  }

  /**
   * Fetch Complete Application Details
   */
  static async fetchBankApplicationByAppRefId(appRefId) {
    const response = await axios.get(
      `${API_BASE_URL}bank/refinance/fetchBankApplicationByAppRefId`,
      {
        params: { appRefId },
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );

    return response.data;
  }

  /**
   * Download Application / Signatory File
   */
  static async downloadFileByPath(filePath, fileName) {
    try {
      const response = await axios.post(
        `${API_BASE_URL}bank/refinance/downloadFileByPath`,
        {
          filePath,
          action: "download",
        },
        {
          headers: {
            Authorization: `Bearer ${getJwtToken()}`,
            "Content-Type": "application/json",
          },
          responseType: "blob",
        }
      );

      if (!response.data || response.data.size <= 10) {
        return {
          success: false,
          message: "File is not available.",
        };
      }

      if (
        response.data.type &&
        response.data.type.includes("application/json")
      ) {
        const text = await response.data.text();

        let message = "Unable to download file.";

        try {
          const json = JSON.parse(text);
          message = json.message || message;
        } catch (e) {}

        return {
          success: false,
          message,
        };
      }

      const url = URL.createObjectURL(response.data);

      const link = document.createElement("a");
      link.href = url;
      link.download = fileName;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      URL.revokeObjectURL(url);

      return {
        success: true,
      };
    } catch (err) {
      return {
        success: false,
        message: err?.response?.data?.message || "Failed to download file.",
      };
    }
  }

  static async returnBankApplication(payload) {
    const response = await axios.post(
      `${API_BASE_URL}bank/refinance/returnBankApplication`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
          "Content-Type": "application/json",
        },
      }
    );
    return response.data;
  }

  static async validateBankApplication(payload) {
    const response = await axios.post(
      `${API_BASE_URL}bank/refinance/validateBankApplication`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
          "Content-Type": "application/json",
        },
      }
    );
    return response.data;
  }

  static async fetchActiveProposalBankApps(payload) {
    const response = await axios.post(
      `${API_BASE_URL}bank/refinance/fetchActiveProposalBankApps`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;
  }

  static async fetchComplianceSummaryForAllBanks(payload) {
    const response = await axios.post(
      `${API_BASE_URL}bank/refinance/fetchComplianceSummaryForAllBanks`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;
  }

  static async acceptOrReturnCompliance(payload) {
    const response = await axios.post(
      `${API_BASE_URL}bank/refinance/acceptOrReturnCompliance`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
          "Content-Type": "application/json",
        },
      }
    );
    return response.data;
  }
}

export default bankRefinanceApi;
