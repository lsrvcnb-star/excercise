import axios from "axios";
import { getJwtToken } from "services/utils/JwtUtil";

const API_BASE_URL = process.env.REACT_APP_API_ENDPOINT;

/**
 * Fetch IFV RIMV Applications with pagination, filtering, and sorting
 */
export const fetchIfvRimvApps = async ({
  start,
  size,
  filters,
  sorting,
  globalFilter,
}) => {
  const params = new URLSearchParams({
    start: start.toString(),
    size: size.toString(),
  });

  if (filters) params.append("filters", filters);
  if (sorting) params.append("sorting", sorting);
  if (globalFilter) params.append("globalFilter", globalFilter);

  const response = await axios.get(
    `${API_BASE_URL}rimv/fetchIfvRimvApps?${params}`,
    {
      headers: {
        Authorization: `Bearer ${getJwtToken()}`,
      },
    }
  );
  return response.data;
};

/**
 * Create a new IFV RIMV Application
 */
export const createIfvRimvApp = async (data) => {
  const requestData = {
    cifNumber: data.cifNumber,
    bankName: data.bankName,
    singleScaleRating: data.singleScaleRating,
    combinedRating: data.combinedRating,
    currentUserId: data.currentUserId,
    currentUserName: data.currentUserName,
  };

  const response = await axios.post(
    `${API_BASE_URL}rimv/saveIfvRimvApp`,
    requestData,
    {
      headers: {
        Authorization: `Bearer ${getJwtToken()}`,
        "Content-Type": "application/json",
      },
    }
  );
  return response.data;
};

/**
 * Delete an IFV RIMV Application by ID
 */
export const deleteIfvRimvApp = async (id) => {
  const response = await axios.delete(
    `${API_BASE_URL}rimv/deleteIfvRimvApp/${id}`,
    {
      headers: {
        Authorization: `Bearer ${getJwtToken()}`,
      },
    }
  );
  return response.data;
};

/**
 * Forward documents to RIMV
 */
export const forwardDocumentsToRimv = async (forwardData) => {
  const response = await axios.post(
    `${API_BASE_URL}rimv/forwardDocumentsToRimv`,
    forwardData,
    {
      headers: {
        Authorization: `Bearer ${getJwtToken()}`,
        "Content-Type": "application/json",
      },
    }
  );
  return response.data;
};

export const getCountOfRimvApps = async () => {
  const response = await axios.get(`${API_BASE_URL}rimv/getCountOfRimvApps`, {
    headers: {
      Authorization: `Bearer ${getJwtToken()}`,
    },
  });
  return response.data;
};
