import axios from "axios";
import { getJwtToken } from "./utils/JwtUtil";

let API_URL = process.env.REACT_APP_API_ENDPOINT;

const getAllBcmCif = () => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getAllBcmCifEntity', {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getAllSchemes = () => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getBcmSchemes', {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getStatesOrUT = () => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getBcmLocaltionCodes', {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getDistrictsByState = (stCode) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getDistrictsByState/' + stCode, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getCustOs = (cifNumber) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getCustOs/' + cifNumber, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getCustExpo = (cifNumber) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getCustExpo/' + cifNumber, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getPastDisbursementsOnCifNumber = (cifNumber) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getPastDisbursements/' + cifNumber, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getOSDetailsOnCifNumber = (cifNumber) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getOSDetails/' + cifNumber, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getFutureRepayDetails = (cifNumber) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getFutureRepayDetails/' + cifNumber, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getExposureLimit = (cifNumber) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getExpouserDetails/' + cifNumber, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getAllFundCode = () => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getFundCodeAndDesc', {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getAllSchemesOnFundCode = (fundCode) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getSchemesOnFundCd/' + fundCode, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getAllSanctionedProposals = () => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getAllSanctionDetails', {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getAllMemberNames = () => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getAllEmpNames', {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getMemberDetailsByName = (empName) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getEmpDetails/' + empName, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getEmpCodeAndDesc = () => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getEmpCodeAndDesc', {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getBankType = (cifNumber) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getBankType/' + cifNumber, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const findBankDetailsByCifNumber = (cifNumber) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/findBankDetailsByCifNumber/' + cifNumber, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getBenchmarkDetails = () => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getBenchmarkDetails', {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const findBankAddressByCifNumber = (cifNumber) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/ifcapp/getAddressByCifNumber/' + cifNumber, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getSanctionedProposalsCount = () => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getSanctionedProposalsCount', {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const getAllTrancheOnFundCode = (fundCode) => {
    const token = getJwtToken()
    return axios.get(API_URL + 'ifv/masters/getAllTrancheOnFundCode/' + fundCode, {
        headers: { Authorization: `Bearer ${token}` },
    })
}

const MasterService = {
    getAllBcmCif,
    getAllSchemes,
    getStatesOrUT, getDistrictsByState,
    getCustExpo,
    getCustOs,
    getPastDisbursementsOnCifNumber,
    getOSDetailsOnCifNumber,
    getFutureRepayDetails,
    getExposureLimit,
    getAllFundCode,
    getAllSchemesOnFundCode,
    getAllSanctionedProposals,
    getAllMemberNames,
    getMemberDetailsByName,
    getEmpCodeAndDesc,
    getBankType, findBankDetailsByCifNumber,
    getBenchmarkDetails,
    findBankAddressByCifNumber,
    getSanctionedProposalsCount, getAllTrancheOnFundCode
}

export default MasterService;
