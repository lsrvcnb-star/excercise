
const isMaker = (user) => {
    return user.ofrType === '9092'
}

const isChecker = (user) => {
    return user.ofrType === '9093'
}

const isMakerChecker = (user) => {
    return user.ofrType === '9094'
}

const isHigherAuthority = (user) => {
    return user.ofrType === '9095'
}

const isMakerConvenor = (user) => {
    return user.ofrType === '10489'
}

const isCheckerConvenor = (user) => {
    return user.ofrType === '11314'
}

const isAdminMaker = (user) => {
    return user.ofrType === '9129'
}

const isAdminChecker = (user) => {
    return user.ofrType === '9128'
}

const isChairMan = (user) => {
    return user.ofrEmpId === '053517'
}

const isBeneficiaryUser = (user) => {
    return user?.userType === 'BENEFICIARY'
}

const UserService = {
    isChecker,
    isMaker,
    isMakerConvenor,
    isHigherAuthority,
    isAdminChecker,
    isAdminMaker,
    isMakerChecker,
    isCheckerConvenor,
    isChairMan,
    isBeneficiaryUser,
}

export default UserService;