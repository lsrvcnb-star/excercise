import axios from "axios";
import { getJwtToken } from "./utils/JwtUtil";

const API_BASE_URL = process.env.REACT_APP_API_ENDPOINT;

export const getGroupNameByCif = async (cifNumber) => {
  const token = getJwtToken();
  const response = await axios.get(
    `${API_BASE_URL}ifv/masters/getGroupNameByCif/${cifNumber}`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  return response.data;
};

export const checkStatus = async (asOnDate, groupName) => {
  const token = getJwtToken();

  const response = await axios.post(
    `${API_BASE_URL}ifv/masters/getAggregateExposureStatus`,
    {
      asOnDate,
      groupName,
    },
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  return response.data;
};

export const triggerProcedure = async (payload) => {
  const token = getJwtToken();
  const response = await axios.post(
    `${API_BASE_URL}ifv/masters/triggerAggregateExposure`,
    payload,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  return response.data;
};

export const getAggregateExposureData = async (payload) => {
  const token = getJwtToken();
  const response = await axios.post(
    `${API_BASE_URL}ifv/masters/getAggregateExposureData`,
    payload,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  return response.data;
};

export const getAggregateExposureOnGroup = async (payload) => {
  const token = getJwtToken();
  const response = await axios.post(
    `${API_BASE_URL}ifv/masters/getAggregateExposureOnGroup`,
    payload,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  return response.data;
};
