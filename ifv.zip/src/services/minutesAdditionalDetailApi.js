import axios from "axios";
import { getJwtToken } from "./utils/JwtUtil";

const BASE_URL = process.env.REACT_APP_API_ENDPOINT + "minutes/additional-details";

export const getColendingLimits = async (minuteSanctionId) => {
    const res = await axios.get(
        `${BASE_URL}/getColendingLimits/${minuteSanctionId}`, {
        headers: {
            Authorization: `Bearer ${getJwtToken()}`
        }
    }
    );
    return res.data;
};

export const saveColendingLimits = async (minuteSanctionId, data) => {
    const res = await axios.post(
        `${BASE_URL}/saveColendingLimits/${minuteSanctionId}`,
        data, {
        headers: {
            Authorization: `Bearer ${getJwtToken()}`
        }
    }
    );
    return res.data;
};

export const deleteColendingLimit = async (id) => {
    const res = await axios.delete(
        `${BASE_URL}/deleteColendingLimits/${id}`, {
        headers: {
            Authorization: `Bearer ${getJwtToken()}`
        }
    }
    );
    return res.data;
};

export const getInterestResets = async (minuteSanctionId) => {
    const res = await axios.get(
        `${BASE_URL}/getInterestResets/${minuteSanctionId}`, {
        headers: {
            Authorization: `Bearer ${getJwtToken()}`
        }
    }
    );
    return res.data;
};

export const saveInterestResets = async (minuteSanctionId, data) => {
    const res = await axios.post(
        `${BASE_URL}/saveInterestResets/${minuteSanctionId}`,
        data, {
        headers: {
            Authorization: `Bearer ${getJwtToken()}`
        }
    }
    );
    return res.data;
};

export const deleteInterestReset = async (id) => {
    const res = await axios.delete(
        `${BASE_URL}/deleteInterestReset/${id}`, {
        headers: {
            Authorization: `Bearer ${getJwtToken()}`
        }
    }
    );
    return res.data;
};

export const fetchOtherItems = async (minuteSanctionId) => {
    const res = await axios.get(
        `${BASE_URL}/fetchOtherItems/${minuteSanctionId}`, {
        headers: {
            Authorization: `Bearer ${getJwtToken()}`
        }
    }
    );
    return res.data;
};

export const saveOtherItems = async (minuteSanctionId, data) => {
    const res = await axios.post(
        `${BASE_URL}/saveOtherItems/${minuteSanctionId}`,
        data, {
        headers: {
            Authorization: `Bearer ${getJwtToken()}`
        }
    }
    );
    return res.data;
};

export const deleteOtherItemsById = async (id) => {
    const res = await axios.delete(
        `${BASE_URL}/deleteOtherItemsById/${id}`, {
        headers: {
            Authorization: `Bearer ${getJwtToken()}`
        }
    }
    );
    return res.data;
};