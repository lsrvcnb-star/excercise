const CommitteeMemberType = {
    'CV': 'Convenor',
    'AC': 'Alternate Convenor',
    'MB': 'Member',
    'CM': 'Chairman'
}
export default CommitteeMemberType;