const UserType = {
    '9092': 'Maker',
    '9093': 'Checker',
   // '9094': 'Maker-Checker',
    '9095': 'High Authority',
    '10489': 'Maker-Convener',
    '11314': 'Checker-Convener',
  //  '9129': 'Admin-Maker',
    '9128': 'Admin-Checker',

}


export default UserType;