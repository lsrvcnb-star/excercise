const PrincipalRepaymentData = {
    "Monthly": "The principal would be repayable on monthly basis payable on 10th day of every month starting from the subsequent month from the date of first disbursement. The repayment schedule shall be drawn accordingly based on the date on which first disbursement is affected.",
    "Quarterly": "The principal would be repayable in quarterly installments commencing after 3 months from the date of first disbursement and due date would be 10th of the month concerned.",
    "Half-yearly": "The principal would be repayable in Half yearly installments commencing after 6 months from the date of first disbursement and due date would be 10th of the month concerned.",
    "Yearly": "",
    "Bullet": "The principal would be repayable in single bullet installment at the end of **________ months starting from the date of first disbursement."
}


export default PrincipalRepaymentData;