const Committee = {
    101: 'IFCC-CGM',
    102: 'SUB-ALCO'
}


export default Committee;