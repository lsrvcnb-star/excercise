import axios from "axios";
import { getJwtToken } from "services/utils/JwtUtil";
import CommonUtil from "./utils/CommonUtil";

const API_BASE_URL = process.env.REACT_APP_API_ENDPOINT;

class BeneficiaryApiService {
  /**
   * Fetch all beneficiaries with pagination, filters, and sorting
   */
  static async fetchBeneficiaries({
    start,
    size,
    filters,
    sorting,
    globalFilter,
  }) {
    const params = new URLSearchParams({
      start: start.toString(),
      size: size.toString(),
    });

    if (filters) params.append("filters", filters);
    if (sorting) params.append("sorting", sorting);
    if (globalFilter) params.append("globalFilter", globalFilter);

    const response = await axios.get(
      `${API_BASE_URL}beneficiary/fetchBenificiaryDetails?${params}`,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );
    return response.data;
  }

  /**
   * Fetch beneficiary documents by CIF number
   */
  static async fetchBeneficiaryDocuments({ cifNumber, start, size }) {
    const params = new URLSearchParams({
      start: start.toString(),
      size: size.toString(),
    });

    const response = await axios.get(
      `${API_BASE_URL}beneficiary/fetchBenificiaryDetailsByCifNo/${cifNumber}?${params}`,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );
    return response.data;
  }

  /**
   * Fetch loan account numbers based on CIF number
   */
  static async fetchLoanAccNoOnCif(cifNumber) {
    const response = await axios.get(
      `${API_BASE_URL}beneficiary/fetchLoanAccNoOnCif`,
      {
        params: { cifNumber },
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );
    return response.data;
  }

  // Trigger insertion (DFS forward) — only call this after validation status === 'COMPLETED'
  static async forwardBeneficiaryData(jobId) {
    try {
      const response = await axios.post(
        `${API_BASE_URL}beneficiary/forwardBeneficiaryData?jobId=${encodeURIComponent(
          jobId
        )}`,
        null,
        {
          headers: {
            Authorization: `Bearer ${getJwtToken()}`,
          },
        }
      );
      return response.data;
    } catch (error) {
      if (error.response) throw error.response.data;
      throw error;
    }
  }

  /**
   * Delete beneficiary by ID
   */
  static async deleteBeneficiary(id) {
    const response = await axios.delete(
      `${API_BASE_URL}beneficiary/deleteBenificiary/${id}`,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );
    return response.data;
  }

  /**
   * Delete document by ID
   */
  static async deleteDocument(id) {
    const response = await axios.delete(
      `${API_BASE_URL}beneficiary/deleteBenificiary/${id}`,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );
    return response.data;
  }

  /**
   * Download document by ID
   */
  static async downloadDocument(id, fileName) {
    const response = await axios.get(
      `${API_BASE_URL}beneficiary/downloadBeneficiaryDoc/${id}`,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
        responseType: "blob",
      }
    );

    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", fileName);
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  }

  static async fetchBeneficiaryDataForIfv(params) {
    const response = await axios.post(
      `${API_BASE_URL}beneficiary/fetchBeneficiaryDataFromService`,
      params,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
          "Content-Type": "application/json",
        },
      }
    );
    return response.data;
  }

  static async fetchBeneficiaryDocsByCif(params) {
    const response = await axios.post(
      `${API_BASE_URL}beneficiary/fetchBeneficiaryDocsByCif`,
      params,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
          "Content-Type": "application/json",
        },
      }
    );
    return response.data;
  }

  static async uploadBenificiaryAppDoc({ file, data }) {
    const formData = new FormData();
    formData.append("file", file);
    formData.append(
      "request",
      new Blob([JSON.stringify(data)], { type: "application/json" })
    );

    const response = await axios.post(
      `${API_BASE_URL}beneficiary/uploadBenificiaryAppDoc`,
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );
    return response.data;
  }

  static async downloadAppDocument(filePath, fileName) {
    try {
      const token = getJwtToken();

      const response = await axios.post(
        `${API_BASE_URL}beneficiary/downloadBeneficiaryAppDoc`,
        {
          filePath,
          action: "download",
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          responseType: "blob",
        }
      );

      // Invalid response
      if (!response.data || response.data.size <= 10) {
        return {
          success: false,
          message: "File is not available.",
        };
      }

      // Backend error returned as JSON blob
      if (
        response.data.type &&
        response.data.type.includes("application/json")
      ) {
        const text = await response.data.text();

        let message = "Unable to download file.";

        try {
          const json = JSON.parse(text);
          message = json.message || message;
        } catch (e) {}

        return {
          success: false,
          message,
        };
      }

      const url = URL.createObjectURL(response.data);

      const link = document.createElement("a");

      link.href = url;
      link.download = fileName;

      document.body.appendChild(link);

      link.click();

      document.body.removeChild(link);

      URL.revokeObjectURL(url);

      return {
        success: true,
      };
    } catch (err) {
      return {
        success: false,
        message: err?.response?.data?.message || "Failed to download file.",
      };
    }
  }

  static async deleteAppDocument(id) {
    const encId = await CommonUtil.encryptPassword(id);
    const response = await axios.delete(
      `${API_BASE_URL}beneficiary/deleteBenificiaryApp/${encId}`,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );
    return response.data;
  }

  static async processingStatus(jobId) {
    const response = await axios.get(
      `${API_BASE_URL}beneficiary/processingStatus/${jobId}`,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );
    return response.data;
  }

  static async fetchDisbDateOnAccNo(accNo) {
    const response = await axios.get(
      `${API_BASE_URL}beneficiary/fetchDisbDateOnAccNo`,
      {
        params: { accNo },
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );
    return response.data;
  }

  static async getIfvVerticals() {
    const response = await axios.get(
      `${API_BASE_URL}beneficiary/getIfvVerticals`,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );
    return response.data;
  }

  static async fetchCustomersOnVertical(vertical) {
    const response = await axios.get(
      `${API_BASE_URL}beneficiary/fetchCustomersOnVertical?vertical=${vertical}`,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );
    return response.data;
  }

  //Upload and validate beneficiary doc
  static async uploadAndValidateBeneficiary({ file, data }) {
    const formData = new FormData();
    formData.append("file", file);
    formData.append(
      "request",
      new Blob([JSON.stringify(data)], { type: "application/json" })
    );

    try {
      const response = await axios.post(
        `${API_BASE_URL}beneficiary/uploadAndValidateBeneficiary`,
        formData,
        {
          headers: { Authorization: `Bearer ${getJwtToken()}` },
          timeout: 120000, // 2 min — 50MB uploads need headroom over the default
        }
      );
      return response.data;
    } catch (error) {
      if (error.response) throw error.response.data;
      throw error;
    }
  }

  // Get Beneficiary Upload Validation Status
  static async getBeneficiaryUploadStatus(jobId) {
    try {
      const response = await axios.get(
        `${API_BASE_URL}beneficiary/getBeneficiaryUploadStatus/${jobId}`,
        {
          headers: {
            Authorization: `Bearer ${getJwtToken()}`,
          },
        }
      );

      return response.data;
    } catch (error) {
      if (error.response) {
        throw error.response.data;
      }
      throw error;
    }
  }

  // Get Beneficiary Validation Errors
  static async getValidationErrors(jobId) {
    try {
      const response = await axios.get(
        `${API_BASE_URL}beneficiary/getValidationErrors/${jobId}`,
        {
          headers: {
            Authorization: `Bearer ${getJwtToken()}`,
          },
        }
      );

      return response.data;
    } catch (error) {
      if (error.response) {
        throw error.response.data;
      }
      throw error;
    }
  }

  /**
   * Fetch Beneficiary Uploads For All Banks
   */
  static async fetchBeneficiaryUploadsForAllBanks(payload) {
    const response = await axios.post(
      `${API_BASE_URL}beneficiary/fetchBeneficiaryUploadsForAllBanks`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;
  }

  /**
   * Submit Beneficiary To DFS
   */
  static async submitToDFS(id) {
    const response = await axios.post(
      `${API_BASE_URL}beneficiary/submitBeneficiaryToDfs/${id}`,
      {},
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
        },
      }
    );

    return response.data;
  }

  static async returnForwardedApplication(payload) {
    const response = await axios.post(
      `${API_BASE_URL}beneficiary/returnForwardedApplication`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;
  }

  static async fetchDfsSubmittedBeneficiaries(payload) {
    const response = await axios.post(
      `${API_BASE_URL}beneficiary/fetchDfsSubmittedBeneficiaries`,
      payload,
      {
        headers: {
          Authorization: `Bearer ${getJwtToken()}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;
  }
}

export default BeneficiaryApiService;
