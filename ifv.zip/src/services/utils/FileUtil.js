const downloadFile = (fileByteArray, fileName, fileType) => {

  const binaryData = atob(fileByteArray);
  // Convert binary data to Uint8Array
  const uint8Array = new Uint8Array(binaryData.length);
  for (let i = 0; i < binaryData.length; i++) {
    uint8Array[i] = binaryData.charCodeAt(i);
  }
  // Create a Blob from the Uint8Array
  const blob = new Blob([uint8Array], { type: fileType });

  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
};

const viewFile = (fileByteArray, fileName, fileType) => {

  const binaryData = atob(fileByteArray);
  // Convert binary data to Uint8Array
  const uint8Array = new Uint8Array(binaryData.length);
  for (let i = 0; i < binaryData.length; i++) {
    uint8Array[i] = binaryData.charCodeAt(i);
  }
  // Create a Blob from the Uint8Array
  const blob = new Blob([uint8Array], { type: fileType });

  const fileURL = URL.createObjectURL(blob);
  window.open(fileURL, '_blank')

};

const viewPdfFile = (fileByteArray) => {

  const fileDataArray = new Uint8Array(fileByteArray);

  // Create a Blob from the Uint8Array
  const blob = new Blob([fileDataArray], { type: "application/pdf" });

  const fileURL = URL.createObjectURL(blob);
  window.open(fileURL, '_blank')

};

const downloadPdfFile = (fileByteArray, fileName) => {

  const fileDataArray = new Uint8Array(fileByteArray);
  // Create a Blob from the Uint8Array
  const blob = new Blob([fileDataArray], { type: "application/pdf" });

  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
};

const downloadWordFile = (response) => {
  // Get filename from content-disposition header
  const contentDisposition = response.headers['content-disposition'];
  const filename = contentDisposition
    ? contentDisposition.split('filename=')[1].replace(/['"]/g, '')
    : 'generated-document.docx';
  // Create blob and download
  const blob = new Blob([response.data], {
    type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  });
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}

const FileUtil = {
  downloadFile,
  viewFile,
  viewPdfFile,
  downloadPdfFile,
  downloadWordFile
}

export default FileUtil;