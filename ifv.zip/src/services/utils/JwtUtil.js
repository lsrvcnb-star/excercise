export function getJwtToken() {
    return sessionStorage.getItem("jwtToken");
}