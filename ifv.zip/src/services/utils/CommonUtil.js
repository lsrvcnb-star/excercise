
const setTwoDecimalPlaces = (e) => {
    if (isNaN(e.target.value)) {
        throw new Error('Invalid input. Please provide a valid number.');
    }
    e.target.value = Math.round(e.target.value * 100) / 100;
}

const isEmpty = (val) => {
    return (val === undefined || val == null || val.length <= 0) ? true : false;
}

const isValidNumber = (val) => {
    return (val !== undefined && val != null && val !== '' && !isNaN(val)) ? true : false;
}

const roundToTwoDecimals = (val) => {
    if (!isValidNumber(val)) {
        return 0;
    }
    return Math.round(val * 100) / 100;
}

const formatDate = (date) => {
    const dateObject = new Date(date);
    // Format the date and time
    const formattedDate = `${dateObject.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })}`;
    return formattedDate;
}

const validateDate = (value) => {
    const formattedDate = formatDate(value)
    const pattern = /^\d{2}\/\d{2}\/\d{4}$/;
    if (!formattedDate.match(pattern)) {
        return "Please enter date in dd/MM/yyyy format";
    }
    return true;
};

const numberToWords = (val) => {
    var convert = require('decimal-number-to-words');
    return convert.toWords(val);
}

const indianRupeesInWords = (value) => {
    if (!isValidNumber(value)) {
        return " ";
    }
    var fraction = Math.round(frac(value) * 100);
    var f_text = "";

    if (fraction > 0) {
        f_text = "AND " + convert_number(fraction) + " PAISE";
    }

    return convert_number(value) + " RUPEE " + f_text + " ONLY";
}

function frac(f) {
    return f % 1;
}

function convert_number(number) {

    var Gn = Math.floor(number / 10000000);  /* Crore */
    number -= Gn * 10000000;
    var kn = Math.floor(number / 100000);     /* lakhs */
    number -= kn * 100000;
    var Hn = Math.floor(number / 1000);      /* thousand */
    number -= Hn * 1000;
    var Dn = Math.floor(number / 100);       /* Tens (deca) */
    number = number % 100;               /* Ones */
    var tn = Math.floor(number / 10);
    var one = Math.floor(number % 10);
    var res = "";

    if (Gn > 0) {
        res += (convert_number(Gn) + " CRORE");
    }
    if (kn > 0) {
        res += (((res == "") ? "" : " ") +
            convert_number(kn) + " LAKH");
    }
    if (Hn > 0) {
        res += (((res == "") ? "" : " ") +
            convert_number(Hn) + " THOUSAND");
    }

    if (Dn) {
        res += (((res == "") ? "" : " ") +
            convert_number(Dn) + " HUNDRED");
    }


    var ones = Array("", "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX", "SEVEN", "EIGHT", "NINE", "TEN", "ELEVEN", "TWELVE", "THIRTEEN", "FOURTEEN", "FIFTEEN", "SIXTEEN", "SEVENTEEN", "EIGHTEEN", "NINETEEN");
    var tens = Array("", "", "TWENTY", "THIRTY", "FOURTY", "FIFTY", "SIXTY", "SEVENTY", "EIGHTY", "NINETY");

    if (tn > 0 || one > 0) {
        if (!(res == "")) {
            res += " AND ";
        }
        if (tn < 2) {
            res += ones[tn * 10 + one];
        }
        else {

            res += tens[tn];
            if (one > 0) {
                res += ("-" + ones[one]);
            }
        }
    }

    if (res == "") {
        res = "ZERO";
    }
    return res;
}

// function numberToWordsInCrores(num) {
//     if (num === 0) return "Zero";
//     let parts = num.toString().split(".");
//     let integerPart = parseInt(parts[0], 10);
//     let fractionalPart = parts[1] ? parseInt(parts[1], 10) : 0;

//     var convert = require('decimal-number-to-words');
//     var integerPartWords = convert.toWords(integerPart);
//     var words = 'Rupees ' + capitalizeFirstLetter(integerPartWords) + ' Crore';

//     if (fractionalPart > 0) {
//         if (parts[1].length == 1) {
//             fractionalPart = fractionalPart * 10;
//         }
//         var decimalPartWords = convert.toWords(fractionalPart);
//         words += ' and ' + capitalizeFirstLetter(decimalPartWords) + ' Lakh';
//     }

//     return words.trim() + " Only";
// }

function numberToWordsInCrores(num) {
    if (num === 0) return "Zero";
    let parts = num.toString().split(".");
    let integerPart = parseInt(parts[0], 10);
    let fractionalPart = parts[1] ? parts[1] : "00";
    const convert = require('decimal-number-to-words');
    const integerPartWords = convert.toWords(integerPart);
    let words;
    if (isEmpty(integerPartWords)) {
        words = 'Rupees ';
    } else {
        words = 'Rupees ' + capitalizeFirstLetter(integerPartWords) + ' Crore';
    }

    if (fractionalPart > 0) {
        let fractionWords = '';
        fractionalPart = fractionalPart.padEnd(6, '0'); // Ensure there are at least 6 digits
        // First two digits as Lakh
        let lakhs = parseInt(fractionalPart.slice(0, 2), 10);
        if (lakhs > 0) {
            fractionWords += capitalizeFirstLetter(convert.toWords(lakhs)) + ' Lakh ';
        }
        // Next two digits as Thousand
        let thousands = parseInt(fractionalPart.slice(2, 4), 10);
        if (thousands > 0) {
            fractionWords += capitalizeFirstLetter(convert.toWords(thousands)) + ' Thousand ';
        }
        // Fifth digit as Hundred
        let hundreds = parseInt(fractionalPart.charAt(4), 10);
        if (hundreds > 0) {
            fractionWords += capitalizeFirstLetter(convert.toWords(hundreds)) + ' Hundred ';
        }
        // Last two digits (as tens and units combined)
        let tensAndUnits = fractionalPart.slice(5);
        if (tensAndUnits.length === 1) {
            // If it's a single digit, treat it as a ten (e.g., 7 becomes 70)
            tensAndUnits = parseInt(tensAndUnits, 10) * 10;
        } else {
            tensAndUnits = parseInt(tensAndUnits, 10);
        }
        if (tensAndUnits > 0) {
            fractionWords += capitalizeFirstLetter(convert.toWords(tensAndUnits));
        }
        if (fractionWords.trim() !== '') {
            words += ' ' + fractionWords.trim();
        }
    }
    return words.trim() + " Only";
}

function capitalizeFirstLetter(sentence) {
    return sentence.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
}

const extractTextUpToWord = (text) => {
    const wordToFind = 'FUND';
    const index = text.indexOf(wordToFind);
    if (index !== -1) {
        return text.substring(0, index).trim();
    }
    return text;
};





const encryptPassword = async (password) => {
    try {
        // Convert Base64 key to ArrayBuffer
        const base64Key = 'pPz5z1m8KVf+9Gvgq5R5FA==';
        const keyData = atob(base64Key);
        const keyArray = new Uint8Array(keyData.length);
        for (let i = 0; i < keyData.length; i++) {
            keyArray[i] = keyData.charCodeAt(i);
        }
        // Import the key
        const key = await window.crypto.subtle.importKey(
            'raw',
            keyArray,
            { name: 'AES-GCM' },
            false,
            ['encrypt']
        );
        // Generate random IV (12 bytes for GCM)
        const iv = window.crypto.getRandomValues(new Uint8Array(12));
        // Encrypt the data
        const encodedPassword = new TextEncoder().encode(password);
        const encryptedData = await window.crypto.subtle.encrypt(
            {
                name: 'AES-GCM',
                iv: iv,
                tagLength: 128 // 16 bytes authentication tag
            },
            key,
            encodedPassword
        );
        // Combine IV and encrypted data
        const combined = new Uint8Array(iv.length + new Uint8Array(encryptedData).length);
        combined.set(iv);
        combined.set(new Uint8Array(encryptedData), iv.length);
        // Convert to Base64
        return btoa(String.fromCharCode.apply(null, combined));
    } catch (error) {
        console.error('Encryption failed:', error);
        throw new Error('Failed to encrypt password');
    }
};

const hasDecimals = (number) => {
    const numStr = number.toString();
    if (numStr.includes('.')) {
        const decimalPart = numStr.split('.')[1];
        return decimalPart.split('').some(digit => digit !== '0');
    }
    return false;
}

const formatAmount = (num) => {
    const number = parseFloat(num);
    if (isNaN(number)) {
        return "Invalid number";
    }
    if (number % 1 === 0) {
        return number.toString();
    }
    const numStr = number.toString();
    const decimalPart = numStr.split('.')[1];
    if (decimalPart.length === 1) {
        return number.toFixed(2);
    } else {
        return parseFloat(number.toString()).toString();
    }
}

function convertToIndianRupees(crores) {
    const rupees = crores * 10000000;
    return rupees.toLocaleString('en-IN');
}

function dynamicTotal(total) {
    const roundedTotal = Math.round((total + Number.EPSILON) * 1000000) / 1000000;
    const roundedTotalStr = roundedTotal.toString();
    if (roundedTotalStr.includes('.') && roundedTotalStr.split('.')[1].length === 1) {
        return roundedTotal.toFixed(2);
    }
    return roundedTotal;
}

const handleNumericInput = (e) => {
    // Prevent input of negative numbers and scientific notation
    if (e.key === '-' || e.key === 'e' || e.key === 'E') {
        e.preventDefault();
    }
};

const CommonUtil = {
    setTwoDecimalPlaces,
    isEmpty,
    isValidNumber,
    formatDate,
    numberToWords,
    roundToTwoDecimals,
    indianRupeesInWords,
    validateDate,
    numberToWordsInCrores,
    extractTextUpToWord,
    encryptPassword,
    hasDecimals, formatAmount, convertToIndianRupees, dynamicTotal,
    handleNumericInput
}

export default CommonUtil;