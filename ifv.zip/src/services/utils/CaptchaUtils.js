export const generateCaptchaImage = (text, width = 200, height = 50) => {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
   
    // Background
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, width, height);
   
    // Text
    ctx.font = 'bold 30px Arial';
    ctx.fillStyle = 'black';
    const textMetrics = ctx.measureText(text);
    const x = (width - textMetrics.width) / 2;
    const y = height / 2 + 10;
    ctx.fillText(text, x, y);
   
    // Noise (dots)
    ctx.fillStyle = 'gray';
    for (let i = 0; i < 50; i++) {
      const nx = Math.random() * width;
      const ny = Math.random() * height;
      ctx.beginPath();
      ctx.arc(nx, ny, 1, 0, 2 * Math.PI);
      ctx.fill();
    }
   
    // Cross lines
    ctx.strokeStyle = 'red';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(width, height);
    ctx.moveTo(0, height);
    ctx.lineTo(width, 0);
    ctx.stroke();
   
    return canvas.toDataURL();
  };