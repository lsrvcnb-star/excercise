import axios from "axios";
import { getJwtToken } from "./utils/JwtUtil";

let API_URL = process.env.REACT_APP_API_ENDPOINT;

const ssoIfvLogin = (username) => {
  return axios.post(
    API_URL + "auth/ssoIfvLogin",
    null,
    {
      params: {
        username: username,
      },
    },
    { withCredentials: true }
  );
};

const ifvLogin = (requestBody) => {
  return axios.post(API_URL + "auth/ifvLogin", requestBody);
};

const getAllIfvApps = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcapp/getAll", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getCaptcha = () => {
  // const token = getJwtToken()
  return axios.get(API_URL + "auth/getCaptcha", {
    //  headers: { Authorization: `Bearer ${token}` },
  });
};

const getIfvAppById = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcapp/get/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveIfvApp = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcapp/save", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const updateIfvApp = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcapp/update/" + data.ifvId, data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getKeyProductsByIfvId = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifckyc/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getChiefBoardByIfvId = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcchboard/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAreaOfGeographicalByIfvId = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/geographical-area/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getKeyInvestorsByIfvId = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcinvestor/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveKeyProducts = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifckyc/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveChiefFunctionalityBoard = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcchboard/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveAreaOfOperationGeographical = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/geographical-area/saveCommonDTO", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveKeyInvestors = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcinvestor/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getEligibilityByIfvId = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcelig/getByIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveEligibility = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcelig/save", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const updateEligibility = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcelig/update/" + data.ecId, data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getFinancialHighlightsByIfvId = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifchighlights/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveFinancialHlts = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifchighlights/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllPastDisbursement = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcpastdis/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const savePastDisbursement = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcpastdis/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllOutstandings = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifccOustanding/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveAllOutstandings = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifccOustanding/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllRepayment = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcrepayment/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveAllRepayment = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcrepayment/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getCommonData = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifccmmon/getByIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveCommonData = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifccmmon/save", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getSchema = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcsche/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveSchema = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcsche/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getPrincipal = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcprin/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const savePrincipal = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcprin/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getMajorTermsAndConditionData = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifvtermcondata/getByIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveTermsAndConditionData = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifvtermcondata/save", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getinstitutional = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/instit/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveInstitutional = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/instit/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

// const submitLogin = (username, password) => {
//     const response = axios.post(API_URL + 'auth/authenticate', null, {
//         params: {
//             username: username,
//             password: password
//         }
//     })
//     if (response.data.jwttoken) {
//         sessionStorage.removeItem("jwtToken")
//         sessionStorage.setItem("jwtToken", response.data.jwttoken)
//     }
//     return response.data
// }

const getCurrentUser = () => {
  return JSON.parse(sessionStorage.getItem("user"));
};

const generateReport = (ifvId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/pdfreport/apraisalMerged/" + ifvId, {
    headers: { Authorization: `Bearer ${token}` },
    //   responseType: 'arraybuffer'
  });
};

const ifvLogout = () => {
  sessionStorage.removeItem("jwtToken");
  sessionStorage.removeItem("user");
  return true;
};

const lockDocument = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcapp/lockDocument", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getTblFwdDetail = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/modulefwd/getByIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllTblFwdDetail = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/modulefwd/getAll", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const validateapp = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcapp/validateapp/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllOnIfvIdOnST = (appId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "ifv/geographical-area/getAllOnIfvIdOnST/" + appId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getAllOnIfvIdOnCT = (appId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "ifv/geographical-area/getAllOnIfvIdOnCT/" + appId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const saveParticulars = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/geographical-area/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getRatingRepo = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/rating/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveRatingRepo = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/rating/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getBoardOfDirectors = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/bdprofile/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveBoardOfDirectors = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/bdprofile/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllIfvAppsOnUserType = (userType, ofrCode) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "ifv/ifcapp/getAllOnUserType/" + userType + "/" + ofrCode,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const unlockDocument = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcapp/unlockDocument", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const confirmDocument = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcapp/confirmDocument", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const approveDocument = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcapp/approveDocument", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllOnMstParticulars = (mstParticulars) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "ifv/masterrepo/getAllOnMstParticulars/" + mstParticulars,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getAlcoProposal = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/alcoproposal/getAll", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveAlcoProposal = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/alcoproposal/save", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const updateAlcoProposal = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/alcoproposal/update/" + data.alCode, data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllAlcoData = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/alcodata/getAll", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveAllAlcoData = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/alcodata/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllBenchMarkRepo = (bankType) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/benchmark/getAllOnBankType/" + bankType, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveAllBenchMarkRepo = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/benchmark/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllBanks = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcapp/getAllBanks", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllIfvAppsOnStatus = (status) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcapp/getAllIfvAppsOnStatus/" + status, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllAlcoDataOnAlCode = (alCode) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/alcodata/getAllOnAlCode/" + alCode, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllBenchMarkRepoOnAlCodeAndBankType = (alCode, bankType) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "ifv/benchmark/getAllOnAlCodeAndBankType/" +
      alCode +
      "/" +
      bankType,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getAlcoProposalById = (alCode) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/alcoproposal/get/" + alCode, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getTblFwdDetailByAlCode = (alCode) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/modulefwd/getByAlCode/" + alCode, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteKyc = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/ifckyc/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteChiefFuncBoard = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/ifcchboard/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteAeStates = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/geographical-area/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteAeParticulars = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/geographical-area/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteOtherKeyInvestors = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/ifcinvestor/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteSchema = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/ifcsche/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteRepaymentTerms = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/ifcrepayment/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteRatingDetails = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/rating/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteProfileBOD = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/bdprofile/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteInstitutional = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/instit/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const generateAlcoReport = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/pdfreport/subCommALCO/" + id, {
    headers: { Authorization: `Bearer ${token}` },
    //responseType: 'arraybuffer'
  });
};

const updateDocument = (data, status) => {
  const token = getJwtToken();
  return axios.post(
    API_URL + "ifv/alcoproposal/updateDocument/" + status,
    data,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getAlcoProposalsOnUserType = (userType) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "ifv/alcoproposal/getAlcoProposalsOnUserType/" + userType,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getAllAlcoAppsByStatus = (status) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "ifv/alcoproposal/getAllOnAppStatusAndAlCode/" + status,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getIfvAppsReportData = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcapp/getIfvAppsReportData", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAlcoReportData = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/alcoproposal/getAlcoReportData", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteScheme = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "api/propschema-details/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getCollEfficiency = (appId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "api/collection-efficiency/getAllOnIfvId/" + appId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const saveCollEfficiency = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "api/collection-efficiency/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllSchemesOnIfvId = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/propschema-details/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const generateMinutesReport = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/pdfreport/finalMinutes/" + id, {
    headers: { Authorization: `Bearer ${token}` },
    // responseType: 'arraybuffer'
  });
};

const deleteAlcoData = (name) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/alcodata/delete/" + name, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getRestructuredAssets = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/restructured-assets/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveRestructuredAssets = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "api/restructured-assets/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllProposedSchemes = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/propschema-details/getAll", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getSanctionTermsOnPrIdAndIfvId = (ifvId, prId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "api/sanctiontermconditions/getAllOnIfvIdAndPrId/" +
      ifvId +
      "/" +
      prId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const saveSanctionTerms = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "api/sanctiontermconditions/save", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteOtherCondition = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/masterrepo/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveAllOtherConditions = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/masterrepo/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const updateOtherConditions = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/masterrepo/update/" + data.mstCode, data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const loadCommitteeMembers = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/cmt-member/getAll", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveAllCommitteeMembers = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "api/cmt-member/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const updateMember = (data) => {
  const token = getJwtToken();
  return axios.post(
    API_URL + "api/cmt-member/update/" + data.cmtMemberCode,
    data,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const saveCommitteeMember = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "api/cmt-member/save", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteCommitteeMember = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/cmt-member/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getAllIfvUsers = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/users/getAll", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveIfvUser = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "api/users/saveUser", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const updateIfvUser = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "api/users/update/" + data.ofrCode, data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveOrUpdateAuditComment = (ifvId, auditComment) => {
  const token = getJwtToken();
  return axios.post(
    API_URL +
      "ifv/ifccmmon/saveOrUpdateAuditComment/" +
      ifvId +
      "/" +
      auditComment,
    null,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getAllPoaSignatureCards = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/poa-signature/getAllGroupByCifnumber", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const savePoaSignatureCards = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/poa-signature/savePoaSignature", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getPoaSignatureCardsOnCifNumber = (cifNo) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/poa-signature/getAllByCifNumber/" + cifNo, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteFile = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/poa-signature/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const viewFile = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/poa-signature/get/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const updatePoaSignatureCards = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/poa-signature/updatePoaSignature", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const downloadusermanual = (module) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcapp/downloadusermanual/" + module, {
    headers: { Authorization: `Bearer ${token}` },
    //  responseType: 'arraybuffer'
  });
};

const findByFileIfvIdAndFileModule = (ifvId, fileModule) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "ifv/filerepo/findByFileIfvIdAndFileModule/" +
      ifvId +
      "/" +
      fileModule,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const deleteAnnexureIIFile = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/filerepo/deleteByFileCode/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const findAllByOfrType = (ofrType) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/users/findAllByOfrType/" + ofrType, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const handleBenchMarkADelete = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/benchmark/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getCheckerListForForwarding = (ifvId, ofrCode) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "api/users/getCheckerListForForwarding/" + ifvId + "/" + ofrCode,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const getStatusOfListing = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "api/status-listing/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveStatusOfListing = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "api/status-listing/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getCheckerListForSendBack = (ifvId, ofrCode) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "api/users/getCheckerListForSendBack/" + ifvId + "/" + ofrCode,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const revertApprovedDocument = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcapp/revertApprovedDocument", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getTopBorrowersByIfvId = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ucb-borrowers/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveTopBorrowers = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ucb-borrowers/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteTopBorrowers = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ucb-borrowers/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getUcbFincByIfvId = (appId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "ucb-financial-performance/getAllOnIfvId/" + appId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const saveUcbFinc = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ucb-financial-performance/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getUcbEligibilityByIfvId = (appId) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "ucb-eligibility-criteria/getAllOnIfvId/" + appId,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const saveUcbEligibility = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ucb-eligibility-criteria/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getUcbCriteriaByIfvId = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ucb-criteria-parameter/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveUcbCriteria = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ucb-criteria-parameter/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getUcbAnnexure4 = (appId, annexureNo) => {
  const token = getJwtToken();
  return axios.get(
    API_URL +
      "ucb-annexure/getAllOnIfvIdAndAnnexureNo/" +
      appId +
      "/" +
      annexureNo,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const saveUcbAnnexure4 = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ucb-annexure/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteUcbAnnexure4 = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ucb-annexure/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getUcbBorrowersDetailByIfvId = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ucb-borrowers-details/findByIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveUcbBorrowersDetail = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ucb-borrowers-details/save", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getDisclosure = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "disclosure-divergence/getAllOnIfvId/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const saveDisclosure = (data) => {
  const token = getJwtToken();
  return axios.post(API_URL + "disclosure-divergence/saveAll", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const deleteDisc = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "disclosure-divergence/delete/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getDisclosureStatus = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifchighlights/getDisclosureStatus/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getDetailsOfEmptyData = (appId) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcapp/getDetailsOfEmptyData/" + appId, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getByCifNumber = (cifNo) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/ifcapp/getByCifNumber/" + cifNo, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const findByFileAlcoId = (id) => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv/filerepo/findByFileAlcoId/" + id, {
    headers: { Authorization: `Bearer ${token}` },
    //responseType: 'arraybuffer'
  });
};

const getStatusCountOfProposals = (userType, ofrCode) => {
  const token = getJwtToken();
  return axios.get(
    API_URL + "ifv/ifcapp/status-counts/" + userType + "/" + ofrCode,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const deleteGeographicalArea = (id) => {
  const token = getJwtToken();
  return axios.delete(
    API_URL + "ifv/geographical-area/deleteGeographicalArea/" + id,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );
};

const deleteAssistanceApplied = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/ifcapp/deleteAssistanceApplied/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const getCountOfLoIs = () => {
  const token = getJwtToken();
  return axios.get(API_URL + "ifv-proposals-loi/getCountOfLoIs", {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const beneficiaryLogin = (requestBody) => {
  return axios.post(API_URL + "beneficiary/bankLogin", requestBody);
};

const deleteAggregateExposure = (id) => {
  const token = getJwtToken();
  return axios.delete(API_URL + "ifv/ifcapp/deleteAggregateExposure/" + id, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const loadProposalData = (requestBody) => {
  const token = getJwtToken();
  return axios.post(API_URL + "ifv/ifcapp/loadProposalData", requestBody, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

const IfvAppraisalService = {
  ssoIfvLogin,
  getAllIfvApps,
  getIfvAppById,
  saveIfvApp,
  updateIfvApp,
  getKeyProductsByIfvId,
  getKeyInvestorsByIfvId,
  getAreaOfGeographicalByIfvId,
  getChiefBoardByIfvId,
  saveAreaOfOperationGeographical,
  saveChiefFunctionalityBoard,
  saveKeyInvestors,
  saveKeyProducts,
  getEligibilityByIfvId,
  saveEligibility,
  getFinancialHighlightsByIfvId,
  saveFinancialHlts,
  getAllPastDisbursement,
  savePastDisbursement,
  getAllOutstandings,
  saveAllOutstandings,
  getAllRepayment,
  saveAllRepayment,
  getCommonData,
  saveCommonData,
  getSchema,
  saveSchema,
  getPrincipal,
  savePrincipal,
  getinstitutional,
  saveInstitutional,
  getMajorTermsAndConditionData,
  saveTermsAndConditionData,
  // submitLogin,
  generateReport,
  updateEligibility,
  ifvLogin,
  ifvLogout,
  getCurrentUser,
  lockDocument,
  getTblFwdDetail,
  validateapp,
  getAllOnIfvIdOnCT,
  getAllOnIfvIdOnST,
  saveParticulars,
  getRatingRepo,
  saveRatingRepo,
  getBoardOfDirectors,
  saveBoardOfDirectors,
  getAllIfvAppsOnUserType,
  unlockDocument,
  confirmDocument,
  approveDocument,
  getAllOnMstParticulars,
  getAlcoProposal,
  getAllAlcoData,
  getAllBenchMarkRepo,
  saveAlcoProposal,
  saveAllAlcoData,
  saveAllBenchMarkRepo,
  getAllBanks,
  getAllIfvAppsOnStatus,
  getAllAlcoDataOnAlCode,
  updateAlcoProposal,
  getAllBenchMarkRepoOnAlCodeAndBankType,
  getAlcoProposalById,
  getTblFwdDetailByAlCode,
  deleteKyc,
  deleteChiefFuncBoard,
  deleteAeStates,
  deleteAeParticulars,
  deleteOtherKeyInvestors,
  deleteSchema,
  deleteRepaymentTerms,
  deleteRatingDetails,
  deleteProfileBOD,
  deleteInstitutional,
  generateAlcoReport,
  updateDocument,
  getAlcoProposalsOnUserType,
  getAllAlcoAppsByStatus,
  getIfvAppsReportData,
  getAlcoReportData,
  deleteScheme,
  getCollEfficiency,
  saveCollEfficiency,
  getAllSchemesOnIfvId,
  generateMinutesReport,
  deleteAlcoData,
  getRestructuredAssets,
  saveRestructuredAssets,
  getAllProposedSchemes,
  getSanctionTermsOnPrIdAndIfvId,
  saveSanctionTerms,
  deleteOtherCondition,
  saveAllOtherConditions,
  updateOtherConditions,
  loadCommitteeMembers,
  saveAllCommitteeMembers,
  updateMember,
  getAllIfvUsers,
  saveIfvUser,
  updateIfvUser,
  saveOrUpdateAuditComment,
  getAllPoaSignatureCards,
  savePoaSignatureCards,
  getPoaSignatureCardsOnCifNumber,
  deleteFile,
  viewFile,
  updatePoaSignatureCards,
  downloadusermanual,
  findByFileIfvIdAndFileModule,
  deleteAnnexureIIFile,
  findAllByOfrType,
  handleBenchMarkADelete,
  getCheckerListForForwarding,
  getStatusOfListing,
  saveStatusOfListing,
  getCheckerListForSendBack,
  getAllTblFwdDetail,
  revertApprovedDocument,
  getTopBorrowersByIfvId,
  saveTopBorrowers,
  deleteTopBorrowers,
  getUcbFincByIfvId,
  saveUcbFinc,
  getUcbEligibilityByIfvId,
  saveUcbEligibility,
  getUcbCriteriaByIfvId,
  saveUcbCriteria,
  getUcbAnnexure4,
  saveUcbAnnexure4,
  deleteUcbAnnexure4,
  getUcbBorrowersDetailByIfvId,
  saveUcbBorrowersDetail,
  getDisclosure,
  saveDisclosure,
  deleteDisc,
  getDisclosureStatus,
  getCaptcha,
  getDetailsOfEmptyData,
  getByCifNumber,
  findByFileAlcoId,
  getStatusCountOfProposals,
  deleteGeographicalArea,
  deleteAssistanceApplied,
  getCountOfLoIs,
  saveCommitteeMember,
  deleteCommitteeMember,
  beneficiaryLogin,
  deleteAggregateExposure,
  loadProposalData,
};

export default IfvAppraisalService;
