export class ErrorHandler {
    constructor(showMessage) {
        this.showMessage = showMessage;
    }
    handleApiError = (error, context) => {
        const errorMessage = error.response?.data?.message || error.message || error.toString();
        console.error(`${context}:`, errorMessage);
        this.showMessage(`Error occurred while ${context.toLowerCase()}`, 'error');
    };
}