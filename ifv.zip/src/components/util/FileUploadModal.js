import { Close as CloseIcon, Delete as DeleteIcon, Edit as EditIcon, PictureAsPdf as PdfIcon, Upload as UploadIcon } from '@mui/icons-material';
import { Alert, Box, Button, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Paper, Stack, Typography } from '@mui/material';
import axios from 'axios';
import { useEffect, useRef, useState } from 'react';
import IfvAppraisalService from 'services/IfvAppraisalService';
import CommonUtil from 'services/utils/CommonUtil';
import { getJwtToken } from 'services/utils/JwtUtil';

const FileUploadModal = ({ minuteId, onFileChange, status }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [document, setDocument] = useState(null);
    const [error, setError] = useState(null);
    const [uploading, setUploading] = useState(false);
    const [loading, setLoading] = useState(true);
    const [deleting, setDeleting] = useState(false);

    const fileInputRef = useRef(null);
    const [selectedFileName, setSelectedFileName] = useState('');

    useEffect(() => {
        fetchDocument();
    }, [minuteId]);

    const fetchDocument = async () => {
        try {
            setLoading(true);
            const token = getJwtToken();
            const response = await axios.get(
                `${process.env.REACT_APP_API_ENDPOINT}api/sanction-minutes/getDocumentByMinuteId/${minuteId}`,
                { headers: { Authorization: `Bearer ${token}` } }
            );
            if (!CommonUtil.isEmpty(response.data.id)) {
                setDocument(response.data);
                onFileChange(true);
            } else {
                setDocument(null);
                onFileChange(false);
            }
        } catch (error) {
            if (error.response?.status !== 404) {
                console.error('Error fetching document:', error);
                setError('Failed to fetch document. Please try again.');
            }
            setDocument(null);
        } finally {
            setLoading(false);
        }
    };

    const validateFile = (file) => {
        if (!file) return 'Please select a file';
        if (file.type !== 'application/pdf') return 'Only PDF files are allowed';
        if (file.size > 5 * 1024 * 1024) return 'File size exceeds 5MB limit';
        return null;
    };

    const handleFileChange = (event) => {
        const file = event.target.files[0];
        const validationError = validateFile(file);

        if (validationError) {
            setError(validationError);
            setSelectedFileName('');
            return;
        }

        setSelectedFileName(file.name);
        setError(null);
        onFileChange(true);
    };

    const handleUpload = async () => {
        const file = fileInputRef.current?.files[0];
        const validationError = validateFile(file);

        if (validationError) {
            setError(validationError);
            return;
        }

        setUploading(true);
        setError(null);

        try {
            const user = IfvAppraisalService.getCurrentUser();
            const formData = new FormData();
            formData.append('file', file);

            const documentRequest = {
                module: 'FLASH MINUTES',
                minuteId: minuteId,
                createdBy: user.ofrName,
                status: 'APPROVE',
                uploadedUserId: user.ofrCode
            };

            formData.append('document', new Blob([JSON.stringify(documentRequest)], { type: 'application/json' }));

            const token = getJwtToken();
            await axios.post(
                `${process.env.REACT_APP_API_ENDPOINT}api/sanction-minutes/saveOrUpdateDocument`,
                formData,
                {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            setIsModalOpen(false);
            await fetchDocument();
        } catch (err) {
            console.error(err);
            setError(err.response?.data || 'Upload failed. Please try again.');
        } finally {
            setUploading(false);
        }
    };

    const handleDelete = async () => {
        if (!document?.id) return;

        setDeleting(true);
        try {
            const token = getJwtToken();
            await axios.delete(
                `${process.env.REACT_APP_API_ENDPOINT}api/sanction-minutes/deleteDocument/${document.id}`,
                { headers: { Authorization: `Bearer ${token}` } }
            );
            setIsDeleteModalOpen(false);
            await fetchDocument();
        } catch (err) {
            console.error(err);
            setError('Failed to delete document. Please try again.');
        } finally {
            setDeleting(false);
        }
    };

    const viewDocument = async () => {
        if (!document?.id) return;
        try {
            const token = getJwtToken();
            const response = await axios.get(
                `${process.env.REACT_APP_API_ENDPOINT}api/sanction-minutes/viewDocument/${document.id}`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                    responseType: 'blob'
                }
            );
            // Create blob URL
            const blob = new Blob([response.data], { type: 'application/pdf' });
            const url = window.URL.createObjectURL(blob);
            // Open in new window
            window.open(url, '_blank');
            // Cleanup blob URL after a delay
            setTimeout(() => {
                window.URL.revokeObjectURL(url);
            }, 1000);
        } catch (error) {
            console.error('Error viewing document:', error);
            setError('Failed to view document. Please try again.');
        }
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setSelectedFileName('');
        setError(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    return (
        <Box sx={{ p: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6" sx={{ textTransform: 'none' }}>Flash Minutes Document</Typography>
                {status === 'CREATED' && <Button
                    variant="contained"
                    startIcon={document ? <EditIcon /> : <UploadIcon />}
                    onClick={() => setIsModalOpen(true)}
                    sx={{ textTransform: 'none' }}
                >
                    {document ? 'Update Document' : 'Upload Document'}
                </Button>
                }
            </Box>
            {loading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                    <CircularProgress />
                </Box>
            ) : document ? (
                <Paper elevation={1} sx={{ p: 2 }}>
                    <Stack direction="row" alignItems="center" spacing={2}>
                        <PdfIcon color="primary" />
                        <Box sx={{ flexGrow: 1 }}>
                            <Button
                                color="primary"
                                onClick={viewDocument}
                                sx={{ textTransform: 'none' }}
                            >
                                {document.documentName}
                            </Button>
                            <Typography variant="body2" color="text.secondary">
                                {new Date(document.updatedAt || document.createdAt).toLocaleDateString()}
                            </Typography>
                        </Box>
                        {status === 'CREATED' && <IconButton
                            color="error"
                            onClick={() => setIsDeleteModalOpen(true)}
                            disabled={deleting}
                        >
                            <DeleteIcon />
                        </IconButton>
                        }
                    </Stack>
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                        {document.updatedAt ?
                            `Last updated by: ${document.updatedBy}` :
                            `Created by: ${document.createdBy}`}
                    </Typography>
                </Paper>
            ) : (
                <Paper elevation={1} sx={{ p: 2 }}>
                    <Typography style={{color:'#FF4400'}}>
                        {status === 'CREATED' ? 'No document uploaded yet' : 'No document'}
                    </Typography>
                </Paper>
            )}

            {/* Upload Modal */}
            <Dialog
                open={isModalOpen}
                onClose={handleCloseModal}
                maxWidth="sm"
                fullWidth
            >
                <DialogTitle>
                    {document ? 'Update Document' : 'Upload Document'}
                    <IconButton
                        aria-label="close"
                        onClick={handleCloseModal}
                        sx={{
                            position: 'absolute',
                            right: 8,
                            top: 8
                        }}
                    >
                        <CloseIcon />
                    </IconButton>
                </DialogTitle>
                <DialogContent>
                    <Box sx={{ mt: 2 }}>
                        <Button
                            variant="outlined"
                            component="label"
                            fullWidth
                            disabled={uploading}
                        >
                            Choose PDF File
                            <input
                                type="file"
                                hidden
                                ref={fileInputRef}
                                onChange={handleFileChange}
                                accept="application/pdf"
                            />
                        </Button>
                        {selectedFileName && (
                            <Typography variant="body2" sx={{ mt: 1 }}>
                                Selected file: {selectedFileName}
                            </Typography>
                        )}
                        <Typography variant="caption" color="text.secondary" sx={{ mt: 1, display: 'block' }}>
                            Maximum file size: 5MB, Format: PDF only
                        </Typography>
                    </Box>
                    {error && (
                        <Alert severity="error" sx={{ mt: 2 }}>
                            {error}
                        </Alert>
                    )}
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseModal} disabled={uploading}>
                        Cancel
                    </Button>
                    <Button
                        onClick={handleUpload}
                        disabled={!selectedFileName || uploading}
                        variant="contained"
                        startIcon={uploading ? <CircularProgress size={20} /> : null}
                    >
                        {uploading ? 'Uploading...' : (document ? 'Update' : 'Upload')}
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Delete Confirmation Modal */}
            <Dialog
                open={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                maxWidth="sm"
                fullWidth
            >
                <DialogTitle>Confirm Delete</DialogTitle>
                <DialogContent>
                    <Typography>
                        Are you sure you want to delete this document?
                        This action cannot be undone.
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button
                        onClick={() => setIsDeleteModalOpen(false)}
                        disabled={deleting}
                    >
                        Cancel
                    </Button>
                    <Button
                        onClick={handleDelete}
                        color="error"
                        variant="contained"
                        disabled={deleting}
                        startIcon={deleting ? <CircularProgress size={20} /> : null}
                    >
                        {deleting ? 'Deleting...' : 'Delete'}
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    );
};

export default FileUploadModal;
