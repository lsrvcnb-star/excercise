import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import InfoIcon from '@mui/icons-material/Info';
import NavigateBeforeIcon from '@mui/icons-material/NavigateBefore';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import WarningIcon from '@mui/icons-material/Warning';
import { Fade, Slide, Typography } from '@mui/material';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogContent from '@mui/material/DialogContent';
import IconButton from '@mui/material/IconButton';
import { styled } from '@mui/material/styles';
import { MESSAGE_TYPES } from 'hooks/useMessageModal';
const StyledDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialog-paper': {
    borderRadius: '12px',
    padding: theme.spacing(1),
    maxWidth: '300px',
    width: '90%'
  }
}));
const MessageContainer = styled('div')(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  padding: theme.spacing(2),
  textAlign: 'center'
}));
const IconContainer = styled('div')(({ type }) => ({
  marginBottom: '12px',
  '& svg': {
    fontSize: '48px',
    color: {
      [MESSAGE_TYPES.SUCCESS]: '#4caf50',
      [MESSAGE_TYPES.ERROR]: '#f44336',
      [MESSAGE_TYPES.WARNING]: '#ff9800',
      [MESSAGE_TYPES.INFO]: '#2196f3'
    }[type]
  }
}));
const Message = styled('h5')(({ type }) => ({
  color: {
    [MESSAGE_TYPES.SUCCESS]: '#4caf50',
    [MESSAGE_TYPES.ERROR]: '#f44336',
    [MESSAGE_TYPES.WARNING]: '#ff9800',
    [MESSAGE_TYPES.INFO]: '#2196f3'
  }[type],
  fontSize: '1rem',
  marginBottom: '16px',
  fontWeight: 500,
  whiteSpace: 'pre-wrap',
  wordBreak: 'break-word'
}));
const ButtonContainer = styled('div')({
  display: 'flex',
  gap: '8px',
  alignItems: 'center',
  justifyContent: 'center',
  width: '100%'
});
const NavigationContainer = styled('div')({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  width: '100%',
  marginTop: '8px'
});
const StyledButton = styled(Button)(({ type }) => ({
  minWidth: '100px',
  borderRadius: '6px',
  textTransform: 'none',
  fontSize: '0.9rem',
  padding: '6px 16px',
  backgroundColor: {
    [MESSAGE_TYPES.SUCCESS]: '#4caf50',
    [MESSAGE_TYPES.ERROR]: '#f44336',
    [MESSAGE_TYPES.WARNING]: '#ff9800',
    [MESSAGE_TYPES.INFO]: '#2196f3'
  }[type],
  '&:hover': {
    backgroundColor: {
      [MESSAGE_TYPES.SUCCESS]: '#388e3c',
      [MESSAGE_TYPES.ERROR]: '#d32f2f',
      [MESSAGE_TYPES.WARNING]: '#f57c00',
      [MESSAGE_TYPES.INFO]: '#1976d2'
    }[type]
  }
}));
const MessageCounter = styled(Typography)({
  fontSize: '0.8rem',
  color: '#666',
  marginTop: '8px'
});
const MessageIcon = ({ type }) => {
  const icons = {
    [MESSAGE_TYPES.SUCCESS]: <CheckCircleIcon />,
    [MESSAGE_TYPES.ERROR]: <ErrorIcon />,
    [MESSAGE_TYPES.WARNING]: <WarningIcon />,
    [MESSAGE_TYPES.INFO]: <InfoIcon />
  };
  return icons[type] || icons[MESSAGE_TYPES.INFO];
};
const MessageModal = ({
  open,
  onClose,
  message = '',
  type = MESSAGE_TYPES.INFO,
  totalMessages = 1,
  currentIndex = 0,
  onNext,
  onPrev,
  hasNext,
  hasPrev
}) => {
  const handleClose = (reason) => {
    if (reason === 'backdropClick' || reason === 'escapeKeyDown') {
      return;
    }
    onClose();
  };
  return (
    <StyledDialog
      open={open}
      onClose={handleClose}
      TransitionComponent={Slide}
      TransitionProps={{ direction: 'down' }}
      disableEscapeKeyDown
    >
      <DialogContent>
        <Fade in={open}>
          <MessageContainer>
            <IconContainer type={type}>
              <MessageIcon type={type} />
            </IconContainer>
            <Message type={type}>
              {message}
            </Message>
            {totalMessages > 1 && (
              <MessageCounter>
                Message {currentIndex + 1} of {totalMessages}
              </MessageCounter>
            )}
            <NavigationContainer>
              <IconButton
                onClick={onPrev}
                disabled={!hasPrev}
                size="small"
              >
                <NavigateBeforeIcon />
              </IconButton>
              <ButtonContainer>
                <StyledButton
                  variant="contained"
                  onClick={onClose}
                  type={type}
                >
                  {totalMessages === currentIndex + 1 ? 'Close' : 'Close All'}
                </StyledButton>
              </ButtonContainer>
              <IconButton
                onClick={onNext}
                disabled={!hasNext}
                size="small"
              >
                <NavigateNextIcon />
              </IconButton>
            </NavigationContainer>
          </MessageContainer>
        </Fade>
      </DialogContent>
    </StyledDialog>
  );
};
export default MessageModal;