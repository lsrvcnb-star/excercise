import { useState } from 'react';
import { NavLink } from 'react-router-dom';
const AdminDropdown = ({ prop }) => {
  const [isOpen, setIsOpen] = useState(false);
  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };
  return (
    <li className={`nav-item dropdown ${isOpen ? 'show' : ''}`}>
      <button
        className="nav-link dropdown-toggle"
        id="navbarDropdown"
        type="button"
        aria-expanded={isOpen}
        aria-haspopup="true"
        onClick={toggleDropdown}
      >
        <i className={prop.icon} />
        <p>{prop.name}</p>
      </button>
      <div
        className={`dropdown-menu ${isOpen ? 'show' : ''}`}
        aria-labelledby="navbarDropdown"
      >
        <NavLink
          className={({ isActive }) => `dropdown-item${isActive ? ' active' : ''}`}
          to={`${prop.layout}/otherConditions`}
        >
          Manage Other Conditions
        </NavLink>
        <NavLink
          className={({ isActive }) => `dropdown-item${isActive ? ' active' : ''}`}
          to={`${prop.layout}/recommendations`}
        >
          Manage Recommendations
        </NavLink>
        <NavLink
          className={({ isActive }) => `dropdown-item${isActive ? ' active' : ''}`}
          to={`${prop.layout}/committeeMembers`}
        >
          Manage Committee Members
        </NavLink>
        <NavLink
          className={({ isActive }) => `dropdown-item${isActive ? ' active' : ''}`}
          to={`${prop.layout}/users`}
        >
          Manage Users
        </NavLink>
        <NavLink
          className={({ isActive }) => `dropdown-item${isActive ? ' active' : ''}`}
          to={`${prop.layout}/poaSignature`}
        >
          Poa/Signature Cards
        </NavLink>
      </div>
    </li>
  );
};
export default AdminDropdown;