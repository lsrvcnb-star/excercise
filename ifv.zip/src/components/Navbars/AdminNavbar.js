import { TimeoutLogic } from "components/TimeoutLogic";
import { Fragment, useCallback, useEffect, useMemo, useState } from 'react';
import { Container, Dropdown, Nav, Navbar } from "react-bootstrap";
import { useLocation, useNavigate } from "react-router-dom";
import routes from "routes.js";
import IfvAppraisalService from "services/IfvAppraisalService";
import FileUtil from "services/utils/FileUtil";
function Header() {
  const location = useLocation();
  const navigate = useNavigate();
  const user = IfvAppraisalService.getCurrentUser();
  const [date, setDate] = useState(new Date());
  const brandText = useMemo(() => {
    const currentRoute = routes.find(
      route => location.pathname.indexOf(route.layout + route.path) !== -1
    );
    return currentRoute ? currentRoute.name : "Brand";
  }, [location.pathname]);
  // Function to format the current time
  const formattedTime = useMemo(() => {
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
    const amPM = hours >= 12 ? 'PM' : 'AM';
    const formattedHours = hours % 12 || 12; // Convert hours to 12-hour format
    return `${formattedHours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')} ${amPM}`;
  }, [date]);
  // Function to handle logout
  const ifvLogout = useCallback(() => {
    if (IfvAppraisalService.ifvLogout()) {
      if (user.userType === 'BENEFICIARY') {
        navigate('/bankLogin');
      } else {
        navigate('/login');
      }
    }
  }, [navigate]);
  // Function to handle downloading the user manual
  const downloadUserManual = useCallback((module) => {
    IfvAppraisalService.downloadusermanual(module).then(
      (response) => {
        FileUtil.downloadFile(response.data.fileDataBytea, response.data.fileName, "application/pdf");
      },
      (error) => {
        const resMessage =
          error.response?.data?.message || error.message || error.toString();
        alert('Error: ' + resMessage);
      }
    );
  }, []);
  // Effect to update time every second
  useEffect(() => {
    const intTimer = setInterval(() => {
      setDate(new Date());
    }, 1000);
    return () => clearInterval(intTimer);
  }, []);
  return (
    <Fragment>
      <Navbar expand="lg" sticky="top">
        <Container fluid>
          <div className="row w-100">
            <div className="topLvl ml-2 ml-lg-0">
              <Navbar.Brand className="mr-4">{brandText}</Navbar.Brand>
              <Navbar.Toggle aria-controls="basic-navbar-nav" className="mr-2">
                <span className="navbar-toggler-bar burger-lines"></span>
                <span className="navbar-toggler-bar burger-lines"></span>
                <span className="navbar-toggler-bar burger-lines"></span>
              </Navbar.Toggle>
              <Navbar.Collapse id="basic-navbar-nav" className="clps_nav">
                {user.userType !== 'BENEFICIARY' &&
                  <Nav className="nav mr-auto" navbar>
                    <Dropdown as={Nav.Item} className="tls_drop">
                      <Dropdown.Toggle as={Nav.Link} id="dropdown-67443507" variant="default" className="m-0 hvr-icon-push">
                        <span className="ntfy"><i className="nc-icon nc-tap-01 hvr-icon"></i></span>
                        <span className="d-lg-none ml-1">Help</span>
                      </Dropdown.Toggle>
                      <Dropdown.Menu>
                        <Dropdown.Item onClick={() => downloadUserManual('USER_MANUAL')}>User Manual - Appraisal</Dropdown.Item>
                        <Dropdown.Item onClick={() => downloadUserManual('USER_MANUAL_MINUTES')}>User Manual - Minutes & LoI</Dropdown.Item>
                      </Dropdown.Menu>
                    </Dropdown>
                  </Nav>
                }
                <Nav className="ml-auto" navbar>
                  <Nav.Item>
                    <Nav.Link className="m-0">
                      <div className="wlcm">Welcome, <span><strong>{user.ofrShortName || user.userShortName || user.userName}</strong></span></div>
                      <div className="tm_zn">
                        <h6>{date.toDateString()} <span className="ses_tm">{formattedTime}</span></h6>
                      </div>
                    </Nav.Link>
                  </Nav.Item>
                  <Nav.Item>
                    <Nav.Link className="m-0 pr-0" onClick={ifvLogout}>
                      <span className="pwr"><i className="nc-icon nc-button-power"></i>
                        <span className="tls_tps">Are you sure!! You want to log out.</span>
                      </span>
                    </Nav.Link>
                  </Nav.Item>
                </Nav>
              </Navbar.Collapse>
            </div>
          </div>
          <TimeoutLogic />
        </Container>
      </Navbar>
    </Fragment>
  );
}
export default Header;