import { Container } from "react-bootstrap";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  const copyrightText = "This computer software is owned by Small Industries Development Bank of India (SIDBI).";
  return (
    <footer>
      <Container fluid>
        <nav>
          <p className="text-center">
            © {currentYear}{" "}
            <a href="http://www.sidbi.in" target="_blank" rel="noopener noreferrer">
              {copyrightText}
            </a>
          </p>
        </nav>
      </Container>
    </footer>
  );
};
export default Footer;
