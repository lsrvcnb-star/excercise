import Tab from '@mui/material/Tab';
import Tabs from '@mui/material/Tabs';
import { useNavigate } from 'react-router-dom';
const SectionNavigation = ({ activeView, showSFB, appId }) => {
    const navigate = useNavigate();
    const views = ['Proposal Info', 'Section One', 'Section Two', 'Section Three', 'Section Four', 'Section Five'];
    const filteredViews = showSFB ? views : views.filter(view => view !== 'Section One');
    const activeIndex = filteredViews.indexOf(activeView);
    const handleViewChange = (newView) => {
        const routes = {
            'Proposal Info': '/ifv/basic',
            'Section One': '/ifv/sectionOne',
            'Section Two': '/ifv/sectionTwo',
            'Section Three': '/ifv/sectionThree',
            'Section Four': '/ifv/sectionFour',
            'Section Five': '/ifv/sectionFive'
        };
        const route = routes[newView];
        if (route) {
            navigate(route, {
                state: {
                    showSFB,
                    appId
                }
            });
        }
    };
    const handleTabChange = (event, newValue) => {
        handleViewChange(filteredViews[newValue]);
    };
    return (
        <div className="pergs">
            <Tabs
                value={activeIndex}
                onChange={handleTabChange}
                variant="scrollable"
                scrollButtons="auto"
                indicatorColor="primary"
                textColor="primary"
                aria-label="section navigation tabs"
            >
                {filteredViews.map((view, index) => (
                    <Tab
                        key={index}
                        label={view}
                        wrapped
                        sx={{ fontWeight: 'bold' }}
                    />
                ))}
            </Tabs>
        </div>
    );
};
export default SectionNavigation;