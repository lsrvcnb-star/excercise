import DescriptionIcon from '@mui/icons-material/Description';
import {
    Alert,
    Box,
    Button,
    Divider,
    Grid,
    Paper,
    Snackbar,
    Typography
} from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import { useState } from 'react';
import IfvAppraisalService from 'services/IfvAppraisalService';
import CommonUtil from 'services/utils/CommonUtil';
import FileUtil from 'services/utils/FileUtil';
const ProposalHeader = ({
    bankName = '',
    appNumber = '',
    status = 'New',
    appId = '',
}) => {
    const [isLoading, setIsLoading] = useState(false);
    const [snackbar, setSnackbar] = useState({
        open: false,
        message: '',
        severity: 'success'
    });
    const labelStyle = {
        fontWeight: 500,
        fontSize: '0.875rem',
        color: 'text.secondary',
        marginRight: 1
    };
    const valueStyle = {
        fontWeight: 600,
        color: '#2c3e50',
        fontSize: '0.975rem'
    };
    const handleCloseSnackbar = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }
        setSnackbar(prev => ({ ...prev, open: false }));
    };
    const showErrorMessage = (message) => {
        setSnackbar({
            open: true,
            message: message,
            severity: 'error'
        });
    };
    const showSuccessMessage = (message) => {
        setSnackbar({
            open: true,
            message: message,
            severity: 'success'
        });
    };
    const onGenerateReport = () => {
        setIsLoading(true);
        IfvAppraisalService.generateReport(appId)
            .then((response) => {
                if (response.data && response.data != null) {
                    FileUtil.downloadFile(
                        response.data.fileDataBytea,
                        response.data.fileName,
                        "application/pdf"
                    );
                    showSuccessMessage('Report generated successfully');
                } else {
                    showErrorMessage('Invalid file: No data received');
                }
            })
            .catch((error) => {
                showErrorMessage('Error generating report!');
                console.error('Report generation error:', error);
            })
            .finally(() => {
                setIsLoading(false);
            });
    };
    return (
        <>
            <Paper
                elevation={2}
                sx={{
                    p: 1.5,
                    mb: 2,
                    borderRadius: 2,
                    maxWidth: '1000px',
                    background: 'linear-gradient(to right bottom, #FFFFFF, #fafafa)',
                    border: '1px solid #f0f0f0'
                }}
            >
                <Grid container spacing={1.5}>
                    {/* Row 1 */}
                    <Grid item xs={12} md={8}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <Typography variant="subtitle2" sx={labelStyle}>
                                Name of the Bank:
                            </Typography>
                            <Typography variant="subtitle1" sx={valueStyle}>
                                {bankName}
                            </Typography>
                        </Box>
                    </Grid>
                    <Grid item xs={12} md={4}>
                        <Box
                            display="flex"
                            justifyContent={{ xs: 'flex-start', md: 'flex-end' }}
                            alignItems="center"
                            height="100%"
                        >
                            {!CommonUtil.isEmpty(appId) && appId > 0 && (
                                <Button
                                    variant="contained"
                                    color="primary"
                                    startIcon={
                                        isLoading ? (
                                            <CircularProgress size={20} color="inherit" />
                                        ) : (
                                            <DescriptionIcon sx={{ fontSize: 18 }} />
                                        )
                                    }
                                    onClick={onGenerateReport}
                                    disabled={isLoading}
                                    size="small"
                                    sx={{
                                        textTransform: 'none',
                                        px: 2,
                                        py: 0.5,
                                        borderRadius: 1.5,
                                        boxShadow: 1,
                                        fontSize: '0.875rem',
                                        minWidth: '150px',
                                        '&:hover': {
                                            boxShadow: 2
                                        }
                                    }}
                                >
                                    {isLoading ? 'Generating...' : 'Generate Report'}
                                </Button>
                            )}
                        </Box>
                    </Grid>
                    <Grid item xs={12}>
                        <Divider sx={{ my: 0.5 }} />
                    </Grid>
                    {/* Row 2 */}
                    <Grid item xs={12} md={6}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <Typography variant="subtitle2" sx={labelStyle}>
                                App Number:
                            </Typography>
                            <Typography variant="subtitle1" sx={valueStyle}>
                                {appId > 0 ? appNumber : ''}
                            </Typography>
                        </Box>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <Typography variant="subtitle2" sx={labelStyle}>
                                Status:
                            </Typography>
                            <Typography
                                component="span"
                                sx={{
                                    display: 'inline-flex',
                                    alignItems: 'center',
                                    px: 1.5,
                                    py: 0.25,
                                    borderRadius: 1,
                                    fontSize: '0.875rem',
                                    fontWeight: 600,
                                    backgroundColor: status.toLowerCase() === 'new' ? '#4caf50' : '#1976d2',
                                    color: 'white',
                                    height: '24px'
                                }}
                            >
                                {status}
                            </Typography>
                        </Box>
                    </Grid>
                </Grid>
            </Paper>
            <Snackbar
                open={snackbar.open}
                autoHideDuration={6000}
                onClose={handleCloseSnackbar}
                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
            >
                <Alert
                    onClose={handleCloseSnackbar}
                    severity={snackbar.severity}
                    variant="filled"
                    sx={{ width: '100%' }}
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </>
    );
};
export default ProposalHeader;