import {
    Box,
    CircularProgress,
    TableCell,
    TableRow,
} from "@mui/material";
import TableContainer from "@mui/material/TableContainer";
import { styled } from "@mui/material/styles";
import Select from "react-select";
import { useEffect, useState } from "react";
import MasterService from "services/MasterService";

/* ------------------ STYLED COMPONENTS ------------------ */
export const StyledTableContainer = styled(TableContainer)(({ theme }) => ({
    marginBottom: theme.spacing(3),
    maxHeight: "600px",
    overflow: "auto",
}));

export const StyledTableCell = styled(TableCell)(({ theme }) => ({
    "&.MuiTableCell-head": {
        backgroundColor: "#6082B6",
        color: "#fff",
        fontWeight: "bold",
        padding: "12px 8px",
        fontSize: "0.875rem",
        position: "sticky",
        top: 0,
        zIndex: 10,
    },
    "&.MuiTableCell-body": {
        padding: "8px",
        fontSize: "0.875rem",
        verticalAlign: "middle",
    },
}));

export const StyledTableRow = styled(TableRow)(({ theme }) => ({
    "&:nth-of-type(odd)": {
        backgroundColor: theme.palette.action.hover,
    },
    height: "60px",
}));

export const StyledInput = styled("input")(({ theme }) => ({
    width: "100%",
    padding: "8px",
    border: "1px solid #ccc",
    borderRadius: "4px",
    fontSize: "0.875rem",
    fontFamily: "inherit",
    "&:focus": {
        outline: "none",
        borderColor: theme.palette.primary.main,
        boxShadow: `0 0 0 2px ${theme.palette.primary.light}33`,
    },
    "&.error": {
        borderColor: "#d32f2f",
    },
}));

export const StyledTextArea = styled("textarea")(({ theme }) => ({
    width: "100%",
    padding: "8px",
    border: "1px solid #ccc",
    borderRadius: "4px",
    fontSize: "0.875rem",
    fontFamily: "inherit",
    minHeight: "60px",
    resize: "vertical",
    "&:focus": {
        outline: "none",
        borderColor: theme.palette.primary.main,
        boxShadow: `0 0 0 2px ${theme.palette.primary.light}33`,
    },
    "&.error": {
        borderColor: "#d32f2f",
    },
}));

/* ------------------ SELECT STYLES ------------------ */
export const selectStyles = {
    control: (base, state) => ({
        ...base,
        minHeight: "38px",
        fontSize: "0.875rem",
        borderColor: state.selectProps.error ? "#d32f2f" : base.borderColor,
        "&:hover": {
            borderColor: state.selectProps.error ? "#d32f2f" : base.borderColor,
        },
    }),
    menuPortal: (base) => ({
        ...base,
        zIndex: 9999,
    }),
    menu: (base) => ({
        ...base,
        fontSize: "0.875rem",
    }),
};

/* ------------------ LOADING SPINNER ------------------ */
export const LoadingSpinner = () => (
    <Box display="flex" justifyContent="center" p={3}>
        <CircularProgress />
    </Box>
);

/* ------------------ BANK SELECT CELL ------------------ */
export const BankSelectCell = ({ field, bankOptions, loadingBanks, onBankChange, error }) => {
    const selectedBank = bankOptions.find((opt) => opt.cifNumber === field.value);
    return (
        <Select
            options={bankOptions}
            isLoading={loadingBanks}
            value={selectedBank || null}
            onChange={(selected) => {
                if (selected) {
                    field.onChange(selected.cifNumber);
                    onBankChange(selected.bankName);
                } else {
                    field.onChange("");
                    onBankChange("");
                }
            }}
            styles={selectStyles}
            menuPortalTarget={document.body}
            menuPosition="fixed"
            placeholder="Select Bank..."
            isClearable
            error={error}
        />
    );
};

/* ------------------ useBankOptions HOOK ------------------ */
export const useBankOptions = (open) => {
    const [bankOptions, setBankOptions] = useState([]);
    const [loadingBanks, setLoadingBanks] = useState(false);

    const fetchBankOptions = async () => {
        try {
            setLoadingBanks(true);
            const bcmCif = await MasterService.getAllBcmCif();
            const options = bcmCif.data.map((item) => ({
                value: item.customerCode,
                label: `${item.customerLongName} >> (${item.customerCode})`,
                bankName: item.customerLongName,
                cifNumber: item.customerCode,
            }));
            setBankOptions(options);
        } catch (error) {
            console.error("Bank load failed");
        } finally {
            setLoadingBanks(false);
        }
    };

    useEffect(() => {
        if (open) {
            fetchBankOptions();
        }
    }, [open]);

    return { bankOptions, loadingBanks };
};