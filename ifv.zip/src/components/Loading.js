const Loading = () => {
  return (
    <div className="loading-screen">
      <div>
        <div className="loader"></div>
        <p> <span>Please wait... </span></p>
      </div>
    </div>
  );
};
export default Loading;