import AdminDropdown from "components/AdminDropdown";
import { useEffect, useState } from "react";
import { Nav } from "react-bootstrap";
import { NavLink, useLocation } from "react-router-dom";
import IfvAppraisalService from "services/IfvAppraisalService";
import UserService from "services/UserService";

function Sidebar({ color, image, routes }) {
  const location = useLocation();
  // Initialize all user roles state in a single object
  const [userRoles, setUserRoles] = useState({
    isMaker: false,
    isChecker: false,
    isMakerChecker: false,
    isHigherAuthority: false,
    isMakerConvenor: false,
    isCheckerConvenor: false,
    isAdminMaker: false,
    isAdminChecker: false,
    isBeneficiaryUser: false
  });

  useEffect(() => {
    const user = IfvAppraisalService.getCurrentUser();
    setUserRoles({
      isMaker: UserService.isMaker(user),
      isChecker: UserService.isChecker(user),
      isMakerChecker: UserService.isMakerChecker(user),
      isHigherAuthority: UserService.isHigherAuthority(user),
      isMakerConvenor: UserService.isMakerConvenor(user),
      isCheckerConvenor: UserService.isCheckerConvenor(user),
      isAdminMaker: UserService.isAdminMaker(user),
      isAdminChecker: UserService.isAdminChecker(user),
      isBeneficiaryUser: UserService.isBeneficiaryUser(user)
    });
  }, []);

  // Memoize route active check logic
  const isActiveRoute = (routeName) => {
    const pathMap = {
      '/ifv/basic': [
        '/ifv/sectionOne',
        '/ifv/sectionTwo',
        '/ifv/sectionThree',
        '/ifv/sectionFour',
        '/ifv/sectionFive',
        '/ifv/proposalsSummary',
        '/ifv/sanctionedSummary',
        '/ifv/generate-loi',
        '/ifv/loiSummary',
      ],
      '/ifv/minutes': ['/ifv/meeting-details', '/ifv/generateLoI'],
      '/ifv/reports': ['/ifv/proposalsReportSummary', '/ifv/loiReportSummary'],
      '/ifv/beneficiaryDashboard': ['/ifv/viewUploadedFiles', '/ifv/manageBeneficiaryDetails']
    };
    if (pathMap[routeName]?.includes(location.pathname)) {
      return "active";
    }
    return location.pathname.indexOf(routeName) > -1 ? "active" : "";
  };

  const handleNavLinkClick = (e, path) => {
    const allowedPaths = ['/dashboard', '/sanc', '/reports', '/minutes', '/admin', '/beneficiaryInfo', '/beneficiaryDashboard', '/rimvDocs'];
    if (!allowedPaths.includes(path)) {
      e.preventDefault();
    }
  };

  const renderNavLink = (prop) => {
    return (
      <NavLink
        to={prop.layout + prop.path}
        className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
        onClick={(e) => handleNavLinkClick(e, prop.path)}
      >
        <i className={prop.icon} />
        <p>{prop.name}</p>
      </NavLink>
    );
  };

  const isAccessibleRoute = (path, roles) => {
    // If user is a beneficiary, only allow beneficiaryInfo
    if (roles.isBeneficiaryUser) {
      return path === '/beneficiaryInfo';
    }

    // For non-beneficiary users, use beneficiaryDashboard
    const makerCheckerPaths = ['/basic', '/dashboard', '/minutes', '/reports', '/rimvDocs', '/beneficiaryDashboard'];
    const convenorPaths = [...makerCheckerPaths, '/sanc'];
    const adminPaths = [...convenorPaths];

    if (roles.isAdminMaker || roles.isAdminChecker) {
      return adminPaths.includes(path);
    }
    if (roles.isMakerConvenor || roles.isCheckerConvenor) {
      return convenorPaths.includes(path);
    }
    return makerCheckerPaths.includes(path);
  };

  return (
    <div className="sidebar" data-image={image} data-color={color}>
      <div className="sidebar-wrapper">
        <div className="logo d-flex align-items-center justify-content-start">
          <div className="logo-img dg_lg">
            <img src={require("assets/img/sidebar_logo.png")} alt="..." />
          </div>
        </div>
        <Nav>
          {routes.map((prop, key) => {
            if (!prop.redirect) {
              return (
                <li
                  className={prop.upgrade ? "active active-pro" : isActiveRoute(prop.layout + prop.path)}
                  key={key}
                >
                  {isAccessibleRoute(prop.path, userRoles) && renderNavLink(prop)}
                  {(userRoles.isAdminMaker || userRoles.isAdminChecker) && prop.path === '/admin' && (
                    <AdminDropdown prop={prop} />
                  )}
                </li>
              );
            }
            return null;
          })}
        </Nav>
      </div>
    </div>
  );
}

export default Sidebar;