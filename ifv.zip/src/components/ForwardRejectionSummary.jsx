import {
    ArrowForward,
    Check,
    Clear,
    Create
} from '@mui/icons-material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {
    Accordion,
    AccordionDetails,
    AccordionSummary,
    Avatar,
    Box,
    Chip,
    CircularProgress,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Typography
} from '@mui/material';
import { format } from 'date-fns';
import { useState } from 'react';
import MinutesService from '../services/MinutesService'; // Your existing service
const ForwardRejectionSummary = ({ mtCode }) => {
    const [fwdRejSummary, setFwdRejSummary] = useState([]);
    const [loading, setLoading] = useState(false);
    const [expanded, setExpanded] = useState(false);
    const [dataFetched, setDataFetched] = useState(false);
    // Helper function to format dates
    const formatDateTime = (dateTime) => {
        if (!dateTime) return "-";
        return format(new Date(dateTime), "MMM dd, yyyy HH:mm");
    };
    // Helper function to get action color
    const getActionColor = (action) => {
        if (!action) return 'default';
        if (action.includes('Originator')) return 'info';
        if (action.includes('Accept and Forward')) return 'primary';
        if (action.includes('Reject')) return 'error';
        if (action.includes('Approve')) return 'success';
        return 'default';
    };
    // Helper function to get action icon
    const getActionIcon = (action) => {
        if (!action) return null;
        if (action.includes('Originator')) return <Create fontSize="small" />;
        if (action.includes('Accept and Forward')) return <ArrowForward fontSize="small" />;
        if (action.includes('Reject')) return <Clear fontSize="small" />;
        if (action.includes('Approve')) return <Check fontSize="small" />;
        return null;
    };
    const handleChange = (event, isExpanded) => {
        setExpanded(isExpanded);
        // Only fetch data if expanding and we haven't fetched it before
        if (isExpanded && !dataFetched) {
            getMinutesFwdRejDetails(mtCode);
        }
    };
    const getMinutesFwdRejDetails = (mtCode) => {
        setLoading(true);
        MinutesService.getMinutesFwdRejDetails(mtCode).then(
            (response) => {
                setFwdRejSummary(response.data);
                setLoading(false);
                setDataFetched(true);
            },
            (error) => {
                setLoading(false);
                console.error('Error loading forwarding details:', error);
                // Your error handling logic
            }
        );
    };
    return (
        <Accordion expanded={expanded} onChange={handleChange}>
            <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="document-history-content"
                id="document-history-header"
            >
                <Typography variant="subtitle1" sx={{ textTransform: 'none' }}>Minutes Forward / Reject History</Typography>
            </AccordionSummary>
            <AccordionDetails>
                {loading ? (
                    <Box display="flex" justifyContent="center" p={2}>
                        <CircularProgress size={24} />
                    </Box>
                ) : fwdRejSummary.length === 0 ? (
                    <Typography variant="body2" style={{color:'#FF4400'}}>
                        No activity history available
                    </Typography>
                ) : (
                    <TableContainer component={Paper} variant="outlined">
                        <Table size="small">
                            <TableHead>
                                <TableRow>
                                    <TableCell>User</TableCell>
                                    <TableCell>Action</TableCell>
                                    <TableCell>Date & Time</TableCell>
                                    <TableCell>Comments</TableCell>
                                    <TableCell>Forwarded To</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {fwdRejSummary.map((item, index) => (
                                    <TableRow key={index} hover>
                                        <TableCell>
                                            <Box display="flex" alignItems="center">
                                                <Avatar
                                                    sx={{ width: 28, height: 28, mr: 1, bgcolor: 'primary.main' }}
                                                >
                                                    {item.currentUserName?.charAt(0)}
                                                </Avatar>
                                                <Box>
                                                    <Typography variant="body2" component="div">
                                                        {item.currentUserName}
                                                    </Typography>
                                                    <Typography variant="caption" color="textSecondary">
                                                        {item.currentUserDesignation}
                                                    </Typography>
                                                </Box>
                                            </Box>
                                        </TableCell>
                                        <TableCell>
                                            <Chip
                                                icon={getActionIcon(item.currentUserAction)}
                                                label={item.currentUserAction || "Unknown"}
                                                size="small"
                                                color={getActionColor(item.currentUserAction)}
                                                variant="outlined"
                                            />
                                        </TableCell>
                                        <TableCell>
                                            <Typography variant="body2">
                                                {formatDateTime(item.dateTimeOfAction)}
                                            </Typography>
                                            <Typography variant="caption" color="textSecondary">
                                                Received: {formatDateTime(item.dateTimeOfReceipt)}
                                            </Typography>
                                        </TableCell>
                                        <TableCell>
                                            <Typography variant="body2">
                                                {item.currentUserComment || "-"}
                                            </Typography>
                                        </TableCell>
                                        <TableCell>
                                            {item.forwardedUserName ? (
                                                <Box>
                                                    <Typography variant="body2">
                                                        {item.forwardedUserName}
                                                    </Typography>
                                                    <Typography variant="caption" color="textSecondary">
                                                        {item.forwardedUserDesignation}
                                                    </Typography>
                                                </Box>
                                            ) : (
                                                "-"
                                            )}
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                )}
            </AccordionDetails>
        </Accordion>
    );
};
export default ForwardRejectionSummary;