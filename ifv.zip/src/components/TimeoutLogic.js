import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import IfvAppraisalService from "services/IfvAppraisalService";
import { TimeoutWarningModal } from "./TimeoutWarningModal";
import { addEventListeners, removeEventListeners } from './util/eventListenerUtil';

export const TimeoutLogic = () => {
  const [isWarningModalOpen, setWarningModalOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const createTimeout1 = () => setTimeout(() => {
      setWarningModalOpen(true);
    }, 15 * 60 * 1000)

    const createTimeout2 = () => setTimeout(() => {
      if (IfvAppraisalService.ifvLogout()) {
        navigate('/login');
      } else {
        alert('Something went wrong!')
      }
    }, 2 * 60 * 1000)

    const listener = () => {
      if (!isWarningModalOpen) {
        clearTimeout(timeout)
        timeout = createTimeout1();
      }
    }

    // Initialization
    let timeout = isWarningModalOpen ? createTimeout2() : createTimeout1()
    addEventListeners(listener);

    // Cleanup
    return () => {
      removeEventListeners(listener);
      clearTimeout(timeout);
    }
  }, [isWarningModalOpen, navigate])
  return (
    <div>
      {isWarningModalOpen && (
        <TimeoutWarningModal
          isOpen={isWarningModalOpen}
          onRequestClose={() => setWarningModalOpen(false)}
        />
      )
      }
    </div>
  )
}