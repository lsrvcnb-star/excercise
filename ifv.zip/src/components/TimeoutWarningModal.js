import {
    Modal
} from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import IfvAppraisalService from "services/IfvAppraisalService";

export const TimeoutWarningModal = ({ isOpen, onRequestClose }) => {
    const navigate = useNavigate();
    const onLogOffCall = () => {
        if (IfvAppraisalService.ifvLogout()) {
            navigate('/login');
        } else {
            alert('Something went wrong!')
        }
    }

    return (
        <div>
            <Modal show={isOpen}>
                <Modal.Header>
                    <Modal.Title>Session Timeout</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div>You're being timed out due to inactivity. Please choose to stay signed in or to logoff. Otherwise, you will be logged off automatically.</div>
                </Modal.Body>
                <Modal.Footer>
                    <button className="btn btnPrev" onClick={onLogOffCall}>Log off</button>&nbsp;&nbsp;
                    <button className="btn btnSave" onClick={onRequestClose}>Stay Logged In</button>
                </Modal.Footer>
            </Modal>
        </div>
    );
}
