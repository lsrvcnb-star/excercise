import { ErrorHandler } from 'components/util/ErrorHandler';
import { useCallback } from 'react';
export const useErrorHandler = (showMessage) => {
    const handleApiError = useCallback((error, context) => {
        const errorHandler = new ErrorHandler(showMessage);
        errorHandler.handleApiError(error, context);
    }, [showMessage]);
    return { handleApiError };
};