import { useEffect, useRef, useState } from "react";
import {
  checkStatus,
  getAggregateExposureOnGroup,
  triggerProcedure
} from "services/aggregateExposureApi";

const POLL_INTERVAL = 8000;

export const formatDate = (date) => {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

export const useAggregateExposure = (
  cifNumber,
  asOnDate,
  groupName,
  trigger
) => {
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");
  const [data, setData] = useState(null);
  const [error, setError] = useState("");

  const pollingRef = useRef(null);

  const stopPolling = () => {
    if (pollingRef.current) {
      clearInterval(pollingRef.current);
      pollingRef.current = null;
    }
  };

  const fetchExposure = async (date) => {
    try {
      const res = await getAggregateExposureOnGroup({
        cifNumber,
        asOnDate: date,
        groupName,
      });
      setData(res);
    } catch {
      setError("Failed to fetch exposure data");
    } finally {
      setLoading(false);
    }
  };

  const poll = async (date) => {
    try {
      const res = await checkStatus(date, groupName);
      setStatus(res.status);

      if (res.status === "READY") {
        stopPolling();
        await fetchExposure(date);
      }

      if (res.status === "FAILED") {
        stopPolling();
        setError("Processing failed. Please try again.");
        setLoading(false);
      }
    } catch (err) {
      console.warn("Polling error, retrying...", err);
      // intentionally keep polling on transient errors
    }
  };

  const startFlow = async (date) => {
    try {
      stopPolling();
      setLoading(true);
      setData(null); // ← reset stale data on re-trigger
      setError("");
      setStatus("");

      const res = await checkStatus(date, groupName);
      setStatus(res.status);

      if (res.status === "READY") {
        await fetchExposure(date);
        return;
      }

      if (res.status === "PENDING" || res.status === "FAILED") {
        // Trigger on PENDING (never ran) or FAILED (allow re-run)
        const triggerRes = await triggerProcedure({
          cifNumber,
          asOnDate: date,
          groupName, // ← added
        });

        // Backend returned ALREADY_RUNNING — just start polling
        if (triggerRes.status === "ALREADY_READY") {
          await fetchExposure(date);
          return;
        }
      }

      // PROCESSING or just TRIGGERED — start polling
      pollingRef.current = setInterval(() => poll(date), POLL_INTERVAL);
    } catch (err) {
      console.error(err);
      setError("Initialization failed. Please try again.");
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!trigger || !cifNumber || !asOnDate || !groupName) return;
    const formatted = formatDate(asOnDate);
    startFlow(formatted);
    return () => stopPolling();
  }, [trigger]);

  return { loading, status, data, error };
};
