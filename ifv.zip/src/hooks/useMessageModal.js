import { useState, useCallback } from 'react';
export const MESSAGE_TYPES = {
  SUCCESS: 'success',
  ERROR: 'error',
  WARNING: 'warning',
  INFO: 'info'
};
export const useMessageModal = () => {
  const [messages, setMessages] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const hideMessage = useCallback(() => {
    setMessages([]);
    setCurrentIndex(0);
  }, []);
  const showMessage = useCallback((message, type = MESSAGE_TYPES.ERROR) => {
    setMessages(prev => [...prev, { message, type }]);
  }, []);
  const nextMessage = useCallback(() => {
    setCurrentIndex(prev => Math.min(prev + 1, messages.length - 1));
  }, [messages.length]);
  const prevMessage = useCallback(() => {
    setCurrentIndex(prev => Math.max(prev - 1, 0));
  }, []);
  return {
    isOpen: messages.length > 0,
    messageConfig: messages[currentIndex] || { message: '', type: MESSAGE_TYPES.INFO },
    showMessage,
    hideMessage,
    nextMessage,
    prevMessage,
    totalMessages: messages.length,
    currentIndex,
    hasNext: currentIndex < messages.length - 1,
    hasPrev: currentIndex > 0
  };
};
export default useMessageModal;