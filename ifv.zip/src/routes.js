import Dashboard from "views/Dashboard.js";
import Admin from "views/ifv/Admin";
import Alco from "views/ifv/Alco";
import AlcoReportsReactQuery from "views/ifv/AlcoReportSummary";
import BankSubmittedApplicationSummary from "views/ifv/bank-portal/BankSubmittedApplicationSummary";
import ComplianceManagement from "views/ifv/bank-portal/ComplianceManagement";
import ProposalFromBankAppSummary from "views/ifv/bank-portal/ProposalFromBankAppSummary";
import ViewSignedLoiSummary from "views/ifv/bank-portal/ViewSignedLoiSummary";
import Section from "views/ifv/BasicInfo.js";
import ViewAndManageBeneficiary from "views/ifv/beneficiary/ViewAndManageBeneficiary";
import ViewDfsSubmittedBeneficiaries from "views/ifv/beneficiary/ViewDfsSubmittedBeneficiaries";
import BeneficiaryAppSummary from "views/ifv/BeneficiaryAppSummary";
import BeneficiaryDashboard from "views/ifv/BeneficiaryDashboard";
import CmtMemberMaster from "views/ifv/CmtMemberMaster";
import GenerateLOI from "views/ifv/GenerateLOI";
import GenerateLoIFromProposal from "views/ifv/GenerateLoIFromProposal";
import IfvRimvAppsSummaryPage from "views/ifv/IfvRimvAppsSummary";
import LoiReportsSummary from "views/ifv/LoiReportSummary";
import LoISummary from "views/ifv/LoISummary";
import MeetingDetails from "views/ifv/MeetingDetails";
import Minutes from "views/ifv/Minutes";
import MinutesReportsSummary from "views/ifv/MinutesReportSummary";
import MinutesSummary from "views/ifv/MinutesSummary";
import OtherConditions from "views/ifv/OtherConditions";
import PoaSignatureCard from "views/ifv/PoaSignatureCard";
import AppraisalReportSummary from "views/ifv/ProposalsReportSummary";
import AppraisalSummaryReactQuery from "views/ifv/ReactQueryProposalSummary";
import Recommendations from "views/ifv/Recommendations";
import ReportDashboard from "views/ifv/ReportDashboard";
import SanctionedProposalsSummary from "views/ifv/SanctionedProposalsSummary";
import Section1 from "views/ifv/Section1.js";
import Section2 from "views/ifv/Section2.js";
import Section3 from "views/ifv/Section3.js";
import Section4 from "views/ifv/Section4.js";
import Section5 from "views/ifv/Section5.js";
import Users from "views/ifv/Users";

const dashboardRoutes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "fa fa-dashboard",
    component: Dashboard,
    layout: "/ifv",
  },
  {
    path: "/basic",
    name: "Proposals",
    icon: "fa fa-laptop-file",
    component: Section,
    layout: "/ifv",
  },
  {
    path: "/sectionOne",
    name: "Section 1",
    icon: "fa fa-file-signature",
    component: Section1,
    layout: "/ifv",
  },
  {
    path: "/sectionTwo",
    name: "Section 2",
    icon: "fa fa-file-signature",
    component: Section2,
    layout: "/ifv",
  },
  {
    path: "/sectionThree",
    name: "Section 3",
    icon: "fa fa-file-signature",
    component: Section3,
    layout: "/ifv",
  },
  {
    path: "/sectionFour",
    name: "Section 4",
    icon: "fa fa-file-signature",

    component: Section4,
    layout: "/ifv",
  },
  {
    path: "/sectionFive",
    name: "Section 5",
    icon: "fa fa-file-signature",
    component: Section5,
    layout: "/ifv",
  },
  {
    path: "/alco",
    name: "ALCO",
    icon: "fa fa-chart-pie",
    component: Alco,
    layout: "/ifv",
  },
  {
    path: "/minutes",
    name: "Minutes & LoI",
    icon: "fa fa-business-time ",
    component: Minutes,
    layout: "/ifv",
  },
  {
    path: "/meeting-details",
    name: "Meeting Details",
    icon: "fa fa-business-time ",
    component: MeetingDetails,
    layout: "/ifv",
  },
  {
    path: "/reports",
    name: "Reports",
    icon: "fas fa-file-pdf",
    component: ReportDashboard,
    layout: "/ifv",
  },
  {
    path: "/admin",
    name: "Admin",
    icon: "fas fa-user-tie",
    component: Admin,
    layout: "/ifv",
  },
  {
    path: "/otherConditions",
    name: "Admin / Other Conditions",
    icon: "	fas fa-user-tie",
    component: OtherConditions,
    layout: "/ifv",
  },
  {
    path: "/recommendations",
    name: "Admin / Recommendations",
    icon: "	fas fa-user-tie",
    component: Recommendations,
    layout: "/ifv",
  },
  {
    path: "/committeeMembers",
    name: "Admin / Commitee Members",
    icon: "	fas fa-user-tie",
    component: CmtMemberMaster,
    layout: "/ifv",
  },
  {
    path: "/users",
    name: "Admin / Users",
    icon: "	fas fa-user-tie",
    component: Users,
    layout: "/ifv",
  },
  {
    path: "/poaSignature",
    name: "Admin / Poa/Signature Cards",
    icon: "	fas fa-user-tie",
    component: PoaSignatureCard,
    layout: "/ifv",
  },
  {
    path: "/proposalsSummary",
    name: "Existing Proposals",
    icon: "	fas fa-user-tie",
    component: AppraisalSummaryReactQuery,
    layout: "/ifv",
  },
  {
    path: "/generateLoI",
    name: "Generate LoI",
    icon: "	fas fa-user-tie",
    component: GenerateLOI,
    layout: "/ifv",
  },
  {
    path: "/minutesSummary",
    name: "Minutes/Generate LoI",
    icon: "	fas fa-user-tie",
    component: MinutesSummary,
    layout: "/ifv",
  },
  {
    path: "/alcoReports",
    name: "Alco Reports",
    icon: "fas fa-user-tie",
    component: AlcoReportsReactQuery,
    layout: "/ifv",
  },
  {
    path: "/proposalsReportSummary",
    name: "Reports / Proposals",
    icon: "fas fa-file-pdf",
    component: AppraisalReportSummary,
    layout: "/ifv",
  },
  {
    path: "/minutesReportSummary",
    name: "Reports / Minutes",
    icon: "fas fa-file-pdf",
    component: MinutesReportsSummary,
    layout: "/ifv",
  },
  {
    path: "/loiReportSummary",
    name: "Reports / LoI",
    icon: "fas fa-file-pdf",
    component: LoiReportsSummary,
    layout: "/ifv",
  },
  {
    path: "/sanctionedSummary",
    name: "Sanctioned Proposals",
    icon: "	fas fa-user-tie",
    component: SanctionedProposalsSummary,
    layout: "/ifv",
  },
  {
    path: "/generate-loi",
    name: "Genrate LoI",
    icon: "	fas fa-user-tie",
    component: GenerateLoIFromProposal,
    layout: "/ifv",
  },
  {
    path: "/loiSummary",
    name: "LoI Summary",
    icon: "	fas fa-user-tie",
    component: LoISummary,
    layout: "/ifv",
  },
  {
    path: "/beneficiaryInfo",
    name: "Beneficiary Info",
    icon: "fas fa-user-tag",
    component: BeneficiaryAppSummary,
    layout: "/ifv",
  },
  {
    path: "/rimvDocs",
    name: "RiMV",
    icon: "fa fa-chart-pie",
    component: IfvRimvAppsSummaryPage,
    layout: "/ifv",
  },
  {
    path: "/beneficiaryDashboard",
    name: "Beneficiary Details",
    icon: "fas fa-users",
    component: BeneficiaryDashboard,
    layout: "/ifv",
  },
  {
    path: "/viewUploadedFiles",
    name: "Review Bank Submitted Beneficiaries",
    icon: "fa fa-chart-pie",
    component: ViewAndManageBeneficiary,
    layout: "/ifv",
  },
  {
    path: "/manageBeneficiaryDetails",
    name: "View Beneficiaries Submitted to DFS",
    icon: "fas fa-users",
    component: ViewDfsSubmittedBeneficiaries,
    layout: "/ifv",
  },
  {
    path: "/bankSubmittedApps",
    name: "Create Proposal from Bank Applications",
    icon: "fas fa-users",
    component: BankSubmittedApplicationSummary,
    layout: "/ifv",
  },
  {
    path: "/proposalCreatedFromBankApps",
    name: "Create Proposal from Bank Applications",
    icon: "fas fa-users",
    component: ProposalFromBankAppSummary,
    layout: "/ifv",
  },
  {
    path: "/complianceManagement",
    name: "Compliance Management",
    icon: "fas fa-users",
    component: ComplianceManagement,
    layout: "/ifv",
  },
  {
    path: "/viewSignedLoiSummary",
    name: "View Signed LoI",
    icon: "fas fa-users",
    component: ViewSignedLoiSummary,
    layout: "/ifv",
  },
];

export default dashboardRoutes;
