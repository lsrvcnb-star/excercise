
import "@fortawesome/fontawesome-free/css/all.min.css";
import "bootstrap/dist/css/bootstrap.min.css";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./assets/css/all.css";
import "./assets/css/animate.min.css";
import "./assets/css/commoncss.css";
import "./assets/css/demo.css";
import "./assets/scss/light-bootstrap-dashboard-react.scss?v=2.0.0";

import AdminLayout from "layouts/Admin.js";
import Login from "views/ifv/Login";
import NotFound from "views/ifv/NotFound";
import SSOLogin from "views/ifv/SSOLogin";

// Prevent mouse wheel from changing number input values
document.addEventListener(
  "wheel",
  function (e) {
    const target = e.target;

    if (
      target instanceof HTMLInputElement &&
      target.type === "number"
    ) {
      target.blur();
    }
  },
  true // capture phase (similar to onWheelCapture)
);

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <BrowserRouter>
    <Routes>
      {/* For the AdminLayout route */}
      <Route
        path="/ifv/*"
        element={<AdminLayout />}
      />
      {/* Login routes */}
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Login />} />
      <Route path="/SSOLogin" element={<SSOLogin />} />
      {/* <Route path="/bankLogin" element={<BeneficiaryLogin />} /> */}
      {/* 404 route */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  </BrowserRouter>
);