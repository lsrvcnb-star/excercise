import sidebarImage from "assets/img/sidebar-3.jpg";
import Footer from "components/Footer/Footer";
import AdminNavbar from "components/Navbars/AdminNavbar";
import Sidebar from "components/Sidebar/Sidebar";
import React from "react";
import { Route, Routes, useLocation } from "react-router-dom";
import routes from "routes.js";
import NotFound from "views/ifv/NotFound";

function Admin() {
  const location = useLocation();
  const mainPanel = React.useRef(null);
  const getRoutes = (routes) => {
    const validRoutes = routes
      .filter(prop => prop.layout === "/ifv")
      .map((prop, key) => (
        <Route
          path={prop.path}
          element={<prop.component />}
          key={key}
        />
      ));
    return [
      ...validRoutes,
      <Route path="*" element={<NotFound />} key="not-found" />
    ];
  };

  React.useEffect(() => {
    document.documentElement.scrollTop = 0;
    document.scrollingElement.scrollTop = 0;
    mainPanel.current.scrollTop = 0;
    if (
      window.innerWidth < 993 &&
      document.documentElement.className.indexOf("nav-open") !== -1
    ) {
      document.documentElement.classList.toggle("nav-open");
      var element = document.getElementById("bodyClick");
      element.parentNode?.removeChild(element);
    }
  }, [location]);
  return (
    <>
      <div className="wrapper">
        <Sidebar color={"black"} image={sidebarImage} routes={routes} />
        <div className="main-panel" ref={mainPanel}>
          <AdminNavbar />
          <div className="content">
            <div className="bnfcWrp">
            <Routes>{getRoutes(routes)}</Routes>
            </div>
          </div>
          <Footer />
        </div>
      </div>
    </>
  );
}

export default Admin;