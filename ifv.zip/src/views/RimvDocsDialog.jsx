import {
    Close,
    CloudUpload,
    Delete,
    Description,
    Download,
    Visibility
} from '@mui/icons-material';
import {
    Alert,
    Box,
    Button,
    Chip,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    Paper,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TextField,
    Typography
} from '@mui/material';
import axios from 'axios';
import { useEffect, useRef, useState } from 'react';
import CommonUtil from 'services/utils/CommonUtil';
import { getJwtToken } from 'services/utils/JwtUtil';
import Pattern from 'services/validators/Pattern';

const API_BASE_URL = process.env.REACT_APP_API_ENDPOINT;
const MAX_FILE_SIZE = 12 * 1024 * 1024; // 12MB in bytes

const RimvDocsDialog = ({ open, onClose, ifvId, ifvName, appNo }) => {
    const [documents, setDocuments] = useState([]);
    const [loading, setLoading] = useState(false);
    const [uploading, setUploading] = useState(false);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);
    const [selectedFile, setSelectedFile] = useState(null);
    const [deleteDialog, setDeleteDialog] = useState({ open: false, docId: null, docName: '' });
    const [isForwarded, setForwarding] = useState(false);
    const [isRimvRejected, setRimvRejected] = useState(false);
    const [isRimvApproved, setRimvApproved] = useState(false);
    const [isNew, setNew] = useState(false);
    const fileInputRef = useRef(null);
    const [fwdComment, setFwdComment] = useState("");
    const [rimvComments, setValidatorComments] = useState("");
    const [rimvFilePath, setRimvFilePath] = useState("");
    const [rimvUpdatedDateTime, setRimvUpdatedDateTime] = useState("");

    useEffect(() => {
        if (open && ifvId) {
            fetchDocuments();
        }
    }, [open, ifvId]);

    const fetchDocuments = async () => {
        setLoading(true);
        setError(null);
        const token = getJwtToken();

        try {
            const response = await axios.get(
                `${API_BASE_URL}rimv/getAllDocsOnIfvId/${ifvId}`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            const docs = response.data || [];
            const hasRejected = docs.some(doc => doc.fwdStatus === 'R');

            if (hasRejected) {
                setRimvRejected(true);
                const rejectedDoc = docs.find(doc => doc.fwdStatus === 'R');
                setValidatorComments(rejectedDoc?.rimvComments);
                setRimvFilePath(rejectedDoc?.rimvFilePath);
                setRimvUpdatedDateTime(rejectedDoc?.rimvUpdatedDateTime);
            } else {
                const status = docs[0]?.fwdStatus;
                if (CommonUtil.isEmpty(status) || status === 'N') {
                    setNew(true);
                }
                if (status === 'P') {
                    setForwarding(true);
                }
                if (status === 'A') {
                    setRimvApproved(true);
                    setValidatorComments(docs[0]?.rimvComments);
                    setRimvFilePath(docs[0]?.rimvFilePath);
                    setRimvUpdatedDateTime(docs[0]?.rimvUpdatedDateTime);
                }
            }

            setDocuments(docs);
        } catch (err) {
            setError(err.response?.data?.message || 'Failed to fetch documents');
            console.error('Error fetching documents:', err);
        } finally {
            setLoading(false);
        }
    };

    const handleViewRimvFile = async () => {
        if (!rimvFilePath) {
            setError('No RIMV file available');
            return;
        }

        try {
            const token = getJwtToken();

            const response = await axios.post(
                `${API_BASE_URL}rimv/viewRimvDocByFilePath`,
                { filePath: rimvFilePath },
                {
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${token}`
                    },
                    responseType: 'blob'
                }
            );

            const blob = new Blob([response.data], { type: 'application/pdf' });
            const url = window.URL.createObjectURL(blob);
            window.open(url, '_blank');
            setTimeout(() => {
                window.URL.revokeObjectURL(url);
            }, 1000);
        } catch (err) {
            console.error('Error viewing RIMV file:', err);
            setError('Failed to view RIMV file');
        }
    };

    const handleDownloadRimvFile = async () => {
        if (!rimvFilePath) {
            setError('No RIMV file available');
            return;
        }

        try {
            const token = getJwtToken();

            const response = await axios.post(
                `${API_BASE_URL}rimv/downloadRimvDocByFilePath`,
                { filePath: rimvFilePath },
                {
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: `Bearer ${token}`
                    },
                    responseType: 'blob'
                }
            );

            const fileName = rimvFilePath.split('\\').pop() || 'rimv-document.pdf';

            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', fileName);
            document.body.appendChild(link);
            link.click();
            link.remove();
            window.URL.revokeObjectURL(url);
        } catch (err) {
            console.error('Error downloading RIMV file:', err);
            setError('Failed to download RIMV file');
        }
    };

    const allowedMimeTypes = [
        'application/pdf',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
        'application/vnd.ms-excel', // .xls
    ];

    const allowedExtensions = ['.pdf', '.xlsx', '.xls'];

    function isAllowedFile(file) {
        const typeOk = allowedMimeTypes.includes(file.type);

        const name = (file.name || '').toLowerCase();
        const extOk = allowedExtensions.some(ext => name.endsWith(ext));

        return typeOk || extOk;
    }

    const handleFileChange = (event) => {
        const file = event.target.files[0];

        if (!file) {
            return;
        }

        if (!isAllowedFile(file)) {
            setError('Only PDF, XLSX, and XLS files are allowed');
            setSelectedFile(null);
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
            }
            return;
        }

        if (file.size > MAX_FILE_SIZE) {
            setError('File size must not exceed 12MB');
            setSelectedFile(null);
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
            }
            return;
        }

        setSelectedFile(file);
        setError(null);
    };

    const handleRemoveFile = () => {
        setSelectedFile(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };

    const handleUpload = async () => {
        if (!selectedFile) {
            setError('Please select a file to upload');
            return;
        }

        setUploading(true);
        setError(null);
        setSuccess(null);

        const formData = new FormData();
        formData.append('file', selectedFile);
        formData.append('ifvId', ifvId);
        formData.append('fwdComment', fwdComment || "");

        try {
            const token = getJwtToken();
            await axios.post(
                `${API_BASE_URL}rimv/uploadRimvDocument`,
                formData,
                {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            setSuccess('Document uploaded successfully');
            setSelectedFile(null);
            if (fileInputRef.current) {
                fileInputRef.current.value = '';
            }
            fetchDocuments();
        } catch (err) {
            setError(err.response?.data?.message || 'Failed to upload document');
            console.error('Error uploading document:', err);
        } finally {
            setUploading(false);
            setFwdComment("");
        }
    };

    const handleView = async (documentId) => {
        try {
            const token = getJwtToken();
            const response = await axios.get(
                `${API_BASE_URL}rimv/viewRimvDocument/${documentId}`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                    responseType: 'blob'
                }
            );

            const blob = new Blob([response.data], { type: 'application/pdf' });
            const url = window.URL.createObjectURL(blob);
            window.open(url, '_blank');
            setTimeout(() => {
                window.URL.revokeObjectURL(url);
            }, 1000);
        } catch (err) {
            console.error('Error viewing document:', err);
            setError('Failed to view document');
        }
    };

    const handleDownload = async (documentId, fileName) => {
        try {
            const token = getJwtToken();
            const response = await axios.get(
                `${API_BASE_URL}rimv/downloadRimvDocument/${documentId}`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    },
                    responseType: 'blob'
                }
            );

            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', fileName);
            document.body.appendChild(link);
            link.click();
            link.remove();
            window.URL.revokeObjectURL(url);
        } catch (err) {
            console.error('Error downloading document:', err);
            setError('Failed to download document');
        }
    };

    const formatDateTime = (dateTime) => {
        if (!dateTime) return 'N/A';
        return new Date(dateTime).toLocaleString('en-IN', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const formatFileSize = (bytes) => {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    };

    const handleDeleteClick = (doc) => {
        setDeleteDialog({
            open: true,
            docId: doc.id,
            docName: doc.fileName
        });
    };

    const handleDeleteConfirm = async () => {
        const { docId } = deleteDialog;
        try {
            const token = getJwtToken();
            await axios.delete(
                `${API_BASE_URL}rimv/deleteRimvDocument/${docId}`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );
            setSuccess('Document deleted successfully');
            setDeleteDialog({ open: false, docId: null, docName: '' });
            fetchDocuments();
        } catch (err) {
            setError(err.response?.data?.message || 'Failed to delete document');
            console.error('Error deleting document:', err);
            setDeleteDialog({ open: false, docId: null, docName: '' });
        }
    };

    const handleDeleteCancel = () => {
        setDeleteDialog({ open: false, docId: null, docName: '' });
    };

    const sendToRimv = async () => {
        if (!window.confirm("Are you sure you want to forward the documents to RiMV? Once forwarded, you will not be able to modify them.")) {
            return;
        }

        setUploading(true);
        try {
            const token = getJwtToken();
            const response = await axios.post(
                `${API_BASE_URL}rimv/forwardDocumentsToRimv?ifvId=${ifvId}`,
                {},
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            if (response.data === true) {
                setSuccess('Documents forwarded successfully to RiMV');
                setForwarding(true);
            } else {
                setError('Failed to forward documents');
            }
        } catch (err) {
            setError(err.response?.data?.message || 'Error forwarding documents');
            console.error('Error forwarding documents:', err);
        } finally {
            setUploading(false);
        }
    };

    const handleClose = () => {
        setSelectedFile(null);
        setError(null);
        setSuccess(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
        onClose();
    };

    return (
        <>
            <Dialog
                open={open}
                onClose={handleClose}
                maxWidth="lg"
                fullWidth
                PaperProps={{
                    sx: { minHeight: '70vh' }
                }}
            >
                <DialogTitle sx={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    borderBottom: '1px solid #E0E0E0',
                    pb: 2
                }}>
                    <Typography variant="h5" component="span">
                        RiMV Documents / {appNo} / {ifvName}
                    </Typography>
                    <IconButton onClick={handleClose} size="small">
                        <Close />
                    </IconButton>
                </DialogTitle>

                <DialogContent sx={{ pt: 3 }}>
                    {/* Status Alerts */}
                    {isNew && (
                        <Alert severity="info" sx={{ mb: 3 }}>
                            Please send the proposal and any available supporting documents (such as rating details) to RiMV for validation.
                        </Alert>
                    )}

                    {isRimvRejected && (
                        <>
                            <Paper
                                elevation={2}
                                sx={{
                                    p: 2,
                                    mb: 3,
                                    backgroundColor: '#FFF3E0',
                                    border: '1px solid #FFB74D'
                                }}
                            >
                                <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1 }}>
                                    RiMV Response Details:
                                </Typography>

                                <Box sx={{ mb: 2 }}>
                                    <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
                                        <strong>Status:</strong>
                                    </Typography>
                                    <Typography variant="body2">
                                        Rejected
                                    </Typography>
                                </Box>

                                <Box sx={{ mb: 2 }}>
                                    <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
                                        <strong>Comments:</strong>
                                    </Typography>
                                    <Typography variant="body2">
                                        {rimvComments}
                                    </Typography>
                                </Box>

                                {rimvUpdatedDateTime && (
                                    <Box sx={{ mb: 2 }}>
                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
                                            <strong>Response Date:</strong>
                                        </Typography>
                                        <Typography variant="body2">
                                            {formatDateTime(rimvUpdatedDateTime)}
                                        </Typography>
                                    </Box>
                                )}

                                {rimvFilePath && (
                                    <Box>
                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                            <strong>Validation Report:</strong>
                                        </Typography>
                                        <Stack direction="row" spacing={1}>
                                            <Button
                                                size="small"
                                                variant="outlined"
                                                startIcon={<Visibility />}
                                                onClick={handleViewRimvFile}
                                                disabled={!rimvFilePath.toLowerCase().endsWith('.pdf')}
                                            >
                                                View
                                            </Button>
                                            <Button
                                                size="small"
                                                variant="outlined"
                                                color="success"
                                                startIcon={<Download />}
                                                onClick={handleDownloadRimvFile}
                                            >
                                                Download
                                            </Button>
                                        </Stack>
                                    </Box>
                                )}
                            </Paper>
                        </>
                    )}

                    {isRimvApproved && (
                        <>
                            <Alert severity="success" sx={{ mb: 2 }}>
                                The document has been approved by RiMV
                            </Alert>
                            <Paper
                                elevation={2}
                                sx={{
                                    p: 2,
                                    mb: 3,
                                    backgroundColor: '#E8F5E9',
                                    border: '1px solid #81C784'
                                }}
                            >
                                <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1 }}>
                                    RiMV Approval Details:
                                </Typography>

                                <Box sx={{ mb: 2 }}>
                                    <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
                                        <strong>Comments:</strong>
                                    </Typography>
                                    <Typography variant="body2">
                                        {rimvComments}
                                    </Typography>
                                </Box>

                                {rimvUpdatedDateTime && (
                                    <Box sx={{ mb: 2 }}>
                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
                                            <strong>Approval Date:</strong>
                                        </Typography>
                                        <Typography variant="body2">
                                            {formatDateTime(rimvUpdatedDateTime)}
                                        </Typography>
                                    </Box>
                                )}

                                {rimvFilePath && (
                                    <Box>
                                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                                            <strong>Validation Report:</strong>
                                        </Typography>
                                        <Stack direction="row" spacing={1}>
                                            <Button
                                                size="small"
                                                variant="outlined"
                                                startIcon={<Visibility />}
                                                onClick={handleViewRimvFile}
                                                disabled={!rimvFilePath.toLowerCase().endsWith('.pdf')}
                                            >
                                                View
                                            </Button>
                                            <Button
                                                size="small"
                                                variant="outlined"
                                                color="success"
                                                startIcon={<Download />}
                                                onClick={handleDownloadRimvFile}
                                            >
                                                Download
                                            </Button>
                                        </Stack>
                                    </Box>
                                )}
                            </Paper>
                        </>
                    )}

                    {/* Upload Section */}
                    {(isNew || isRimvRejected) && (
                        <Paper elevation={2} sx={{ p: 3, mb: 3 }}>
                            <Typography variant="h6" gutterBottom sx={{ mb: 2 }}>
                                Upload New Document (If Any)
                            </Typography>

                            <Stack spacing={2}>
                                <Stack direction="row" spacing={2} alignItems="center">
                                    <Button
                                        variant="outlined"
                                        component="label"
                                        startIcon={<CloudUpload />}
                                        sx={{ minWidth: 200 }}
                                    >
                                        Choose File
                                        <input
                                            type="file"
                                            hidden
                                            ref={fileInputRef}
                                            onChange={handleFileChange}
                                            accept=".pdf, .xlsx, .xls, application/pdf, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
                                        />
                                    </Button>

                                    <Button
                                        variant="contained"
                                        disabled={uploading || !selectedFile}
                                        onClick={handleUpload}
                                        startIcon={uploading ? <CircularProgress size={20} /> : <CloudUpload />}
                                    >
                                        {uploading ? 'Uploading...' : 'Upload'}
                                    </Button>
                                </Stack>

                                <Typography variant="caption" color="text.secondary">
                                    Maximum file size: 12MB. Allowed formats: PDF, XLS, XLSX
                                </Typography>

                                {selectedFile && (
                                    <Paper
                                        variant="outlined"
                                        sx={{
                                            p: 2,
                                            backgroundColor: '#F5F5F5',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'space-between'
                                        }}
                                    >
                                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                                            <Description color="primary" />
                                            <Box>
                                                <Typography variant="body2" sx={{ fontWeight: 500 }}>
                                                    {selectedFile.name}
                                                </Typography>
                                                <Typography variant="caption" color="text.secondary">
                                                    {formatFileSize(selectedFile.size)}
                                                </Typography>
                                            </Box>
                                        </Box>
                                        <IconButton
                                            size="small"
                                            onClick={handleRemoveFile}
                                            sx={{ color: 'error.main' }}
                                        >
                                            <Close />
                                        </IconButton>
                                    </Paper>
                                )}

                                <TextField
                                    label="Remarks (Optional)"
                                    value={fwdComment}
                                    onChange={(e) => {
                                        Pattern.sanitizeInput(e);
                                        setFwdComment(e.target.value);
                                    }}
                                    fullWidth
                                    size="small"
                                    multiline
                                    rows={1}
                                    placeholder="Enter any remarks or comments"
                                    inputProps={{ maxLength: 1000 }}
                                />
                                <Typography
                                    variant="caption"
                                    color={fwdComment.length >= 1000 ? 'error' : 'textSecondary'}
                                    sx={{ textAlign: 'right', mt: 0.5 }}
                                >
                                    {fwdComment.length}/1000
                                </Typography>
                            </Stack>
                        </Paper>
                    )}

                    {/* Alert Messages */}
                    {error && (
                        <Alert severity="error" onClose={() => setError(null)} sx={{ mb: 2 }}>
                            {error}
                        </Alert>
                    )}

                    {success && (
                        <Alert severity="success" onClose={() => setSuccess(null)} sx={{ mb: 2 }}>
                            {success}
                        </Alert>
                    )}

                    {/* Documents Table */}
                    <Paper elevation={2}>
                        {loading ? (
                            <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
                                <CircularProgress />
                            </Box>
                        ) : documents.length === 0 ? (
                            <Box sx={{ p: 4, textAlign: 'center' }}>
                                <Description sx={{ fontSize: 60, color: 'text.secondary', mb: 2 }} />
                                <Typography color="text.secondary">
                                    No documents uploaded yet
                                </Typography>
                            </Box>
                        ) : (
                            <TableContainer>
                                <Table>
                                    <TableHead>
                                        <TableRow sx={{ backgroundColor: '#F5F5F5' }}>
                                            <TableCell sx={{ fontWeight: 600 }}>#</TableCell>
                                            <TableCell sx={{ fontWeight: 600 }}>File Name</TableCell>
                                            <TableCell sx={{ fontWeight: 600 }}>Module</TableCell>
                                            <TableCell sx={{ fontWeight: 600 }}>Upload Date</TableCell>
                                            <TableCell sx={{ fontWeight: 600 }}>Remarks</TableCell>
                                            <TableCell align="center" sx={{ fontWeight: 600 }}>Actions</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {documents.map((doc, index) => (
                                            <TableRow
                                                key={doc.id}
                                                sx={{ '&:hover': { backgroundColor: '#F9F9F9' } }}
                                            >
                                                <TableCell>{index + 1}</TableCell>
                                                <TableCell>
                                                    <Typography variant="body2" sx={{ fontWeight: 500 }}>
                                                        {doc.fileName}
                                                    </Typography>
                                                </TableCell>
                                                <TableCell>
                                                    <Chip
                                                        label={doc.fileSubModule}
                                                        size="small"
                                                        color="primary"
                                                        variant="outlined"
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <Typography variant="body2" color="text.secondary">
                                                        {formatDateTime(doc.uploadedDateTime)}
                                                    </Typography>
                                                </TableCell>
                                                <TableCell>
                                                    <Typography variant="body2">
                                                        {doc.fwdComments || '-'}
                                                    </Typography>
                                                </TableCell>
                                                <TableCell align="center">
                                                    <IconButton
                                                        color="primary"
                                                        onClick={() => handleView(doc.id)}
                                                        title="View Document"
                                                        size="small"
                                                        disabled={!doc.fileName.toLowerCase().endsWith('.pdf')}
                                                    >
                                                        <Visibility />
                                                    </IconButton>
                                                    <IconButton
                                                        color="success"
                                                        onClick={() => handleDownload(doc.id, doc.fileName)}
                                                        title="Download Document"
                                                        size="small"
                                                        sx={{ ml: 1 }}
                                                    >
                                                        <Download />
                                                    </IconButton>
                                                    {doc.fileSubModule !== "PROPOSAL" && (isNew || isRimvRejected) && (
                                                        <IconButton
                                                            color="error"
                                                            onClick={() => handleDeleteClick(doc)}
                                                            title="Delete Document"
                                                            size="small"
                                                            sx={{ ml: 1 }}
                                                        >
                                                            <Delete />
                                                        </IconButton>
                                                    )}
                                                </TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        )}
                    </Paper>

                    {/* Status and Instructions */}
                    {isForwarded && (
                        <Alert severity="info" sx={{ mt: 3 }}>
                            Documents have been submitted to RiMV and are currently under review.
                        </Alert>
                    )}

                    {!isRimvApproved && (
                        <Box sx={{ mt: 3, p: 2, backgroundColor: '#F5F5F5', borderRadius: 1 }}>
                            <Typography variant="body2" sx={{ mb: 1 }}>
                                <strong>Note:</strong>
                            </Typography>
                            <Typography variant="body2" sx={{ mb: 1 }}>
                                • After forwarding documents to RiMV, you can proceed to forward the proposal to the checker.
                            </Typography>
                            <Typography variant="body2">
                                • The proposal can be forwarded within the IFV DigiLending app. However, final approval will only be possible after RiMV approval.
                            </Typography>
                        </Box>
                    )}
                </DialogContent>

                <DialogActions sx={{ px: 3, py: 2, borderTop: '1px solid #E0E0E0' }}>
                    <Button onClick={handleClose} color="inherit">
                        Close
                    </Button>
                    {(isNew || isRimvRejected) && (
                        <Button
                            variant="contained"
                            onClick={sendToRimv}
                            disabled={uploading || documents.length === 0}
                            sx={{ background: '#3498DB' }}
                        >
                            Send to RiMV
                        </Button>
                    )}
                </DialogActions>
            </Dialog>

            {/* Delete Confirmation Dialog */}
            <Dialog
                open={deleteDialog.open}
                onClose={handleDeleteCancel}
                maxWidth="xs"
                fullWidth
            >
                <DialogTitle>
                    Confirm Delete
                </DialogTitle>
                <DialogContent sx={{ pt: 2 }}>
                    <Typography>
                        Are you sure you want to delete <strong>{deleteDialog.docName}</strong>? This action cannot be undone.
                    </Typography>
                </DialogContent>
                <DialogActions sx={{ px: 3, pb: 2 }}>
                    <Button onClick={handleDeleteCancel} color="inherit">
                        Cancel
                    </Button>
                    <Button
                        onClick={handleDeleteConfirm}
                        color="error"
                        variant="contained"
                        autoFocus
                    >
                        Delete
                    </Button>
                </DialogActions>
            </Dialog>
        </>
    );
};

export default RimvDocsDialog;