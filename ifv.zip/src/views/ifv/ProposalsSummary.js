import { Box, Typography } from '@mui/material';
import Loading from 'components/Loading';
import {
    MaterialReactTable,
    useMaterialReactTable,
} from 'material-react-table';
import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from "react-router-dom";
import IfvAppraisalService from 'services/IfvAppraisalService';
import UserService from 'services/UserService';
import CommonUtil from 'services/utils/CommonUtil';

const ProposalsSummary = () => {

    const [loading, setLoading] = useState(false);
    const [data, setData] = useState([])
    const navigate = useNavigate();
    const location = useLocation();
    const mode = location.state.mode

    useEffect(() => {
        const user = IfvAppraisalService.getCurrentUser();
        const isMaker = UserService.isMaker(user);
        setLoading(true)
        IfvAppraisalService.getAllIfvAppsOnUserType(user.ofrType, user.ofrCode).then(
            (response) => {
                setLoading(false)
                let finalData = response.data

                if (mode === 'All') {
                    finalData = finalData.filter((item) => item.status !== 'Approve')
                } else if (mode === 'Approve') {
                    finalData = finalData.filter((item) => item.status === 'Approve')
                }
                getAllProposedSchemes(finalData)

            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();
                setLoading(false)
                setErrorMsg('Error occured while loading existing proposals: ' + resMessage)
                setShowMsg(true)
            }
        );



    }, []);

    const getAllProposedSchemes = (finalData) => {
        setLoading(true)
        IfvAppraisalService.getAllProposedSchemes().then(
            (response) => {

                getAllCheckers(finalData, response.data)

            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                setLoading(false)
                setErrorMsg('Error occured while loading schemes Data: ' + resMessage)
                setShowMsg(true)
            }
        )
    }

    const getAllCheckers = (finalData, proposedData) => {
        setLoading(true)
        IfvAppraisalService.getAllTblFwdDetail().then(response => {

            const tblData = response.data
            const convertedMap = tblData.reduce((acc, obj) => {
                acc[obj.ifvId] = obj;
                return acc;
            }, {});

            let newData = []
            finalData.forEach(e => {

                let schemeName = ''
                proposedData.forEach(item => {

                    if (item.ifvId === e.ifvId) {
                        if (schemeName === '') {
                            schemeName = item.prSchemeName + ' / ' + item.prAmount;
                        }
                        else {
                            schemeName = schemeName + ";   " + item.prSchemeName + ' / ' + item.prAmount;
                        }
                    }
                });

                const tblObj = convertedMap[e.ifvId.toString()]
                let pendingWith = ""
                if (tblObj.checker1Id === e.checkerId) {
                    pendingWith = tblObj.checker1Name
                } else if (tblObj.checker2Id === e.checkerId) {
                    pendingWith = tblObj.checker2Name
                } else if (tblObj.checker3Id === e.checkerId) {
                    pendingWith = tblObj.checker3Name
                } else if (tblObj.checker4Id === e.checkerId) {
                    pendingWith = tblObj.checker4Name
                }

                let approvedBy = ""
                if (e.status === 'Approve') {
                    approvedBy = pendingWith
                }

                const d = {
                    ifvId: e.ifvId,
                    ifvName: e.ifvName,
                    appNumber: e.appNumber,
                    sfb: e.sfb === 'Y' ? 'SFB' : 'Non SFB',
                    createdDate: CommonUtil.formatDate(e.createdDate),
                    schemeName: schemeName,
                    makerName: e.makerName,
                    status: e.status,
                    checker: pendingWith,
                    checker1: tblObj.checker1Name,
                    checker2: tblObj.checker2Name,
                    checker3: tblObj.checker3Name,
                    checker4: tblObj.checker4Name,
                    cifNumber: e.cifNumber,
                    approvedBy: approvedBy
                }
                newData.push(d)
            });
            setData(newData)
            setLoading(false)
        },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                setErrorMsg('Error occured while loading checker list: ' + resMessage)
                setShowMsg(true)

            }
        )
    }

    const getValueByKey = (dataArray, keyToFind) => {
        if (CommonUtil.isEmpty(keyToFind)) {
            return null
        }
        const foundItem = dataArray.find(item => item.hasOwnProperty(keyToFind));
        return foundItem ? foundItem[keyToFind] : null;
    };

    //should be memoized or stable
    const columns = useMemo(
        () => [
            {
                accessorKey: 'ifvName', //access nested data with dot notation
                header: 'Name of the Bank',
                size: 200,
            },
            {
                accessorKey: 'appNumber',
                header: 'Application No',
                size: 100,
            },
            // {
            //     accessorKey: 'sfb', //normal accessorKey
            //     header: 'SFB / Non SFB',
            //     size: 50,
            // },
            {
                accessorKey: 'createdDate',
                header: 'Application Date',
                size: 100,
            },
            {
                accessorKey: 'schemeName',
                header: 'Scheme / Applied Amount',
                size: 150,
            },
            // {
            //     accessorKey: 'makerName',
            //     header: 'Maker Name',
            //     size: 100,
            // },
            {
                accessorKey: 'status',
                header: 'Status',
                size: 50,
            },
        ],
        [],
    );

    const table = useMaterialReactTable({
        columns,
        data, //data must be memoized or stable (useState, useMemo, defined outside of this component, etc.)
        enableRowNumbers: true,
        rowNumberDisplayMode: 'static',

        // enableExpandAll: false,
        muiDetailPanelProps: () => ({
            sx: (theme) => ({
                backgroundColor:
                    theme.palette.mode === 'dark'
                        ? 'rgba(255,210,244,0.1)'
                        : 'rgba(0,0,0,0.1)',
            }),
        }),
        //custom expand button rotation
        muiExpandButtonProps: ({ row, table }) => ({
            onClick: () => table.setExpanded({ [row.id]: !row.getIsExpanded() }), //only 1 detail panel open at a time
            sx: {
                transform: row.getIsExpanded() ? 'rotate(180deg)' : 'rotate(-90deg)',
                transition: 'transform 0.2s',
            },
        }),
        //conditionally render detail panel
        renderDetailPanel: ({ row }) =>
            row.original.ifvName ? (
                <Box
                    sx={{
                        display: 'grid',
                        margin: 'auto',
                        gridTemplateColumns: '1fr 1fr',
                        width: '75%',
                    }}
                >

                    <Typography>Maker Name: <strong>{row.original.makerName}</strong></Typography>
                    <Typography><strong>{row.original.sfb}</strong></Typography>
                    <Typography>CIF Number: <strong>{row.original.cifNumber}</strong> </Typography>
                    <Typography></Typography>

                    {row.original.checker1 && <Typography>Checker 1: <strong>{row.original.checker1}</strong> </Typography>}
                    {row.original.checker2 && <Typography>Checker 2: <strong>{row.original.checker2}</strong> </Typography>}
                    {row.original.checker3 && <Typography>Checker 3: <strong>{row.original.checker3}</strong> </Typography>}
                    {row.original.checker4 && <Typography>Checker 4: <strong>{row.original.checker4}</strong> </Typography>}
                    {row.original.checker && CommonUtil.isEmpty(row.original.approvedBy) && <Typography>Pending with: <strong>{row.original.checker}</strong></Typography>}
                    {row.original.approvedBy && <Typography>Approved By: <strong>{row.original.approvedBy}</strong></Typography>}
                </Box>
            ) : null,

        muiTableBodyRowProps: ({ row }) => ({
            onClick: () =>
                navigate('/ifv/basic', {
                    state: {
                        data: row.original.ifvName,
                        appId: row.original.ifvId
                    },
                }),
            sx: {
                cursor: 'pointer',
            },
        }),
    });

    return (
        <div className={loading ? 'blur-background' : ''}>

            <MaterialReactTable table={table} />
            {loading && <Loading />}
        </div>

    )
};

export default ProposalsSummary;
