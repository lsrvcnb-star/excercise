import CloseIcon from '@mui/icons-material/Close';
import SaveIcon from '@mui/icons-material/Save';
import {
    Box,
    Button,
    CircularProgress,
    Dialog,
    DialogContent,
    DialogTitle,
    IconButton,
    MenuItem,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TextField,
    Typography
} from '@mui/material';
import { styled } from '@mui/material/styles';
import MessageModal from 'components/MessageModal';
import { useErrorHandler } from 'hooks/useErrorHandler';
import useMessageModal from 'hooks/useMessageModal';
import React, { useEffect, useState } from 'react';
import ReactDatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { useFieldArray, useForm } from 'react-hook-form';
import { PrincipalRepayment } from 'services/constants/PrincipalRepayment';
import MasterService from 'services/MasterService';
import MinutesService from 'services/MinutesService';
import CommonUtil from 'services/utils/CommonUtil';

// Styled components
const StyledDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialog-paper': {
        backgroundColor: '#f8f9fa',
        borderRadius: '12px',
        maxWidth: '95vw',
        width: '95vw'
    },
    '& .MuiDialogTitle-root': {
        backgroundColor: theme.palette.primary.main,
        color: 'white',
        padding: theme.spacing(2),
    },
    '& .MuiDialogContent-root': {
        padding: theme.spacing(3),
        marginTop: '10px'
    }
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
}));

const StyledTableContainer = styled(TableContainer)(({ theme }) => ({
    overflowX: 'auto',
    '& .MuiTable-root': {
        minWidth: 1550,
    },
    '&::-webkit-scrollbar': {
        height: 8,
    },
    '&::-webkit-scrollbar-track': {
        background: '#f1f1f1',
        borderRadius: 4,
    },
    '&::-webkit-scrollbar-thumb': {
        background: theme.palette.primary.light,
        borderRadius: 4,
        '&:hover': {
            background: theme.palette.primary.main,
        },
    },
}));
const StyledTableCell = styled(TableCell)(({ theme }) => ({
    '&.MuiTableCell-head': {
        backgroundColor: theme.palette.primary.dark,
        color: theme.palette.common.white,
        fontWeight: 'bold',
        fontSize: '0.95rem',
        padding: theme.spacing(2),
        whiteSpace: 'nowrap',
    },
    '&.MuiTableCell-body': {
        padding: theme.spacing(1.5),
        '&.slno-cell': { minWidth: 60 },
        '&.fund-cell': { minWidth: 150 },
        '&.scheme-cell': { minWidth: 150 },
        '&.amount-cell': { minWidth: 120 },
        '&.roi-cell': { minWidth: 100 },
        '&.type-cell': { minWidth: 120 },
        '&.benchmark-cell': { minWidth: 150 },
        '&.spread-cell': { minWidth: 100 },
        '&.reset-cell': { minWidth: 130 },
        '&.tenure-cell': { minWidth: 130 },
        '&.repayment-cell': { minWidth: 150 },
        '&.maturity-cell': { minWidth: 140 },
    }
}));

const MinutesModal = ({
    open,
    onClose,
    status,
    agendaId,
    appId,
    agendaNo,
    sancDtlCode,
    unitName,
}) => {
    const {
        showMessage,
        hideMessage,
        isOpen,
        messageConfig,
        totalMessages,
        currentIndex,
        nextMessage,
        prevMessage,
        hasNext,
        hasPrev
    } = useMessageModal();
    const { handleApiError } = useErrorHandler(showMessage);
    const [loading, setLoading] = useState(false);
    const [dataLoading, setDataLoading] = useState(false);
    const [nameOfTheBank, setNameOfTheBank] = useState('');
    const [minuteId, setMinuteId] = useState(false);
    const [benchmarkList, setBenchmarkList] = useState([]);

    const {
        control,
        register,
        handleSubmit,
        setValue,
        reset,
        watch,
        formState: { errors },
    } = useForm({
        defaultValues: {
            appraisalData: [],
        },
    });

    const formValues = watch('appraisalData');

    const { fields } = useFieldArray({
        control,
        name: 'appraisalData',
    });

    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR',
            minimumFractionDigits: 0,
            maximumFractionDigits: 20
        }).format(amount);
    };

    const totalAmount = React.useMemo(() => {
        return formValues?.reduce((sum, item) => {
            return sum + (parseFloat(item?.loanAmount) || 0);
        }, 0);
    }, [formValues]);

    useEffect(() => {
        if (open && agendaId && appId) {
            getBenchmarkDetails();
            loadMinutesData();
        }
    }, [open, agendaId, appId]);

    const getBenchmarkDetails = async () => {
        try {
            const response = await MasterService.getBenchmarkDetails();
            setBenchmarkList(response.data);
        } catch (error) {
            handleApiError(error, 'loading benchmark details');
        }
    };

    const loadMinutesData = async () => {
        try {
            setDataLoading(true);
            reset({ appraisalData: [] });
            const response = await MinutesService.getAllAppraisalsOnAgendaIdAndAppId(agendaId, appId);
            if (response.data.length === 0) {
                await handleNewMinutes();
            } else {
                await handleExistingMinutes(response.data);
            }
        } catch (error) {
            handleApiError(error, 'loading minutes Details');
        } finally {
            setDataLoading(false);
        }
    };

    const handleNewMinutes = async () => {
        setMinuteId(false);
        try {
            const res = await MinutesService.getAllSchemesOnAppId(appId);
            const appData = res.data;
            reset({ appraisalData: [] });
            const formData = appData.map(item => ({
                sancDtlCode,
                agendaNo,
                agendaId,
                appId,
                bankName: unitName,
                fundName: item.prFundname,
                schemeName: item.prSchemeName,
                loanAmount: item.prAmount,
                interestRate: item.prRoi,
                interestType: item.interestType,
                benchMark: item.benchMark,
                spread: item.spread,
                interestReset: item.interestReset,
                principalRepayment: item.prPrincipalRepayment,
                tenure: item.prTenure,
                prId: item.prId,
                fundCode: item.prFundcode,
                schemeCode: item.prSchemecode,
                maturityDate: item.prMaturityDate
            }));
            reset({ appraisalData: formData });
            setNameOfTheBank(unitName);
        } catch (error) {
            console.error('Error loading schemes:', error);
        }
    };

    const handleExistingMinutes = async (data) => {
        try {
            setMinuteId(true);
            reset({ appraisalData: [] });
            reset({ appraisalData: data });
            setNameOfTheBank(data[0]?.bankName);
        } catch (error) {
            console.error('Error handling existing minutes:', error);
        }
    };

    const onSubmit = async (data) => {
        setLoading(true);
        try {
            const finalData = data.appraisalData.filter(
                (item) => item && item.bankName
            );

            const validationErrors = finalData.map((item, index) => {
                if (item.interestType === 'Fixed' && !item.interestRate) {
                    return `Row ${index + 1}: Interest Rate is required for Fixed interest type`;
                }
                if (item.interestType === 'Floating' && (!item.benchMark || !item.spread)) {
                    //  return `Row ${index + 1}: Benchmark and Spread are required for Floating interest type`;
                }
                return null;
            }).filter(Boolean);
            if (validationErrors.length > 0) {
                alert(validationErrors.join('\n'));
                setLoading(false);
                return;
            }
            if (!finalData.length) {
                return;
            }
            await MinutesService.saveAllAppraisalMinutesData(finalData);
            setMinuteId(true);
            loadMinutesData();
        } catch (error) {
            handleApiError(error, 'saving Minutes Details');
        } finally {
            setLoading(false);
        }
    };

    return (
        <>  <StyledDialog open={open} onClose={onClose} maxWidth="xl" fullWidth>
            <DialogTitle>
                <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography variant="h6">Minutes</Typography>
                    <IconButton onClick={onClose} sx={{ color: 'white' }}>
                        <CloseIcon />
                    </IconButton>
                </Box>
            </DialogTitle>

            <DialogContent>
                {dataLoading ? (
                    <Box display="flex" justifyContent="center" p={4}>
                        <CircularProgress />
                    </Box>
                ) : (
                    <form onSubmit={handleSubmit(onSubmit)}>
                        <Paper elevation={3} sx={{ p: 2, mb: 3, backgroundColor: 'primary.light', color: 'white' }}>
                            <Box display="grid" gridTemplateColumns="1fr 1fr 1fr" gap={2}>
                                <Typography><strong>Name of the Bank:</strong> {nameOfTheBank}</Typography>
                            </Box>
                        </Paper>

                        <StyledTableContainer component={Paper} elevation={3} sx={{ mb: 3 }}>
                            <Table size="small">
                                <TableHead>
                                    <TableRow>
                                        <StyledTableCell className="slno-cell">Sl No</StyledTableCell>
                                        <StyledTableCell className="fund-cell">Fund Name</StyledTableCell>
                                        <StyledTableCell className="scheme-cell">Scheme Name</StyledTableCell>
                                        <StyledTableCell className="amount-cell">Amount (crore)</StyledTableCell>
                                        <StyledTableCell className="roi-cell">RoI (%)</StyledTableCell>
                                        <StyledTableCell className="type-cell">Interest Type</StyledTableCell>
                                        <StyledTableCell className="benchmark-cell">Benchmark</StyledTableCell>
                                        <StyledTableCell className="spread-cell">Spread</StyledTableCell>
                                        <StyledTableCell className="reset-cell">Interest Reset</StyledTableCell>
                                        <StyledTableCell className="tenure-cell">Tenure (months)</StyledTableCell>
                                        <StyledTableCell className="repayment-cell">Principal repayment</StyledTableCell>
                                        <StyledTableCell className="maturity-cell">Maturity Date</StyledTableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {fields.map((field, index) => {
                                        const interestType = watch(`appraisalData[${index}].interestType`);
                                        const fundName = CommonUtil.extractTextUpToWord(watch(`appraisalData[${index}].fundName`));
                                        const schemeName = watch(`appraisalData[${index}].schemeName`);
                                        return (
                                            <StyledTableRow key={field.id}>
                                                <TableCell>{index + 1}</TableCell>
                                                <TableCell>{fundName}</TableCell>
                                                <TableCell>{schemeName}</TableCell>
                                                <TableCell>
                                                    <TextField
                                                        fullWidth
                                                        size="small"
                                                        type="number"
                                                        sx={{ width: '100px' }}
                                                        inputProps={{
                                                            min: 0,
                                                            max: 99999,
                                                            step: "any",
                                                        }}
                                                        {...register(`appraisalData[${index}].loanAmount`, {
                                                            required: "Amount is required",
                                                            min: { value: 0, message: "Amount must be positive" }
                                                        })}
                                                        error={!!errors?.appraisalData?.[index]?.loanAmount}
                                                        helperText={errors?.appraisalData?.[index]?.loanAmount?.message}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <TextField
                                                        fullWidth
                                                        size="small"
                                                        type="number"
                                                        sx={{ width: '70px' }}
                                                        inputProps={{
                                                            min: 0,
                                                            max: 100,
                                                            step: "any",
                                                        }}
                                                        {...register(`appraisalData[${index}].interestRate`, {
                                                            valueAsNumber: true,
                                                            validate: interestType === 'Floating' ? undefined : {
                                                                isInRange: value =>
                                                                    (value >= 0 && value <= 100) || 'Value must be between 0 and 100',
                                                                isNumber: value =>
                                                                    !isNaN(value) || 'Please enter a valid number'
                                                            }
                                                        })}
                                                        disabled={interestType === 'Floating'}
                                                        error={!!errors?.appraisalData?.[index]?.interestRate}
                                                        helperText={errors?.appraisalData?.[index]?.interestRate?.message}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <TextField
                                                        select
                                                        fullWidth
                                                        size="small"
                                                        required
                                                        value={watch(`appraisalData[${index}].interestType`) || ''}
                                                        onChange={(e) => {
                                                            setValue(`appraisalData[${index}].interestType`, e.target.value);
                                                            if (e.target.value === 'Fixed') {
                                                                setValue(`appraisalData[${index}].benchMark`, '');
                                                                setValue(`appraisalData[${index}].spread`, '');
                                                                setValue(`appraisalData[${index}].interestReset`, '');
                                                            } else if (e.target.value === 'Floating') {
                                                                setValue(`appraisalData[${index}].interestRate`, '');
                                                            }
                                                        }}
                                                    >
                                                        <MenuItem value="">Select type</MenuItem>
                                                        <MenuItem value="Fixed">Fixed</MenuItem>
                                                        <MenuItem value="Floating">Floating</MenuItem>
                                                    </TextField>
                                                </TableCell>
                                                <TableCell>
                                                    <TextField
                                                        select
                                                        fullWidth
                                                        size="small"
                                                        value={watch(`appraisalData[${index}].benchMark`) || ''}
                                                        onChange={(e) => setValue(`appraisalData[${index}].benchMark`, e.target.value)}
                                                        disabled={interestType === 'Fixed' || !interestType}
                                                    >
                                                        <MenuItem value="">Select benchmark</MenuItem>
                                                        {benchmarkList.map((item, idx) => (
                                                            <MenuItem key={idx} value={item}>{item}</MenuItem>
                                                        ))}
                                                    </TextField>
                                                </TableCell>
                                                <TableCell>
                                                    <TextField
                                                        fullWidth
                                                        size="small"
                                                        {...register(`appraisalData[${index}].spread`)}
                                                        disabled={interestType === 'Fixed' || !interestType}
                                                        error={!!errors?.appraisalData?.[index]?.spread}
                                                        helperText={errors?.appraisalData?.[index]?.spread?.message}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <TextField
                                                        select
                                                        fullWidth
                                                        size="small"
                                                        value={watch(`appraisalData[${index}].interestReset`) || ''}
                                                        onChange={(e) => setValue(`appraisalData[${index}].interestReset`, e.target.value)}
                                                    >
                                                        <MenuItem value="">Select reset period</MenuItem>
                                                        <MenuItem value="Quarterly">Quarterly</MenuItem>
                                                        <MenuItem value="Half Yearly">Half Yearly</MenuItem>
                                                        <MenuItem value="Annual">Annual</MenuItem>
                                                        <MenuItem value="After 2 Years">After 2 Years</MenuItem>
                                                    </TextField>
                                                </TableCell>
                                                <TableCell>
                                                    <TextField
                                                        fullWidth
                                                        size="small"
                                                        type="number"
                                                        {...register(`appraisalData[${index}].tenure`, {
                                                            required: "Tenure is required",
                                                            min: { value: 1, message: "Invalid tenure" }
                                                        })}
                                                        error={!!errors?.appraisalData?.[index]?.tenure}
                                                        helperText={errors?.appraisalData?.[index]?.tenure?.message}
                                                    />
                                                </TableCell>
                                                <TableCell>
                                                    <TextField
                                                        select
                                                        fullWidth
                                                        size="small"
                                                        value={watch(`appraisalData[${index}].principalRepayment`) || ''}
                                                        onChange={(e) => setValue(`appraisalData[${index}].principalRepayment`, e.target.value)}
                                                    >
                                                        <MenuItem value="">Select type</MenuItem>
                                                        {PrincipalRepayment.map((item, idx) => (
                                                            <MenuItem key={idx} value={item}>{item}</MenuItem>
                                                        ))}
                                                    </TextField>
                                                </TableCell>
                                                <TableCell className="maturity-cell">
                                                    <ReactDatePicker
                                                        selected={watch(`appraisalData[${index}].maturityDate`) ? new Date(watch(`appraisalData[${index}].maturityDate`)) : null}
                                                        onChange={(date) => setValue(`appraisalData[${index}].maturityDate`, date)}
                                                        dateFormat="dd-MM-yyyy"
                                                        placeholderText="Select date"
                                                        isClearable
                                                        showYearDropdown
                                                        scrollableYearDropdown
                                                        yearDropdownItemNumber={15}
                                                        customInput={
                                                            <TextField
                                                                fullWidth
                                                                size="small"
                                                                sx={{
                                                                    '& .MuiInputBase-root': {
                                                                        width: '100%',
                                                                        minWidth: '120px'
                                                                    }
                                                                }}
                                                            />
                                                        }
                                                    />
                                                </TableCell>
                                            </StyledTableRow>
                                        );
                                    })}
                                    <StyledTableRow>
                                        <StyledTableCell colSpan={3} align="right">
                                            Total:
                                        </StyledTableCell>
                                        <StyledTableCell>
                                            {formatCurrency(totalAmount)} crore
                                        </StyledTableCell>
                                        <StyledTableCell colSpan={8} />
                                    </StyledTableRow>
                                </TableBody>
                            </Table>
                        </StyledTableContainer>
                        {status === 'CREATED' && <Box display="flex" justifyContent="center">
                            <Button
                                type="submit"
                                variant="contained"
                                disabled={loading}
                                startIcon={loading ? <CircularProgress size={20} /> : <SaveIcon />}
                                sx={{ minWidth: 150 }}
                            >
                                {loading ? 'Saving...' : (minuteId ? 'Update' : 'Save')}
                            </Button>
                        </Box>
                        }
                    </form>
                )}
            </DialogContent>
        </StyledDialog>
            <MessageModal
                open={isOpen}
                onClose={hideMessage}
                message={messageConfig.message}
                type={messageConfig.type}
                totalMessages={totalMessages}
                currentIndex={currentIndex}
                onNext={nextMessage}
                onPrev={prevMessage}
                hasNext={hasNext}
                hasPrev={hasPrev}
            />
        </>
    );
};

export default MinutesModal;