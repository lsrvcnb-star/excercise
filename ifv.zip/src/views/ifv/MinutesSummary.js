import CloseIcon from "@mui/icons-material/Close";
import DownloadIcon from "@mui/icons-material/Download";
import RefreshIcon from "@mui/icons-material/Refresh";
import {
  Alert,
  Box,
  CircularProgress,
  IconButton,
  Modal,
  Tooltip,
  Typography,
} from "@mui/material";
import {
  QueryClient,
  QueryClientProvider,
  useQuery,
} from "@tanstack/react-query";
import axios from "axios";
import Loading from "components/Loading";
import { format } from "date-fns";
import {
  MaterialReactTable,
  useMaterialReactTable,
} from "material-react-table";
import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import IfvAppraisalService from "services/IfvAppraisalService";
import MinutesService from "services/MinutesService";
import Committee from "services/constants/Committee";
import CommonUtil from "services/utils/CommonUtil";
import FileUtil from "services/utils/FileUtil";
import { getJwtToken } from "services/utils/JwtUtil";
const MinutesSummaryQuery = () => {
  const [loading, setLoading] = useState(false);
  const [showMsg, setShowMsg] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [backendError, setBackendError] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();
  const mode = location.state?.mode || "";
  const isLoiSummary = mode === "LOI";
  const [columnFilters, setColumnFilters] = useState([]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [sorting, setSorting] = useState([]);
  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: 10,
  });
  const closeAgenda = async (mtCode) => {
    if (!window.confirm("Are you sure you want to close the agenda?")) return;
    setLoading(true);
    try {
      await MinutesService.updateSanctionMinutes({
        sanctDetailCode: mtCode,
        sanctStage: "CLOSED",
      });
      setErrorMsg("Agenda has been Closed!");
    } catch (error) {
      setErrorMsg(
        `Error occurred while closing agenda: ${
          error.response?.data?.message || error.message
        }`
      );
      console.error("Error closing agenda:", error);
    } finally {
      setLoading(false);
      setShowMsg(true);
    }
  };
  const {
    data: queryData,
    isError,
    isRefetching,
    isLoading,
    refetch,
    error,
  } = useQuery({
    queryKey: [
      "table-data",
      columnFilters,
      globalFilter,
      pagination.pageIndex,
      pagination.pageSize,
      sorting,
    ],
    queryFn: async () => {
      const user = IfvAppraisalService.getCurrentUser();
      const url = new URL(
        `${process.env.REACT_APP_API_ENDPOINT}api/sanction-minutes/getAllOnUserTypeOnPage/${user.ofrType}/${user.ofrEmpId}`
      );
      url.searchParams.set(
        "start",
        `${pagination.pageIndex * pagination.pageSize}`
      );
      url.searchParams.set("size", `${pagination.pageSize}`);
      url.searchParams.set("filters", JSON.stringify(columnFilters ?? []));
      url.searchParams.set("globalFilter", globalFilter);
      url.searchParams.set("sorting", JSON.stringify(sorting ?? []));
      url.searchParams.set("status", mode);
      try {
        const response = await axios.get(url.href, {
          headers: { Authorization: `Bearer ${getJwtToken()}` },
        });
        return response.data;
      } catch (error) {
        console.error("Backend error while loading data:", error);
        setBackendError("ERR_BAD_RESPONSE");
        throw error;
      }
    },
  });
  const handleDownload = async (sanctDetailCode) => {
    setLoading(sanctDetailCode);
    try {
      const response = await MinutesService.getDocumentByMinuteId(
        sanctDetailCode
      );
      if (!CommonUtil.isEmpty(response.data.documentName)) {
        FileUtil.downloadFile(
          response.data.documentContent,
          response.data.documentName,
          "application/pdf"
        );
      } else {
        alert("No file");
      }
    } catch (error) {
      const resMessage =
        (error.response &&
          error.response.data &&
          error.response.data.message) ||
        error.message ||
        error.toString();
      console.log(resMessage);
      alert("Error occurred while generating report");
    } finally {
      setLoading(null);
    }
  };
  useEffect(() => {
    if (isError && error) {
      console.error("Query error:", error);
      setBackendError("ERR_BAD_RESPONSE");
    }
  }, [isError, error]);
  const columns = useMemo(
    () => [
      {
        accessorKey: "commiteeCode",
        header: "Committee Name",
        size: 100,
        Cell: ({ cell }) => Committee[cell.getValue()],
      },
      {
        accessorKey: "agendaId",
        header: "Agenda ID",
        size: 100,
      },
      {
        accessorKey: "meetingNo",
        header: "Meeting No",
        size: 100,
      },
      {
        accessorKey: "createdDate",
        header: "Created Date",
        size: 150,
        Cell: ({ cell }) => format(new Date(cell.getValue()), "dd-MM-yyyy"),
      },
      {
        accessorKey: "sanctStage",
        header: "Status",
        size: 50,
      },
    ],
    []
  );

  const showActions = !isLoiSummary;
  const showExpand = !isLoiSummary;

  const table = useMaterialReactTable({
    columns,
    data: queryData?.content || [],
    enableRowNumbers: true,
    rowNumberDisplayMode: "static",
    //createDisplayMode: "modal",
    //editDisplayMode: "modal",
    enableEditing: !isLoiSummary,
    getRowId: (row) => row.id,
    muiTableContainerProps: { sx: { minHeight: "500px" } },
    initialState: {
      showColumnFilters: false,
    },
    manualFiltering: true,
    manualPagination: true,
    manualSorting: true,
    muiToolbarAlertBannerProps: isError
      ? {
          color: "error",
          children: error?.response?.data?.message || "Error loading data",
        }
      : undefined,
    rowCount: queryData?.totalElements ?? 0,
    state: {
      columnFilters,
      globalFilter,
      isLoading,
      pagination,
      showAlertBanner: isError,
      showProgressBars: isRefetching,
      sorting,
    },
    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
    onPaginationChange: setPagination,
    onSortingChange: setSorting,
    enableExpanding: showExpand,
    renderDetailPanel: showExpand
      ? ({ row }) =>
          row.original.remarks && (
            <Box
              sx={{
                p: 1,
                bgcolor: "#E5E4E2",
                borderRadius: 1,
                boxShadow: "0 0 10px rgba(0,0,0,0.1)",
                mx: 22,
                //my: 0
              }}
            >
              <Typography>{row.original.remarks}</Typography>
            </Box>
          )
      : undefined,
    renderTopToolbarCustomActions: () => (
      <Tooltip arrow title="Refresh Data">
        <IconButton onClick={() => refetch()}>
          <RefreshIcon />
        </IconButton>
      </Tooltip>
    ),
    enableRowActions: showActions,
    renderRowActions: showActions
      ? ({ row }) => (
          <Box sx={{ display: "flex" }}>
            {row.original.sanctStage !== "APPROVED" && (
              <Tooltip title="Close Agenda">
                <IconButton
                  color="error"
                  onClick={(event) => {
                    event.stopPropagation();
                    closeAgenda(row.original.sanctDetailCode);
                  }}
                >
                  <CloseIcon />
                </IconButton>
              </Tooltip>
            )}
            {row.original.sanctStage === "APPROVED" && (
              <Tooltip title="Download">
                <IconButton
                  onClick={(event) => {
                    event.stopPropagation();
                    handleDownload(row.original.sanctDetailCode);
                  }}
                  sx={{
                    color:
                      loading === row.original.sanctDetailCode
                        ? "gray"
                        : "primary.main",
                  }}
                  disabled={loading === row.original.sanctDetailCode}
                >
                  {loading === row.original.sanctDetailCode ? (
                    <CircularProgress size={24} />
                  ) : (
                    <DownloadIcon />
                  )}
                </IconButton>
              </Tooltip>
            )}
          </Box>
        )
      : undefined,
    muiTableBodyRowProps: ({ row }) => ({
      onClick: (event) => {
        // Only navigate if the click wasn't on a button or the expand/collapse control
        if (
          !event.target.closest("button") &&
          !event.target.closest('[data-expansion-toggle="true"]')
        ) {
          const path =
            mode === "Min" || mode === "AP"
              ? "/ifv/meeting-details"
              : "/ifv/generateLoI";
          const state =
            mode === "Min" || mode === "AP"
              ? { mtCode: row.original.sanctDetailCode }
              : { sancId: row.original.sanctDetailCode };
          navigate(path, { state });
        }
      },
      sx: { cursor: "pointer" },
    }),
  });
  return (
    <div className={loading ? "blur-background" : ""}>
      <h5>
        <strong>
          {mode === "Min"
            ? "Existing Minutes"
            : mode === "AP"
            ? "Approved Minutes"
            : "Generate LoI"}
        </strong>
      </h5>
      {backendError && (
        <Alert severity="error" onClose={() => setBackendError(null)}>
          Error: {backendError}
        </Alert>
      )}
      <MaterialReactTable table={table} />
      {loading && <Loading />}
      <Modal
        open={showMsg}
        onClose={() => setShowMsg(false)}
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Box
          sx={{
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 4,
            borderRadius: 2,
            maxWidth: 400,
          }}
        >
          <h5 className={errorMsg.includes("Error") ? "alertMsg" : "loadMsg"}>
            {errorMsg}
          </h5>
          <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
            <button
              className="btn btnRegister themebutton"
              onClick={() => setShowMsg(false)}
            >
              OK
            </button>
          </Box>
        </Box>
      </Modal>
    </div>
  );
};
const queryClient = new QueryClient();
const MinutesSummary = () => (
  <QueryClientProvider client={queryClient}>
    <MinutesSummaryQuery />
  </QueryClientProvider>
);
export default MinutesSummary;
