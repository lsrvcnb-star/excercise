import AddIcon from "@mui/icons-material/Add";
import DeleteIcon from "@mui/icons-material/Delete";
import {
    Box,
    Button,
    Collapse,
    FormHelperText,
    IconButton,
    Paper,
    Table,
    TableBody,
    TableHead,
    TableRow
} from "@mui/material";
import {
    BankSelectCell,
    LoadingSpinner,
    StyledTableCell,
    StyledTableContainer,
    StyledTableRow,
    StyledTextArea,
    useBankOptions,
} from "components/common/colendingShared";
import { useEffect, useState } from "react";
import { Controller, useFieldArray, useForm } from "react-hook-form";
import {
    deleteOtherItemsById,
    fetchOtherItems,
    saveOtherItems,
} from "services/minutesAdditionalDetailApi";
import Pattern from "services/validators/Pattern";

const OtherItemsSection = ({ minuteSanctionId, open, isEditable }) => {
    const [loading, setLoading] = useState(false);
    const { bankOptions, loadingBanks } = useBankOptions(open);

    const {
        control,
        handleSubmit,
        setValue,
        formState: { errors },
    } = useForm({
        defaultValues: { otherItems: [] },
        mode: "onChange",
    });

    const { fields, append, remove, replace } = useFieldArray({
        control,
        name: "otherItems",
    });

    const fetchData = async () => {
        try {
            setLoading(true);
            const res = await fetchOtherItems(minuteSanctionId);
            const formatted =
                res?.map((item) => ({
                    dbId: item.id,
                    bankName: item.bankName,
                    cifNumber: item.cifNumber,
                    remarks: item.remarks || "",
                })) || [];
            replace(formatted);
        } catch (err) {
            console.error("Fetch other items error", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (open && minuteSanctionId) {
            fetchData();
        }
    }, [open, minuteSanctionId]);

    const handleAddRow = () => {
        append({ dbId: null, bankName: "", cifNumber: "", remarks: "" });
    };

    const handleDelete = async (index, dbId) => {
        if (!window.confirm("Delete this other item record?")) return;
        try {
            if (dbId) await deleteOtherItemsById(dbId);
            remove(index);
        } catch (err) {
            console.error("Delete failed", err);
            alert("Delete failed. Please try again.");
        }
    };

    const onSubmit = async (formData) => {
        if (!formData?.otherItems || formData.otherItems.length === 0) {
            alert("Please add at least one record before submitting.");
            return;
        }
        try {
            const payload = formData.otherItems.map((item) => ({
                bankName: item.bankName,
                cifNumber: item.cifNumber,
                remarks: item.remarks,
                minuteSanctionId,
            }));
            await saveOtherItems(minuteSanctionId, payload);
            alert("Other Items saved successfully");
            fetchData();
        } catch (err) {
            console.error("Save failed", err);
            alert("Save failed. Please try again.");
        }
    };

    return (
        <Collapse in={open} timeout="auto" unmountOnExit>
            <Box mt={2}>
                {loading ? (
                    <LoadingSpinner />
                ) : (
                    <Box className="intRst">
                        <StyledTableContainer component={Paper}>
                            <Table size="small" stickyHeader>
                                <TableHead>
                                    <TableRow>
                                        <StyledTableCell sx={{ width: "50px" }}>S.No</StyledTableCell>
                                        <StyledTableCell sx={{ minWidth: "350px" }}>
                                            Name of the Bank <span style={{ color: "red" }}>*</span>
                                        </StyledTableCell>
                                        <StyledTableCell sx={{ minWidth: "400px" }}>
                                            Remarks <span style={{ color: "red" }}>*</span>
                                        </StyledTableCell>
                                        <StyledTableCell align="center" sx={{ width: "80px" }}>
                                            {isEditable && <IconButton
                                                onClick={handleAddRow}
                                                size="small"
                                                sx={{
                                                    bgcolor: 'primary.light',
                                                    color: 'white',
                                                    padding: '4px',
                                                    '&:hover': {
                                                        bgcolor: 'primary.main',
                                                    },
                                                }}
                                            >
                                                <AddIcon fontSize="small" />
                                            </IconButton>
                                            }
                                        </StyledTableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {fields.length === 0 ? (
                                        <TableRow>
                                            <StyledTableCell colSpan={4} align="center">
                                                No Records
                                            </StyledTableCell>
                                        </TableRow>
                                    ) : (
                                        fields.map((row, index) => {
                                            const bankError = errors?.otherItems?.[index]?.cifNumber;
                                            const remarksError = errors?.otherItems?.[index]?.remarks;
                                            return (
                                                <StyledTableRow key={row.id}>
                                                    <StyledTableCell>{index + 1}</StyledTableCell>
                                                    <StyledTableCell>
                                                        <Controller
                                                            name={`otherItems.${index}.cifNumber`}
                                                            control={control}
                                                            rules={{ required: "Bank name is required" }}
                                                            render={({ field }) => (
                                                                <Box>
                                                                    <BankSelectCell
                                                                        field={field}
                                                                        bankOptions={bankOptions}
                                                                        loadingBanks={loadingBanks}
                                                                        onBankChange={(name) =>
                                                                            setValue(`otherItems.${index}.bankName`, name)
                                                                        }
                                                                        error={!!bankError}
                                                                    />
                                                                    {bankError && (
                                                                        <FormHelperText error>
                                                                            {bankError.message}
                                                                        </FormHelperText>
                                                                    )}
                                                                </Box>
                                                            )}
                                                        />
                                                    </StyledTableCell>
                                                    <StyledTableCell>
                                                        <Controller
                                                            name={`otherItems.${index}.remarks`}
                                                            control={control}
                                                            rules={{
                                                                required: "Remarks are required",
                                                                minLength: {
                                                                    value: 3,
                                                                    message: "Remarks must be at least 3 characters",
                                                                },
                                                                maxLength: {
                                                                    value: 500,
                                                                    message: "Remarks cannot exceed 500 characters",
                                                                },
                                                            }}
                                                            render={({ field }) => (
                                                                <Box>
                                                                    <StyledTextArea
                                                                        {...field}
                                                                        placeholder="Enter remarks..."
                                                                        onChange={(e) => {
                                                                            Pattern.sanitizeInput(e);
                                                                            field.onChange(e);
                                                                        }}
                                                                        className={remarksError ? "error" : ""}
                                                                    />
                                                                    {remarksError && (
                                                                        <FormHelperText error>
                                                                            {remarksError.message}
                                                                        </FormHelperText>
                                                                    )}
                                                                </Box>
                                                            )}
                                                        />
                                                    </StyledTableCell>
                                                    <StyledTableCell align="center">
                                                        {isEditable &&
                                                            <IconButton
                                                                color="error"
                                                                size="small"
                                                                onClick={() => handleDelete(index, row.dbId)}
                                                            >
                                                                <DeleteIcon fontSize="small" />
                                                            </IconButton>
                                                        }
                                                    </StyledTableCell>
                                                </StyledTableRow>
                                            );
                                        })
                                    )}
                                </TableBody>
                            </Table>
                        </StyledTableContainer>
                        {isEditable && <Box mt={2} display="flex" gap={2}>
                            <Button type="button" variant="contained" onClick={handleSubmit(onSubmit)}>
                                Save Other Items
                            </Button>
                        </Box>
                        }
                    </Box>
                )}
            </Box>
        </Collapse>
    );
};

export default OtherItemsSection;