import {
  Alert,
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  InputLabel,
  LinearProgress,
  MenuItem,
  Select as MuiSelect,
  Stack,
  Tab,
  Tabs,
  TextField,
  Typography
} from "@mui/material";
import Loading from "components/Loading";
import MessageModal from "components/MessageModal";
import { format } from "date-fns";
import { useErrorHandler } from "hooks/useErrorHandler";
import useMessageModal from "hooks/useMessageModal";
import { Fragment, useEffect, useState } from "react";
import Accordion from "react-bootstrap/Accordion";
import ReactDatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Controller, useForm } from "react-hook-form";
import { useLocation } from "react-router-dom";
import Select from "react-select";
import IfvAppraisalService from "services/IfvAppraisalService";
import MasterService from "services/MasterService";
import MinutesService from "services/MinutesService";
import CommonUtil from "services/utils/CommonUtil";
import FileUtil from "services/utils/FileUtil";
import Pattern from "services/validators/Pattern";

const GenerateLOI = () => {
  const env = process.env.REACT_APP_ENV;
  const location = useLocation();
  const sancId = location.state.sancId;

  const {
    control,
    register: register1,
    handleSubmit: handleSubmitOfLoIDetails,
    setValue: setValue1,
    getValues: getValues1,
    formState: { errors: errors1 },
  } = useForm({
    mode: "onBlur",
  });

  const {
    control: control16,
    register: register16,
    handleSubmit: handleSubmitOfTermsAndConditionData,
    setValue: setValue16,
    getValues: getValues16,
    formState: { errors: errors16 },
  } = useForm({
    mode: "onBlur",
  });

  const {
    showMessage,
    hideMessage,
    isOpen,
    messageConfig,
    totalMessages,
    currentIndex,
    nextMessage,
    prevMessage,
    hasNext,
    hasPrev,
  } = useMessageModal();
  const { handleApiError } = useErrorHandler(showMessage);

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    getUserList();
    getSanctionMinutesById();
  }, []);

  const [loiId, setLoiId] = useState(0);
  const [ofrName, setOfrName] = useState("");
  const [enableInterestReset, setEnableInterestReset] = useState(false);
  const [ThreeMTBillBenchmark, setThreeMTBillBenchmark] = useState(false);
  const [benchMarkSpread, setBenchMarkSpread] = useState("");

  const [repoRate, setRepoRate] = useState(false);

  const findLoIBySancIdAndSancDetailCode = (
    sancDtlCode,
    schemeName,
    appId,
    prId,
    minuteId,
    loanAmount
  ) => {
    setLoading(true);
    MinutesService.findLoIBySancIdAndSancDetailCode(
      sancId,
      sancDtlCode,
      minuteId
    ).then(
      (response) => {
        const appData = response.data;
        let no = schemeName.includes("RMSE") ? "7" : "3";

        if (CommonUtil.isEmpty(appData) || CommonUtil.isEmpty(appData.id)) {
          setLoiId(appData.id);
          setValue1("id", "");
          setValue1("sancId", sancId);
          setValue1("sancDetailId", sancDtlCode);
          setValue1("appraisalMnuteId", minuteId);
          setValue1("ifvNo", "");
          setValue1("ifvDate", "");
          setValue1("addressOfTheBank", "");
          setValue1(
            "headerNote",
            "Letter of Intent for refinance under " + schemeName + " Scheme"
          );
          let amtWords = CommonUtil.numberToWordsInCrores(loanAmount);
          let words = "";
          if (!CommonUtil.isEmpty(amtWords)) {
            words = amtWords
              .replace(/[,-]/g, " ")
              .split(" ")
              .filter((word) => word.length > 0)
              .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
              .join(" ");
          }

          MinutesService.getAppraisalDateByAppId(appId, minuteId).then(
            (res) => {
              setValue1(
                "note1",
                "Please refer to your application dated " +
                  res.data +
                  ", requesting for sanction of Refinance under " +
                  schemeName +
                  " Scheme. We inform you  that your request has been considered and Small Industries Development Bank of India (SIDBI) is agreeable, in principle, to grant to your Bank financial support to the extent of Rs. " +
                  loanAmount +
                  " crore (" +
                  words +
                  ") by way of refinance under " +
                  schemeName +
                  " Scheme on the conditions as agreed under the General Agreement executed by you and more specifically on the terms and conditions specified herein in Annexure for the present proposal."
              );
            },
            (error) => {
              handleApiError(error, "loading application date");
            }
          );

          setValue1(
            "note2",
            "This Letter of Intent is being issued in duplicate. In case these terms and conditions are acceptable to your Bank, you may please return the duplicate copy hereof duly accepted by an authorized official on behalf of your bank. Please sign on each page of the duplicate LoI along with Round stamp and attached it to a non-judicial stamp paper of the requisite value for agreement with an endorsement thereon by the authorized official as follows:"
          );

          setValue1(
            "note2Subnote1",
            "“The terms and conditions contained in the attached LoI bearing SIDBI: IFV: No. __________ dated ___________, are hereby accepted."
          );
          setValue1(
            "note2Subnote2",
            "I/We are authorized to accept the LoI as per the following document issued in my / our favour and which is valid as on date."
          );
          setValue1(
            "note3",
            "Please note that this communication should not be construed as giving rise to any binding obligation on the part of SIDBI, unless the loan agreement and other documents, if any, relating to the above facility are executed by your Bank in such form as may be required by SIDBI within " +
              no +
              " working days from the date of this Letter of Intent or such further time as may be allowed by SIDBI in its absolute discretion."
          );
          setValue1("loiUser", "");
          setValue1("userDesignation", "");
          setOfrName("");

          setValue1(
            "nameOfDocuments",
            "Power of Attorney / Authorization letter / Board resolution / any other document (please specify)"
          );
          setValue1("documentDated", "");
          setValue1("sectionOrClauseNo", "");
          setValue1("sectionMode", "Singly / Jointly");
          setValue1(
            "kycDocuments",
            "•	Aadhar Card / Passport / Driving License / Voter ID Card / PAN Card."
          );

          MasterService.findBankAddressByCifNumber(appId).then(
            (res) => {
              const appData1 = res.data;
              console.log(appData1);
              setValue1("addressOfTheBank", appData1);
            },
            (error) => {
              handleApiError(error, "loading bank address");
            }
          );

          MinutesService.findBankDetailsByAppNumber(appId).then(
            (res) => {
              const appData1 = res.data;
              console.log(appData1);
              let ifvNumber;
              if (CommonUtil.isEmpty(appData1[3])) {
                ifvNumber = appId + "/" + schemeName;
              } else {
                ifvNumber = appId + "/" + appData1[3] + "/" + schemeName;
              }

              setValue1("ifvNo", ifvNumber);
              if (loiId <= 0) {
                setValue1(
                  "note2Subnote1",
                  "“The terms and conditions contained in the attached LoI bearing SIDBI: IFV: No. " +
                    ifvNumber +
                    " dated ___________, are hereby accepted."
                );
              }
            },
            (error) => {
              handleApiError(error, "loading bank details");
            }
          );
        } else {
          setLoiId(appData.id);
          setValue1("id", appData.id);
          setValue1("sancId", appData.sancId);
          setValue1("sancDetailId", appData.sancDetailId);
          setValue1("appraisalMnuteId", appData.appraisalMnuteId);
          setValue1("ifvNo", appData.ifvNo);
          if (!CommonUtil.isEmpty(appData.ifvDate)) {
            setValue1("ifvDate", new Date(appData.ifvDate));
          }
          setValue1("addressOfTheBank", appData.addressOfTheBank);
          setValue1("headerNote", appData.headerNote);
          setValue1("note1", appData.note1);
          setValue1("note2", appData.note2);
          setValue1("note2Subnote1", appData.note2Subnote1);
          setValue1("note2Subnote2", appData.note2Subnote2);
          setValue1("note3", appData.note3);
          setValue1("loiUser", appData.loiUser);
          setValue1("userDesignation", appData.userDesignation);
          setOfrName(appData.loiUser);

          setValue1("nameOfDocuments", appData.nameOfDocuments);
          setValue1(
            "documentDated",
            appData.documentDated != null ? new Date(appData.documentDated) : ""
          );
          setValue1("sectionOrClauseNo", appData.sectionOrClauseNo);
          setValue1("sectionMode", appData.sectionMode);
          setValue1("kycDocuments", appData.kycDocuments);

          getLoIOrSanctionTermConditionsData(
            appId,
            prId,
            appData.id,
            minuteId,
            sancDtlCode
          );
        }

        if (appData?.id) {
          loadSignedLoIDocument(appData.id);
        }

        setLoading(false);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading LoI details");
      }
    );
  };

  const saveLoiDetails = (data, e) => {
    setLoading(true);
    data.ifvName = selectedObj.bankName;
    MinutesService.saveLoiDetails(data).then(
      (response) => {
        findLoIBySancIdAndSancDetailCode(
          response.data.sancDetailId,
          "",
          selectedObj.appId,
          selectedObj.prId,
          selectedObj.id,
          selectedObj.loanAmount
        );
        showMessage("LoI details have been successfully saved!", "success");
        setLoading(false);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "saving LoI details");
      }
    );
  };

  const [checkerList, setCheckerList] = useState([]);

  const getUserList = () => {
    setLoading(true);
    MinutesService.loadCheckers().then(
      (response) => {
        setLoading(false);
        setCheckerList(response.data);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading user list");
      }
    );
  };

  const [sancList, setSancList] = useState([]);

  const getSanctionMinutesById = () => {
    setLoading(true);
    MinutesService.getAllAppraisalMinutesDataBySancId(sancId).then(
      (response) => {
        setLoading(false);

        let finalData = response.data;

        if (!CommonUtil.isEmpty(finalData)) {
          finalData.map((item, index) => {
            if (item.schemeName.toUpperCase().includes("RMSE")) {
              item.schemeName = CommonUtil.extractTextUpToWord(item.fundName);
            }
          });
          setSancList(finalData);

          const obj = finalData[0];
          setSelectedObj(obj);
          setSelectedButton([]);
          setSelectedButton((prev) => ({ ...prev, 0: "true" }));
          findLoIBySancIdAndSancDetailCode(
            obj.sancDtlCode,
            obj.schemeName,
            obj.appId,
            obj.prId,
            obj.id,
            obj.loanAmount
          );
        } else {
          alert("No Data!");
        }
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading sanction details");
      }
    );
  };

  const generateLOI = () => {
    setLoading(true);
    MinutesService.generateLOIReport(loiId).then(
      (response) => {
        setLoading(false);
        FileUtil.downloadFile(
          response.data.fileDataBytea,
          response.data.fileName,
          "application/pdf"
        );
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "while generating report");
      }
    );
  };

  const [selectedButton, setSelectedButton] = useState([]);
  const [selectedObj, setSelectedObj] = useState({});

  const loadDetailsOfSanction = (obj, i) => {
    setSelectedButton([]);
    setSelectedButton((prev) => ({ ...prev, [i]: "true" }));
    setSelectedObj(obj);
    findLoIBySancIdAndSancDetailCode(
      obj.sancDtlCode,
      obj.schemeName,
      obj.appId,
      obj.prId,
      obj.id,
      obj.loanAmount
    );
  };

  const setUserDetails = (id) => {
    const checker = checkerList.find((item) => item.ofrCode == id);
    setValue1(
      "loiUser",
      CommonUtil.isEmpty(checker.shortName)
        ? checker.ofrName
        : checker.shortName
    );
    setValue1("userDesignation", checker.ofrDesgCode);
  };

  function capitalizeFirstLetter(sentence) {
    return sentence
      .split(" ")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  }

  const [sancTermsConditionsList, setSanctionTermsConditionsList] = useState(
    []
  );

  const getLoIOrSanctionTermConditionsData = (
    appId,
    prId,
    loiId,
    minuteId,
    sancDtlCode
  ) => {
    setLoading(true);
    MinutesService.findByloiId(loiId).then(
      (response) => {
        setLoading(true);

        MinutesService.getSanctionTermConditionsByAppNoAndPrId(
          appId,
          prId,
          loiId
        ).then(
          (res) => {
            setLoading(false);
            if (
              CommonUtil.isEmpty(res.data) ||
              CommonUtil.isEmpty(res.data[0].id)
            ) {
              alert("Appendix is empty!");
            } else {
              setSanctionTermsConditionsList(res.data);
              if (response.data.length <= 0) {
                setSelectedLoITermId(0);
                setSanctionTermsConditions(res.data[0], loiId);
              }
            }
          },
          (error) => {
            setLoading(false);
            handleApiError(
              error,
              "loading Details of Sanction terms and conditions"
            );
          }
        );

        if (response.data.length > 0) {
          let appData = response.data[0];
          setLoiTermsAndConditions(appData);
        }

        inputHandler(getValues16("tsRoiRepayment"), "roiPayment");
        inputHandler(getValues16("tsPrincipalRepayment"), "princRep");
        inputHandler(getValues16("tsIntrestPayment"), "intPay");
        inputHandler(getValues16("tsTenureWd"), "note");
        inputHandler(getValues16("tsExtent"), "extOfRefinance");
        inputHandler(getValues16("tsEligibleMse"), "eligEndBorrow");
        inputHandler(getValues16("tsEventDflt"), "eventOfDefault");
        inputHandler(getValues16("tsSecurity"), "security");
        inputHandler(getValues16("tsDocumentstion"), "docs");
        inputHandler(getValues16("tsTimeFrame"), "timeFrame");
        inputHandler(getValues16("tsDrawaloan"), "drawalOfLoan");
        setLoading(false);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading Details of LoI terms and conditions");
      }
    );
  };

  const setSanctionTermsConditions = (appData, loiId) => {
    MinutesService.getMinuteIdByLoiIdAndPrId(loiId, appData.prId).then(
      (res) => {
        const [k, v] = Object.entries(res.data)[0];
        setValue16("sancDetailId", k);
        setValue16("appraisalMinuteId", v);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading Minute Id");
      }
    );

    MinutesService.findByloiIdAndPrId(loiId, appData.prId).then(
      (res) => {
        if (CommonUtil.isEmpty(res.data) || CommonUtil.isEmpty(res.data.id)) {
          setSelectedLoITermId(0);
          setValue16("id", "");
          setValue16("ifvId", appData.ifvId);
          setValue16("prId", appData.prId);
          setValue16("loiId", loiId);
          setValue16("schemeName", appData.schemeName);
          let sch = appData.schemeName;

          if (appData.fundName?.toLowerCase().includes("rmse")) {
            sch = "RMSE";
          }
          setValue16("schemeNameAdv", sch);
          setValue16("fundName", appData.fundName);
          setValue16("amount", appData.amount);

          let words = CommonUtil.numberToWordsInCrores(appData.amount);
          // let capitalizedSentence = capitalizeFirstLetter(words);
          setAmountInCrores(words);
          setValue16(
            "amountInWords",
            appData.amountInWords === null ? words : appData.amountInWords
          );
          setValue16("tsRAteInterest", appData.tsRAteInterest);
          setNumberToWords(
            capitalizeFirstLetter(
              CommonUtil.numberToWords(appData.tsRAteInterest)
            )
          );
          setValue16("tsRoiRepayment", appData.tsRoiRepayment);
          setValue16("tsTenurePeriod", appData.tsTenurePeriod);
          setValue16("tsPrincipalRepayment", appData.tsPrincipalRepayment);
          setValue16("tsIntrestPayment", appData.tsIntrestPayment);
          setValue16("tsTenureWd", appData.tsTenureWd);
          setValue16("tsExtent", appData.tsExtent);
          setValue16("tsEligibleMse", appData.tsEligibleMse);
          setValue16("tsEligibleActivities", appData.tsEligibleActivities);
          setValue16("tsEventDflt", appData.tsEventDflt);
          setValue16("tsSecurity", appData.tsSecurity);
          setValue16("tsDocumentstion", appData.tsDocumentstion);
          setValue16("tsTimeFrame", appData.tsTimeFrame);
          setValue16("tsDrawaloan", appData.tsDrawaloan);
          setValue16("tsOtherCond", appData.tsOtherCond);

          if (appData.tsOtherCond != null) {
            const arrayOne = appData.tsOtherCond.split(",");
            let otherConditions = [];

            getAllOnMstParticulars()
              .then((formattedOptions) => {
                arrayOne.map((item, index) => {
                  const it = formattedOptions.find(
                    (obj) => obj["value"] === parseInt(item)
                  );
                  if (it !== undefined) {
                    otherConditions.push(it);
                  }
                });
                setSelectedOption(otherConditions);
              })
              .catch((error) => {
                setLoading(false);
                handleApiError(error, "loading conditions");
              });
          }

          setValue16("tsOutstandingAmount", appData.tsOutstandingAmount);
          setValue16("tsTermsection", appData.tsTermsection);
          setValue16("tsExtraConditions", appData.tsExtraConditions);
          setValue16("tsTenureApprox", appData.tsTenureApprox);

          setValue16("interestType", appData.interestType);
          setValue16("benchMark", appData.benchMark);
          setValue16("spread", appData.spread);
          setValue16("interestReset", appData.interestReset);

          setRepoRate(false);
          setThreeMTBillBenchmark(false);

          if (
            appData.interestType == "Floating" &&
            !CommonUtil.isEmpty(appData.benchMark) &&
            appData.benchMark.toLowerCase().includes("bill")
          ) {
            setThreeMTBillBenchmark(true);
            setBenchMarkSpread(
              appData.benchMark + " + " + appData.spread + " bps."
            );
          } else if (
            appData.interestType == "Floating" &&
            !CommonUtil.isEmpty(appData.benchMark) &&
            appData.benchMark.toLowerCase().includes("repo")
          ) {
            setRepoRate(true);
          }

          if (!CommonUtil.isEmpty(appData.interestReset)) {
            setEnableInterestReset(true);
          } else {
            setEnableInterestReset(false);
          }

          setValue16("benchMarkNote", appData.benchMarkNote);
          setValue16("interestResetNote", appData.interestResetNote);
        } else {
          setLoiTermsAndConditions(res.data);
        }
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading LoI terms and conditions");
      }
    );

    inputHandler(getValues16("tsRoiRepayment"), "roiPayment");
    inputHandler(getValues16("tsPrincipalRepayment"), "princRep");
    inputHandler(getValues16("tsIntrestPayment"), "intPay");
    inputHandler(getValues16("tsTenureWd"), "note");
    inputHandler(getValues16("tsExtent"), "extOfRefinance");
    inputHandler(getValues16("tsEligibleMse"), "eligEndBorrow");
    inputHandler(getValues16("tsEventDflt"), "eventOfDefault");
    inputHandler(getValues16("tsSecurity"), "security");
    inputHandler(getValues16("tsDocumentstion"), "docs");
    inputHandler(getValues16("tsTimeFrame"), "timeFrame");
    inputHandler(getValues16("tsDrawaloan"), "drawalOfLoan");
  };

  const setLoiTermsAndConditions = (appData) => {
    setSelectedLoITermId(appData.id);
    setValue16("id", appData.id);
    setValue16("ifvId", appData.ifvId);
    setValue16("prId", appData.prId);
    setValue16("loiId", appData.loiId);
    setValue16("sancDetailId", appData.sancDetailId);
    setValue16("appraisalMinuteId", appData.appraisalMinuteId);

    setValue16("schemeName", appData.schemeName);
    let sch = appData.schemeName;

    if (appData.fundName?.toLowerCase().includes("rmse")) {
      sch = "RMSE";
    }
    setValue16("schemeNameAdv", sch);
    setValue16("fundName", appData.fundName);
    setValue16("amount", appData.amount);

    let words = CommonUtil.numberToWordsInCrores(appData.amount);
    // let capitalizedSentence = capitalizeFirstLetter(words);
    setAmountInCrores(words);
    setValue16(
      "amountInWords",
      appData.amountInWords === null ? words : appData.amountInWords
    );
    setValue16("tsRAteInterest", appData.tsRAteInterest);
    setNumberToWords(
      capitalizeFirstLetter(CommonUtil.numberToWords(appData.tsRAteInterest))
    );
    setValue16("tsRoiRepayment", appData.tsRoiRepayment);
    setValue16("tsTenurePeriod", appData.tsTenurePeriod);
    setValue16("tsPrincipalRepayment", appData.tsPrincipalRepayment);
    setValue16("tsIntrestPayment", appData.tsIntrestPayment);
    setValue16("tsTenureWd", appData.tsTenureWd);
    setValue16("tsExtent", appData.tsExtent);
    setValue16("tsEligibleMse", appData.tsEligibleMse);
    setValue16("tsEligibleActivities", appData.tsEligibleActivities);
    setValue16("tsEventDflt", appData.tsEventDflt);
    setValue16("tsSecurity", appData.tsSecurity);
    setValue16("tsDocumentstion", appData.tsDocumentstion);
    setValue16("tsTimeFrame", appData.tsTimeFrame);
    setValue16("tsDrawaloan", appData.tsDrawaloan);
    setValue16("tsOtherCond", appData.tsOtherCond);

    if (appData.tsOtherCond != null) {
      const arrayOne = appData.tsOtherCond.split(",");
      let otherConditions = [];

      getAllOnMstParticulars()
        .then((formattedOptions) => {
          arrayOne.map((item, index) => {
            const it = formattedOptions.find(
              (obj) => obj["value"] === parseInt(item)
            );
            if (it !== undefined) {
              otherConditions.push(it);
            }
          });
          setSelectedOption(otherConditions);
        })
        .catch((error) => {
          setLoading(false);
          handleApiError(error, "loading conditions");
        });
    }

    setValue16("tsOutstandingAmount", appData.tsOutstandingAmount);
    setValue16("tsTermsection", appData.tsTermsection);
    setValue16("tsExtraConditions", appData.tsExtraConditions);
    setValue16("tsTenureApprox", appData.tsTenureApprox);

    setValue16("interestType", appData.interestType);
    setValue16("benchMark", appData.benchMark);
    setValue16("spread", appData.spread);
    setValue16("interestReset", appData.interestReset);

    setRepoRate(false);
    setThreeMTBillBenchmark(false);

    if (
      appData.interestType == "Floating" &&
      !CommonUtil.isEmpty(appData.benchMark) &&
      appData.benchMark.toLowerCase().includes("bill")
    ) {
      setThreeMTBillBenchmark(true);
      setBenchMarkSpread(appData.benchMark + " + " + appData.spread + " bps.");
    } else if (
      appData.interestType == "Floating" &&
      !CommonUtil.isEmpty(appData.benchMark) &&
      appData.benchMark.toLowerCase().includes("repo")
    ) {
      setRepoRate(true);
    }

    if (!CommonUtil.isEmpty(appData.interestReset)) {
      setEnableInterestReset(true);
    } else {
      setEnableInterestReset(false);
    }

    setValue16("benchMarkNote", appData.benchMarkNote);
    setValue16("interestResetNote", appData.interestResetNote);
  };

  const [options, setOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState([]);
  const handleChange = (val) => {
    setSelectedOption(val);
  };

  const [value, setValue] = useState(0);
  const handleTabChange = (event, newValue) => {
    setValue(newValue);
    loadDetailsOfSanction(sancList[newValue], newValue);
  };

  const getAllOnMstParticulars = () => {
    let formattedOptions = [];
    return IfvAppraisalService.getAllOnMstParticulars("Other Conditions").then(
      (response) => {
        const filteredData = response.data.filter(
          (item) => item.mstFlg === "Y"
        );

        formattedOptions = filteredData.map((item) => ({
          value: parseInt(item.mstCode),
          label: item.mstRemarks,
        }));
        setOptions(formattedOptions);
        // getMajorTermsAndConditionData(formattedOptions)
        //getProposedSchemesData(formattedOptions)

        return formattedOptions;
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();

        handleApiError(error, "loading Other Conditions");
        throw new Error(resMessage);
      }
    );
  };

  const [selectedLoITermId, setSelectedLoITermId] = useState(0);

  const onSubmitOfSanctionTermsAndConditions = (data, e) => {
    setLoading(true);
    let mstCodes = "";
    if (selectedOption.length > 0) {
      selectedOption.map((item, index) => {
        mstCodes = mstCodes.concat(item["value"] + ",");
      });
    }

    data.tsOtherCond = mstCodes;
    delete data.schemeNameAdv;

    MinutesService.saveLoiSanctionTermsConditions(data).then(
      (response) => {
        setLoading(false);
        showMessage(
          "Terms Conditions details have been successfully saved!",
          "success"
        );
        setSelectedLoITermId(response.data.id);
        getLoIOrSanctionTermConditionsData(
          selectedObj.appId,
          response.data.prId,
          response.data.loiId,
          response.data.appraisalMinuteId,
          response.data.sancDetailId
        );
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "saving Terms Conditions details");
      }
    );
  };

  const [amountInCrores, setAmountInCrores] = useState("");
  const [numberToWords, setNumberToWords] = useState("");

  const convertNumberToWords = (value) => {
    setNumberToWords(CommonUtil.numberToWords(parseFloat(value)));
  };

  const initialState = {
    roiPayment: "",
    princRep: "",
    intPay: "",
    note: "",
    extOfRefinance: "",
    eligEndBorrow: "",
    eventOfDefault: "",
    security: "",
    docs: "",
    timeFrame: "",
    drawalOfLoan: "",
  };
  const [input, setInput] = useState(initialState);
  const inputHandler = (value, input) => {
    setInput((prevState) => ({ ...prevState, [input]: value }));
  };

  const setSubNote1 = (e) => {
    const ifvNumber = getValues1("ifvNo");
    const originalDate = new Date(e.target.value);
    //const formattedDate = moment(originalDate, 'DD/MM/YYYY').format('MMMM D, YYYY');
    const formattedDate = format(originalDate, "MMMM d, yyyy");
    setValue1(
      "note2Subnote1",
      "“The terms and conditions contained in the attached LoI bearing SIDBI: IFV: No. " +
        ifvNumber +
        " dated " +
        formattedDate +
        ", are hereby accepted."
    );
  };

  const [selectedAnnexureTab, setSelectedAnnexureTab] = useState(0);
  const handleAnnexureTab = (event, newValue) => {
    setSelectedAnnexureTab(newValue);
    setSanctionTermsConditions(sancTermsConditionsList[newValue], loiId);
  };

  const setSubNote1ForLoI = (e) => {
    const ifvNumber = e.target.value;
    let formattedDate = "";

    if (!CommonUtil.isEmpty(getValues1("ifvDate"))) {
      const originalDate = new Date(getValues1("ifvDate"));
      formattedDate = format(originalDate, "MMMM d, yyyy");
    }

    setValue1(
      "note2Subnote1",
      `"The terms and conditions contained in the attached LoI bearing SIDBI: IFV: No. ${ifvNumber} dated ${formattedDate}, are hereby accepted.`
    );
  };

  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  //  const [loading, setLoading] = useState(false);
  // Login credentials
  const [credentials, setCredentials] = useState({
    username: "",
    password: "",
    localAddress: "",
  });
  // IFV form fields
  const [ifvForm, setIfvForm] = useState({
    username: "",
    documentName: "",
    region: "",
    language: "",
    folderId: "",
  });
  const [validationErrors, setValidationErrors] = useState({
    username: "",
    documentName: "",
    folderId: "",
    loginUsername: "",
    password: "",
    localAddress: "",
  });
  const validateUsername = (username) => {
    if (!username.trim()) {
      return "Username is required";
    }
    if (username.length < 3) {
      return "Username must be at least 3 characters long";
    }
    if (username.length > 50) {
      return "Username cannot exceed 50 characters";
    }
    if (!/^[a-zA-Z0-9._-]+$/.test(username)) {
      return "Username can only contain letters, numbers, dots, hyphens, and underscores";
    }
    return "";
  };

  const validateDocumentName = (documentName) => {
    if (!documentName.trim()) {
      return "Document name is required";
    }
    if (documentName.length < 2) {
      return "Document name must be at least 2 characters long";
    }
    if (documentName.length > 100) {
      return "Document name cannot exceed 100 characters";
    }
    if (!/^[a-zA-Z0-9\s._-]+$/.test(documentName)) {
      return "Document name can only contain letters, numbers, spaces, dots, hyphens, and underscores";
    }
    return "";
  };

  const validateFolderId = (folderId) => {
    if (!folderId.trim()) {
      return "Folder ID is required";
    }
    if (!/^\d+$/.test(folderId)) {
      return "Folder ID must contain only numbers";
    }
    if (folderId.length < 3) {
      return "Folder ID must be at least 3 digits long";
    }
    if (folderId.length > 20) {
      return "Folder ID cannot exceed 20 digits";
    }
    return "";
  };

  const validatePassword = (password) => {
    if (!password.trim()) {
      return "Password is required";
    }
    if (password.length < 6) {
      return "Password must be at least 6 characters long";
    }
    if (password.length > 100) {
      return "Password cannot exceed 100 characters";
    }
    return "";
  };

  const validateLocalAddress = (localAddress) => {
    if (!localAddress.trim()) {
      return "Local address is required";
    }
    // Basic IP address validation
    const ipPattern =
      /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (!ipPattern.test(localAddress)) {
      return "Please enter a valid IP address (e.g., 192.168.1.1)";
    }
    return "";
  };
  const handleClickOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const handleDMSTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };
  const handleIFVInputChange = (e) => {
    const { name, value } = e.target;

    // Update form state
    setIfvForm((prev) => ({
      ...prev,
      [name]: value,
    }));

    // Validate and update errors
    let error = "";
    switch (name) {
      case "username":
        error = validateUsername(value);
        break;
      case "documentName":
        error = validateDocumentName(value);
        break;
      case "folderId":
        error = validateFolderId(value);
        break;
      default:
        break;
    }

    setValidationErrors((prev) => ({
      ...prev,
      [name]: error,
    }));
  };

  const handleLoginInputChange = (e) => {
    const { name, value } = e.target;

    // Update credentials state (assuming you have this)
    setCredentials((prev) => ({
      ...prev,
      [name]: value,
    }));

    // Validate and update errors
    let error = "";
    switch (name) {
      case "username":
        error = validateUsername(value);
        setValidationErrors((prev) => ({
          ...prev,
          loginUsername: error,
        }));
        break;
      case "password":
        error = validatePassword(value);
        setValidationErrors((prev) => ({
          ...prev,
          password: error,
        }));
        break;
      case "localAddress":
        error = validateLocalAddress(value);
        setValidationErrors((prev) => ({
          ...prev,
          localAddress: error,
        }));
        break;
      default:
        break;
    }
  };
  const isLoginFormValid = () => {
    const usernameError = validateUsername(credentials.username);
    const passwordError = validatePassword(credentials.password);
    const localAddressError = validateLocalAddress(credentials.localAddress);

    return !usernameError && !passwordError && !localAddressError;
  };

  const isIFVFormValid = () => {
    const usernameError = validateUsername(ifvForm.username);
    const documentNameError = validateDocumentName(ifvForm.documentName);
    const folderIdError = validateFolderId(ifvForm.folderId);

    return (
      !usernameError &&
      !documentNameError &&
      !folderIdError &&
      ifvForm.region &&
      ifvForm.language
    );
  };

  const handleSelectChange = (name) => (event) => {
    setIfvForm((prev) => ({
      ...prev,
      [name]: event.target.value,
    }));
  };
  const handleLogin = async () => {
    // Validate all fields before submission
    const usernameError = validateUsername(credentials.username);
    const passwordError = validatePassword(credentials.password);
    const localAddressError = validateLocalAddress(credentials.localAddress);

    setValidationErrors((prev) => ({
      ...prev,
      loginUsername: usernameError,
      password: passwordError,
      localAddress: localAddressError,
    }));

    if (!isLoginFormValid()) {
      showMessage(
        "Please fix the validation errors before proceeding",
        "warning"
      );
      return;
    }

    setLoading(true);
    try {
      const response = await MinutesService.dmsLogin(credentials);
      if (response.data.success === true) {
        if (response.data.sessionId === "ACTIVE") {
          showMessage("Already session is active", "success");
        } else {
          sessionStorage.setItem("cvSessionId", response.data.sessionId);
          showMessage("Login successful", "success");
          setIfvForm((prev) => ({
            ...prev,
            username: credentials.username,
          }));
        }
        setActiveTab(1);
      } else {
        showMessage(response.data.errorMessage || "Login failed", "warning");
      }
    } catch (error) {
      handleApiError(error, "logging in");
    } finally {
      setLoading(false);
    }
  };

  const handleGetIFVNo = async () => {
    const usernameError = validateUsername(ifvForm.username);
    const documentNameError = validateDocumentName(ifvForm.documentName);
    const folderIdError = validateFolderId(ifvForm.folderId);

    setValidationErrors((prev) => ({
      ...prev,
      username: usernameError,
      documentName: documentNameError,
      folderId: folderIdError,
    }));

    if (!isIFVFormValid()) {
      showMessage(
        "Please fix the validation errors before proceeding",
        "warning"
      );
      return;
    }

    setLoading(true);
    try {
      const sessionId = sessionStorage.getItem("cvSessionId");
      const requestData = {
        username: ifvForm.username,
        documentName: ifvForm.documentName,
        region: ifvForm.region,
        language: ifvForm.language,
        folderId: ifvForm.folderId,
        sessionId: sessionId,
      };
      const response = await MinutesService.getIFVNo(requestData);
      if (response.data.success) {
        sessionStorage.removeItem("cvSessionId");
        const docNo = response.data.documentId;
        setValue1("ifvNo", docNo);
        setValue1("cvRegion", ifvForm.region);
        setValue1("cvLanguage", ifvForm.language);
        let formattedDate = "";

        if (!CommonUtil.isEmpty(getValues1("ifvDate"))) {
          const originalDate = new Date(getValues1("ifvDate"));
          formattedDate = format(originalDate, "MMMM d, yyyy");
        }
        setValue1(
          "note2Subnote1",
          `"The terms and conditions contained in the attached LoI bearing SIDBI: IFV: No. ${docNo} dated ${formattedDate}, are hereby accepted.`
        );
        showMessage(`IFV Number retrieved: ${docNo}`, "success");
        handleClose();
      } else {
        showMessage(
          response.data.errorMessage || "Failed to get IFV Number",
          "warning"
        );
      }
    } catch (error) {
      handleApiError(error, "getting IFV No");
    } finally {
      setLoading(false);
    }
  };
  // Check if a session exists
  const sessionExists =
    typeof window !== "undefined" && sessionStorage.getItem("cvSessionId");

  //Submit Signed LOI
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [signedLoiFile, setSignedLoiFile] = useState(null);
  const [signedLoiDocument, setSignedLoiDocument] = useState(null);

  const loadSignedLoIDocument = async (loiDetailsId) => {
    try {
      const response = await MinutesService.getSignedLoIDocument(loiDetailsId);

      setSignedLoiDocument(response.data?.data);
    } catch (error) {
      // Ignore not found
      setSignedLoiDocument(null);
    }
  };

  const submitSignedLoI = async () => {
    if (!signedLoiFile) {
      showMessage("Please select a signed LoI PDF", "warning");
      return;
    }

    try {
      setLoading(true);

      const payload = {
        loiDetailsId: loiId,
        amount: selectedObj.loanAmount,
        scheme: selectedObj.schemeName,
        uploadBy: IfvAppraisalService.getCurrentUser()?.ofrName,
      };

      await MinutesService.submitSignedLoI(signedLoiFile, payload);

      showMessage("Signed LoI uploaded successfully", "success");

      setUploadDialogOpen(false);
      setSignedLoiFile(null);
      loadSignedLoIDocument(loiId);
    } catch (error) {
      handleApiError(error, "uploading signed LoI");
    } finally {
      setLoading(false);
    }
  };

  const downloadSignedLoI = async () => {
    try {
      const response = await MinutesService.downloadSignedLoIDocument(
        signedLoiDocument.filePath
      );

      const url = window.URL.createObjectURL(new Blob([response.data]));

      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", signedLoiDocument.fileName);

      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      handleApiError(error, "downloading signed LoI");
    }
  };

  return (
    <Fragment>
      <div
        className={
          loading ? "col-md-12 mint blur-background" : "col-md-12 mint"
        }
      >
        <form key={1} onSubmit={handleSubmitOfLoIDetails(saveLoiDetails)}>
          <input type="hidden" {...register1("sancId")} value={sancId} />
          <input type="hidden" {...register1("sancDetailId")} />
          <input type="hidden" {...register1("id")} />
          <input type="hidden" {...register1("appraisalMnuteId")} />
          <input type="hidden" {...register1("loiUser")} />
          <input type="hidden" {...register1("userDesignation")} />
          <input type="hidden" {...register1("ifvName")} />
          <input type="hidden" {...register1("cvLanguage")} />
          <input type="hidden" {...register1("cvRegion")} />
          <>
            <div className="row mt-0">
              <div className="col-md-12 p-0">
                <div className="row no-prop alg_adst">
                  <div className="col-md-12">
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-end",
                        gap: 1,
                        mb: 1,
                        flexWrap: "wrap",
                      }}
                    >
                      {loiId > 0 && (
                        <Button
                          variant="contained"
                          color="primary"
                          startIcon={<i className="fa fa-file-signature" />}
                          onClick={generateLOI}
                          sx={{
                            borderRadius: 2,
                            textTransform: "none",
                            boxShadow: 2,
                          }}
                        >
                          Generate LoI
                        </Button>
                      )}

                      {loiId > 0 && !signedLoiDocument && (
                        <Button
                          variant="contained"
                          color="success"
                          startIcon={<i className="fa fa-upload" />}
                          onClick={() => setUploadDialogOpen(true)}
                          sx={{
                            borderRadius: 2,
                            textTransform: "none",
                            boxShadow: 2,
                          }}
                        >
                          Upload Signed LoI
                        </Button>
                      )}

                      {signedLoiDocument && (
                        <Button
                          variant="outlined"
                          color="success"
                          startIcon={<i className="fa fa-download" />}
                          onClick={downloadSignedLoI}
                          sx={{
                            borderRadius: 2,
                            textTransform: "none",
                          }}
                        >
                          Download Signed LoI
                        </Button>
                      )}
                    </Box>
                  </div>
                  <div className="col-md-12 pb-1 pt-3">
                    <h5 className="HdngTitl mb-0">LoI Details</h5>
                    <Box sx={{ width: "100%" }}>
                      <Tabs
                        value={value}
                        onChange={handleTabChange}
                        variant="scrollable"
                        scrollButtons="auto"
                        aria-label="sanction tabs"
                      >
                        {sancList.map((item, index) => (
                          <Tab
                            key={index}
                            label={`${item.appId} / ${item.bankName}`}
                          />
                        ))}
                      </Tabs>
                    </Box>
                  </div>
                  <div className="col-md-12 pb-1 pt-3"></div>
                  <div className="col-md-6">
                    <h2 className="heading">
                      <strong>Scheme:</strong> {selectedObj.schemeName}
                    </h2>
                  </div>
                  <div className="col-md-6">
                    <h2 className="heading">
                      <strong>Amount (₹ in crore):</strong> ₹
                      {selectedObj.loanAmount}
                    </h2>
                  </div>
                  {/* <div className="col-md-6">
                                        <h2 className="heading"><strong>RoI (%):</strong> {selectedObj.interestRate}</h2>
                                    </div>
                                    <div className="col-md-6">
                                        <h2 className="heading"><strong>Tenure (in months):</strong> {selectedObj.tenure}</h2>
                                    </div> */}

                  <div className="col pt-4">
                    <div data-mdb-input-init className="form-outline">
                      <Box
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                          marginBottom: "8px",
                          width: "100%",
                        }}
                      >
                        <label className="form-label" htmlFor="form3Example1">
                          <strong className="mndt">
                            {" "}
                            IFV No <span className="color-red"> *</span>
                          </strong>
                        </label>
                        {/* <Link
                                                    component="button"
                                                    onClick={(e) => { e.preventDefault(); handleClickOpen() }}
                                                    sx={{
                                                        textDecoration: 'underline',
                                                        fontWeight: 'bold',
                                                        fontSize: '0.875rem',
                                                        cursor: 'pointer',
                                                        textTransform: 'none',
                                                        marginLeft: 'auto'
                                                    }}
                                                >
                                                    Get IFV No from DMS
                                                </Link> */}
                      </Box>
                      <input
                        type="text"
                        className="form-control"
                        {...register1("ifvNo", {
                          required: "Field is required",
                        })}
                        onKeyUp={(e) => setSubNote1ForLoI(e)}
                        onChange={(e) => Pattern.sanitizeInput(e)}
                      />
                      <span className="vldn">
                        {errors1.ifvNo && errors1.ifvNo.message}
                      </span>
                    </div>
                  </div>

                  <div className="col pt-4">
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong className="mndt">
                          Date <span className="color-red"> *</span>
                        </strong>
                      </label>
                      <Controller
                        control={control}
                        name="ifvDate"
                        rules={{
                          required: {
                            value: true,
                            message: "Date is required",
                          },
                          validate: (value) => CommonUtil.validateDate(value),
                          onChange: (value) => setSubNote1(value),
                        }}
                        render={({
                          field: { onChange, onBlur, value, ref },
                        }) => (
                          <ReactDatePicker
                            className="form-control"
                            onChange={onChange}
                            onBlur={onBlur}
                            selected={value}
                            dateFormat="dd/MM/yyyy"
                            placeholderText="Select date"
                          />
                        )}
                        {...register1("ifvDate")}
                      />
                      <span className="vldn">
                        {errors1.ifvDate && errors1.ifvDate.message}
                      </span>
                    </div>
                  </div>

                  <div className="col-md-12">
                    <br />
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong>Address of Bank </strong>
                      </label>
                      <textarea
                        type="text"
                        className="form-control"
                        {...register1("addressOfTheBank", {
                          required: "Field is required",
                        })}
                      />
                      <span className="vldn">
                        {errors1.addressOfTheBank &&
                          errors1.addressOfTheBank.message}
                      </span>
                    </div>
                  </div>

                  <div className="col-md-12">
                    <br />
                    <div data-mdb-input-init className="form-outline">
                      <input
                        type="text"
                        className="form-control"
                        {...register1("headerNote", {
                          required: "Field is required",
                        })}
                      />
                      <span className="vldn">
                        {errors1.headerNote && errors1.headerNote.message}
                      </span>
                    </div>
                  </div>

                  <div className="col-md-12">
                    <br />
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong>Note 1:</strong>
                      </label>
                      <textarea
                        type="text"
                        className="form-control"
                        {...register1("note1", {
                          //  required: "Field is required",
                        })}
                      />
                      <span className="vldn">
                        {errors1.note1 && errors1.note1.message}
                      </span>
                    </div>
                  </div>

                  <div className="col-md-12">
                    <br />
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong>Note 2:</strong>
                      </label>
                      <textarea
                        type="text"
                        className="form-control"
                        {...register1("note2", {
                          //  required: "Field is required",
                        })}
                      />
                      <span className="vldn">
                        {errors1.note2 && errors1.note2.message}
                      </span>
                    </div>
                  </div>

                  <div className="col-md-12">
                    <br />
                    <div data-mdb-input-init className="form-outline">
                      <span className="color-red">
                        {" "}
                        Please keep this field data only if required. Otherwise,
                        please remove the autofilled data.
                      </span>
                      <textarea
                        type="text"
                        className="form-control"
                        {...register1("note2Subnote1", {
                          // required: "Field is required",
                        })}
                      />
                      <span className="vldn">
                        {errors1.note2Subnote1 && errors1.note2Subnote1.message}
                      </span>
                    </div>
                  </div>

                  <div className="col-md-12">
                    <br />
                    <div data-mdb-input-init className="form-outline">
                      <span className="color-red">
                        {" "}
                        Please keep this field data only if required. Otherwise,
                        please remove the autofilled data.
                      </span>
                      <textarea
                        type="text"
                        className="form-control"
                        {...register1("note2Subnote2", {
                          //  required: "Field is required",
                        })}
                      />
                      <span className="vldn">
                        {errors1.note2Subnote2 && errors1.note2Subnote2.message}
                      </span>
                    </div>
                  </div>

                  <div className="col-md-12">
                    <br />
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong>Name of the document:</strong>
                      </label>
                      <textarea
                        type="text"
                        className="form-control"
                        {...register1("nameOfDocuments", {
                          //  required: "Field is required",
                        })}
                      />
                      <span className="vldn">
                        {errors1.nameOfDocuments &&
                          errors1.nameOfDocuments.message}
                      </span>
                    </div>
                  </div>

                  <div className="col pt-4">
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong className="mndt">Dated:</strong>
                      </label>
                      <Controller
                        control={control}
                        name="documentDated"
                        rules={{
                          // required: {
                          //     value: true,
                          //    message: "Date is required",
                          //  },
                          validate: (value) =>
                            !CommonUtil.isEmpty(value)
                              ? CommonUtil.validateDate(value)
                              : true,
                        }}
                        render={({
                          field: { onChange, onBlur, value, ref },
                        }) => (
                          <ReactDatePicker
                            className="form-control"
                            onChange={onChange}
                            onBlur={onBlur}
                            selected={value}
                            dateFormat="dd/MM/yyyy"
                            placeholderText="Select date"
                          />
                        )}
                        {...register1("documentDated")}
                      />
                      <span className="vldn">
                        {errors1.documentDated && errors1.documentDated.message}
                      </span>
                    </div>
                  </div>

                  <div className="col pt-4">
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example1">
                        <strong className="mndt">
                          Section / Clause No. & Page Number:
                        </strong>
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        {...register1("sectionOrClauseNo", {
                          // required: "Field is required",
                        })}
                      />
                      <span className="vldn">
                        {errors1.sectionOrClauseNo &&
                          errors1.sectionOrClauseNo.message}
                      </span>
                    </div>
                  </div>

                  <div className="col-md-12">
                    <br />
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong>Mode:</strong>
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        {...register1("sectionMode", {
                          //  required: "Field is required",
                        })}
                      />
                      <span className="vldn">
                        {errors1.sectionMode && errors1.sectionMode.message}
                      </span>
                    </div>
                  </div>

                  <div className="col-md-12">
                    <br />
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong>
                          The following KYC documents of authorized signatories
                          are attached (Any one).
                        </strong>
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        {...register1("kycDocuments", {
                          //  required: "Field is required",
                        })}
                      />
                      <span className="vldn">
                        {errors1.kycDocuments && errors1.kycDocuments.message}
                      </span>
                    </div>
                  </div>

                  <div className="col-md-12">
                    <br />
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong>Note 3:</strong>
                      </label>
                      <textarea
                        type="text"
                        className="form-control"
                        {...register1("note3", {
                          //  required: "Field is required",
                        })}
                      />
                      <span className="vldn">
                        {errors1.note3 && errors1.note3.message}
                      </span>
                    </div>
                  </div>

                  <div className="col-md-6">
                    <br />
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong>User:</strong>
                      </label>
                      <select
                        className="form-select"
                        onChange={(e) => setUserDetails(e.target.value)}
                      >
                        <option value="">Please select user</option>
                        {checkerList.map((item, index) => (
                          <option
                            value={item.ofrCode}
                            selected={item.ofrName == ofrName}
                          >
                            {item.ofrName}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="button-container-center">
              <button type="submit" className="btn btnSave">
                {loiId > 0 ? "Update" : "Save"}{" "}
                <i className="fa fa-circle-check"></i>
              </button>
            </div>
          </>
        </form>
        <br />

        {loiId > 0 && (
          <Accordion flush>
            <Accordion.Item>
              <Accordion.Header>Annexure</Accordion.Header>
              <Accordion.Body>
                <h5
                  className="HdngTitl"
                  style={{ marginTop: "0.8rem", marginBottom: "1.5rem" }}
                >
                  Terms and Conditions of Sanction
                </h5>
                <div className="pergs">
                  <Tabs
                    value={selectedAnnexureTab}
                    onChange={handleAnnexureTab}
                    variant="scrollable"
                    scrollButtons="auto"
                    aria-label="proposed schemes tabs"
                    sx={{ marginBottom: "20px" }}
                  >
                    {sancTermsConditionsList.map((item, i) => (
                      <Tab
                        key={i}
                        label={
                          item.fundName?.toLowerCase().includes("rmse")
                            ? item.fundName
                            : item.schemeName
                        }
                      />
                    ))}
                  </Tabs>

                  <form
                    key={14}
                    onSubmit={handleSubmitOfTermsAndConditionData(
                      onSubmitOfSanctionTermsAndConditions
                    )}
                  >
                    <input type="hidden" {...register16("id")} />
                    <input
                      type="hidden"
                      {...register16("ifvId")}
                      value={sancId}
                    />
                    <input type="hidden" {...register16("prId")} />
                    <input type="hidden" {...register16("loiId")} />
                    <input type="hidden" {...register16("sancDetailId")} />
                    <input type="hidden" {...register16("appraisalMinuteId")} />
                    <div className="container-fluid p-0">
                      <div className="row">
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>
                              <strong>Fund</strong>
                            </label>
                            <input
                              type="text"
                              className="form-control"
                              {...register16("fundName")}
                              readOnly
                            />
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="form-group">
                            <label>
                              <strong>Scheme</strong>
                            </label>
                            <input
                              type="text"
                              className="form-control"
                              {...register16("schemeNameAdv")}
                              readOnly
                            />
                            <input
                              type="hidden"
                              className="form-control"
                              {...register16("schemeName")}
                              readOnly
                            />
                          </div>
                        </div>

                        <div className="col-md-3">
                          <div className="form-group">
                            <label>
                              <strong>Amount (₹ in crore)</strong>
                            </label>
                            <div className="brn_wrp">
                              <input
                                type="number"
                                step="any"
                                className="form-control"
                                {...register16("amount")}
                                readOnly
                              />
                            </div>
                          </div>
                        </div>

                        <div className="col-md-9">
                          <div className="form-group">
                            <label>
                              <strong>Amount (₹ in crore) In Words</strong>
                            </label>
                            <input
                              type="text"
                              className="form-control"
                              readOnly
                              value={amountInCrores}
                              {...register16("amountInWords", {
                                required: "Field is required",
                              })}
                            />
                            <span className="vldn">
                              {" "}
                              {errors16.amountInWords &&
                                errors16.amountInWords.message}
                            </span>
                          </div>
                        </div>
                        <div className="col-md-12 mt-3">
                          <div className="form-group">
                            <label>
                              <strong>Rate of Interest</strong>
                            </label>
                            <div className="branch_on">
                              <label>Interest will be charged @</label>
                              {ThreeMTBillBenchmark ? (
                                <>
                                  {" "}
                                  <div className="brn_wrp">
                                    <label>{benchMarkSpread}</label>
                                  </div>{" "}
                                </>
                              ) : (
                                <>
                                  {" "}
                                  <div className="brn_wrp">
                                    <input
                                      className="form-control"
                                      type="number"
                                      readOnly
                                      step="0.01"
                                      {...register16("tsRAteInterest", {
                                        onChange: (e) =>
                                          convertNumberToWords(e.target.value),
                                      })}
                                    />
                                  </div>
                                  <label> % p.a. </label>
                                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                  <label>
                                    {numberToWords} percent per annum
                                  </label>
                                </>
                              )}
                            </div>

                            {ThreeMTBillBenchmark && (
                              <>
                                <div className="col-md-12">
                                  <label>
                                    <strong>Interest Reset:</strong>
                                  </label>
                                  <div className="form-group">
                                    <textarea
                                      className="form-control"
                                      {...register16("interestResetNote", {
                                        maxLength: {
                                          value: 4000,
                                          message:
                                            "The maximum length of the field is 4000",
                                        },
                                      })}
                                      maxLength="4000"
                                      onChange={(e) => {
                                        Pattern.sanitizeInput(e);
                                      }}
                                    />
                                    <span className="vldn">
                                      {" "}
                                      {errors16.interestResetNote &&
                                        errors16.interestResetNote.message}
                                    </span>
                                  </div>
                                </div>

                                <div className="col-md-12">
                                  <label>
                                    <strong>Benchmark:</strong>
                                  </label>
                                  <div className="form-group">
                                    <textarea
                                      className="form-control"
                                      {...register16("benchMarkNote", {
                                        maxLength: {
                                          value: 4000,
                                          message:
                                            "The maximum length of the field is 4000",
                                        },
                                      })}
                                      maxLength="4000"
                                      onChange={(e) => {
                                        Pattern.sanitizeInput(e);
                                      }}
                                    />
                                    <span className="vldn">
                                      {" "}
                                      {errors16.benchMarkNote &&
                                        errors16.benchMarkNote.message}
                                    </span>
                                  </div>
                                </div>
                              </>
                            )}

                            <div className="col-md-12">
                              <label
                                className="prog_lbl"
                                style={{
                                  justifyContent: "right",
                                  marginBottom: "6px",
                                }}
                              >
                                <div className="prgs">
                                  <span className="lft_crt">
                                    {4000 - input["roiPayment"].length}{" "}
                                    Characters left
                                  </span>
                                  <LinearProgress
                                    variant="determinate"
                                    value={input["roiPayment"].length}
                                  />
                                </div>
                              </label>
                              <div className="form-group">
                                {/* <label>The unpaid interest shall also bear interest on monthly rest at the agreed rate till its repayments.</label> */}
                                <textarea
                                  className="form-control"
                                  {...register16("tsRoiRepayment", {
                                    maxLength: {
                                      value: 4000,
                                      message:
                                        "The maximum length of the field is 4000",
                                    },
                                    validate: (value) => {
                                      if (
                                        Pattern.validateHtmlTags().test(value)
                                      )
                                        return "Invalid value";
                                      return true;
                                    },
                                  })}
                                  maxLength="4000"
                                  onChange={(e) => {
                                    Pattern.sanitizeInput(e);
                                    inputHandler(e.target.value, "roiPayment");
                                  }}
                                />
                                <span className="vldn">
                                  {" "}
                                  {errors16.tsRoiRepayment &&
                                    errors16.tsRoiRepayment.message}
                                </span>
                              </div>
                            </div>
                            {repoRate && (
                              <>
                                <div className="col-md-12">
                                  <label>
                                    <strong>Reset of interest rate:</strong>
                                  </label>
                                  <div className="form-group">
                                    <textarea
                                      className="form-control"
                                      {...register16("interestResetNote", {
                                        maxLength: {
                                          value: 4000,
                                          message:
                                            "The maximum length of the field is 4000",
                                        },
                                      })}
                                      maxLength="4000"
                                      onChange={(e) => {
                                        Pattern.sanitizeInput(e);
                                      }}
                                    />
                                    <span className="vldn">
                                      {" "}
                                      {errors16.interestResetNote &&
                                        errors16.interestResetNote.message}
                                    </span>
                                  </div>
                                </div>
                              </>
                            )}

                            {!ThreeMTBillBenchmark &&
                              !repoRate &&
                              enableInterestReset && (
                                <div className="col-md-12">
                                  <label>
                                    <strong>Interest Reset:</strong>
                                  </label>
                                  <div className="form-group">
                                    <textarea
                                      className="form-control"
                                      {...register16("interestResetNote", {
                                        maxLength: {
                                          value: 4000,
                                          message:
                                            "The maximum length of the field is 4000",
                                        },
                                      })}
                                      maxLength="4000"
                                      onChange={(e) => {
                                        Pattern.sanitizeInput(e);
                                      }}
                                    />
                                    <span className="vldn">
                                      {" "}
                                      {errors16.interestResetNote &&
                                        errors16.interestResetNote.message}
                                    </span>
                                  </div>
                                </div>
                              )}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="form-group msersWrap">
                      <div className="row">
                        <div className="branch_on">
                          <label>Tenure: </label>
                          <div className="brn_wrp">
                            <input
                              className="form-control"
                              type="number"
                              step="0.01"
                              readOnly
                              {...register16("tsTenurePeriod", {
                                required: "Field is required",
                                pattern: {
                                  value: /^(?!0(?:\.0*|)$)\d*(?:\.\d+)?$/,
                                  message: "Invalid value",
                                },
                              })}
                            />
                            <span className="vldn">
                              {" "}
                              {errors16.tsTenurePeriod &&
                                errors16.tsTenurePeriod.message}
                            </span>
                          </div>
                          <label> months </label>
                          <input
                            className="form-control"
                            type="text"
                            defaultValue="(Approx.)"
                            {...register16("tsTenureApprox")}
                            autoComplete="off"
                            onChange={(e) => Pattern.sanitizeInput(e)}
                          />
                          <span className="vldn">
                            {" "}
                            {errors16.tsTenureApprox &&
                              errors16.tsTenureApprox.message}
                          </span>
                        </div>
                      </div>
                      <div className="container-fluid pt-0">
                        <div className="row">
                          <div className="col-md-6 ps-0">
                            <label className="prog_lbl">
                              <strong>Principal Repayment</strong>
                              <div className="prgs">
                                <span className="lft_crt">
                                  {4000 - input["princRep"]?.length} Characters
                                  left
                                </span>
                                <LinearProgress
                                  variant="determinate"
                                  value={input["princRep"]?.length}
                                />
                              </div>
                            </label>
                            <div className="form-group">
                              {/* The principal would be repayable in quarterly instaliments starting from the date of first disbursement commencing from 10th of the month concerned. The repayment schedule shall be drawn accordingly based on the date on which first disbursement is affected */}
                              <textarea
                                className="form-control mt-2"
                                {...register16("tsPrincipalRepayment", {
                                  maxLength: {
                                    value: 4000,
                                    message:
                                      "The maximum length of the field is 4000",
                                  },
                                  validate: (value) => {
                                    if (Pattern.validateHtmlTags().test(value))
                                      return "Invalid value";
                                    return true;
                                  },
                                })}
                                maxLength="4000"
                                onChange={(e) => {
                                  Pattern.sanitizeInput(e);
                                  inputHandler(e.target.value, "princRep");
                                }}
                              />
                              <span className="vldn">
                                {" "}
                                {errors16.tsPrincipalRepayment &&
                                  errors16.tsPrincipalRepayment.message}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-6 pe-0">
                            <label className="prog_lbl">
                              <strong>Interest Payment</strong>
                              <div className="prgs">
                                <span className="lft_crt">
                                  {4000 - input["intPay"].length} Characters
                                  left
                                </span>
                                <LinearProgress
                                  variant="determinate"
                                  value={input["intPay"].length}
                                />
                              </div>
                            </label>
                            <div className="form-group">
                              {/* Interest shall be paid on monthly basis on the 10th day of each month starting from 10th day of the subsequent month from the date of first disbursement. */}
                              <textarea
                                className="form-control mt-2"
                                {...register16("tsIntrestPayment", {
                                  maxLength: {
                                    value: 4000,
                                    message:
                                      "The maximum length of the field is 4000",
                                  },
                                  validate: (value) => {
                                    if (Pattern.validateHtmlTags().test(value))
                                      return "Invalid value";
                                    return true;
                                  },
                                })}
                                maxLength="4000"
                                onChange={(e) => {
                                  Pattern.sanitizeInput(e);
                                  inputHandler(e.target.value, "intPay");
                                }}
                              />
                              <span className="vldn">
                                {" "}
                                {errors16.tsIntrestPayment &&
                                  errors16.tsIntrestPayment.message}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="row mt-2">
                          <div className="col-md-12 p-0">
                            <label
                              className="prog_lbl"
                              style={{
                                justifyContent: "right",
                                marginBottom: "6px",
                              }}
                            >
                              <div className="prgs">
                                <span className="lft_crt">
                                  {4000 - input["note"].length} Characters left
                                </span>
                                <LinearProgress
                                  variant="determinate"
                                  value={input["note"].length}
                                />
                              </div>
                            </label>
                            <div className="form-group">
                              {/* However, if the due date of repayment falls on Saturday/Sunday/ Holidays under N.1. Act, the due date of payment would be the preceding working day. */}
                              <textarea
                                className="form-control mt-2"
                                {...register16("tsTenureWd", {
                                  maxLength: {
                                    value: 4000,
                                    message:
                                      "The maximum length of the field is 4000",
                                  },
                                  validate: (value) => {
                                    if (Pattern.validateHtmlTags().test(value))
                                      return "Invalid value";
                                    return true;
                                  },
                                })}
                                maxLength="4000"
                                onChange={(e) => {
                                  Pattern.sanitizeInput(e);
                                  inputHandler(e.target.value, "note");
                                }}
                              />
                              <span className="vldn">
                                {" "}
                                {errors16.tsTenureWd &&
                                  errors16.tsTenureWd.message}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="container-fluid mt-4 p-0">
                      <div className="row">
                        <div className="col-md-12">
                          <div className="form-group">
                            <label className="prog_lbl">
                              <strong>Extent of Refinance</strong>
                              <div className="prgs">
                                <span className="lft_crt">
                                  {4000 - input["extOfRefinance"].length}{" "}
                                  Characters left
                                </span>
                                <LinearProgress
                                  variant="determinate"
                                  value={input["extOfRefinance"].length}
                                />
                              </div>
                            </label>

                            <textarea
                              className="form-control"
                              {...register16("tsExtent", {
                                maxLength: {
                                  value: 4000,
                                  message:
                                    "The maximum length of the field is 4000",
                                },
                                validate: (value) => {
                                  if (Pattern.validateHtmlTags().test(value))
                                    return "Invalid value";
                                  return true;
                                },
                              })}
                              maxLength="4000"
                              onChange={(e) => {
                                Pattern.sanitizeInput(e);
                                inputHandler(e.target.value, "extOfRefinance");
                              }}
                            />
                            <span className="vldn">
                              {" "}
                              {errors16.tsExtent && errors16.tsExtent.message}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="row mt-3">
                        <div className="col-md-12">
                          <div className="form-group">
                            <label className="prog_lbl">
                              <strong>
                                Eligible end borrowers/underlying assets
                              </strong>
                              <div className="prgs">
                                <span className="lft_crt">
                                  {4000 - input["eligEndBorrow"].length}{" "}
                                  Characters left
                                </span>
                                <LinearProgress
                                  variant="determinate"
                                  value={input["eligEndBorrow"].length}
                                />
                              </div>
                            </label>

                            <textarea
                              className="form-control"
                              {...register16("tsEligibleMse", {
                                maxLength: {
                                  value: 4000,
                                  message:
                                    "The maximum length of the field is 4000",
                                },
                                validate: (value) => {
                                  if (Pattern.validateHtmlTags().test(value))
                                    return "Invalid value";
                                  return true;
                                },
                              })}
                              maxLength="4000"
                              onChange={(e) => {
                                Pattern.sanitizeInput(e);
                                inputHandler(e.target.value, "eligEndBorrow");
                              }}
                            />
                            <span className="vldn">
                              {" "}
                              {errors16.tsEligibleMse &&
                                errors16.tsEligibleMse.message}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="row  mt-3">
                        <div className="col-md-12">
                          <div className="form-group">
                            <label>
                              <strong>Eligible Activities</strong>
                            </label>
                            As Defined in Sction 2(h) of SIDBI Act.
                          </div>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-md-12">
                          <div className="form-group">
                            <label className="prog_lbl">
                              <strong>Event of Default</strong>
                              <div className="prgs">
                                <span className="lft_crt">
                                  {4000 - input["eventOfDefault"].length}{" "}
                                  Characters left
                                </span>
                                <LinearProgress
                                  variant="determinate"
                                  value={input["eventOfDefault"].length}
                                />
                              </div>
                            </label>

                            <textarea
                              className="form-control"
                              {...register16("tsEventDflt", {
                                maxLength: {
                                  value: 4000,
                                  message:
                                    "The maximum length of the field is 4000",
                                },
                                validate: (value) => {
                                  if (Pattern.validateHtmlTags().test(value))
                                    return "Invalid value";
                                  return true;
                                },
                              })}
                              maxLength="4000"
                              onChange={(e) => {
                                Pattern.sanitizeInput(e);
                                inputHandler(e.target.value, "eventOfDefault");
                              }}
                            />
                            <span className="vldn">
                              {" "}
                              {errors16.tsEventDflt &&
                                errors16.tsEventDflt.message}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="row mt-3">
                        <div className="col-md-12">
                          <div className="form-group">
                            <label className="prog_lbl">
                              <strong>Security</strong>
                              <div className="prgs">
                                <span className="lft_crt">
                                  {4000 - input["security"].length} Characters
                                  left
                                </span>
                                <LinearProgress
                                  variant="determinate"
                                  value={input["security"].length}
                                />
                              </div>
                            </label>
                            <textarea
                              className="form-control"
                              {...register16("tsSecurity", {
                                maxLength: {
                                  value: 4000,
                                  message:
                                    "The maximum length of the field is 4000",
                                },
                                validate: (value) => {
                                  if (Pattern.validateHtmlTags().test(value))
                                    return "Invalid value";
                                  return true;
                                },
                              })}
                              maxLength="4000"
                              onChange={(e) => {
                                Pattern.sanitizeInput(e);
                                inputHandler(e.target.value, "security");
                              }}
                            />
                            <span className="vldn">
                              {" "}
                              {errors16.tsSecurity &&
                                errors16.tsSecurity.message}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="row mt-3">
                        <div className="col-md-12">
                          <div className="form-group">
                            <label className="prog_lbl">
                              <strong>Documentation</strong>
                              <div className="prgs">
                                <span className="lft_crt">
                                  {4000 - input["docs"].length} Characters left
                                </span>
                                <LinearProgress
                                  variant="determinate"
                                  value={input["docs"].length}
                                />
                              </div>
                            </label>
                            <textarea
                              className="form-control"
                              {...register16("tsDocumentstion", {
                                maxLength: {
                                  value: 4000,
                                  message:
                                    "The maximum length of the field is 4000",
                                },
                                validate: (value) => {
                                  if (Pattern.validateHtmlTags().test(value))
                                    return "Invalid value";
                                  return true;
                                },
                              })}
                              maxLength="4000"
                              onChange={(e) => {
                                Pattern.sanitizeInput(e);
                                inputHandler(e.target.value, "docs");
                              }}
                            />
                            <span className="vldn">
                              {" "}
                              {errors16.tsDocumentstion &&
                                errors16.tsDocumentstion.message}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="row mt-3">
                        <div className="col-md-12">
                          <div className="form-group">
                            <label className="prog_lbl">
                              <strong>
                                Time Frame for Aceptance of LoI/Disbursement
                              </strong>
                              <div className="prgs">
                                <span className="lft_crt">
                                  {4000 - input["timeFrame"].length} Characters
                                  left
                                </span>
                                <LinearProgress
                                  variant="determinate"
                                  value={input["timeFrame"].length}
                                />
                              </div>
                            </label>
                            <textarea
                              className="form-control"
                              {...register16("tsTimeFrame", {
                                maxLength: {
                                  value: 4000,
                                  message:
                                    "The maximum length of the field is 4000",
                                },
                                validate: (value) => {
                                  if (Pattern.validateHtmlTags().test(value))
                                    return "Invalid value";
                                  return true;
                                },
                              })}
                              maxLength="4000"
                              onChange={(e) => {
                                Pattern.sanitizeInput(e);
                                inputHandler(e.target.value, "timeFrame");
                              }}
                            />
                            <span className="vldn">
                              {" "}
                              {errors16.tsTimeFrame &&
                                errors16.tsTimeFrame.message}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="row mt-3">
                        <div className="col-md-12">
                          <div className="form-group">
                            <label className="prog_lbl">
                              <strong>Drawal of Loan</strong>
                              <div className="prgs">
                                <span className="lft_crt">
                                  {4000 - input["drawalOfLoan"].length}{" "}
                                  Characters left
                                </span>
                                <LinearProgress
                                  variant="determinate"
                                  value={input["drawalOfLoan"].length}
                                />
                              </div>
                            </label>
                            {/* SIDBI reserves the right to disburse the amount in lump sum or in one or more tranches, at mutually agreed rates of interest depending upon the market conditions. */}
                            <textarea
                              className="form-control"
                              {...register16("tsDrawaloan", {
                                maxLength: {
                                  value: 4000,
                                  message:
                                    "The maximum length of the field is 4000",
                                },
                                validate: (value) => {
                                  if (Pattern.validateHtmlTags().test(value))
                                    return "Invalid value";
                                  return true;
                                },
                              })}
                              maxLength="4000"
                              onChange={(e) => {
                                Pattern.sanitizeInput(e);
                                inputHandler(e.target.value, "drawalOfLoan");
                              }}
                            />
                            <span className="vldn">
                              {" "}
                              {errors16.tsDrawaloan &&
                                errors16.tsDrawaloan.message}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="row mt-3">
                        <div className="col-md-12">
                          <div className="form-group">
                            <label>
                              <strong>Other Conditions</strong>
                            </label>
                            {/* <textarea className='form-control' {...register16('tsOtherCond')} /> */}

                            <Select
                              isMulti
                              value={selectedOption}
                              onChange={handleChange}
                              options={options}
                              // {...register16('tsOtherCond')}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="button-container-center">
                      {selectedLoITermId <= 0 && (
                        <p className="color-red">
                          Please save the autofilled data before proceeding.
                        </p>
                      )}
                    </div>
                    <div className="button-container-center mb-4">
                      {
                        <button type="submit" className="save">
                          {selectedLoITermId <= 0 ? "Save" : "Update"}{" "}
                          <i className="fa fa-circle-check"></i>
                        </button>
                      }
                    </div>
                  </form>
                </div>
              </Accordion.Body>
            </Accordion.Item>
          </Accordion>
        )}
      </div>
      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>DMS Portal</DialogTitle>
        <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
          <Tabs
            value={activeTab}
            onChange={handleDMSTabChange}
            aria-label="DMS tabs"
          >
            <Tab label="Login" />
            <Tab label="Get IFV Number" disabled={!sessionExists} />
          </Tabs>
        </Box>
        <DialogContent>
          {activeTab === 0 && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <TextField
                label="Username"
                name="username"
                value={credentials.username}
                onChange={handleLoginInputChange}
                fullWidth
                required
                size="small"
                error={!!validationErrors.loginUsername}
                helperText={validationErrors.loginUsername}
              />
              <TextField
                label="Password"
                name="password"
                type="password"
                value={credentials.password}
                onChange={handleLoginInputChange}
                fullWidth
                required
                size="small"
                error={!!validationErrors.password}
                helperText={validationErrors.password}
              />
              <TextField
                label="Local Address (IP)"
                name="localAddress"
                value={credentials.localAddress}
                onChange={handleLoginInputChange}
                fullWidth
                required
                size="small"
                error={!!validationErrors.localAddress}
                helperText={validationErrors.localAddress}
              />
            </Stack>
          )}
          {activeTab === 1 && (
            <Stack spacing={2} sx={{ mt: 1 }}>
              <TextField
                label="Username"
                name="username"
                value={ifvForm.username}
                onChange={(e) => {
                  Pattern.sanitizeInput(e);
                  handleIFVInputChange(e);
                }}
                fullWidth
                required
                size="small"
                error={!!validationErrors.username}
                helperText={validationErrors.username}
              />

              <TextField
                label="Document Name"
                name="documentName"
                value={ifvForm.documentName}
                onChange={handleIFVInputChange}
                fullWidth
                required
                size="small"
                error={!!validationErrors.documentName}
                helperText={validationErrors.documentName}
              />

              <FormControl fullWidth size="small" required>
                <InputLabel id="region-label" shrink={!!ifvForm.region}>
                  Region
                </InputLabel>
                <MuiSelect
                  labelId="region-label"
                  id="region"
                  label="Region"
                  name="region"
                  value={ifvForm.region}
                  onChange={handleSelectChange("region")}
                  displayEmpty
                >
                  <MenuItem value="A">A</MenuItem>
                  <MenuItem value="B">B</MenuItem>
                  <MenuItem value="C">C</MenuItem>
                </MuiSelect>
              </FormControl>

              <FormControl fullWidth size="small" required>
                <InputLabel id="language-label" shrink={!!ifvForm.language}>
                  Language
                </InputLabel>
                <MuiSelect
                  labelId="language-label"
                  id="language"
                  label="Language"
                  name="language"
                  value={ifvForm.language}
                  onChange={handleSelectChange("language")}
                  displayEmpty
                >
                  <MenuItem value="ENGLISH">ENGLISH</MenuItem>
                  <MenuItem value="BILINGUAL">BILINGUAL</MenuItem>
                  <MenuItem value="HINDI">HINDI</MenuItem>
                  <MenuItem value="OTHERS">OTHERS</MenuItem>
                  <MenuItem value="SIGNED IN ENGLISH">
                    SIGNED IN ENGLISH
                  </MenuItem>
                  <MenuItem value="SIGNED IN HINDI">SIGNED IN HINDI</MenuItem>
                </MuiSelect>
              </FormControl>

              <TextField
                label="Folder ID"
                name="folderId"
                value={ifvForm.folderId}
                onChange={handleIFVInputChange}
                fullWidth
                required
                size="small"
                error={!!validationErrors.folderId}
                helperText={validationErrors.folderId}
              />

              <Alert severity="info">
                Note:{" "}
                {env === "dev" || env === "uat"
                  ? "Folder ID for UAT is 392904."
                  : env === "prod"
                  ? "Please enter the Folder ID generated from DMS."
                  : "Environment not recognized."}
              </Alert>
            </Stack>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          {activeTab === 0 && (
            <Button
              onClick={handleLogin}
              variant="contained"
              disabled={!isLoginFormValid() || loading}
            >
              {loading ? "Logging in..." : "Login"}
            </Button>
          )}
          {activeTab === 1 && (
            <Button
              onClick={handleGetIFVNo}
              variant="contained"
              disabled={!isIFVFormValid() || loading}
            >
              {loading ? "Processing..." : "Get IFV Number"}
            </Button>
          )}
        </DialogActions>
      </Dialog>
      <Dialog
        open={uploadDialogOpen}
        onClose={() => setUploadDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Upload Signed LoI</DialogTitle>

        <DialogContent>
          <Box sx={{ mt: 2 }}>
            <Button component="label" variant="outlined" fullWidth>
              Select Signed LoI PDF
              <input
                hidden
                type="file"
                accept=".pdf"
                onChange={(e) => setSignedLoiFile(e.target.files?.[0] || null)}
              />
            </Button>

            {signedLoiFile && (
              <Typography sx={{ mt: 2 }} color="success.main">
                Selected File: {signedLoiFile.name}
              </Typography>
            )}
          </Box>
        </DialogContent>

        <DialogActions>
          <Button
            onClick={() => {
              setUploadDialogOpen(false);
              setSignedLoiFile(null);
            }}
          >
            Cancel
          </Button>

          <Button
            variant="contained"
            disabled={!signedLoiFile}
            onClick={submitSignedLoI}
          >
            Confirm Submit
          </Button>
        </DialogActions>
      </Dialog>
      {loading && <Loading />}
      <MessageModal
        open={isOpen}
        onClose={hideMessage}
        message={messageConfig.message}
        type={messageConfig.type}
        totalMessages={totalMessages}
        currentIndex={currentIndex}
        onNext={nextMessage}
        onPrev={prevMessage}
        hasNext={hasNext}
        hasPrev={hasPrev}
      />
    </Fragment>
  );
};

export default GenerateLOI;
