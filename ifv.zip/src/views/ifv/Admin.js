import Loading from 'components/Loading';
import { Fragment, useState } from 'react';
import {
    Modal
} from "react-bootstrap";
import 'react-datepicker/dist/react-datepicker.css';
import { useFieldArray, useForm } from "react-hook-form";
import IfvAppraisalService from 'services/IfvAppraisalService';
import CommonUtil from 'services/utils/CommonUtil';


const Admin = () => {

    const { control: control1, register: register1, handleSubmit: handleSubmitOfOtherConditions, setValue: setValue1, getValues: getValues1, formState: { errors: errors1 }, } = useForm({
        mode: "onBlur"
    });

    const { fields: fields1, append: append1, remove: remove1 } = useFieldArray({
        control: control1, // control props comes from useForm (optional: if you are using FormContext)
        name: "otherConditions", // unique name for your Field Array
    });

    const { control: control2, register: register2, handleSubmit: handleSubmitOfRecommendations, setValue: setValue2, getValues: getValues2, formState: { errors: errors2 }, } = useForm({
        mode: "onBlur"
    });

    const { fields: fields2, append: append2, remove: remove2 } = useFieldArray({
        control: control2, // control props comes from useForm (optional: if you are using FormContext)
        name: "recommendations", // unique name for your Field Array
    });

    const [loading, setLoading] = useState(false)
    const [showOtherConditions, setShowOtherConditions] = useState(false);
    const handleOtheConditionsClose = () => setShowOtherConditions(false)
    const [showMsg, setShowMsg] = useState(false)
    const [message, setMessage] = useState('')
    const hideMsg = () => setShowMsg(false);

    const [showRecommendatrions, setShowRecommendations] = useState(false);
    const handleRecommendationsClose = () => setShowRecommendations(false)

    const showOtherConditionsModal = () => {
        setLoading(true)
        IfvAppraisalService.getAllOnMstParticulars("Other Conditions").then(
            (response) => {

                response.data.forEach((item, index) => {
                    remove1(index)
                    append1({})

                    setValue1(`otherConditions[${index}].mstCode`, item.mstCode)
                    setValue1(`otherConditions[${index}].mstParticulars`, item.mstParticulars)
                    setValue1(`otherConditions[${index}].mstRemarks`, item.mstRemarks)
                    setValue1(`otherConditions[${index}].mstOrder`, item.mstOrder)
                    setValue1(`otherConditions[${index}].mstFlg`, item.mstFlg)
                });

                setLoading(false)
                setShowOtherConditions(true)

            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                setLoading(false)
                setMessage('Error occured while loading other conditions: ' + resMessage)
                setShowMsg(true)
            }
        )


    }

    const handleotherConditionDelete = (index) => {
        const id = getValues1(`otherConditions[${index}].mstCode`)
        if (CommonUtil.isValidNumber(id)) {
            setMessage('Cannot be deleted')
            setShowMsg(true)
            // IfvAppraisalService.deleteOtherCondition(id).then((response) => {
            //     setValue1(`otherConditions[${index}]`, undefined)
            //     remove1(index)
            //     setMessage('Other condition deleted successfully!')
            //     setShowMsg(true)
            // },
            //     (error) => {
            //         const resMessage =
            //             (error.response &&
            //                 error.response.data &&
            //                 error.response.data.message) ||
            //             error.message ||
            //             error.toString();

            //         setMessage('Error occured while deleting other conditions: ' + resMessage)
            //         setShowMsg(true)
            //     }
            // )
        } else {
            remove1(index)
        }
    }

    const onSubmitOfOtherCondition = (data, e) => {
        IfvAppraisalService.saveAllOtherConditions(data['otherConditions']).then((response) => {
            showOtherConditionsModal()
            setMessage('Other conditions details have been successfully saved!')
            setShowMsg(true)
        },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                setMessage('Error occured while saving other conditions: ' + resMessage)
                setShowMsg(true)
            })
    }

    const showRecommendationsModal = () => {
        setLoading(true)
        IfvAppraisalService.getAllOnMstParticulars("Recommendation").then(
            (response) => {

                response.data.forEach((item, index) => {
                    remove2(index)
                    append2({})

                    setValue2(`recommendations[${index}].mstCode`, item.mstCode)
                    setValue2(`recommendations[${index}].mstParticulars`, item.mstParticulars)
                    setValue2(`recommendations[${index}].mstRemarks`, item.mstRemarks)
                    setValue2(`recommendations[${index}].mstOrder`, item.mstOrder)
                    setValue2(`recommendations[${index}].mstFlg`, item.mstFlg)
                });

                setLoading(false)
                setShowRecommendations(true)

            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                setLoading(false)
                setMessage('Error occured while loading recommendations: ' + resMessage)
                setShowMsg(true)
            }
        )


    }

    const handleRecommendationsDelete = (index) => {
        const id = getValues2(`recommendations[${index}].mstCode`)
        if (CommonUtil.isValidNumber(id)) {
            setMessage('Cannot be deleted')
            setShowMsg(true)
            // IfvAppraisalService.deleteOtherCondition(id).then((response) => {
            //     setValue2(`recommendations[${index}]`, undefined)
            //     remove2(index)
            //     setMessage('Recommendations deleted successfully!')
            //     setShowMsg(true)
            // },
            //     (error) => {
            //         const resMessage =
            //             (error.response &&
            //                 error.response.data &&
            //                 error.response.data.message) ||
            //             error.message ||
            //             error.toString();

            //         setMessage('Error occured while deleting recommendations: ' + resMessage)
            //         setShowMsg(true)
            //     }
            // )
        } else {
            remove2(index)
        }
    }

    const onSubmitOfRecommendations = (data, e) => {
        IfvAppraisalService.saveAllOtherConditions(data['recommendations']).then((response) => {
            showRecommendationsModal()
            setMessage('Recommendations details have been successfully saved!')
            setShowMsg(true)
        },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                setMessage('Error occured while saving recommendations: ' + resMessage)
                setShowMsg(true)
            })
    }

    return (
        <Fragment>
            <div className={loading ? 'frgmnt blur-background' : 'frgmnt mst_stp'}>

                <div className='stpin'>
                    <h3>Manage Master Setups</h3>
                    <button type='button'
                        style={{
                            margin: '5px',
                            padding: '10px',
                            backgroundColor: '#4E4FEB',
                        }}
                        className='btn btnNext'
                        onClick={() => showOtherConditionsModal()}
                    >Manage Other Conditions</button>

                    <button type='button'
                        style={{
                            margin: '5px',
                            padding: '10px',
                            backgroundColor: '#4E4FEB',
                        }}
                        className='btn btnNext'
                        onClick={() => showRecommendationsModal()}
                    >Manage Recommendations</button>
                </div>
            </div>

            <Modal style={{ marginTop: "200px" }} show={showMsg} onHide={hideMsg}>

                <Modal.Body >
                    <div className="conatiner text-center">
                        <div className="row">
                            <div className="col-sm-12">
                            <h5 className= {message.includes('Error')? 'alertMsg':'loadMsg'}>{message}</h5>
                            </div>
                        </div>
                    </div>
                    
                    <div className="row text-center">
                        <div className="col-sm-12 text-center">
                            <button type="button" className=" btn  btnRegister  themebutton" onClick={hideMsg}>OK</button>
                        </div>
                    </div>

                </Modal.Body>
            </Modal>

            <Modal className={loading ? 'blur-background' : ''} size="xl" show={showOtherConditions} onHide={handleOtheConditionsClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Other Conditions Setup</Modal.Title>
                </Modal.Header>
                <form key={1} onSubmit={handleSubmitOfOtherConditions(onSubmitOfOtherCondition)}>
                    <Modal.Body className="exi_prop">

                        <div className='row'>
                            <div className='col-md-1'>
                                <div className='form-group'>
                                    <label className='ml-4'><strong>Sl No</strong></label>
                                </div>
                            </div>

                            <div className='col-md-9'>
                                <div className='form-group'>
                                    <label className='ml-2'><strong>Condition</strong></label>
                                </div>
                            </div>

                            <div className='col-md-1'>
                                <div className='form-group'>
                                    <label><strong>Order</strong> </label>
                                </div>
                            </div>
                            <div className='col-md-1'>

                            </div>

                        </div>

                        {fields1.map((field, index) => (
                            <div className='container-fluid'>
                                <div className='row pt-0' key={field.id}>
                                    <div className='col-md-1'>
                                        <div className='form-group'>
                                            {index + 1}
                                        </div>
                                    </div>
                                    <div className='col-md-9'>
                                        <div className='form-group'>
                                            <textarea className='form-control'
                                                key={field.id} // important to include key with field's id
                                                {...register1(`otherConditions[${index}].mstRemarks`)}
                                            />
                                            <input type='hidden' {...register1(`otherConditions[${index}].mstParticulars`)} value="Other Conditions" />
                                            <input type='hidden' {...register1(`otherConditions[${index}].mstCode`)} />
                                            <input type='hidden' {...register1(`otherConditions[${index}].mstFlg`)} value='Y' />
                                        </div>
                                    </div>

                                    <div className='col-md-1'>
                                        <div className='form-group'>
                                            <input className='form-control'
                                                key={field.id} // important to include key with field's id
                                                type='text'
                                                {...register1(`otherConditions[${index}].mstOrder`)}
                                            />
                                        </div>
                                    </div>

                                    <div className='col-md-1'>
                                        <div className='form-group'>
                                            <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                                onClick={() => handleotherConditionDelete(index)}></i>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        ))}
                        <div className='col-md-12'>
                            <div className="button-container-end">
                                <button type="button" className='addBtn' onClick={() => append1({})}>+</button>
                            </div>

                        </div>

                    </Modal.Body>
                    <Modal.Footer>
                        <div className="button-container-center">
                            <button type='submit' className='save btn btnSave'>Save <i className="fa fa-circle-check"></i></button>
                        </div>
                    </Modal.Footer>
                </form>
            </Modal>

            <Modal className={loading ? 'blur-background' : ''} size="xl" show={showRecommendatrions} onHide={handleRecommendationsClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Recommendations Setup</Modal.Title>
                </Modal.Header>
                <form key={2} onSubmit={handleSubmitOfRecommendations(onSubmitOfRecommendations)}>
                    <Modal.Body className="exi_prop">

                        <div className='row'>
                            <div className='col-md-1'>
                                <div className='form-group'>
                                    <label className='ml-4'><strong>Sl No</strong></label>
                                </div>
                            </div>

                            <div className='col-md-9'>
                                <div className='form-group'>
                                    <label className='ml-2'><strong>Condition</strong></label>
                                </div>
                            </div>

                            <div className='col-md-1'>
                                <div className='form-group'>
                                    <label><strong>Order</strong> </label>
                                </div>
                            </div>
                            <div className='col-md-1'>

                            </div>

                        </div>

                        {fields2.map((field, index) => (
                            <div className='container-fluid'>
                                <div className='row pt-0' key={field.id}>
                                    <div className='col-md-1'>
                                        <div className='form-group'>
                                            {index + 1}
                                        </div>
                                    </div>
                                    <div className='col-md-9'>
                                        <div className='form-group'>
                                            <textarea className='form-control'
                                                key={field.id} // important to include key with field's id
                                                {...register2(`recommendations[${index}].mstRemarks`)}
                                            />
                                            <input type='hidden' {...register2(`recommendations[${index}].mstParticulars`)} value="Recommendation" />
                                            <input type='hidden' {...register2(`recommendations[${index}].mstCode`)} />
                                            <input type='hidden' {...register2(`recommendations[${index}].mstFlg`)} value='Y' />
                                        </div>
                                    </div>

                                    <div className='col-md-1'>
                                        <div className='form-group'>
                                            <input className='form-control'
                                                key={field.id} // important to include key with field's id
                                                type='text'
                                                {...register2(`recommendations[${index}].mstOrder`)}
                                            />
                                        </div>
                                    </div>

                                    <div className='col-md-1'>
                                        <div className='form-group'>
                                            <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                                onClick={() => handleRecommendationsDelete(index)}></i>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        ))}
                        <div className='col-md-12'>
                            <div className="button-container-end">
                                <button type="button" className='addBtn' onClick={() => append2({})}>+</button>
                            </div>
                        </div>

                    </Modal.Body>
                    <Modal.Footer>
                        <div className="button-container-center">
                            <button type='submit' className='save btn btnSave'>Save <i className="fa fa-circle-check"></i></button>
                        </div>
                    </Modal.Footer>
                </form>
            </Modal>

            {loading && <Loading />}
        </Fragment >
    )
}
export default Admin;
