import { LinearProgress } from '@mui/material';
import Loading from 'components/Loading';
import MessageModal from 'components/MessageModal';
import ProposalHeader from 'components/ProposalHeader';
import SectionNavigation from 'components/SectionNavigation';
import { format } from 'date-fns';
import { useErrorHandler } from 'hooks/useErrorHandler';
import useMessageModal from 'hooks/useMessageModal';
import { Fragment, useEffect, useState } from 'react';
import Accordion from 'react-bootstrap/Accordion';
import 'react-datepicker/dist/react-datepicker.css';
import { useFieldArray, useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
import IfvAppraisalService from 'services/IfvAppraisalService';
import UserService from 'services/UserService';
import PrincipalRepaymentData from 'services/constants/PrincipalRepaymentData';
import CommonUtil from 'services/utils/CommonUtil';
import Pattern from 'services/validators/Pattern';

const SectionFour = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const showSFB = location.state ? location.state.showSFB : null;
    const appId = location.state ? location.state.appId : 0;
    const {
        showMessage,
        hideMessage,
        isOpen,
        messageConfig,
        totalMessages,
        currentIndex,
        nextMessage,
        prevMessage,
        hasNext,
        hasPrev
    } = useMessageModal();
    const { handleApiError } = useErrorHandler(showMessage);

    const { control, register, handleSubmit, formState: { errors } } = useForm({
        mode: "onBlur"
    });

    const { control: control14, register: register14, handleSubmit: handleSubmitOfPrincipal, setValue: setValue14, getValues: getValues14, formState: { errors: errors14 }, } = useForm({
        mode: "onBlur"
    });

    const { control: control15, register: register15, handleSubmit: handleSubmitOfTermsAndConditionData, setValue: setValue15, getValues: getValues15, formState: { errors: errors15 }, } = useForm({
        mode: "onBlur"
    });

    const { fields: fields11, append: append11, remove: remove11 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "principal", // unique name for your Field Array
    });

    const [locked, setLocked] = useState(false)
    const [ifvApp, setIfvApp] = useState({})
    const [isMaker, setMaker] = useState(false)

    useEffect(() => {
        const user = IfvAppraisalService.getCurrentUser();
        setMaker(UserService.isMaker(user))
        IfvAppraisalService.getIfvAppById(appId).then(
            (response) => {
                setIfvApp(response.data)
                getProposedSchemesData(response.data.ifvName)
            },
            (error) => {
                handleApiError(error, 'loading App Data');
            }
        )
        getTblFwdDetail()
    }, []);

    const [editable, setEditable] = useState(false)
    const [appStatus, setAppStatus] = useState('')
    const getTblFwdDetail = () => {
        IfvAppraisalService.getTblFwdDetail(appId)
            .then((response) => {
                const status = response.data.appStatus
                switch (status) {
                    case 'LK':
                        setLocked(true)
                        setEditable(false)
                        setAppStatus('Locked')
                        break
                    case 'NW':
                        setLocked(false)
                        setEditable(true)
                        setAppStatus('New')
                        break
                    case 'CN':
                        setLocked(false)
                        setEditable(false)
                        setAppStatus('Confirmed')
                        break
                    case 'AP':
                        setLocked(false)
                        setEditable(false)
                        setAppStatus('Approved')
                        break
                }
            })
            .catch(error => {
                handleApiError(error, 'loading TBL data')
            })
    }

    const [proposedSchemes, setProposedSchemes] = useState([])
    const [showInterestResest, setShowInterestReset] = useState(false)
    const [rmseScheme, setRmseScheme] = useState(false)
    const [prTotal, setPrTotal] = useState(0)
    const [proposeSchemesLength, setProposedSchemesLength] = useState(0)

    function getProposedSchemesData(ifvName) {

        IfvAppraisalService.getAllSchemesOnIfvId(appId).then(
            (response) => {
                let finalData = response.data
                let note = 'The proposal does not involve any relaxation.\nIFCC-CGM is requested to approve sanction of Rs. '
                let sum = 0;
                let intResetExists = false;

                if (finalData.length > 1) {
                    let smallNote = '';
                    let appendixVal = '';
                    finalData.forEach((item, i) => {
                        sum = parseFloat(sum) + parseFloat(item.prAmount)
                        let schemeName = item.prSchemeName
                        if (schemeName.toLowerCase().includes('rmse')) {
                            schemeName = CommonUtil.extractTextUpToWord(item.prFundname)
                        }
                        smallNote = smallNote + 'Rs. ' + item.prAmount + ' crore under ' + schemeName
                        smallNote += finalData.length - 1 == i ? ' ' : ' and '

                        if (item.prFundname.toLowerCase().includes('rmse')) {
                            setRmseScheme(true)
                        }

                        let principalRepaymentdata = PrincipalRepaymentData[item.prPrincipalRepayment];

                        if (item.prPrincipalRepayment == 'Bullet') {

                            const originalDate = new Date(item.prMaturityDate)
                            //const formattedDate = moment(originalDate, 'DD/MM/YYYY').format('MMMM D, YYYY');
                            const formattedDate = format(originalDate, 'MMMM d, yyyy');
                            principalRepaymentdata = 'The principal would be repayable in single bullet installment at the end of ' + formattedDate + ' months starting from the date of first disbursement.';
                        }

                        remove11(i)
                        append11({})
                        setValue14(`principal[${i}].plScheme`, item.prSchemeName)
                        setValue14(`principal[${i}].plRepayment`, principalRepaymentdata)
                        setValue14(`principal[${i}].prId`, item.prId)

                        let benchMarkIn = item.benchMark
                        if (!CommonUtil.isEmpty(benchMarkIn)) {
                            if (benchMarkIn.toUpperCase().includes("REPO RATE")) {
                                benchMarkIn = "RBI Repo rate";
                            }

                            if (!CommonUtil.isEmpty(item.spread)) {
                                benchMarkIn += " + " + item.spread + " bps";

                            }

                        } else {
                            benchMarkIn = item.prRoi
                        }

                        item.benchMark = benchMarkIn;
                        if (!CommonUtil.isEmpty(item.interestReset)) {
                            intResetExists = true;
                        }

                    })

                    if (finalData.length == 2) {
                        appendixVal = 'Appendix-I and Appendix-II'
                    }
                    if (finalData.length == 3) {
                        appendixVal = 'Appendix-I and Appendix-II and Appendix-III'
                    }
                    if (finalData.length == 4) {
                        appendixVal = 'Appendix-I and Appendix-II and Appendix-III and Appendix-IV'
                    }

                    note = note + CommonUtil.dynamicTotal(sum) + ' crore comprising ' + smallNote + 'Scheme to ' + ifvName
                    note = note + ', as per the terms and conditions given in ' + appendixVal

                } else {
                    finalData.forEach((item, i) => {
                        let schemeName = item.prSchemeName
                        if (schemeName.toLowerCase().includes('rmse')) {
                            schemeName = CommonUtil.extractTextUpToWord(item.prFundname)
                        }

                        sum = parseFloat(sum) + parseFloat(item.prAmount)

                        note = note + item.prAmount + ' crore under ' + schemeName + ' Scheme to ' + ifvName

                        note = note + ', as per the terms and conditions given in Appendix.'

                        if (item.prFundname.toLowerCase().includes('rmse')) {
                            setRmseScheme(true)
                        }

                        let principalRepaymentdata = PrincipalRepaymentData[item.prPrincipalRepayment];

                        if (item.prPrincipalRepayment == 'Bullet') {

                            const originalDate = new Date(item.prMaturityDate)
                            // const formattedDate = moment(originalDate, 'DD/MM/YYYY').format('MMMM D, YYYY');
                            const formattedDate = format(originalDate, 'MMMM d, yyyy');
                            principalRepaymentdata = 'The principal would be repayable in single bullet installment at the end of ' + formattedDate + ' months starting from the date of first disbursement.';
                        }

                        remove11(i)
                        append11({})
                        setValue14(`principal[${i}].plScheme`, item.prSchemeName)
                        setValue14(`principal[${i}].plRepayment`, principalRepaymentdata)
                        setValue14(`principal[${i}].prId`, item.prId)

                        let benchMarkIn = item.benchMark
                        if (!CommonUtil.isEmpty(benchMarkIn)) {
                            if (benchMarkIn.toUpperCase().includes("REPO RATE")) {
                                benchMarkIn = "RBI Repo rate";
                            }

                            if (!CommonUtil.isEmpty(item.spread)) {
                                benchMarkIn += " + " + item.spread + " bps";

                            }

                        } else {
                            benchMarkIn = item.prRoi
                        }

                        item.benchMark = benchMarkIn;
                        if (!CommonUtil.isEmpty(item.interestReset)) {
                            intResetExists = true;
                        }
                    })
                }

                getMajorTermsAndConditionData(note, finalData.length)
                setProposedSchemesLength(finalData.length)
                setProposedSchemes(finalData)
                setPrTotal(CommonUtil.dynamicTotal(sum))
                getPrincipal();
                setShowInterestReset(intResetExists)
            },
            (error) => {
                handleApiError(error, 'loading schemes data');
            }
        )
    }

    const [princIdExists, setPrincIdExists] = useState(false)

    const getPrincipal = () => {
        IfvAppraisalService.getPrincipal(appId).then(response => {
            const appData = response.data
            if (appData.length > 0) {
                setPrincIdExists(true)

                appData.forEach((item, index) => {
                    remove11(index)
                    append11({})
                    setValue14(`principal[${index}].plId`, item.plId)
                    setValue14(`principal[${index}].ifvId`, item.ifvId)
                    if (!CommonUtil.isEmpty(item.plRepayment)) {
                        setValue14(`principal[${index}].plRepayment`, item.plRepayment)
                    }

                    setValue14(`principal[${index}].plIntPayment`, item.plIntPayment)
                    setValue14(`principal[${index}].plMonths`, item.plMonths)
                    setValue14(`principal[${index}].plPeriod`, item.plPeriod)
                    setValue14(`principal[${index}].plScheme`, item.plScheme)
                    setValue14(`principal[${index}].prId`, item.prId)
                    if (!CommonUtil.isEmpty(item.plPeriod)) {
                        inputHandler(item.plPeriod, 'plp')
                    }

                });
            }
            else {
                setPrincIdExists(false)
            }
        },
            (error) => {
                handleApiError(error, 'loading Details of Principals');
            }
        )
    }

    const onSubmitOfPrincipal = (data, e) => {

        let plPeriodIn = getValues14('principal[0].plPeriod')
        data['principal'].forEach(item => {
            item.plPeriod = plPeriodIn
        })

        IfvAppraisalService.savePrincipal(data['principal']).then((response) => {
            showMessage('Principal details have been successfully saved!', 'success')
            getPrincipal()
        },
            (error) => {
                handleApiError(error, 'saving Principals');
            })
    }

    const [tsIdExists, setTsIdExists] = useState(false)

    const getMajorTermsAndConditionData = (note, schemeSize) => {
        setLoading(true)
        IfvAppraisalService.getMajorTermsAndConditionData(appId).then(response => {
            const appData = response.data
            if (appData.tsId != null && appData.tsId > 0) {
                setTsIdExists(true)
            }
            setValue15('tsId', appData.tsId)
            setValue15('ifvId', appData.ifvId)
            setValue15('tsUpfrontFee', appData.tsUpfrontFee)
            if (appData.tsUpfrontFee != null) {
                inputHandler(appData.tsUpfrontFee, 'upFrontFee')
            }
            setValue15('tsMonths', appData.tsMonths)
            setValue15('tsDisbursement', appData.tsDisbursement)
            if (appData.tsDisbursement != null) {
                inputHandler(appData.tsDisbursement, 'dateDisb')
            }
            setValue15('tsSpecific', appData.tsSpecific)
            if (appData.tsSpecific != null) {
                inputHandler(appData.tsSpecific, 'specComm')
            }
            if (appData.tsBorrowers != null) {
                setValue15('tsBorrowers', appData.tsBorrowers)
            } else {
                setValue15('tsBorrowers', '(i)	The bank shall submit a list of end borrowers in the prescribed format at the time of disbursement or within such extended period as may be allowed by the sanctioning committee. In case the bank fails to furnish the list of end-borrowers as per sanction terms, penal charges @ 0.5% p.a., along with applicable taxes, on the disbursed amount will be charged with prospective effect till date of receipt of data.\n(ii)	Further, if the data is not furnished within 3 months from the date of disbursement, SIDBI shall have the right to recall the loan and the bank would be required to prepay the entire loan outstanding.\nThe Bank shall submit the list of end borrowers before disbursement.')
            }

            inputHandler(getValues15('tsBorrowers'), 'endBorrowers')
            if (!CommonUtil.isEmpty(appData.tsTermSanction)) {
                setValue15('tsTermSanction', appData.tsTermSanction)
            } else {
                let termSanc = ''
                if (schemeSize > 3) {
                    termSanc = 'As per Appendix-I and II and III and IV'
                } else if (schemeSize > 2) {
                    termSanc = 'As per Appendix-I and II and III'
                } else if (schemeSize > 1) {
                    termSanc = 'As per Appendix-I and II'
                } else {
                    termSanc = 'As per Appendix.'
                }
                setValue15('tsTermSanction', termSanc)
            }


            setValue15('tsRampe', appData.tsRampe)
            setValue15('tsFabia', appData.tsFabia)
            setValue15('tsTermsection', appData.tsTermsection)

            if (appData.tsValiditySanction != null) {
                setValue15('tsValiditySanction', appData.tsValiditySanction)
            } else {
                setValue15('tsValiditySanction', 'Generally, upto 2 months from the date of sanction, or such extended period as may be decided by SIDBI.')
            }

            inputHandler(getValues15('tsValiditySanction'), 'valOfSanction')

            if (appData.tsDopSanction != null) {
                setValue15('tsDopSanction', appData.tsDopSanction)
            } else {
                setValue15('tsDopSanction', 'In terms of Sr. No. VIII(1)(a) & (b), Page No. 4, read with IX (3) of extant DoP for Institutional Finance Vertical effective from August 31, 2018, read with approval accorded by the Board at its meeting held on February 02, 2022, the proposal falls within powers of IFCC-CGM with PSR to DMD.')
            }

            inputHandler(getValues15('tsDopSanction'), 'dopForSanction')

            if (appData.tsDopRelaxtion != null) {
                setValue15('tsDopRelaxtion', appData.tsDopRelaxtion)
            } else {
                setValue15('tsDopRelaxtion', 'Within relaxable norms, sanctioning committee otherwise next higher committee viz. IFCC-DMD.')
            }

            inputHandler(getValues15('tsDopRelaxtion'), 'dopForRelaxation')

            if (!CommonUtil.isEmpty(appData.tsRecommendation)) {
                setValue15('tsRecommendation', appData.tsRecommendation)
            } else {
                setValue15('tsRecommendation', note)
            }

            inputHandler(getValues15('tsRecommendation'), 'recommendations')
            setLoading(false)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading Details of Appendix');
            }
        )
    }

    const onSubmitOfTermsAndConditionData = (data, e) => {
        setLoading(true)
        data.ifvId = appId
        IfvAppraisalService.saveTermsAndConditionData(data).then((response) => {
            setLoading(false)
            showMessage('Appendix details have been successfully saved!', 'success')
            getMajorTermsAndConditionData(response.data.tsRecommendation, proposeSchemesLength)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving details of Appendix');
            })
    }

    function goToNext() {
        navigate('/ifv/sectionFive', {
            state: {
                showSFB: showSFB,
                appId: appId
            }
        });
    }

    const initialState = {
        princRepayment: '',
        intPayment: '',
        upFrontFee: '',
        dateDisb: '',
        specComm: '',
        endBorrowers: '',
        dopForRelaxation: '',
        valOfSanction: '',
        dopForSanction: '',
        recommendations: '',
        plp: ''
    }
    const [input, setInput] = useState(initialState);
    const inputHandler = (value, input) => {
        setInput(prevState => ({ ...prevState, [input]: value }));
    };

    const [loading, setLoading] = useState(false)

    return (
        <Fragment>
            <div className={loading ? 'frgmnt blur-background' : 'frgmnt'}>
                <SectionNavigation activeView={'Section Four'} showSFB={showSFB} appId={appId} />
                <ProposalHeader
                    bankName={ifvApp.ifvName}
                    appNumber={ifvApp.appNumber}
                    status={appStatus}
                    appId={appId}
                />
                <Accordion flush>


                    <Accordion.Item>
                        <Accordion.Header>Major Terms and Conditions</Accordion.Header>
                        <Accordion.Body>
                            <div className='row'>
                                <table className="table table-hover table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Fund </th>
                                            <th>Scheme</th>
                                            <th>Amount (₹ in crore)</th>
                                            <th>RoI (%)</th>
                                            {showInterestResest && <th>Interest Reset</th>}
                                            <th>Tenure (In Months)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {proposedSchemes.map((item, i) => (
                                            <tr>
                                                <td>{item.prFundname}</td>
                                                <td>{item.prSchemeName}</td>
                                                <td style={{ textAlign: 'right' }}>{CommonUtil.formatAmount(item.prAmount)}</td>
                                                <td>{item.benchMark}</td>
                                                {showInterestResest && <td>{item.interestReset}</td>}
                                                <td style={{ textAlign: 'right' }}>{item.prSchemeName.includes('RMSE') ? `${item.prTenure} (Approx.)` : item.prTenure}</td>
                                            </tr>
                                        ))}
                                        <tr><td colSpan={2}><strong>Total</strong></td>
                                            <td colSpan={4} ><strong>{prTotal}</strong></td>
                                        </tr>
                                    </tbody>

                                </table>
                            </div>

                            {/* <div className='row'>
                                <div className='col-md-2'>
                                    <div className='form-group'>
                                        <label className='ml-3'><strong> Fund</strong></label>
                                    </div>
                                </div>

                                <div className='col-md-2'>
                                    <div className='form-group'>
                                        <label className='ml-3'><strong> Scheme</strong></label>
                                    </div>
                                </div>

                                <div className={showSFB ? 'col-md-2' : 'col-md-1'}>
                                    <div className='form-group'>
                                        <label className='ml-1'><strong> Amount [Crore] </strong></label>
                                    </div>
                                </div>

                                <div className={showSFB ? 'col-md-2' : 'col-md-1'}>
                                    <div className='form-group'>
                                        <label><strong>Rate of Interest (% P.A) </strong></label>
                                    </div>
                                </div>

                                <div className={showSFB ? 'col-md-2' : 'col-md-1'}>
                                    <div className='form-group'>
                                        <label><strong>Tenure (Months) </strong></label>
                                    </div>
                                </div>
                                {!showSFB && <> <div className='col-md-2'>
                                    <div className='form-group'>
                                        <label><strong>Principal Repayment</strong></label>
                                    </div>
                                </div>
                                    <div className='col-md-2'>
                                        <div className='form-group'>
                                            <label><strong>Interest Payment</strong></label>
                                        </div>
                                    </div>
                                </>}
                                <div className={showSFB ? 'col-md-2' : 'col-md-1'}>
                                    <div className='form-group'>
                                    </div>
                                </div>
                            </div> */}


                            {/* <form key={12} onSubmit={handleSubmitOfSchemas(onSubmitOfSchemas)}>
                                {fields10.map((field, index) => (
                                    <div className='container-fluid'>
                                        <div className='row pt-0' eventKey="0" key={field.id}>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <select className="form-control"
                                                        {...register13(`schemes[${index}].fundCode`, {
                                                            required: "Fund code is required",
                                                            onChange: (e) => validateFundCode(e.target.value, index)
                                                        })}
                                                    >
                                                        <option value=""> Please select a fund</option>
                                                        {funds.map((item, i) => (
                                                            <option selected={selectedFundCode[index] === item.fundCode} value={item.fundCode}>{item.fundDescription}</option>
                                                        ))}
                                                    </select></div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                   
                                                    <select className="form-control"
                                                        {...register13(`schemes[${index}].scSchemeName`, {
                                                            required: "Scheme is required",
                                                        })}
                                                    >
                                                        <option value=""> Please select a scheme</option>
                                                        {schemesOnFundCode[index]?.map((item, i) => (
                                                            <option selected={selectedScheme[index] === item.longName} value={item.longName}>{item.longName}</option>
                                                        ))}
                                                    </select>

                                                    <input type='hidden'
                                                        {...register13(`schemes[${index}].scId`)}
                                                    />
                                                    <input type='hidden'
                                                        {...register13(`schemes[${index}].ifvId`)} value={appId}
                                                    />
                                                </div>
                                            </div>

                                            <div className={showSFB ? 'col-md-2' : 'col-md-1'}>
                                                <div className='form-group'>
                                                    <input className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='number'
                                                        step='0.01'
                                                        {...register13(`schemes[${index}].scAmount`)}
                                                    />
                                                </div>
                                            </div>


                                            <div className={showSFB ? 'col-md-2' : 'col-md-1'}>
                                                <div className='form-group'>
                                                    <input className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='number'
                                                        step='0.01'
                                                        {...register13(`schemes[${index}].scRoi`)}
                                                    />
                                                </div>
                                            </div>



                                            <div className={showSFB ? 'col-md-2' : 'col-md-1'}>
                                                <div className='form-group'>
                                                    <input className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='number'
                                                        step='0.01'
                                                        {...register13(`schemes[${index}].scTenure`)}
                                                    />
                                                    
                                                </div>
                                            </div>

                                            {!showSFB && <>  <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <select className="form-control"
                                                        {...register13(`schemes[${index}].principalRepayment`)}
                                                    >
                                                        <option value=""> Please select a value</option>
                                                        {PrincipalRepayment.map((item, index) => (
                                                            <option value={item}>{item}</option>
                                                        ))}
                                                    </select>
                                                </div>
                                            </div>
                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <select className="form-control"
                                                            {...register13(`schemes[${index}].interestPayment`)}
                                                        >
                                                            <option value=""> Please select a value</option>
                                                            {PrincipalRepayment.map((item, index) => (
                                                                <option value={item}>{item}</option>
                                                            ))}
                                                        </select>
                                                    </div>
                                                </div></>
                                            }
                                            <div className={showSFB ? 'col-md-2' : 'col-md-1'}>
                                                <div className='form-group'>
                                                    <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                                        onClick={() => deleteSchema(index)}></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}

                                <div className="button-container-end">
                                    <button className='remove' type="button" onClick={() => append10({})}>+</button>
                                </div>
                                <div className="button-container-center">
                                    {(editable || (isChecker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                                </div>
                            </form> */}



                            <hr className='hr' />

                            <form key={12} onSubmit={handleSubmitOfPrincipal(onSubmitOfPrincipal)}>
                                <div className='container-fluid pt-0'>
                                    <div className='row'>
                                        <div className='col-md-2'>
                                            <div className='form-group'>
                                                <label><strong>Repayment Terms</strong></label>
                                            </div>
                                        </div>

                                        <div className='col-md-5'>
                                            <div className='form-group'>
                                                <label><strong>Principal Repayment </strong></label>

                                            </div>
                                        </div>

                                        <div className='col-md-5'>
                                            <div className='form-group'>
                                                <label><strong>Interest Payment</strong></label>
                                            </div>
                                        </div>
                                        {/* <div className='col-md-1'>
                                            <div className='form-group'>
                                                <label className='ml-1'><strong>MONTHS</strong></label>
                                            </div>
                                        </div> */}
                                        <div className='col-md-2'>
                                            <div className='form-group'>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {fields11.map((field, index) => (
                                    <div className='container-fluid'>
                                        <div className='row' eventKey="0" key={field.id}>

                                            <div className='col-md-2'>
                                                <div className='form-group'>Under <input className='form-control'
                                                    key={field.id} // important to include key with field's id
                                                    type='text' readOnly
                                                    {...register14(`principal[${index}].plScheme`)}
                                                /></div>
                                            </div>

                                            <div className='col-md-5'>
                                                <div className='form-group'>
                                                    {/* <input className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='text'
                                                        {...register14(`principal[${index}].plRepayment`)}
                                                    /> */}
                                                    <textarea className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        // defaultValue='The principal would be repayable in a single bullet installment on November 24, 2026.'
                                                        {...register14(`principal[${index}].plRepayment`, {
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                return true;
                                                            },
                                                            onChange: (e) => Pattern.sanitizeInput(e),
                                                            maxLength: {
                                                                value: 4000,
                                                                message: "The maximum length of the field is 4000"
                                                            }
                                                        })}
                                                        maxLength="4000"></textarea>
                                                    <span className="vldn"> {errors14.principal && errors14.principal[index]?.plRepayment && errors14.principal[index]?.plRepayment.message}</span>
                                                    <input type='hidden'
                                                        {...register14(`principal[${index}].plId`)}
                                                    />
                                                    <input type='hidden'
                                                        {...register14(`principal[${index}].ifvId`)} value={appId}
                                                    />
                                                    <input type='hidden'
                                                        {...register14(`principal[${index}].prId`)}
                                                    />
                                                </div>
                                            </div>

                                            <div className='col-md-5'>
                                                <div className='form-group'>
                                                    {/* <input className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='number'
                                                        {...register14(`principal[${index}].plIntPayment`)}
                                                    /> */}
                                                    <textarea className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        defaultValue='Interest shall be paid on monthly basis on the 10th day of each month starting from 10th day of the subsequent month from the date of first disbursement.'
                                                        {...register14(`principal[${index}].plIntPayment`, {
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                return true;
                                                            },
                                                            onChange: (e) => Pattern.sanitizeInput(e),
                                                            maxLength: {
                                                                value: 4000,
                                                                message: "The maximum length of the field is 4000"
                                                            }
                                                        })}></textarea>
                                                    <span className="vldn"> {errors14.principal && errors14.principal[index]?.plIntPayment && errors14.principal[index]?.plIntPayment.message}</span>
                                                </div>
                                            </div>

                                            {/* <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <input className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='number'
                                                        {...register14(`principal[${index}].plMonths`)}
                                                    />
                                                </div>
                                            </div> */}
                                            {/* <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                                        onClick={() => deleteRepaymentTerms(index)}></i>
                                                </div>
                                            </div> */}
                                        </div>

                                    </div>
                                ))}

                                {rmseScheme && <div className='row'>
                                    <div className='col-md-12'>
                                        <label className="prog_lbl" style={{ justifyContent: 'right', marginBottom: '6px' }}>
                                            <div className='prgs'>
                                                <span className='lft_crt'>{4000 - input['plp'].length} Characters left</span>
                                                <LinearProgress
                                                    variant="determinate"
                                                    value={input['plp'].length}
                                                />
                                            </div>
                                        </label>
                                        <div className='form-group'>
                                            {/* However, if the due date of repayment falls on Saturday/Sunday/ Holidays under N.1. Act, the due date of payment would be the preceding working day. */}
                                            <textarea className='form-control'  {...register14(`principal[0].plPeriod`, {
                                                maxLength: {
                                                    value: 4000,
                                                    message: "The maximum length of the field is 4000"
                                                },
                                                validate: (value) => {
                                                    if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                    return true;
                                                },
                                            })} maxLength="4000"
                                                onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "plp") }} />
                                            <span className="vldn"> {errors14.principal && errors14.principal[0]?.plPeriod && errors14.principal[0]?.plPeriod.message}</span>
                                        </div>
                                    </div>

                                </div>
                                }

                                {/* <div className="button-container-end">
                                    <button type="button" className="remove" onClick={() => append11({})}>+</button>
                                </div> */}
                                <div className="button-container-center">
                                    {(editable || (!isMaker && locked)) && !princIdExists && <p className='color-red'>Please save the autofilled data before proceeding.</p>}
                                </div>
                                <div className="button-container-center">
                                    {(editable || (!isMaker && locked)) && <button type='submit' className="save">{princIdExists ? 'Update' : 'Save'} <i className="fa fa-circle-check"></i></button>}
                                </div>
                            </form>



                            <form key={13} onSubmit={handleSubmitOfTermsAndConditionData(onSubmitOfTermsAndConditionData)} className='mt-4'>
                                <input type='hidden'
                                    {...register15('tsId')}
                                />
                                <input type='hidden'
                                    {...register15('ifvId')} value={appId}
                                />
                                <div>
                                    {/* <div className='row mt-4'> */}
                                    {/* <div className='col-md-2'>
                                    <div className='form-group'>
                                        <label className='ml-3'><strong>Upfront Fee</strong></label>
                                    </div>
                                </div> */}

                                    {/* <div className='col-md-2'>
                                    <div className='form-group'>
                                        <textarea className='form-control' {...register15('tsUpfrontFee')} autoComplete='off' />
                                    </div>
                                </div> */}

                                    {/* </div> */}
                                    {/* {!isPrivatePublicOrForeignBank && !showSFB && <div className='form-group msersWrap'>
                                        <label className="prog_lbl"><strong>Upfront Fee</strong>
                                            <div className='prgs'>
                                                <span className='lft_crt'>{4000 - input['upFrontFee'].length} Characters left</span>
                                                <LinearProgress
                                                    variant="determinate"
                                                    value={input['upFrontFee'].length}
                                                />
                                            </div>
                                        </label>
                                        <div className='row'>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <textarea className='form-control' {...register15('tsUpfrontFee', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                    })} autoComplete='off'
                                                        maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e), inputHandler(e.target.value, "upFrontFee") }} />
                                                    <span className="vldn"> {errors15.tsUpfrontFee && errors15.tsUpfrontFee.message}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>} */}
                                    <div className='form-group msersWrap mt-4'>
                                        <div className='row'>

                                            <label className="prog_lbl">

                                                <strong>Expected Date of Disbursement.</strong>
                                                <div className='prgs'>
                                                    <span className='lft_crt'>{4000 - input['dateDisb'].length} Characters left</span>
                                                    <LinearProgress
                                                        variant="determinate"
                                                        value={input['dateDisb'].length}
                                                    />
                                                </div>
                                            </label>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <textarea className='form-control' {...register15('tsDisbursement', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                    })} autoComplete='off' maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "dateDisb") }} />
                                                    <span className="vldn"> {errors15.tsDisbursement && errors15.tsDisbursement.message}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    {/* <div className='row mt-4'>
                                    <div className='col-md-12'>
                                        <div className='form-group'>




                                            <div className='branch_on'>
                                                <label>It is informed that the repayment schedule is proposed in quarterly instalments as against bullet repayment submitted to the Sub-Committee of ALCO. <strong>Expected date of disbursement.</strong></label>
                                                <div className='brn_wrp'><textarea className='form-control' {...register15('tsDisbursement')} autoComplete='off' /></div>

                                            </div>
                                        </div>
                                    </div>
                                </div> */}
                                    <div className='form-group msersWrap'>

                                        <div className='row'>

                                            <label className="prog_lbl">

                                                <strong>Specific Comments, if any (viz. Period up to Interest Rate is Valid / Last Date of Drawal, etc.)</strong>
                                                <div className='prgs'>
                                                    <span className='lft_crt'>{4000 - input['specComm'].length} Characters left</span>
                                                    <LinearProgress
                                                        variant="determinate"
                                                        value={input['specComm'].length}
                                                    />
                                                </div>

                                            </label>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <textarea className='form-control' {...register15('tsSpecific', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                    })} autoComplete='off' maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "specComm") }} />
                                                    <span className="vldn"> {errors15.tsSpecific && errors15.tsSpecific.message}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className='form-group msersWrap'>

                                    <div className='row'>

                                        <label className="prog_lbl">

                                            <strong>End Borrowers' Data</strong>
                                            <div className='prgs'>
                                                <span className='lft_crt'>{4000 - input['endBorrowers'].length} Characters left</span>
                                                <LinearProgress
                                                    variant="determinate"
                                                    value={input['endBorrowers'].length}
                                                />
                                            </div>
                                        </label>
                                        <div className='col-md-12'>
                                            <div className='form-group'>
                                                <textarea className='form-control'
                                                    autoComplete='off'
                                                    {...register15('tsBorrowers', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                    })} maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "endBorrowers") }} />
                                                <span className="vldn"> {errors15.tsBorrowers && errors15.tsBorrowers.message}</span>
                                            </div>
                                        </div>
                                    </div>



                                    <div className='row mt-3'>
                                        <strong className='mb-1'>Terms for Sanction</strong>
                                        <div className='col-md-12'>
                                            <div className='form-group'>
                                                <textarea className='form-control' {...register15('tsTermSanction')}
                                                    autoComplete='off' />
                                            </div>
                                        </div>
                                    </div>



                                    <div className='row mt-3'>

                                        <label className="prog_lbl">

                                            <strong>Validity of Sanction</strong>
                                            <div className='prgs'>
                                                <span className='lft_crt'>{4000 - input['valOfSanction'].length} Characters left</span>
                                                <LinearProgress
                                                    variant="determinate"
                                                    value={input['valOfSanction'].length}
                                                />
                                            </div>
                                        </label>
                                        <div className='col-md-12'>
                                            <div className='form-group'>
                                                <textarea className='form-control'
                                                    {...register15('tsValiditySanction', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                    })} maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "valOfSanction") }} />
                                                <span className="vldn"> {errors15.tsValiditySanction && errors15.tsValiditySanction.message}</span>
                                            </div>
                                        </div>
                                    </div>


                                    <div className='row mt-3'>

                                        <label className="prog_lbl">

                                            <strong>DOP for Sanction</strong>
                                            <div className='prgs'>
                                                <span className='lft_crt'>{4000 - input['dopForSanction'].length} Characters left</span>
                                                <LinearProgress
                                                    variant="determinate"
                                                    value={input['dopForSanction'].length}
                                                />
                                            </div>
                                        </label>
                                        <div className='col-md-12'>
                                            <div className='form-group'>
                                                <textarea className='form-control' {...register15('tsDopSanction', {
                                                    maxLength: {
                                                        value: 4000,
                                                        message: "The maximum length of the field is 4000"
                                                    },
                                                    validate: (value) => {
                                                        if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                        return true;
                                                    },
                                                })} maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "dopForSanction") }} />
                                                <span className="vldn"> {errors15.tsDopSanction && errors15.tsDopSanction.message}</span>
                                            </div>
                                        </div>
                                    </div>



                                    <div className='row mt-3'>

                                        <label className="prog_lbl">

                                            <strong>DOP for Relaxation</strong>
                                            <div className='prgs'>
                                                <span className='lft_crt'>{4000 - input['dopForRelaxation'].length} Characters left</span>
                                                <LinearProgress
                                                    variant="determinate"
                                                    value={input['dopForRelaxation'].length}
                                                />
                                            </div>
                                        </label>
                                        <div className='col-md-12'>
                                            <div className='form-group'>
                                                <textarea className='form-control' {...register15('tsDopRelaxtion', {
                                                    maxLength: {
                                                        value: 4000,
                                                        message: "The maximum length of the field is 4000"
                                                    },
                                                    validate: (value) => {
                                                        if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                        return true;
                                                    },
                                                })} maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "dopForRelaxation") }} />
                                                <span className="vldn"> {errors15.tsDopRelaxtion && errors15.tsDopRelaxtion.message}</span>
                                            </div>
                                        </div>
                                    </div>


                                    <div className='row mt-3'>

                                        <label className="prog_lbl">

                                            <strong>Recommendation</strong>
                                            <div className='prgs'>
                                                <span className='lft_crt'>{4000 - input['recommendations'].length} Characters left</span>
                                                <LinearProgress
                                                    variant="determinate"
                                                    value={input['recommendations'].length}
                                                />
                                            </div>
                                        </label>
                                        <div className='col-md-12'>
                                            <div className='form-group'>
                                                <textarea className='form-control' {...register15('tsRecommendation', {
                                                    maxLength: {
                                                        value: 4000,
                                                        message: "The maximum length of the field is 4000"
                                                    },
                                                    validate: (value) => {
                                                        if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                        return true;
                                                    },
                                                })} maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "recommendations") }} />
                                                <span className="vldn"> {errors15.tsRecommendation && errors15.tsRecommendation.message}</span>
                                            </div>
                                        </div>
                                    </div>


                                </div>

                                <div className="button-container-center">
                                    {(editable || (!isMaker && locked)) && !tsIdExists && <p className='color-red'>Please save the autofilled data before proceeding.</p>}
                                </div>

                                <div className="button-container-center">
                                    {(editable || (!isMaker && locked)) && <button type='submit' className='save'>{!tsIdExists ? 'Save' : 'Update'} <i className="fa fa-circle-check"></i></button>}
                                </div>


                            </form>
                        </Accordion.Body>
                    </Accordion.Item>
                </Accordion>
                <div className="button-container-center">
                    {appId > 0 && <button type='button' className='btn btnPrev' onClick={() => navigate(-1)}><i className="fa fa-arrow-left"></i> Prev</button>}
                    {appId > 0 && <button type='button' className='btn btnNext' onClick={goToNext}>Next <i className="fa fa-arrow-right"></i></button>}
                </div>
            </div>
            {loading && <Loading />}
            <MessageModal
                open={isOpen}
                onClose={hideMessage}
                message={messageConfig.message}
                type={messageConfig.type}
                totalMessages={totalMessages}
                currentIndex={currentIndex}
                onNext={nextMessage}
                onPrev={prevMessage}
                hasNext={hasNext}
                hasPrev={hasPrev}
            />
        </Fragment >
    )
}
export default SectionFour;