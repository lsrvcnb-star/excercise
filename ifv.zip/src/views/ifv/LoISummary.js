import DownloadIcon from '@mui/icons-material/Download';
import RefreshIcon from '@mui/icons-material/Refresh';
import { Alert, Box, CircularProgress, IconButton, Modal, Tooltip } from '@mui/material';
import { QueryClient, QueryClientProvider, useQuery } from '@tanstack/react-query';
import axios from 'axios';
import Loading from 'components/Loading';
import { format } from 'date-fns';
import { MaterialReactTable, useMaterialReactTable } from 'material-react-table';
import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from "react-router-dom";
import IfvAppraisalService from 'services/IfvAppraisalService';
import MinutesService from 'services/MinutesService';
import CommonUtil from 'services/utils/CommonUtil';
import FileUtil from 'services/utils/FileUtil';
import { getJwtToken } from 'services/utils/JwtUtil';
const LoISummaryQuery = () => {
    const [loading, setLoading] = useState(false);
    const [showMsg, setShowMsg] = useState(false);
    const [errorMsg, setErrorMsg] = useState('');
    const [backendError, setBackendError] = useState(null);
    const navigate = useNavigate();
    const [columnFilters, setColumnFilters] = useState([]);
    const [globalFilter, setGlobalFilter] = useState('');
    const [sorting, setSorting] = useState([]);
    const [pagination, setPagination] = useState({
        pageIndex: 0,
        pageSize: 10,
    });
    const { data: queryData, isError, isRefetching, isLoading, refetch, error } = useQuery({
        queryKey: ['table-data', columnFilters, globalFilter, pagination.pageIndex, pagination.pageSize, sorting],
        queryFn: async () => {
            const user = IfvAppraisalService.getCurrentUser();
            const url = new URL(`${process.env.REACT_APP_API_ENDPOINT}ifv-proposals-loi/getAllOnUserTypeOnPage/${user.ofrType}/${user.ofrEmpId}`);
            url.searchParams.set('start', `${pagination.pageIndex * pagination.pageSize}`);
            url.searchParams.set('size', `${pagination.pageSize}`);
            url.searchParams.set('filters', JSON.stringify(columnFilters ?? []));
            url.searchParams.set('globalFilter', globalFilter);
            url.searchParams.set('sorting', JSON.stringify(sorting ?? []));
            //    url.searchParams.set('status', '');
            try {
                const response = await axios.get(url.href, {
                    headers: { Authorization: `Bearer ${getJwtToken()}` },
                });
                return response.data;
            } catch (error) {
                console.error('Backend error while loading data:', error);
                setBackendError('ERR_BAD_RESPONSE');
                throw error;
            }
        },
    });
    const handleDownload = async (id) => {
        setLoading(id);
        try {
            const response = await MinutesService.getLoIDocumentByPropLoIId(id);
            if (!CommonUtil.isEmpty(response.data.fileName)) {
                FileUtil.downloadFile(response.data.fileDataBytea, response.data.fileName, "application/pdf");
            } else {
                alert('No file')
            }

        } catch (error) {
            const resMessage =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            console.log(resMessage);
            alert('Error occurred while generating report');
        } finally {
            setLoading(null);
        }
    };
    useEffect(() => {
        if (isError && error) {
            console.error('Query error:', error);
            setBackendError('ERR_BAD_RESPONSE');
        }
    }, [isError, error]);
    const columns = useMemo(() => [
        {
            accessorKey: 'ifvName',
            header: 'Name of the Bank',
            size: 200,
        },
        {
            accessorKey: 'loiNo',
            header: 'LoI No',
            size: 100,
        },
        {
            accessorKey: 'schemeName',
            header: 'Scheme',
            size: 100,
        },
        {
            accessorKey: 'amount',
            header: 'Amount',
            size: 150,

        },
        {
            accessorKey: 'loiDate',
            header: 'Date',
            size: 50,
            Cell: ({ cell }) => format(new Date(cell.getValue()), 'dd-MM-yyyy'),
        },
    ], []);
    const table = useMaterialReactTable({
        columns,
        data: queryData?.content || [],
        enableRowNumbers: true,
        rowNumberDisplayMode: 'static',
        createDisplayMode: 'modal',
        editDisplayMode: 'modal',
        enableEditing: true,
        getRowId: (row) => row.id,
        muiTableContainerProps: { sx: { minHeight: '500px' } },
        initialState: {
            showColumnFilters: true,
        },
        manualFiltering: true,
        manualPagination: true,
        manualSorting: true,
        muiToolbarAlertBannerProps: isError
            ? {
                color: 'error',
                children: error?.response?.data?.message || 'Error loading data',
            }
            : undefined,
        rowCount: queryData?.totalElements ?? 0,
        state: {
            columnFilters,
            globalFilter,
            isLoading,
            pagination,
            showAlertBanner: isError,
            showProgressBars: isRefetching,
            sorting,
        },
        onColumnFiltersChange: setColumnFilters,
        onGlobalFilterChange: setGlobalFilter,
        onPaginationChange: setPagination,
        onSortingChange: setSorting,
        renderTopToolbarCustomActions: () => (
            <Tooltip arrow title="Refresh Data">
                <IconButton onClick={() => refetch()}>
                    <RefreshIcon />
                </IconButton>
            </Tooltip>
        ),
        renderRowActions: ({ row }) => (
            <Box sx={{ display: 'flex' }}>
                <Tooltip title="Download">
                    <IconButton
                        onClick={(event) => { event.stopPropagation(); handleDownload(row.original.id) }}
                        sx={{ color: loading === row.original.id ? 'gray' : 'primary.main' }}
                        disabled={loading === row.original.id}
                    >
                        {loading === row.original.id ? (
                            <CircularProgress size={24} />
                        ) : (
                            <DownloadIcon />
                        )}
                    </IconButton>
                </Tooltip>
            </Box>
        ),
        muiTableBodyRowProps: ({ row }) => ({
            onClick: () => {
                navigate('/ifv/generate-loi', {
                    state: { id: row.original.id },
                });
            },
            sx: { cursor: 'pointer' },
        }),
    });
    return (
        <div className={loading ? 'blur-background' : ''}>
            <h5><strong>Generate LoI</strong></h5>
            {backendError && (
                <Alert severity="error" onClose={() => setBackendError(null)}>
                    Error: {backendError}
                </Alert>
            )}
            <MaterialReactTable table={table} />
            {loading && <Loading />}
            <Modal open={showMsg} onClose={() => setShowMsg(false)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Box sx={{ bgcolor: 'background.paper', boxShadow: 24, p: 4, borderRadius: 2, maxWidth: 400 }}>
                    <h5 className={errorMsg.includes('Error') ? 'alertMsg' : 'loadMsg'}>{errorMsg}</h5>
                    <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
                        <button className="btn btnRegister themebutton" onClick={() => setShowMsg(false)}>OK</button>
                    </Box>
                </Box>
            </Modal>
        </div>
    );
};
const queryClient = new QueryClient();
const LoISummary = () => (
    <QueryClientProvider client={queryClient}>
        <LoISummaryQuery />
    </QueryClientProvider>
);
export default LoISummary;