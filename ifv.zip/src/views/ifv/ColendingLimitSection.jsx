import AddIcon from "@mui/icons-material/Add";
import DeleteIcon from "@mui/icons-material/Delete";
import {
    Box,
    Button,
    CircularProgress,
    Collapse,
    IconButton,
    Paper,
    Table,
    TableBody,
    TableHead,
    TableRow
} from "@mui/material";
import {
    BankSelectCell,
    LoadingSpinner,
    StyledInput,
    StyledTableCell,
    StyledTableContainer,
    StyledTableRow,
    useBankOptions,
} from "components/common/colendingShared";
import { useEffect, useState } from "react";
import { Controller, useFieldArray, useForm } from "react-hook-form";
import {
    deleteColendingLimit,
    getColendingLimits,
    saveColendingLimits,
} from "services/minutesAdditionalDetailApi";
import Pattern from "services/validators/Pattern";

const ColendingLimitSection = ({ minuteSanctionId, open, isEditable }) => {
    const [loading, setLoading] = useState(false);
    const { bankOptions, loadingBanks } = useBankOptions(open);
    const amountRegex = /^\d{1,12}(\.\d{1,8})?$/;  // 12 before decimal, 8 after
    const ratioRegex = /^\d{1,3}:\d{1,3}$/;       // e.g. 60:40
    const [submitLoading, setSubmitLoading] = useState(false);
    const [deleteLoadingIndex, setDeleteLoadingIndex] = useState(null);

    const { control, handleSubmit, setValue, reset } = useForm({
        defaultValues: { limits: [] },
    });

    const { fields, append, remove, replace } = useFieldArray({
        control,
        name: "limits",
    });

    const fetchData = async () => {
        try {
            setLoading(true);
            const res = await getColendingLimits(minuteSanctionId);
            const formatted =
                res?.map((item) => ({
                    dbId: item.id,
                    bankName: item.bankName,
                    cifNumber: item.cifNumber,
                    lendingLimit: item.lendingLimit || "",
                    scheme: item.scheme || "",
                    riskSharingRatio: item.riskSharingRatio || "",
                    initialOperatingLimit: item.initialOperatingLimit || "",
                })) || [];
            replace(formatted);
        } catch (err) {
            console.error("Fetch error", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (open && minuteSanctionId) {
            fetchData();
        }
    }, [open, minuteSanctionId]);

    const handleAddRow = () => {
        append({
            dbId: null,
            bankName: "",
            cifNumber: "",
            lendingLimit: "",
            scheme: "",
            riskSharingRatio: "",
            initialOperatingLimit: "",
        });
    };

    const handleDelete = async (index, dbId) => {
        if (!window.confirm("Delete this record?")) return;

        try {
            setDeleteLoadingIndex(index);

            if (dbId) await deleteColendingLimit(dbId);

            remove(index);
        } catch (err) {
            console.error("Delete failed", err);
            alert("Delete failed. Please try again.");
        } finally {
            setDeleteLoadingIndex(null);
        }
    };

    const onSubmit = async (formData) => {

        if (!formData?.limits || formData.limits.length === 0) {
            alert("Please add at least one record before submitting.");
            return;
        }

        const hasEmptyRow = formData.limits.some(
            (row) =>
                !row.cifNumber ||
                !row.lendingLimit ||
                !row.scheme ||
                !row.riskSharingRatio ||
                !row.initialOperatingLimit
        );

        if (hasEmptyRow) {
            alert("All fields are mandatory. Please fill all rows.");
            return;
        }

        try {
            setSubmitLoading(true);

            const payload = formData.limits.map((item) => ({
                bankName: item.bankName,
                cifNumber: item.cifNumber,
                lendingLimit: item.lendingLimit,
                scheme: item.scheme,
                riskSharingRatio: item.riskSharingRatio,
                initialOperatingLimit: item.initialOperatingLimit,
                minuteSanctionId,
            }));

            await saveColendingLimits(minuteSanctionId, payload);
            alert("Saved successfully");
            fetchData();
        } catch (err) {
            console.error("Save failed", err);
            alert("Save failed. Please try again.");
        } finally {
            setSubmitLoading(false);
        }
    };

    return (
        <Collapse in={open} timeout="auto" unmountOnExit>
            <Box mt={2}>
                {loading ? (
                    <LoadingSpinner />
                ) : (
                    <Box>
                        <StyledTableContainer component={Paper}>
                            <Table size="small" stickyHeader>
                                <TableHead>
                                    <TableRow>
                                        <StyledTableCell sx={{ width: "50px" }}>Agenda No</StyledTableCell>
                                        <StyledTableCell sx={{ minWidth: "280px" }}>Name of the Bank</StyledTableCell>
                                        <StyledTableCell sx={{ width: "140px" }}>Lending Limit (₹ in Crore)</StyledTableCell>
                                        <StyledTableCell sx={{ width: "150px" }}>Scheme</StyledTableCell>
                                        <StyledTableCell sx={{ width: "130px" }}>Risk Sharing Ratio</StyledTableCell>
                                        <StyledTableCell sx={{ width: "150px" }}>Initial Operating Limit (₹ in Crore)</StyledTableCell>
                                        <StyledTableCell align="center" sx={{ width: "80px" }}>
                                            {isEditable &&
                                                <IconButton
                                                    onClick={handleAddRow}
                                                    size="small"
                                                    disabled={submitLoading || deleteLoadingIndex !== null}
                                                    sx={{
                                                        bgcolor: 'primary.light',
                                                        color: 'white',
                                                        padding: '4px',
                                                        '&:hover': {
                                                            bgcolor: 'primary.main',
                                                        },
                                                    }}
                                                >
                                                    <AddIcon fontSize="small" />
                                                </IconButton>
                                            }
                                        </StyledTableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {fields.length === 0 ? (
                                        <TableRow>
                                            <StyledTableCell colSpan={7} align="center">
                                                No Records
                                            </StyledTableCell>
                                        </TableRow>
                                    ) : (
                                        fields.map((row, index) => (
                                            <StyledTableRow key={row.id}>
                                                <StyledTableCell>{index + 1}</StyledTableCell>
                                                <StyledTableCell>
                                                    <Controller
                                                        name={`limits.${index}.cifNumber`}
                                                        control={control}
                                                        rules={{ required: "Bank is required" }}
                                                        render={({ field, fieldState }) => (
                                                            <BankSelectCell
                                                                field={field}
                                                                bankOptions={bankOptions}
                                                                loadingBanks={loadingBanks}
                                                                error={!!fieldState.error}
                                                                helperText={fieldState.error?.message}
                                                                onBankChange={(name) =>
                                                                    setValue(`limits.${index}.bankName`, name)
                                                                }
                                                            />
                                                        )}
                                                    />
                                                </StyledTableCell>
                                                <StyledTableCell>
                                                    <Controller
                                                        name={`limits.${index}.lendingLimit`}
                                                        control={control}
                                                        rules={{
                                                            required: "Amount is required",
                                                            pattern: {
                                                                value: amountRegex,
                                                                message: "Max 12 digits + 8 decimals allowed",
                                                            },
                                                            validate: (val) => parseFloat(val) > 0 || "Amount must be > 0",
                                                        }}
                                                        render={({ field, fieldState }) => (
                                                            <StyledInput
                                                                {...field}
                                                                onChange={(e) => {
                                                                    field.onChange(e);
                                                                }}
                                                                error={!!fieldState.error}
                                                                helperText={fieldState.error?.message}
                                                            />
                                                        )}
                                                    />
                                                </StyledTableCell>
                                                <StyledTableCell>
                                                    <Controller
                                                        name={`limits.${index}.scheme`}
                                                        control={control}
                                                        rules={{ required: "Scheme is required" }}
                                                        render={({ field, fieldState }) => (
                                                            <StyledInput
                                                                {...field}
                                                                placeholder="Enter scheme"
                                                                onChange={(e) => {
                                                                    Pattern.sanitizeInput(e);
                                                                    field.onChange(e);
                                                                }}
                                                                error={!!fieldState.error}
                                                                helperText={fieldState.error?.message}
                                                            />
                                                        )}
                                                    />
                                                </StyledTableCell>
                                                <StyledTableCell>
                                                    <Controller
                                                        name={`limits.${index}.riskSharingRatio`}
                                                        control={control}
                                                        rules={{
                                                            required: "Ratio is required",
                                                            pattern: {
                                                                value: ratioRegex,
                                                                message: "Format should be like 60:40",
                                                            },
                                                        }}
                                                        render={({ field, fieldState }) => (
                                                            <StyledInput
                                                                {...field}
                                                                placeholder="e.g., 80:20"
                                                                error={!!fieldState.error}
                                                                helperText={fieldState.error?.message}
                                                            />
                                                        )}
                                                    />
                                                </StyledTableCell>
                                                <StyledTableCell>
                                                    <Controller
                                                        name={`limits.${index}.initialOperatingLimit`}
                                                        control={control}
                                                        rules={{
                                                            required: "Amount is required",
                                                            pattern: {
                                                                value: amountRegex,
                                                                message: "Max 12 digits + 8 decimals allowed",
                                                            },
                                                            validate: (val) => parseFloat(val) > 0 || "Amount must be > 0",
                                                        }}
                                                        render={({ field, fieldState }) => (
                                                            <StyledInput
                                                                {...field}
                                                                onChange={(e) => {
                                                                    field.onChange(e);
                                                                }}
                                                                error={!!fieldState.error}
                                                                helperText={fieldState.error?.message}
                                                            />
                                                        )}
                                                    />
                                                </StyledTableCell>
                                                <StyledTableCell align="center">
                                                    {isEditable &&
                                                        <IconButton
                                                            color="error"
                                                            size="small"
                                                            disabled={deleteLoadingIndex === index || submitLoading}
                                                            onClick={() => handleDelete(index, row.dbId)}
                                                        >
                                                            {deleteLoadingIndex === index ? (
                                                                <CircularProgress size={18} />
                                                            ) : (
                                                                <DeleteIcon fontSize="small" />
                                                            )}
                                                        </IconButton>
                                                    }
                                                </StyledTableCell>
                                            </StyledTableRow>
                                        ))
                                    )}
                                </TableBody>
                            </Table>
                        </StyledTableContainer>
                        {isEditable && <Box mt={2} display="flex" gap={2}>
                            <Button
                                type="button"
                                variant="contained"
                                onClick={handleSubmit(onSubmit)}
                                disabled={submitLoading || deleteLoadingIndex !== null}
                            >
                                {submitLoading ? (
                                    <CircularProgress size={20} />
                                ) : (
                                    "Save Colending Limits"
                                )}
                            </Button>
                        </Box>
                        }
                    </Box>
                )}
            </Box>
        </Collapse>
    );
};

export default ColendingLimitSection;