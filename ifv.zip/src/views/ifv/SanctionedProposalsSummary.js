import RefreshIcon from '@mui/icons-material/Refresh';
import { IconButton, Tooltip } from '@mui/material';
import {
    QueryClient,
    QueryClientProvider,
    keepPreviousData,
    useQuery
} from '@tanstack/react-query';
import axios from 'axios';
import { format } from 'date-fns';
import {
    MaterialReactTable,
    useMaterialReactTable,
} from 'material-react-table';
import { useMemo, useState } from 'react';
import { useLocation } from "react-router-dom";
import { getJwtToken } from 'services/utils/JwtUtil';
const SancSummary = () => {
    const location = useLocation();
    const mode = location.state?.mode || '';
    const [columnFilters, setColumnFilters] = useState([]);
    const [globalFilter, setGlobalFilter] = useState('');
    const [sorting, setSorting] = useState([]);
    const [pagination, setPagination] = useState({
        pageIndex: 0,
        pageSize: 10,
    });
    const formatCustomerId = (custId) => {
        if (!custId) return '';
        const stringId = custId.toString();
        return stringId.length < 7 ? stringId.padStart(7, '0') : stringId;
    };
    const {
        data: queryData,
        isError,
        isRefetching,
        isLoading,
        refetch,
        error,
    } = useQuery({
        queryKey: [
            'table-data',
            columnFilters,
            globalFilter,
            pagination.pageIndex,
            pagination.pageSize,
            sorting,
        ],
        queryFn: async () => {
            const url = new URL(`${process.env.REACT_APP_API_ENDPOINT}ifv/masters/getSanctionDetailsOnPage`);
            url.searchParams.set('start', `${pagination.pageIndex * pagination.pageSize}`);
            url.searchParams.set('size', `${pagination.pageSize}`);
            url.searchParams.set('filters', JSON.stringify(columnFilters ?? []));
            url.searchParams.set('globalFilter', globalFilter);
            url.searchParams.set('sorting', JSON.stringify(sorting ?? []));
            url.searchParams.set('status', mode);
            try {
                const response = await axios.get(url.href, {
                    headers: { Authorization: `Bearer ${getJwtToken()}` },
                });
                return response.data;
            } catch (error) {
                console.error('Backend error while loading data:', error);
                throw error;
            }
        },
        placeholderData: keepPreviousData,
    });

    const columns = useMemo(() => [
        {
            accessorKey: 'bnlRequestNo',
            header: 'Request No',
            size: 50,
        },
        {
            accessorKey: 'bnaApplProjDesc',
            header: 'Description',
            size: 200,
        },
        {
            accessorKey: 'bnlSlAcctNo',
            header: 'Account No',
            size: 50,
        },
        {
            accessorKey: 'bnaApplNo',
            header: 'Application No',
            size: 50,
        },
        {
            accessorKey: 'bnlSanctAmt',
            header: 'Sanctioned Amount (Rs.)',
            size: 150,
            muiTableHeaderCellProps: {
                align: 'right'
            },
            muiTableBodyCellProps: {
                align: 'right'
            },
            Cell: ({ cell }) => cell.getValue().toLocaleString('en-IN')
        },
        // {
        //     accessorKey: 'bnlSanctDt',
        //     header: 'Sanctioned Date',
        //     Cell: ({ cell }) => format(new Date(cell.getValue()), 'dd-MM-yyyy'),
        // },
    ], []);
    const tableData = queryData?.content ?? [];
    const totalRows = queryData?.totalElements ?? 0;
    const table = useMaterialReactTable({
        columns,
        data: tableData,
        getRowId: (row) => row.id,
        muiTableContainerProps: {
            sx: {
                minHeight: '500px',
            },
        },
        initialState: { showColumnFilters: true },
        manualFiltering: true,
        manualPagination: true,
        manualSorting: true,
        muiToolbarAlertBannerProps: isError
            ? {
                color: 'error',
                children: 'Currently facing some technical issues. Please try again later.',
            }
            : undefined,
        onColumnFiltersChange: setColumnFilters,
        onGlobalFilterChange: setGlobalFilter,
        onPaginationChange: setPagination,
        onSortingChange: setSorting,
        renderTopToolbarCustomActions: () => (
            <Tooltip arrow title="Refresh Data">
                <IconButton onClick={() => refetch()}>
                    <RefreshIcon />
                </IconButton>
            </Tooltip>
        ),
        rowCount: totalRows,
        state: {
            columnFilters,
            globalFilter,
            isLoading,
            pagination,
            showAlertBanner: isError,
            showProgressBars: isRefetching,
            sorting,
        },
        enableRowNumbers: true,
        rowNumberDisplayMode: 'static',
        muiDetailPanelProps: () => ({
            sx: (theme) => ({
                backgroundColor:
                    theme.palette.mode === 'dark'
                        ? 'rgba(255,210,244,0.1)'
                        : 'rgba(0,0,0,0.1)',
            }),
        }),
    });
    return (<MaterialReactTable table={table} />);
};
const queryClient = new QueryClient();
const SanctionedProposalsSummary = () => (
    <QueryClientProvider client={queryClient}>
        <SancSummary />
    </QueryClientProvider>
);
export default SanctionedProposalsSummary;