import CloseIcon from "@mui/icons-material/Close";
import CloudDownloadIcon from "@mui/icons-material/CloudDownload";
import DescriptionIcon from "@mui/icons-material/Description";
import VisibilityIcon from "@mui/icons-material/Visibility";
import {
    Box,
    Chip,
    Dialog,
    DialogContent,
    DialogTitle,
    Grid,
    Paper,
    Typography
} from "@mui/material";
import CircularProgress from "@mui/material/CircularProgress";

import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFnsV3";

import { Alert, Button, IconButton, Snackbar, Tooltip } from "@mui/material";

import {
    keepPreviousData,
    QueryClient,
    QueryClientProvider,
    useQuery
} from "@tanstack/react-query";

import {
    MaterialReactTable,
    useMaterialReactTable
} from "material-react-table";

import { useMemo, useState } from "react";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useNavigate } from "react-router-dom";
import MinutesService from "services/MinutesService";

const queryClient = new QueryClient();

function SignedLoiSummaryTable() {
  const [selectedRow, setSelectedRow] = useState(null);
  const navigate = useNavigate();

  const [globalFilter, setGlobalFilter] = useState("");
  const [columnFilters, setColumnFilters] = useState([]);

  const [sorting, setSorting] = useState([
    {
      id: "uploadedDate",
      desc: true,
    },
  ]);

  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: 10,
  });

  const [downloadingFiles, setDownloadingFiles] = useState({});

  const uploadedDateFilter = columnFilters.find(
    (f) => f.id === "uploadedDate"
  )?.value;

  const { data, isLoading, isFetching, isError, error } = useQuery({
    queryKey: [
      "signed-loi-summary",
      pagination,
      sorting,
      globalFilter,
      columnFilters,
    ],
    queryFn: () =>
      MinutesService.fetchSignedLoiSummary({
        page: pagination.pageIndex,
        size: pagination.pageSize,

        ifvAppNo: columnFilters.find((f) => f.id === "ifvAppNo")?.value || "",

        bankRefNo: columnFilters.find((f) => f.id === "bankRefNo")?.value || "",

        bankName: columnFilters.find((f) => f.id === "bankName")?.value || "",

        scheme: columnFilters.find((f) => f.id === "scheme")?.value || "",

        loiNo: columnFilters.find((f) => f.id === "loiNo")?.value || "",

        fileName: columnFilters.find((f) => f.id === "fileName")?.value || "",

        uploadedBy:
          columnFilters.find((f) => f.id === "uploadedBy")?.value || "",

        status: columnFilters.find((f) => f.id === "status")?.value || "",

        uploadedDateFrom: uploadedDateFilter?.[0] || null,

        uploadedDateTo: uploadedDateFilter?.[1] || null,

        sortField: sorting?.[0]?.id,

        sortDirection: sorting?.[0]?.desc ? "desc" : "asc",
      }),
    placeholderData: keepPreviousData,
  });

  const [snackbar, setSnackbar] = useState({
    open: false,
    severity: "error",
    message: "",
  });

  const handleDownload = async (filePath, fileName) => {
    setDownloadingFiles((prev) => ({
      ...prev,
      [filePath]: true,
    }));

    try {
      const response = await MinutesService.downloadSignedLoIDocument(
        filePath,
        fileName
      );
      const url = window.URL.createObjectURL(new Blob([response.data]));

      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", fileName);

      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (err) {
      setSnackbar({
        open: true,
        severity: "error",
        message: err?.message || "Failed to download file.",
      });
    } finally {
      setDownloadingFiles((prev) => ({
        ...prev,
        [filePath]: false,
      }));
    }
  };

  const columns = useMemo(
    () => [
      {
        accessorKey: "loiNo",
        header: "LoI No",
        size: 80,
      },

      {
        accessorKey: "bankName",
        header: "Bank Name",
        size: 100,
      },

      {
        accessorKey: "scheme",
        header: "Scheme",
        size: 80,
      },

      {
        accessorKey: "sanctionAmount",
        header: "Amount (₹ in Cr)",
        size: 80,
        Cell: ({ cell }) =>
          cell.getValue()
            ? `₹ ${Number(cell.getValue()).toLocaleString("en-IN")}`
            : "-",
      },

      {
        accessorKey: "fileName",
        header: "File Name",
        size: 100,
      },

      {
        accessorKey: "status",
        header: "Status",
        size: 80,
        Cell: ({ cell }) => {
          const status = cell.getValue();

          return (
            <span
              className={`badge ${
                status === "ISSUED"
                  ? "bg-primary"
                  : status === "COUNTER_SIGNED"
                  ? "bg-success"
                  : "bg-secondary"
              }`}
            >
              {status}
            </span>
          );
        },
      },
    ],
    []
  );

  const table = useMaterialReactTable({
    columns,

    data: data?.content ?? [],

    rowCount: data?.totalElements ?? 0,

    manualPagination: true,
    manualSorting: true,
    manualFiltering: true,
    enableRowActions: true,
    positionActionsColumn: "last",

    onPaginationChange: setPagination,
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    onColumnFiltersChange: setColumnFilters,

    state: {
      pagination,
      sorting,
      globalFilter,
      columnFilters,
      isLoading,
      showProgressBars: isFetching,
      showAlertBanner: isError,
    },

    renderRowActions: ({ row }) => (
      <Box sx={{ display: "flex", gap: 1 }}>
        <Tooltip title="View Details">
          <IconButton
            color="info"
            sx={{
              backgroundColor: "#E1F5FE",
              "&:hover": {
                backgroundColor: "#B3E5FC",
              },
            }}
            onClick={() => setSelectedRow(row.original)}
          >
            <VisibilityIcon />
          </IconButton>
        </Tooltip>

        {/* Issued LoI Download */}
        <Tooltip title="Download Issued LoI">
          <IconButton
            color="primary"
            sx={{
              backgroundColor: "#E3F2FD",
              "&:hover": {
                backgroundColor: "#BBDEFB",
              },
            }}
            disabled={downloadingFiles[row.original.filePath]}
            onClick={() =>
              handleDownload(row.original.filePath, row.original.fileName)
            }
          >
            {downloadingFiles[row.original.filePath] ? (
              <CircularProgress size={20} />
            ) : (
              <DescriptionIcon />
            )}
          </IconButton>
        </Tooltip>

        {/* Counter Signed LoI Download */}
        {row.original.status === "COUNTER_SIGNED" &&
          row.original.counterFilePath && (
            <Tooltip title="Download Counter Signed LoI">
              <IconButton
                color="success"
                sx={{
                  backgroundColor: "#E8F5E9",
                  "&:hover": {
                    backgroundColor: "#C8E6C9",
                  },
                }}
                disabled={downloadingFiles[row.original.counterFilePath]}
                onClick={() =>
                  handleDownload(
                    row.original.counterFilePath,
                    row.original.counterFileName
                  )
                }
              >
                {downloadingFiles[row.original.counterFilePath] ? (
                  <CircularProgress size={20} />
                ) : (
                  <CloudDownloadIcon />
                )}
              </IconButton>
            </Tooltip>
          )}
      </Box>
    ),

    muiTableHeadCellProps: {
      sx: {
        backgroundColor: "#E3F2FD",
        fontWeight: "bold",
      },
    },
  });

  return (
    <>
      {isError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error?.message ?? "Failed to fetch records"}
        </Alert>
      )}

      <Box
        sx={{
          mb: 2,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Box>
          <h5
            style={{
              margin: 0,
              fontWeight: 600,
            }}
          >
            Signed LoI Summary
          </h5>
        </Box>

        <Button
          variant="outlined"
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate("/ifv/dashboard")}
        >
          Back
        </Button>
      </Box>

      <MaterialReactTable table={table} />

      <Dialog
        open={Boolean(selectedRow)}
        onClose={() => setSelectedRow(null)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle
          sx={{
            background: "linear-gradient(90deg,#1976d2,#42a5f5)",
            color: "#fff",
            fontWeight: 600,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Typography
            variant="h6"
            sx={{
              color: "#fff",
              fontWeight: 600,
            }}
          >
            Signed LoI Details
          </Typography>

          <IconButton
            size="small"
            onClick={() => setSelectedRow(null)}
            sx={{
              color: "#fff",
              "&:hover": {
                backgroundColor: "rgba(255,255,255,0.15)",
              },
            }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>

        <DialogContent sx={{ p: 3 }}>
          {selectedRow && (
            <>
              <Paper
                elevation={0}
                sx={{
                  p: 2,
                  mb: 2,
                  border: "1px solid #E0E0E0",
                  borderRadius: 2,
                  backgroundColor: "#FAFAFA",
                }}
              >
                <Grid container spacing={2}>
                  <Grid item xs={12} md={8}>
                    <Typography
                      variant="h6"
                      sx={{
                        fontWeight: 700,
                        color: "#1565C0",
                      }}
                    >
                      {selectedRow.bankName}
                    </Typography>

                    <Typography variant="body2" color="text.secondary">
                      CIF Number :{" "}
                      <strong>{selectedRow.cifNumber || "-"}</strong>
                    </Typography>

                    <Typography variant="body2" color="text.secondary">
                      LoI No : <strong>{selectedRow.loiNo}</strong>
                    </Typography>
                  </Grid>

                  <Grid
                    item
                    xs={12}
                    md={4}
                    sx={{
                      display: "flex",
                      justifyContent: "flex-end",
                      alignItems: "center",
                    }}
                  >
                    <Chip
                      label={selectedRow.status}
                      color={
                        selectedRow.status === "ISSUED"
                          ? "primary"
                          : selectedRow.status === "COUNTER_SIGNED"
                          ? "success"
                          : "default"
                      }
                    />
                  </Grid>
                </Grid>
              </Paper>

              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Paper variant="outlined" sx={{ p: 2, height: "100%" }}>
                    <Typography
                      variant="subtitle2"
                      color="primary"
                      gutterBottom
                    >
                      IFV App No
                    </Typography>

                    <Typography>{selectedRow.ifvAppNo || "-"}</Typography>
                  </Paper>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Paper variant="outlined" sx={{ p: 2, height: "100%" }}>
                    <Typography
                      variant="subtitle2"
                      color="primary"
                      gutterBottom
                    >
                      Bank Ref No
                    </Typography>

                    <Typography>{selectedRow.bankRefNo || "-"}</Typography>
                  </Paper>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Paper variant="outlined" sx={{ p: 2, height: "100%" }}>
                    <Typography variant="subtitle2" color="primary">
                      Sanction Amount
                    </Typography>

                    <Typography
                      variant="h6"
                      sx={{
                        color: "#2E7D32",
                        fontWeight: 600,
                      }}
                    >
                      ₹{" "}
                      {selectedRow.sanctionAmount
                        ? Number(selectedRow.sanctionAmount).toLocaleString(
                            "en-IN"
                          )
                        : "-"}
                    </Typography>
                  </Paper>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Paper variant="outlined" sx={{ p: 2, height: "100%" }}>
                    <Typography variant="subtitle2" color="primary">
                      File Name
                    </Typography>

                    <Typography>{selectedRow.fileName || "-"}</Typography>
                  </Paper>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Paper variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="subtitle2" color="primary">
                      Uploaded By
                    </Typography>

                    <Typography>{selectedRow.uploadedBy || "-"}</Typography>
                  </Paper>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Paper variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="subtitle2" color="primary">
                      Uploaded Date
                    </Typography>

                    <Typography>
                      {selectedRow.uploadedDate
                        ? new Date(selectedRow.uploadedDate).toLocaleString()
                        : "-"}
                    </Typography>
                  </Paper>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Paper variant="outlined" sx={{ p: 2 }}>
                    <Typography variant="subtitle2" color="primary">
                      Sanction Date
                    </Typography>

                    <Typography>
                      {selectedRow.sanctionedDateTime
                        ? new Date(
                            selectedRow.sanctionedDateTime
                          ).toLocaleString()
                        : "-"}
                    </Typography>
                  </Paper>
                </Grid>

                <Grid item xs={12}>
                  <Paper
                    variant="outlined"
                    sx={{
                      p: 2,
                      backgroundColor: "#FAFAFA",
                    }}
                  >
                    <Typography
                      variant="subtitle2"
                      color="primary"
                      gutterBottom
                    >
                      Remarks
                    </Typography>

                    <Typography>{selectedRow.remarks || "-"}</Typography>
                  </Paper>
                </Grid>
              </Grid>
            </>
          )}
        </DialogContent>
      </Dialog>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() =>
          setSnackbar((prev) => ({
            ...prev,
            open: false,
          }))
        }
      >
        <Alert
          severity={snackbar.severity}
          onClose={() =>
            setSnackbar((prev) => ({
              ...prev,
              open: false,
            }))
          }
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
}

export default function ViewSignedLoiSummary() {
  return (
    <QueryClientProvider client={queryClient}>
      <LocalizationProvider dateAdapter={AdapterDateFns}>
        <SignedLoiSummaryTable />
      </LocalizationProvider>
    </QueryClientProvider>
  );
}
