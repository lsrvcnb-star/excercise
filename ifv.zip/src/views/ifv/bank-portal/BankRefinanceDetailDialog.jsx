import BadgeIcon from "@mui/icons-material/Badge";
import {
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Grid,
  Stack,
  TableContainer,
  Typography
} from "@mui/material";

import CloudDownloadIcon from "@mui/icons-material/CloudDownload";

import { format } from "date-fns";

const DetailField = ({ label, value }) => (
  <Box>
    <Typography
      variant="caption"
      sx={{ color: "text.secondary", fontWeight: 600 }}
    >
      {label}
    </Typography>

    <Typography variant="body2">{value || "-"}</Typography>
  </Box>
);

export default function BankRefinanceDetailDialog({
  open,
  onClose,
  data,
  onDownload,
}) {
  if (!data) return null;

  const documents = [
    {
      title: "Application Document",
      fileName: data.refinanceAppFileName,
      filePath: data.refinanceAppFilePath,
    },
    {
      title: "Authorized Signatory Document",
      fileName: data.authorizedSignatoryFileName,
      filePath: data.authorizedSignatoryFilePath,
    },
  ];

  return (
    <Dialog open={open} onClose={onClose} maxWidth="lg" fullWidth>
      <DialogTitle
        sx={{
          bgcolor: "#1976d2",
          color: "#fff",
          fontWeight: 600,
        }}
      >
        Application Details
      </DialogTitle>

      <DialogContent sx={{ mt: 2 }}>
        <Stack spacing={3}>
          {/* Application Info */}
          <Card variant="outlined">
            <CardContent>
              <Typography variant="h6" gutterBottom color="primary">
                Application Information
              </Typography>

              <Divider sx={{ mb: 2 }} />

              <Grid container spacing={2}>
                <Grid item xs={12} md={4}>
                  <DetailField
                    label="Application Ref No"
                    value={data.appRefId}
                  />
                </Grid>

                <Grid item xs={12} md={4}>
                  <DetailField label="Bank Name" value={data.nameOfBank} />
                </Grid>

                <Grid item xs={12} md={4}>
                  <DetailField label="CIF Number" value={data.cifNumber} />
                </Grid>

                <Grid item xs={12} md={4}>
                  <DetailField label="Type Of Bank" value={data.typeOfBank} />
                </Grid>

                <Grid item xs={12} md={4}>
                  <DetailField
                    label="Scheme Name"
                    value={data.customSchemeName}
                  />
                </Grid>

                <Grid item xs={12} md={4}>
                  <Typography
                    variant="caption"
                    sx={{
                      color: "text.secondary",
                      fontWeight: 600,
                    }}
                  >
                    Status
                  </Typography>

                  <Box mt={0.5}>
                    <Chip
                      label={data.applicationStatus}
                      color="success"
                      size="small"
                    />
                  </Box>
                </Grid>

                <Grid item xs={12} md={4}>
                  <DetailField label="Currency" value={data.currencyType} />
                </Grid>

                {/* <Grid item xs={12} md={4}>
                  <DetailField label="Fund" value={data.fundDescription} />
                </Grid> */}

                <Grid item xs={12} md={4}>
                  <DetailField
                    label="Submitted Date"
                    value={
                      data.submittedDateTime
                        ? format(
                            new Date(data.submittedDateTime),
                            "dd-MMM-yyyy hh:mm a"
                          )
                        : "-"
                    }
                  />
                </Grid>

                {/* <Grid item xs={12} md={4}>
                  <DetailField
                    label="Scheme Short Name"
                    value={data.schemeShortName}
                  />
                </Grid>

                <Grid item xs={12}>
                  <DetailField
                    label="Scheme Long Name"
                    value={data.schemeLongName}
                  />
                </Grid> */}

                <Grid item xs={12} md={4}>
                  <DetailField label="Submitted By" value={data.submittedBy} />
                </Grid>

                <Grid item xs={12} md={4}>
                  <DetailField
                    label="Submitter Email"
                    value={data.submitByEmail}
                  />
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          <Card variant="outlined">
            <CardContent>
              <Typography variant="h6" color="primary" gutterBottom>
                Refinance Proposal Details
              </Typography>

              <Divider sx={{ mb: 2 }} />

              <TableContainer>
                <Box
                  component="table"
                  sx={{
                    width: "100%",
                    borderCollapse: "collapse",

                    "& th": {
                      bgcolor: "#1976d2",
                      color: "#fff",
                      p: 1.5,
                      textAlign: "left",
                      border: "1px solid #1565c0",
                    },

                    "& td": {
                      p: 1.5,
                      border: "1px solid #ddd",
                    },
                  }}
                >
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Amount</th>
                      <th>Rate Type</th>
                      <th>Rate Details</th>
                      <th>Tenure</th>
                      <th>Principal Repayment</th>
                      <th>Interest Reset</th>
                      <th>Maturity Date</th>
                    </tr>
                  </thead>

                  <tbody>
                    {data.proposals?.map((proposal, index) => (
                      <tr key={index}>
                        <td>{index + 1}</td>

                        <td>
                          {data.currencyType === "INR"
                            ? `₹ ${proposal.refinanceAmount} Cr`
                            : `${proposal.refinanceAmount} USD Mn`}
                        </td>

                        <td>{proposal.rateType}</td>

                        <td>
                          {proposal.rateType === "Fixed"
                            ? `${proposal.rateOfInterest}%`
                            : `${proposal.benchmark || "-"} + ${
                                proposal.spread || 0
                              } bps`}
                        </td>

                        <td>
                          {proposal.tenureInMonths} Month(s)
                          <br />
                          {proposal.tenureInDays} Day(s)
                        </td>

                        <td>{proposal.principalRepayment}</td>

                        <td>{proposal.interestReset || "-"}</td>

                        <td>{proposal.maturityDate || "-"}</td>
                      </tr>
                    ))}
                  </tbody>
                </Box>
              </TableContainer>
            </CardContent>
          </Card>

          {/* Framework */}
          <Card variant="outlined">
            <CardContent>
              <Divider sx={{ mb: 2 }} />

              <TableContainer>
                <Box
                  component="table"
                  sx={{
                    width: "100%",
                    borderCollapse: "collapse",

                    "& th": {
                      bgcolor: "#1976d2",
                      color: "#fff",
                      p: 1.5,
                      textAlign: "left",
                      fontWeight: 600,
                      border: "1px solid #1565c0",
                    },

                    "& td": {
                      p: 1.5,
                      border: "1px solid #e0e0e0",
                      verticalAlign: "middle",
                    },

                    "& tbody tr:nth-of-type(even)": {
                      bgcolor: "#fafafa",
                    },

                    "& tbody tr:hover": {
                      bgcolor: "#f5f9ff",
                    },
                  }}
                >
                  <thead>
                    <tr>
                      <th>Framework</th>
                      <th>Parameter</th>
                      <th style={{ width: "180px" }}>Value</th>
                    </tr>
                  </thead>

                  <tbody>
                    <tr>
                      <td rowSpan={2}>
                        <Typography fontWeight={600}>BASEL I / II</Typography>
                      </td>

                      <td>Tier I %</td>

                      <td>
                        <Chip
                          label={`${data.frameworkParmTier || 0}%`}
                          color="primary"
                          variant="outlined"
                          size="small"
                        />
                      </td>
                    </tr>

                    <tr>
                      <td>Capital-to-risk (weighted) assets ratio (CRAR) %</td>

                      <td>
                        <Chip
                          label={`${data.frameworkParmCRAR || 0}%`}
                          color="primary"
                          variant="outlined"
                          size="small"
                        />
                      </td>
                    </tr>

                    <tr>
                      <td rowSpan={2}>
                        <Typography fontWeight={600}>BASEL III</Typography>
                      </td>

                      <td>Common Equity Tier 1 (CET1) %</td>

                      <td>
                        <Chip
                          label={`${data.frameworkParmCET1 || 0}%`}
                          color="success"
                          variant="outlined"
                          size="small"
                        />
                      </td>
                    </tr>

                    <tr>
                      <td>Capital Conservation Buffer (CCB) %</td>

                      <td>
                        <Chip
                          label={`${data.frameworkParmCCB || 0}%`}
                          color="success"
                          variant="outlined"
                          size="small"
                        />
                      </td>
                    </tr>
                  </tbody>
                </Box>
              </TableContainer>
            </CardContent>
          </Card>

          {/* Bank Details */}
          <Card variant="outlined">
            <CardContent>
              <Typography variant="h6" color="primary" gutterBottom>
                Bank Account Details
              </Typography>

              <Divider sx={{ mb: 2 }} />

              <Grid container spacing={2}>
                <Grid item xs={12} md={4}>
                  <DetailField label="Bank Name" value={data.bankName} />
                </Grid>

                <Grid item xs={12} md={4}>
                  <DetailField
                    label="Account Number"
                    value={data.bankAccountNo}
                  />
                </Grid>

                <Grid item xs={12} md={4}>
                  <DetailField label="RTGS Code" value={data.rtgsCode} />
                </Grid>

                <Grid item xs={12} md={4}>
                  <DetailField label="NEFT Code" value={data.neftCode} />
                </Grid>

                <Grid item xs={12} md={4}>
                  <DetailField label="LEI" value={data.legalEntityIdentifier} />
                </Grid>

                <Grid item xs={12} md={4}>
                  <DetailField label="LEI Validity" value={data.leiValidity} />
                </Grid>

                <Grid item xs={12}>
                  <DetailField label="Bank Address" value={data.bankAddress} />
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          <Card variant="outlined">
            <CardContent>
              <Typography variant="h6" color="primary" gutterBottom>
                Authorized Signatories
              </Typography>

              <Divider sx={{ mb: 2 }} />

              <Grid container spacing={2}>
                {data.authorizedSignatories?.map((signatory, index) => (
                  <Grid item xs={12} md={6} key={index}>
                    <Card
                      variant="outlined"
                      sx={{
                        borderLeft: "4px solid #1976d2",
                      }}
                    >
                      <CardContent>
                        <Stack direction="row" spacing={2} alignItems="center">
                          <BadgeIcon color="primary" />

                          <Box>
                            <Typography fontWeight={600}>
                              {signatory.nameOfAuthSignatory}
                            </Typography>

                            <Typography variant="body2" color="text.secondary">
                              {signatory.designation}
                            </Typography>
                          </Box>
                        </Stack>

                        {/* <Divider sx={{ my: 1.5 }} />

                        <Grid container spacing={2}>
                          <Grid item xs={6}>
                            <DetailField
                              label="Email"
                              value={signatory.email}
                            />
                          </Grid>

                          <Grid item xs={6}>
                            <DetailField
                              label="Mobile"
                              value={signatory.mobileNumber}
                            />
                          </Grid>
                        </Grid> */}
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            </CardContent>
          </Card>

          {/* Documents */}
          <Grid container spacing={2}>
            {documents.map((doc, idx) => (
              <Grid item xs={12} key={idx}>
                <Card variant="outlined">
                  <CardContent>
                    <Stack
                      direction="row"
                      justifyContent="space-between"
                      alignItems="center"
                    >
                      <Box>
                        <Typography fontWeight={600}>{doc.title}</Typography>

                        <Typography variant="body2" color="text.secondary">
                          {doc.fileName}
                        </Typography>
                      </Box>

                      <Button
                        variant="contained"
                        startIcon={<CloudDownloadIcon />}
                        onClick={() => onDownload(doc.filePath, doc.fileName)}
                      >
                        Download
                      </Button>
                    </Stack>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Stack>
      </DialogContent>

      <DialogActions sx={{ p: 2 }}>
        <Button variant="outlined" onClick={onClose}>
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
}
