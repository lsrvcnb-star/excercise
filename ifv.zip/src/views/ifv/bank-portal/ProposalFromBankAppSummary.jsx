import {
    keepPreviousData,
    QueryClient,
    QueryClientProvider,
    useQuery,
    useQueryClient
  } from "@tanstack/react-query";
  
  import { Visibility as VisibilityIcon } from "@mui/icons-material";
  import ArrowBackIcon from "@mui/icons-material/ArrowBack";
  import AssignmentReturnIcon from "@mui/icons-material/AssignmentReturn";
  import CloudDownloadIcon from "@mui/icons-material/CloudDownload";
  
  import {
    Alert,
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    Snackbar,
    TextField,
    Tooltip
  } from "@mui/material";
  import CircularProgress from "@mui/material/CircularProgress";
  
  import { LocalizationProvider } from "@mui/x-date-pickers";
  import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFnsV3";
  
  import {
    MaterialReactTable,
    useMaterialReactTable
  } from "material-react-table";
  
  import { format } from "date-fns";
  import { useMemo, useState } from "react";
  import { useNavigate } from "react-router-dom";
  
  import bankRefinanceApi from "services/bankRefinanceApi";
  import IfvAppraisalService from "services/IfvAppraisalService";
  import BankRefinanceDetailDialog from "./BankRefinanceDetailDialog";
  
  const queryClient = new QueryClient();
  
  function BankRefinanceSummaryTable() {
    const queryClient = useQueryClient();
  
    const navigate = useNavigate();
  
    const [selectedRow, setSelectedRow] = useState(null);
    const [detailOpen, setDetailOpen] = useState(false);
  
    const [globalFilter, setGlobalFilter] = useState("");
    const [columnFilters, setColumnFilters] = useState([]);
  
    const [sorting, setSorting] = useState([
      {
        id: "submittedDateTime",
        desc: true,
      },
    ]);
  
    const [pagination, setPagination] = useState({
      pageIndex: 0,
      pageSize: 10,
    });
  
    const [rowSelection, setRowSelection] = useState({});
  
    const [downloadingFiles, setDownloadingFiles] = useState({});
    const [returnDialogOpen, setReturnDialogOpen] = useState(false);
    const [selectedApp, setSelectedApp] = useState(null);
    const [returnRemarks, setReturnRemarks] = useState("");
    const [returning, setReturning] = useState(false);
    const user = IfvAppraisalService.getCurrentUser();
  
    const [snackbar, setSnackbar] = useState({
      open: false,
      severity: "error",
      message: "",
    });
  
    const { data, isLoading, isFetching, isError, error } = useQuery({
      queryKey: [
        "bank-refinance-applications",
        pagination,
        sorting,
        globalFilter,
        columnFilters,
      ],
  
      queryFn: () =>
        bankRefinanceApi.fetchActiveProposalBankApps({
          page: pagination.pageIndex,
          size: pagination.pageSize,
  
          globalFilter,
  
          appRefId: columnFilters.find((f) => f.id === "appRefId")?.value || "",
  
          cifNumber: columnFilters.find((f) => f.id === "cifNumber")?.value || "",
  
          nameOfBank:
            columnFilters.find((f) => f.id === "nameOfBank")?.value || "",
  
          schemeCode:
            columnFilters.find((f) => f.id === "schemeCode")?.value || "",
  
          applicationStatus:
            columnFilters.find((f) => f.id === "applicationStatus")?.value || "",
  
          sortField: sorting?.[0]?.id,
          sortDirection: sorting?.[0]?.desc ? "desc" : "asc",
        }),
  
      placeholderData: keepPreviousData,
    });
  
    const handleView = async (appRefId) => {
      try {
        const response = await bankRefinanceApi.fetchBankApplicationByAppRefId(
          appRefId
        );
  
        setSelectedRow(response);
        setDetailOpen(true);
      } catch (err) {
        setSnackbar({
          open: true,
          severity: "error",
          message: "Failed to fetch application details.",
        });
      }
    };
  
    const handleDownload = async (filePath, fileName) => {
      setDownloadingFiles((prev) => ({ ...prev, [filePath]: true }));
      try {
        const result = await bankRefinanceApi.downloadFileByPath(
          filePath,
          fileName
        );
  
        if (!result.success) {
          setSnackbar({
            open: true,
            severity: "error",
            message: result.message,
          });
        }
      } catch (err) {
        setSnackbar({
          open: true,
          severity: "error",
          message: "Failed to download file.",
        });
      } finally {
        setDownloadingFiles((prev) => ({ ...prev, [filePath]: false }));
      }
    };
  
    const handleReturnApplication = async () => {
      if (!returnRemarks?.trim()) {
        setSnackbar({
          open: true,
          severity: "error",
          message: "Return remarks are required.",
        });
        return;
      }
  
      try {
        setReturning(true);
  
        const response = await bankRefinanceApi.returnBankApplication({
          benRefNo: selectedApp.appRefId,
          returnRemarks,
          returnBy: user?.ofrName,
        });
  
        if (!response.success) {
          throw new Error(response.message);
        }
  
        setSnackbar({
          open: true,
          severity: "success",
          message: "Application returned successfully.",
        });
  
        setReturnDialogOpen(false);
        setReturnRemarks("");
  
        queryClient.invalidateQueries({
          queryKey: ["bank-refinance-applications"],
        });
      } catch (err) {
        setSnackbar({
          open: true,
          severity: "error",
          message: err?.message || "Failed to return application.",
        });
      } finally {
        setReturning(false);
      }
    };
  
    const columns = useMemo(
      () => [
        {
          header: "Sl No",
          size: 50,
          enableSorting: false,
          Cell: ({ row, table }) => {
            const { pageIndex, pageSize } = table.getState().pagination;
  
            return pageIndex * pageSize + row.index + 1;
          },
        },
  
        {
          accessorKey: "appRefId",
          header: "Application Ref No",
          size: 150,
        },
  
        {
          accessorKey: "nameOfBank",
          header: "Bank Name",
          size: 150,
        },
  
        {
          accessorKey: "customSchemeName",
          header: "Scheme Name",
          size: 100,
        },
  
        {
          accessorKey: "applicationStatus",
          header: "Status",
          size: 80,
        },
  
        {
          accessorKey: "submittedDateTime",
          header: "Submitted Date",
          filterVariant: "date-range",
          Cell: ({ cell }) =>
            cell.getValue()
              ? format(new Date(cell.getValue()), "dd-MMM-yyyy hh:mm a")
              : "-",
          size: 100,
        },
      ],
      []
    );
  
    const table = useMaterialReactTable({
      columns,
      data: data?.content ?? [],
  
      rowCount: data?.totalElements ?? 0,
  
      manualPagination: true,
      manualSorting: true,
      manualFiltering: true,
  
      enableRowActions: true,
      positionActionsColumn: "last",
  
      onPaginationChange: setPagination,
      onSortingChange: setSorting,
      onGlobalFilterChange: setGlobalFilter,
      onColumnFiltersChange: setColumnFilters,
  
      state: {
        pagination,
        sorting,
        globalFilter,
        columnFilters,
        isLoading,
        showProgressBars: isFetching,
        showAlertBanner: isError,
      },
  
      renderRowActions: ({ row }) => (
        <Box sx={{ display: "flex", gap: 1 }}>
          <Tooltip title="View Details">
            <IconButton
              color="primary"
              onClick={() => handleView(row.original.appRefId)}
            >
              <VisibilityIcon />
            </IconButton>
          </Tooltip>
  
          <Tooltip title="Download Application File">
            <IconButton
              color="success"
              disabled={downloadingFiles[row.original.refinanceAppFilePath]}
              onClick={() =>
                handleDownload(
                  row.original.refinanceAppFilePath,
                  row.original.refinanceAppFileName
                )
              }
            >
              {downloadingFiles[row.original.refinanceAppFilePath] ? (
                <CircularProgress size={20} />
              ) : (
                <CloudDownloadIcon />
              )}
            </IconButton>
          </Tooltip>
          {row.original.applicationStatus === "SUBMITTED" && (
            <Tooltip title="Return Application">
              <IconButton
                color="error"
                onClick={() => {
                  setSelectedApp(row.original);
                  setReturnDialogOpen(true);
                }}
              >
                <AssignmentReturnIcon />
              </IconButton>
            </Tooltip>
          )}
        </Box>
      ),
  
      muiTableHeadCellProps: {
        sx: {
          backgroundColor: "#E3F2FD",
          fontWeight: "bold",
        },
      },
    });
  
    return (
      <>
        {isError && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error?.message ?? "Failed to fetch records"}
          </Alert>
        )}
  
        <Box
          sx={{
            mb: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Button
            variant="outlined"
            startIcon={<ArrowBackIcon />}
            onClick={() => navigate("/ifv/dashboard")}
          >
            Back
          </Button>
        </Box>
  
        <MaterialReactTable table={table} />
  
        <Dialog
          open={returnDialogOpen}
          onClose={() => !returning && setReturnDialogOpen(false)}
          maxWidth="sm"
          fullWidth
        >
          <DialogTitle
            sx={{
              bgcolor: "#d32f2f",
              color: "white",
              fontWeight: 600,
            }}
          >
            Return Application
          </DialogTitle>
  
          <DialogContent sx={{ mt: 2 }}>
            <Box sx={{ mb: 2 }}>
              <strong>Application Ref No:</strong> {selectedApp?.appRefId}
            </Box>
  
            <TextField
              fullWidth
              multiline
              label="Return Remarks"
              value={returnRemarks}
              onChange={(e) => setReturnRemarks(e.target.value)}
              placeholder="Enter reason for returning application"
            />
          </DialogContent>
  
          <DialogActions>
            <Button
              onClick={() => setReturnDialogOpen(false)}
              disabled={returning}
            >
              Cancel
            </Button>
  
            <Button
              color="error"
              variant="contained"
              disabled={returning}
              onClick={handleReturnApplication}
            >
              {returning ? (
                <CircularProgress size={20} color="inherit" />
              ) : (
                "Return Application"
              )}
            </Button>
          </DialogActions>
        </Dialog>
  
        <BankRefinanceDetailDialog
          open={detailOpen}
          data={selectedRow}
          onClose={() => {
            setDetailOpen(false);
            setSelectedRow(null);
          }}
          onDownload={handleDownload}
        />
  
        <Snackbar
          open={snackbar.open}
          autoHideDuration={4000}
          onClose={() =>
            setSnackbar((prev) => ({
              ...prev,
              open: false,
            }))
          }
        >
          <Alert
            severity={snackbar.severity}
            onClose={() =>
              setSnackbar((prev) => ({
                ...prev,
                open: false,
              }))
            }
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </>
    );
  }
  
  export default function ProposalFromBankAppSummary() {
    return (
      <QueryClientProvider client={queryClient}>
        <LocalizationProvider dateAdapter={AdapterDateFns}>
          <BankRefinanceSummaryTable />
        </LocalizationProvider>
      </QueryClientProvider>
    );
  }
  