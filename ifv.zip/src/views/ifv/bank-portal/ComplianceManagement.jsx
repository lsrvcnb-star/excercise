import AssignmentReturnIcon from "@mui/icons-material/AssignmentReturn";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CloudDownloadIcon from "@mui/icons-material/CloudDownload";
import Chip from "@mui/material/Chip";

import {
    Alert,
    Box,
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    Snackbar,
    TextField,
    Tooltip
} from "@mui/material";
import {
    keepPreviousData,
    QueryClient,
    QueryClientProvider,
    useQuery,
    useQueryClient
} from "@tanstack/react-query";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";

import CircularProgress from "@mui/material/CircularProgress";

import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFnsV3";

import {
    MaterialReactTable,
    useMaterialReactTable
} from "material-react-table";

import { format } from "date-fns";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

import bankRefinanceApi from "services/bankRefinanceApi";
import IfvAppraisalService from "services/IfvAppraisalService";

const queryClient = new QueryClient();

function BankRefinanceSummaryTable() {
  const queryClient = useQueryClient();

  const navigate = useNavigate();

  const [globalFilter, setGlobalFilter] = useState("");
  const [columnFilters, setColumnFilters] = useState([]);

  const [sorting, setSorting] = useState([
    {
      id: "uploadDate",
      desc: true,
    },
  ]);

  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: 10,
  });

  const [downloadingFiles, setDownloadingFiles] = useState({});
  const [returnDialogOpen, setReturnDialogOpen] = useState(false);
  const [selectedApp, setSelectedApp] = useState(null);
  const [returnRemarks, setReturnRemarks] = useState("");
  const [returning, setReturning] = useState(false);
  const user = IfvAppraisalService.getCurrentUser();

  const [rowSelection, setRowSelection] = useState({});

  const [snackbar, setSnackbar] = useState({
    open: false,
    severity: "error",
    message: "",
  });

  const { data, isLoading, isFetching, isError, error } = useQuery({
    queryKey: [
      "compliance-summary",
      pagination,
      sorting,
      globalFilter,
      columnFilters,
    ],

    queryFn: () =>
    bankRefinanceApi.fetchComplianceSummaryForAllBanks({
        page: pagination.pageIndex,
        size: pagination.pageSize,
      
        appRefNo:
          columnFilters.find((f) => f.id === "appRefNo")?.value || "",
      
        complianceType:
          columnFilters.find((f) => f.id === "complianceType")?.value || "",
      
        status:
          columnFilters.find((f) => f.id === "status")?.value || "",
      
        sortField: sorting?.[0]?.id || "uploadDate",
        sortDirection: sorting?.[0]?.desc ? "desc" : "asc",
      }),
    placeholderData: keepPreviousData,
  });

  const handleDownload = async (filePath, fileName) => {
    setDownloadingFiles((prev) => ({ ...prev, [filePath]: true }));
    try {
      const result = await bankRefinanceApi.downloadFileByPath(
        filePath,
        fileName
      );

      if (!result.success) {
        setSnackbar({
          open: true,
          severity: "error",
          message: result.message,
        });
      }
    } catch (err) {
      setSnackbar({
        open: true,
        severity: "error",
        message: "Failed to download file.",
      });
    } finally {
      setDownloadingFiles((prev) => ({ ...prev, [filePath]: false }));
    }
  };

  const handleCompleteCompliance = async (row) => {
    try {
      const response = await bankRefinanceApi.acceptOrReturnCompliance({
        appRefNo: row.appRefNo,
        complianceType: row.complianceType,
        status: "COMPLETED",
        acceptOrReturnRemarks: null,
      });

      if (!response.success) {
        throw new Error(response.message);
      }

      setSnackbar({
        open: true,
        severity: "success",
        message: "Compliance completed successfully.",
      });

      queryClient.invalidateQueries({
        queryKey: ["compliance-summary"],
      });
    } catch (err) {
      setSnackbar({
        open: true,
        severity: "error",
        message: err?.message || "Failed to complete compliance.",
      });
    }
  };

  const handleReturnCompliance = async () => {
    if (!returnRemarks?.trim()) {
      setSnackbar({
        open: true,
        severity: "error",
        message: "Remarks are required.",
      });
      return;
    }

    try {
      setReturning(true);

      const response = await bankRefinanceApi.acceptOrReturnCompliance({
        appRefNo: selectedApp.appRefNo,
        complianceType: selectedApp.complianceType,
        status: "RETURNED",
        acceptOrReturnRemarks: returnRemarks,
      });

      if (!response.success) {
        throw new Error(response.message);
      }

      setSnackbar({
        open: true,
        severity: "success",
        message: "Compliance returned successfully.",
      });

      setReturnDialogOpen(false);
      setReturnRemarks("");

      queryClient.invalidateQueries({
        queryKey: ["compliance-summary"],
      });
    } catch (err) {
      setSnackbar({
        open: true,
        severity: "error",
        message: err?.message || "Failed to return compliance.",
      });
    } finally {
      setReturning(false);
    }
  };

  const columns = useMemo(
    () => [
      {
        accessorKey: "appRefNo",
        header: "App No",
        size: 80,
      },
      {
        accessorKey: "complianceType",
        header: "Compliance Type",
        size: 80,
      },
      {
        accessorKey: "uploadDate",
        header: "Uploaded Date",
        size: 80,
        Cell: ({ cell }) =>
          cell.getValue()
            ? format(new Date(cell.getValue()), "dd-MMM-yyyy hh:mm a")
            : "-",
      },
      {
        accessorKey: "dueDate",
        header: "Due Date",
        size: 80,
      },
      {
        accessorKey: "asOnDate",
        header: "As On Date",
        size: 80,
      },
      {
        accessorKey: "status",
        header: "Status",
        size: 80,
        Cell: ({ row }) => {
          const status = row.original.status;

          const colors = {
            SUBMITTED: "#1976d2",
            COMPLETED: "#2e7d32",
            RETURNED: "#d32f2f",
          };

          return (
            <Chip
              label={status}
              size="small"
              sx={{
                color: "#fff",
                bgcolor: colors[status] || "#757575",
              }}
            />
          );
        },
      },
    ],
    []
  );

  const selectedRows = Object.keys(rowSelection)
    .map((index) => data?.content?.[index])
    .filter(Boolean);

  const firstSelected = selectedRows[0];

  const selectedBank = firstSelected?.nameOfBank || "";
  const selectedCif = firstSelected?.cifNumber || "";

  const table = useMaterialReactTable({
    columns,
    data: data?.content ?? [],

    rowCount: data?.totalElements ?? 0,

    manualPagination: true,
    manualSorting: true,
    manualFiltering: true,
    enableSelectAll: false,
    enableRowActions: true,
    positionActionsColumn: "last",
    onRowSelectionChange: setRowSelection,

    onPaginationChange: setPagination,
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    onColumnFiltersChange: setColumnFilters,

    state: {
      pagination,
      sorting,
      globalFilter,
      columnFilters,
      rowSelection,
      isLoading,
      showProgressBars: isFetching,
      showAlertBanner: isError,
    },

    renderRowActions: ({ row }) => (
      <Box sx={{ display: "flex", gap: 1 }}>
        <Tooltip title="Download File">
          <IconButton
            color="success"
            onClick={() =>
              handleDownload(row.original.filePath, row.original.fileName)
            }
          >
            <CloudDownloadIcon />
          </IconButton>
        </Tooltip>

        {row.original.status === "SUBMITTED" && (
          <>
            <Tooltip title="Complete Compliance">
              <IconButton
                color="primary"
                onClick={() => handleCompleteCompliance(row.original)}
              >
                <CheckCircleIcon />
              </IconButton>
            </Tooltip>

            <Tooltip title="Return Compliance">
              <IconButton
                color="error"
                onClick={() => {
                  setSelectedApp(row.original);
                  setReturnDialogOpen(true);
                }}
              >
                <AssignmentReturnIcon />
              </IconButton>
            </Tooltip>
          </>
        )}
      </Box>
    ),

    muiTableHeadCellProps: {
      sx: {
        backgroundColor: "#E3F2FD",
        fontWeight: "bold",
      },
    },
  });

  return (
    <>
      {isError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error?.message ?? "Failed to fetch records"}
        </Alert>
      )}

      <Box
        sx={{
          mb: 2,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: 2,
        }}
      >
        <Button
          variant="outlined"
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate("/ifv/dashboard")}
        >
          Back
        </Button>
      </Box>

      <MaterialReactTable table={table} />

      <Dialog
        open={returnDialogOpen}
        onClose={() => !returning && setReturnDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle
          sx={{
            bgcolor: "#d32f2f",
            color: "white",
            fontWeight: 600,
          }}
        >
          Return Application
        </DialogTitle>

        <DialogContent sx={{ mt: 2 }}>
          <Box sx={{ mb: 2 }}>
            <strong>Application Ref No:</strong> {selectedApp?.appRefId}
          </Box>

          <TextField
            fullWidth
            multiline
            label="Return Remarks"
            value={returnRemarks}
            onChange={(e) => setReturnRemarks(e.target.value)}
            placeholder="Enter reason for returning application"
          />
        </DialogContent>

        <DialogActions>
          <Button
            onClick={() => setReturnDialogOpen(false)}
            disabled={returning}
          >
            Cancel
          </Button>

          <Button
            color="error"
            variant="contained"
            disabled={returning}
            onClick={handleReturnCompliance}
          >
            {returning ? (
              <CircularProgress size={20} color="inherit" />
            ) : (
              "Return Application"
            )}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() =>
          setSnackbar((prev) => ({
            ...prev,
            open: false,
          }))
        }
      >
        <Alert
          severity={snackbar.severity}
          onClose={() =>
            setSnackbar((prev) => ({
              ...prev,
              open: false,
            }))
          }
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
}

export default function ComplianceManagement() {
  return (
    <QueryClientProvider client={queryClient}>
      <LocalizationProvider dateAdapter={AdapterDateFns}>
        <BankRefinanceSummaryTable />
      </LocalizationProvider>
    </QueryClientProvider>
  );
}
