import CloseIcon from '@mui/icons-material/Close';
import DownloadIcon from '@mui/icons-material/Download';
import {
    Alert,
    Box,
    CircularProgress,
    Dialog,
    DialogContent,
    DialogTitle,
    Grid,
    IconButton,
    Paper,
    Snackbar,
    Typography
} from '@mui/material';
import React, { useState } from 'react';
import IfvAppraisalService from 'services/IfvAppraisalService';
import MinutesService from 'services/MinutesService';
import FileUtil from 'services/utils/FileUtil';
const GenerateReportModal = ({ mtCode, trigger }) => {
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState({
        flash: false,
        pdf: false,
        word: false
    });
    const [snackbar, setSnackbar] = useState({
        open: false,
        message: '',
        severity: 'success'
    });
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const handleSnackbarClose = () => {
        setSnackbar(prev => ({ ...prev, open: false }));
    };
    const handleApiError = (error, action) => {
        console.error(`Error ${action}:`, error);
        setSnackbar({
            open: true,
            message: `Failed ${action}. Please try again.`,
            severity: 'error'
        });
    };
    // Your existing generate functions remain the same
    const generateFlashMinutesReport = async () => {
        setLoading(prev => ({ ...prev, flash: true }));
        try {
            const response = await MinutesService.generateFlashMinutesReport(mtCode);
            FileUtil.downloadFile(
                response.data.fileDataBytea,
                response.data.fileName,
                "application/pdf"
            );
            setSnackbar({
                open: true,
                message: 'Flash Minutes Report downloaded successfully',
                severity: 'success'
            });
        } catch (error) {
            handleApiError(error, 'generating Flash Minutes Report');
        } finally {
            setLoading(prev => ({ ...prev, flash: false }));
        }
    };
    const generateMinutesReport = async () => {
        setLoading(prev => ({ ...prev, pdf: true }));
        try {
            const response = await IfvAppraisalService.generateMinutesReport(mtCode);
            FileUtil.downloadFile(
                response.data.fileDataBytea,
                response.data.fileName,
                "application/pdf"
            );
            setSnackbar({
                open: true,
                message: 'Final Minutes PDF downloaded successfully',
                severity: 'success'
            });
        } catch (error) {
            handleApiError(error, 'generating Final Minutes PDF');
        } finally {
            setLoading(prev => ({ ...prev, pdf: false }));
        }
    };
    const generateFinalMinutesWord = async () => {
        setLoading(prev => ({ ...prev, word: true }));
        try {
            const response = await MinutesService.generateFinalMinutesWord(mtCode);
            FileUtil.downloadWordFile(response);
            setSnackbar({
                open: true,
                message: 'Final Minutes Word document downloaded successfully',
                severity: 'success'
            });
        } catch (error) {
            handleApiError(error, 'generating Final Minutes Word document');
        } finally {
            setLoading(prev => ({ ...prev, word: false }));
        }
    };
    const reportTypes = [
        {
            label: 'Flash Minutes Report',
            type: 'flash',
            description: 'Quick summary report in PDF format',
            handler: generateFlashMinutesReport
        },
        {
            label: 'Final Minutes in PDF',
            type: 'pdf',
            description: 'Complete detailed report in PDF format',
            handler: generateMinutesReport
        },
        {
            label: 'Final Minutes in Word',
            type: 'word',
            description: 'Editable report in Word format',
            handler: generateFinalMinutesWord
        }
    ];
    return (
        <>
            {React.cloneElement(trigger, { onClick: handleOpen })}
            <Dialog
                open={open}
                onClose={handleClose}
                maxWidth="md"
                PaperProps={{
                    sx: {
                        minWidth: '500px',
                        borderRadius: '8px'
                    }
                }}
            >
                <DialogTitle>
                    <Box sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        pr: 1 // Padding right to align with content
                    }}>
                        <Typography variant="h6" component="div" sx={{ fontWeight: 'bold' }}>
                            Generate Minutes Report
                        </Typography>
                        <IconButton
                            aria-label="close"
                            onClick={handleClose}
                            sx={{
                                color: (theme) => theme.palette.grey[500],
                                '&:hover': {
                                    color: (theme) => theme.palette.grey[700],
                                }
                            }}
                        >
                            <CloseIcon />
                        </IconButton>
                    </Box>
                </DialogTitle>
                <DialogContent>
                    <Paper sx={{ p: 2 }}>
                        {reportTypes.map((report, index) => (
                            <Grid
                                container
                                key={report.type}
                                alignItems="center"
                                sx={{
                                    py: 2,
                                    px: 1,
                                    borderBottom: index !== reportTypes.length - 1 ? '1px solid #eee' : 'none',
                                    '&:hover': {
                                        backgroundColor: 'rgba(0, 0, 0, 0.04)',
                                        borderRadius: '4px'
                                    },
                                    transition: 'background-color 0.2s'
                                }}
                            >
                                <Grid item xs={8}>
                                    <Typography variant="subtitle1" sx={{ fontWeight: 'medium' }}>
                                        {report.label}
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        {report.description}
                                    </Typography>
                                </Grid>
                                <Grid item xs={4} sx={{ textAlign: 'center' }}>
                                    <IconButton
                                        color="primary"
                                        onClick={report.handler}
                                        disabled={loading[report.type]}
                                        size="large"
                                        sx={{
                                            '&:hover': {
                                                backgroundColor: 'rgba(25, 118, 210, 0.04)'
                                            }
                                        }}
                                    >
                                        {loading[report.type] ? (
                                            <CircularProgress size={24} />
                                        ) : (
                                            <DownloadIcon />
                                        )}
                                    </IconButton>
                                </Grid>
                            </Grid>
                        ))}
                    </Paper>
                </DialogContent>
            </Dialog>
            <Snackbar
                open={snackbar.open}
                autoHideDuration={6000}
                onClose={handleSnackbarClose}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            >
                <Alert
                    onClose={handleSnackbarClose}
                    severity={snackbar.severity}
                    variant="filled"
                    sx={{ width: '100%' }}
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </>
    );
};
export default GenerateReportModal;