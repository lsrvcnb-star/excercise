import {
    Add as AddIcon,
    Delete as DeleteIcon,
    Download as DownloadIcon,
} from '@mui/icons-material';
import {
    Alert,
    Box,
    Button,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    Snackbar,
    TextField,
    Tooltip,
    Typography
} from '@mui/material';
import {
    QueryClient,
    QueryClientProvider,
    keepPreviousData,
    useMutation,
    useQuery,
    useQueryClient
} from '@tanstack/react-query';
import {
    MaterialReactTable,
    useMaterialReactTable,
} from 'material-react-table';
import { useMemo, useState } from 'react';
import BeneficiaryApiService from 'services/BeneficiaryApiService';
import IfvAppraisalService from 'services/IfvAppraisalService';
import Pattern from 'services/validators/Pattern';

const queryClient = new QueryClient();
const user = IfvAppraisalService.getCurrentUser();

function BeneficiaryTable() {
    const queryClient = useQueryClient();
    const [columnFilters, setColumnFilters] = useState([]);
    const [globalFilter, setGlobalFilter] = useState('');
    const [sorting, setSorting] = useState([]);
    const [pagination, setPagination] = useState({
        pageIndex: 0,
        pageSize: 10,
    });
    const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
    const [uploadFile, setUploadFile] = useState(null);
    const [uploadData, setUploadData] = useState({
        remarks: ''
    });
    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

    const { data, isError, isFetching, isLoading } = useQuery({
        queryKey: ['beneficiaries', pagination.pageIndex, pagination.pageSize, columnFilters, globalFilter, sorting],
        queryFn: () => BeneficiaryApiService.fetchBenificiaryApps({
            start: pagination.pageIndex,
            size: pagination.pageSize,
            filters: JSON.stringify(columnFilters),
            sorting: JSON.stringify(sorting),
            globalFilter
        }),
        placeholderData: keepPreviousData,
    });

    const uploadMutation = useMutation({
        mutationFn: ({ file, data }) => BeneficiaryApiService.uploadBenificiaryAppDoc({ file, data }),
        onSuccess: () => {
            queryClient.invalidateQueries(['beneficiaries']);
            handleCloseDialog();
            setSnackbar({ open: true, message: 'Beneficiary uploaded successfully!', severity: 'success' });
        },
        onError: () => {
            setSnackbar({ open: true, message: 'Failed to upload beneficiary', severity: 'error' });
        }
    });

    const deleteDocMutation = useMutation({
        mutationFn: (id) => BeneficiaryApiService.deleteAppDocument(id),
        onSuccess: () => {
            queryClient.invalidateQueries(['beneficiaries']);
            setSnackbar({ open: true, message: 'Document deleted successfully!', severity: 'success' });
        },
        onError: () => {
            setSnackbar({ open: true, message: 'Failed to delete document', severity: 'error' });
        }
    });

    const handleDownload = async (id, fileName) => {
        try {
            await BeneficiaryApiService.downloadAppDocument(id, fileName);
            setSnackbar({ open: true, message: 'Document downloaded successfully!', severity: 'success' });
        } catch (error) {
            console.error(error);
            setSnackbar({ open: true, message: 'Failed to download document', severity: 'error' });
        }
    };

    const handleDelete = (id) => {
        if (window.confirm('Are you sure you want to delete this document?')) {
            deleteDocMutation.mutate(id);
        }
    };


    const columns = useMemo(
        () => [
            {
                header: 'Sl No',
                size: 70,
                Cell: ({ row, table }) => {
                    const { pageIndex, pageSize } = table.getState().pagination ?? { pageIndex: 0, pageSize: Number.MAX_SAFE_INTEGER };
                    return pageIndex * pageSize + row.index + 1;
                },
            },
            {
                accessorKey: 'fileName',
                header: 'File Name',
                size: 100,
                Cell: ({ cell }) => (
                    <Tooltip title={cell.getValue()}>
                        <Typography variant="body2" noWrap>
                            {cell.getValue()}
                        </Typography>
                    </Tooltip>
                ),
            },
            {
                accessorKey: 'uploadDateTime',
                header: 'Upload Date',
                size: 150,
                Cell: ({ cell }) => {
                    const date = new Date(cell.getValue());
                    return date.toLocaleString();
                },
            },
            {
                accessorKey: 'uploadBy',
                header: 'Uploaded By',
                size: 150,
            },
            {
                accessorKey: 'remarks',
                header: 'Remarks',
                size: 200,
                Cell: ({ cell }) => (
                    <Tooltip title={cell.getValue() || ''}>
                        <Typography variant="body2" noWrap>
                            {cell.getValue() || '-'}
                        </Typography>
                    </Tooltip>
                ),
            },
        ],
        []
    );

    const table = useMaterialReactTable({
        columns,
        data: data?.content ?? [],
        rowCount: data?.totalElements ?? 0,
        manualPagination: true,
        manualSorting: true,
        manualFiltering: true,
        enableRowActions: true,
        positionActionsColumn: 'last',
        state: {
            columnFilters,
            globalFilter,
            isLoading,
            pagination,
            showAlertBanner: isError,
            showProgressBars: isFetching,
            sorting,
        },
        onColumnFiltersChange: setColumnFilters,
        onGlobalFilterChange: setGlobalFilter,
        onPaginationChange: setPagination,
        onSortingChange: setSorting,
        renderTopToolbarCustomActions: () => (
            <Button
                variant="contained"
                startIcon={<AddIcon />}
                onClick={() => setUploadDialogOpen(true)}
            >
                Upload Beneficiary Data
            </Button>
        ),
        renderRowActions: ({ row }) => (
            <Box sx={{ display: 'flex', gap: 0.5 }}>
                <Tooltip title="Download">
                    <IconButton
                        color="primary"
                        onClick={() => handleDownload(row.original.id, row.original.fileName)}
                    >
                        <DownloadIcon />
                    </IconButton>
                </Tooltip>
                {/* <Tooltip title="Delete">
                    <IconButton
                        color="error"
                        onClick={() => handleDelete(row.original.id)}
                    >
                        <DeleteIcon />
                    </IconButton>
                </Tooltip> */}
            </Box>
        ),
    });

    const handleCloseDialog = () => {
        setUploadDialogOpen(false);
        setUploadFile(null);
        setUploadData({ remarks: '' });
    };

    const MAX_SIZE_BYTES = 20 * 1024 * 1024; // 20 MB

    const isExcelFile = (file) => {
        if (!file) return false;

        const allowedMimeTypes = [
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        ];
        const isMimeOk = allowedMimeTypes.includes(file.type);

        const name = file.name?.toLowerCase() || '';
        const hasValidExtension = name.endsWith('.xls') || name.endsWith('.xlsx');

        return isMimeOk || hasValidExtension;
    };

    const handleUploadSubmit = () => {
        if (!uploadFile) {
            setSnackbar({ open: true, message: 'Please select a file', severity: 'warning' });
            return;
        }

        if (!isExcelFile(uploadFile)) {
            setSnackbar({
                open: true,
                message: 'Invalid file type. Please upload an XLS or XLSX file.',
                severity: 'error',
            });
            return;
        }

        if (uploadFile.size > MAX_SIZE_BYTES) {
            setSnackbar({
                open: true,
                message: 'File is too large. Max allowed size is 20 MB.',
                severity: 'error',
            });
            return;
        }

        if (!uploadData.remarks.trim()) {
            setSnackbar({ open: true, message: 'Please enter remarks', severity: 'warning' });
            return;
        }

        uploadData.uploadBy = user?.userName;

        uploadMutation.mutate({ file: uploadFile, data: uploadData });
    };

    return (
        <Box sx={{ p: 3 }}>
            <MaterialReactTable table={table} />

            <Dialog
                open={uploadDialogOpen}
                onClose={handleCloseDialog}
                maxWidth="sm"
                fullWidth
            >
                <DialogTitle>Upload Beneficiary Data</DialogTitle>
                <DialogContent>
                    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, mt: 2 }}>
                        <TextField
                            label="Remarks"
                            value={uploadData.remarks}
                            onChange={(e) => { Pattern.sanitizeInput(e); setUploadData({ ...uploadData, remarks: e.target.value }); }}
                            fullWidth
                            required
                            multiline
                            rows={1}
                            placeholder="Enter remarks for this beneficiary"
                        />

                        <Box>
                            <Button
                                variant="outlined"
                                component="label"
                                startIcon={<AddIcon />}
                                fullWidth
                                sx={{
                                    justifyContent: 'flex-start',
                                    textAlign: 'left',
                                    textTransform: 'none'
                                }}
                            >
                                {uploadFile ? (
                                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, width: '100%' }}>
                                        <Typography noWrap sx={{ flex: 1 }}>
                                            {uploadFile.name}
                                        </Typography>
                                        <Typography variant="caption" color="text.secondary">
                                            ({(uploadFile.size / 1024).toFixed(2)} KB)
                                        </Typography>
                                    </Box>
                                ) : (
                                    'Select File to Upload'
                                )}
                                <input
                                    type="file"
                                    hidden
                                    onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                                    accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
                                />
                            </Button>
                            <Typography
                                variant="caption"
                                color="text.secondary"
                                sx={{ mt: 1, display: 'block' }}
                            >
                                Note: Only .xls and .xlsx files are allowed. Maximum file size: 50MB.
                            </Typography>
                            {uploadFile && (
                                <Button
                                    size="small"
                                    color="error"
                                    onClick={() => setUploadFile(null)}
                                    sx={{ mt: 1 }}
                                >
                                    Remove File
                                </Button>
                            )}
                        </Box>
                    </Box>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDialog}>Cancel</Button>
                    <Button
                        onClick={handleUploadSubmit}
                        variant="contained"
                        disabled={uploadMutation.isPending}
                    >
                        {uploadMutation.isPending ? <CircularProgress size={24} /> : 'Upload'}
                    </Button>
                </DialogActions>
            </Dialog>

            <Snackbar
                open={snackbar.open}
                autoHideDuration={4000}
                onClose={() => setSnackbar({ ...snackbar, open: false })}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            >
                <Alert
                    onClose={() => setSnackbar({ ...snackbar, open: false })}
                    severity={snackbar.severity}
                    sx={{ width: '100%' }}
                >
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </Box>
    );
}

export default function BeneficiaryAppSummary() {
    return (
        <QueryClientProvider client={queryClient}>
            <BeneficiaryTable />
        </QueryClientProvider>
    );
}