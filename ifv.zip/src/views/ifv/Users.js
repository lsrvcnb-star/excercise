import BlockIcon from '@mui/icons-material/Block';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import EditIcon from '@mui/icons-material/Edit';
import {
    Box, Button,
    IconButton,
    Tooltip
} from '@mui/material';
import Loading from 'components/Loading';
import { useEffect, useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import 'react-datepicker/dist/react-datepicker.css';
import { useForm } from "react-hook-form";
import Select from 'react-select';
import IfvAppraisalService from 'services/IfvAppraisalService';
import MasterService from 'services/MasterService';
import UserType from 'services/constants/UserType';
import CommonUtil from 'services/utils/CommonUtil';

import {
    MaterialReactTable,
    useMaterialReactTable
} from 'material-react-table';
import { useMemo } from 'react';

const Users = () => {

    const { control, register: register1, handleSubmit: handleSubmitOfUser, setValue: setValue1, getValues: getValues1, reset: reset1, formState: { errors: errors1 } } = useForm({
        mode: "onBlur"
    });

    const [loading, setLoading] = useState(false);
    const [data, setData] = useState([])
    const [showMsg, setShowMsg] = useState(false)
    const [message, setMessage] = useState('')
    const [modalShow, setModalShow] = useState(false);
    const hideMsg = () => setShowMsg(false);

    useEffect(() => {
        getAllMemberNames();
        getEmpCodeAndDesc()
    }, []);

    const handleDisableEnable = (id, flag) => {

    };

    const getAllMemberNames = () => {
        setLoading(true)
        MasterService.getAllMemberNames().then(
            (response) => {

                const formattedOptions = response.data.map((item) => ({
                    value: item,
                    label: item,
                }))
                setOptions(formattedOptions)
                setFilteredOptions(formattedOptions)
                setLoading(false)
            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();
                setLoading(false)
                setMessage('Error occured while loading master users: ' + resMessage)
                setShowMsg(true)
            }
        );
    }

    const getAllIfvUsers = (mapData) => {
        setLoading(true)
        IfvAppraisalService.getAllIfvUsers().then(
            (response) => {

                let newData = []
                response.data.forEach(e => {

                    let userName = e.ofrName
                    if (!CommonUtil.isEmpty(e.ofrMiddleName)) {
                        userName += ' ' + e.ofrMiddleName
                    }
                    if (!CommonUtil.isEmpty(e.ofrLastName)) {
                        userName += ' ' + e.ofrLastName
                    }

                    const d = {
                        ofrCode: e.ofrCode,
                        ofrOrgCode: e.ofrOrgCode,
                        ofrBrnCode: e.ofrBrnCode,
                        ofrName: userName,
                        ofrDesgName: mapData[e.ofrDesgCode],
                        ofrDesgCode: e.ofrDesgCode,
                        ofrDeptCode: e.ofrDeptCode,
                        makerName: e.makerName,
                        ofrType: e.ofrType,
                        ofrTypeName: UserType[e.ofrType],
                        ofrEmpId: e.ofrEmpId,
                        ofrUserId: e.ofrUserId,
                        ofrUserPassword: e.ofrUserPassword,
                        ofrUserActive: e.ofrUserActive,
                        status: e.ofrUserActive === 'Y' ? 'Enabled' : 'Disabled',
                        reportingOfficerCode: e.reportingOfficerCode,
                        createdDate: e.createdDate,
                        ofrEmail: e.ofrEmail,
                        ofrShortName: e.ofrShortName
                    }
                    newData.push(d)
                });
                setData(newData)
                setLoading(false)
            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();
                setLoading(false)
                setMessage('Error occured while loading users: ' + resMessage)
                setShowMsg(true)
            }
        );
    }

    const [selectedOption, setSelectedOption] = useState(null)
    const [filteredOptions, setFilteredOptions] = useState([])
    const [options, setOptions] = useState([])

    const handleSearch = (inputValue) => {
        if (inputValue === "") { setFilteredOptions(options); return; }
        const filteredOptions = options.filter((option) =>
            option.label.toLowerCase().includes(inputValue.toLowerCase())
        );

        setFilteredOptions(filteredOptions);
    };

    const onSubmitOfUser = (data, e) => {
        setLoading(true)
        const user = IfvAppraisalService.getCurrentUser();
        if (CommonUtil.isValidNumber(data.ofrCode) && data.ofrCode > 0) {
            data.modifiedBy = user.ofrName
            IfvAppraisalService.updateIfvUser(data).then(
                (response) => {
                    setMessage('User details have been successfully updated!')
                    setShowMsg(true)
                    getAllIfvUsers(mapData)
                    setLoading(false)
                },
                (error) => {
                    const resMessage =
                        (error.response &&
                            error.response.data &&
                            error.response.data.message) ||
                        error.message ||
                        error.toString();
                    setLoading(false)
                    setMessage('Error occured while updating user: ' + resMessage)
                    setShowMsg(true)
                }
            );
        } else {
            data.createdBy = user.ofrName
            IfvAppraisalService.saveIfvUser(data).then(
                (response) => {
                    setMessage('User details have been successfully created!')
                    setShowMsg(true)
                    getAllIfvUsers(mapData)
                    setLoading(false)
                },
                (error) => {
                    const resMessage =
                        (error.response &&
                            error.response.data &&
                            error.response.data.message) ||
                        error.message ||
                        error.toString();
                    setLoading(false)
                    setMessage('Error occured while creating user: ' + resMessage)
                    setShowMsg(true)
                }
            );
        }



    }

    const [enable, setEnable] = useState(true)

    const clearAndOpenModal = (id) => {
        reset1()
        setSelectedOption(null)

        if (id > 0) {
            setEnable(true)
            const userObj = data.find((item) => parseInt(item.ofrCode) === parseInt(id))
            setValue1('ofrCode', userObj.ofrCode)

            let empName = userObj.ofrName;
            if (!CommonUtil.isEmpty(userObj.ofrMiddleName)) {
                empName = empName + ' ' + userObj.ofrMiddleName
            }
            if (!CommonUtil.isEmpty(userObj.ofrLastName)) {
                empName = empName + ' ' + userObj.ofrLastName
            }

            const formattedOptions = {
                value: empName,
                label: empName,
            }
            setSelectedOption(formattedOptions)

            setValue1('ofrName', empName)
            setValue1('ofrDesgCode', userObj.ofrDesgCode)
            setValue1('ofrType', userObj.ofrType)
            setValue1('ofrEmail', userObj.ofrEmail)
            setValue1('ofrShortName', userObj.ofrShortName)
            setValue1('ofrEmpId', userObj.ofrEmpId)
            setValue1('ofrUserId', userObj.ofrUserId)
            setValue1('ofrUserPassword', userObj.ofrUserPassword)
            setValue1('reportingOfficerCode', userObj.reportingOfficerCode)
            setValue1('ofrBrnCode', userObj.ofrBrnCode)

            setValue1('ofrOrgCode', userObj.ofrOrgCode)
            setValue1('ofrDeptCode', userObj.ofrDeptCode)
        } else {
            setEnable(false)
        }

        setModalShow(true)
    }

    const onChangeOfEmpName = (selected) => {
        setSelectedOption(selected)
        const empName = selected.label
        setValue1('ofrName', empName)
        setLoading(true)
        MasterService.getMemberDetailsByName(empName).then(
            (response) => {
                const appData = response.data

                setValue1('ofrDesgCode', appData.desigCode)
                setValue1('ofrEmpId', appData.empCode)
                setValue1('reportingOfficerCode', appData.reportingMgr)
                setValue1('ofrBrnCode', appData.branchCd)
                setLoading(false)
            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();
                setLoading(false)
                setMessage('Error occured while loading member details: ' + resMessage)
                setShowMsg(true)
            }
        );
    }

    const [mapData, setMapData] = useState([])

    const getEmpCodeAndDesc = () => {
        setLoading(true)
        MasterService.getEmpCodeAndDesc().then(
            (response) => {
                setMapData(response.data)
                getAllIfvUsers(response.data)
                setLoading(false)
            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();
                setLoading(false)
                setMessage('Error occured while loading master designation: ' + resMessage)
                setShowMsg(true)
            }
        );
    }

    const syncWithMIS = () => {
        const empName = selectedOption.label
        setValue1('ofrName', empName)

        setLoading(true)
        MasterService.getMemberDetailsByName(empName).then(
            (response) => {
                const appData = response.data

                setValue1('ofrDesgCode', appData.desigCode)
                setValue1('ofrEmpId', appData.empCode)
                setValue1('reportingOfficerCode', appData.reportingMgr)
                setValue1('ofrBrnCode', appData.branchCd)
                setLoading(false)
            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();
                setLoading(false)
                setMessage('Error occured while loading member details: ' + resMessage)
                setShowMsg(true)
            }
        );
    }

    const columns = useMemo(
        () => [
            {
                accessorKey: 'ofrName',
                header: 'User Name',
                //enableEditing: false,
                //size: 150,
            },
            {
                accessorKey: 'ofrEmpId',
                header: 'User Code',
                size: 50,
            },
            {
                accessorKey: 'ofrDesgName',
                header: 'Designation',
                // size: 50,
            },
            {
                accessorKey: 'ofrTypeName',
                header: 'User Type',
                size: 50,
            },
            {
                accessorKey: 'ofrUserId',
                header: 'User ID',
                size: 100,
            },
            {
                accessorKey: 'status',
                header: 'Status',
                size: 50,
            },
        ],
        [],
    );

    // //DELETE action
    const openDeleteConfirmModal = (id, flag) => {
        let val = flag === 'Y' ? 'disable' : 'enable'
        if (window.confirm('Are you sure you want to ' + val + ' this user?')) {
            setLoading(true)

            const updateFlag = flag === 'Y' ? 'N' : 'Y';

            if (CommonUtil.isValidNumber(id)) {
                const data = {
                    ofrCode: id,
                    ofrUserActive: updateFlag,

                }
                IfvAppraisalService.updateIfvUser(data).then((response) => {
                    setLoading(false)
                    //  var msg = response.data.enableFlag === 'Y' ? 'Enabled' : 'Disabled'
                    var msg = val + 'd'
                    setMessage('User - ' + response.data.ofrName + ' ' + msg + ' successfully!')
                    getAllIfvUsers(mapData)
                    setShowMsg(true)
                },
                    (error) => {
                        const resMessage =
                            (error.response &&
                                error.response.data &&
                                error.response.data.message) ||
                            error.message ||
                            error.toString();
                        setLoading(false)
                        setMessage('Error occured while updating user: ' + resMessage)
                        setShowMsg(true)
                    }
                )

            } else {
                setLoading(false)
                alert('Something went wrong!')
            }
        }
    };

    const table = useMaterialReactTable({
        columns,
        data: data,
        createDisplayMode: 'modal',
        editDisplayMode: 'modal',
        enableEditing: true,
        getRowId: (row) => row.id,

        muiTableContainerProps: {
            sx: {
                minHeight: '500px',
            },
        },

        renderRowActions: ({ row, table }) => (
            <Box sx={{ display: 'flex' }}>
                <Tooltip title="Edit">
                    <IconButton onClick={() => clearAndOpenModal(row.original.ofrCode)}>
                        <EditIcon />
                    </IconButton>
                </Tooltip>
                <Tooltip title={row.original.ofrUserActive === 'Y' ? 'Disable' : 'Enable'}>

                    <IconButton color={row.original.ofrUserActive === 'Y' ? 'error' : ''} onClick={() => openDeleteConfirmModal(row.original.ofrCode, row.original.ofrUserActive)}>
                        {row.original.ofrUserActive === 'Y' ? <BlockIcon /> : <CheckCircleOutlineIcon />}
                    </IconButton>
                </Tooltip>
            </Box >
        ),
        renderTopToolbarCustomActions: ({ table }) => (
            <Button
                variant="contained"
                onClick={() => {
                    clearAndOpenModal(0)
                }}
            >
                Create New User
            </Button>
        ),
    });

    return (
        <div className={loading ? 'blur-background' : ''}>

            <MaterialReactTable table={table} />
            {loading && <Loading />}

            <Modal show={modalShow}
                onHide={() => setModalShow(false)}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
                className={loading ? 'blur-background' : ''}
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        User Registration
                    </Modal.Title>
                </Modal.Header>
                <form key={1} onSubmit={handleSubmitOfUser(onSubmitOfUser)}>
                    <Modal.Body>

                        <div className="row">
                            <div className="col-md-4">
                                <div className="form-group">
                                    <label> <strong>User Name</strong></label>
                                    <Select
                                        value={selectedOption}
                                        onChange={(selected) => onChangeOfEmpName(selected)}
                                        options={filteredOptions}
                                        onInputChange={handleSearch}
                                        isSearchable
                                        isDisabled={enable}
                                    />
                                    <input type='hidden' {...register1('ofrName')} />
                                    <input type='hidden' {...register1('ofrCode')} />
                                </div>
                            </div>

                            <div className="col-md-4">
                                <div className="form-group">
                                    <label> <strong>User Code</strong></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        required readOnly
                                        {...register1('ofrEmpId')}
                                    />
                                </div>
                            </div>

                            <div className="col-md-4">
                                <div className="form-group">
                                    <label> <strong>Designation</strong></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        required readOnly
                                        {...register1('ofrDesgCode')}
                                    />
                                </div>
                            </div>

                        </div>



                        <div className="row">
                            <div className="col-md-4">
                                <div className="form-group">
                                    <label> <strong>Reporting Officer Code</strong></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        required readOnly
                                        {...register1('reportingOfficerCode')}
                                    />
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="form-group">
                                    <label> <strong>User Org Code</strong></label>
                                    <input
                                        type="number"
                                        className="form-control"
                                        autoComplete="off"
                                        required
                                        {...register1('ofrOrgCode')}
                                    />
                                </div>
                            </div>


                            <div className="col-md-4">
                                <div className="form-group">
                                    <label> <strong>User Branch Code</strong></label>
                                    <input
                                        type="number"
                                        className="form-control"
                                        autoComplete="off"
                                        required readOnly
                                        {...register1('ofrBrnCode')}
                                    />
                                </div>
                            </div>

                        </div>

                        <div className="row">
                            <div className="col-md-4">
                                <div className="form-group">
                                    <label> <strong>User Type</strong></label>

                                    <select className="form-control" autoComplete="off"
                                        required
                                        {...register1('ofrType')}
                                    >
                                        <option value="">Select User Type</option>
                                        {Object.entries(UserType).map(([key, value]) => (
                                            <option value={key}>{value}</option>
                                        ))}
                                    </select>
                                </div>
                            </div>

                            <div className="col-md-4">
                                <div className="form-group">
                                    <label> <strong>User Department Code</strong></label>
                                    <input
                                        type="number"
                                        className="form-control"
                                        autoComplete="off"
                                        required
                                        {...register1('ofrDeptCode')}
                                    />
                                </div>
                            </div>

                            <div className="col-md-4">
                                <div className="form-group">
                                    <label> <strong>User ID</strong></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        required
                                        {...register1('ofrUserId')}
                                    />
                                </div>
                            </div>


                        </div>

                        <div className="row">
                            <div className="col-md-4">
                                <div className="form-group">
                                    <label> <strong>Password</strong></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        required
                                        {...register1('ofrUserPassword')}
                                    />
                                </div>
                            </div>

                            <div className="col-md-4">
                                <div className="form-group">
                                    <label> <strong>Email ID</strong></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        required
                                        {...register1('ofrEmail')}
                                    />
                                </div>
                            </div>

                            <div className="col-md-4">
                                <div className="form-group">
                                    <label> <strong>User Short Name</strong></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        required
                                        {...register1('ofrShortName')}
                                    />
                                </div>
                            </div>

                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <div className="button-container-center">
                            {enable && <> <button type='button' className='btn btnPrev' onClick={() => syncWithMIS()}>Sync with MIS <i className="fas fa-sync"></i></button>&nbsp;</>}
                            <button type='submit' className='save btn btnSave'>{!enable ? 'Save' : 'Update'} <i className="fa fa-circle-check"></i></button>
                        </div>
                    </Modal.Footer>
                </form>
            </Modal>

            <Modal style={{ marginTop: "200px" }} show={showMsg} onHide={hideMsg}>

                <Modal.Body >
                    <div className="conatiner text-center">
                        <div className="row">
                            <div className="col-sm-12">
                                <h5 className={message.includes('Error') ? 'alertMsg' : 'loadMsg'}>{message}</h5>
                                {/* <h5 className="loadMsg">{message}</h5> */}
                            </div>
                        </div>
                    </div>

                    <div className="row text-center">
                        <div className="col-sm-12 text-center">
                            <button type="button" className=" btn  btnRegister  themebutton" onClick={hideMsg}>OK</button>
                        </div>
                    </div>

                </Modal.Body>
            </Modal>
        </div>
    )
}

export default Users;