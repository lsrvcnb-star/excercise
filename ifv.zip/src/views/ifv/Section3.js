import Loading from 'components/Loading';
import MessageModal from 'components/MessageModal';
import ProposalHeader from 'components/ProposalHeader';
import SectionNavigation from 'components/SectionNavigation';
import { useErrorHandler } from 'hooks/useErrorHandler';
import useMessageModal from 'hooks/useMessageModal';
import { Fragment, useEffect, useState } from 'react';
import Accordion from 'react-bootstrap/Accordion';
import ReactDatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { Controller, useFieldArray, useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
import IfvAppraisalService from 'services/IfvAppraisalService';
import MasterService from 'services/MasterService';
import UserService from 'services/UserService';
import CommonUtil from 'services/utils/CommonUtil';
import Pattern from 'services/validators/Pattern';

const SectionThree = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const showSFB = location.state ? location.state.showSFB : null;
    const appId = location.state ? location.state.appId : 0;
    const {
        showMessage,
        hideMessage,
        isOpen,
        messageConfig,
        totalMessages,
        currentIndex,
        nextMessage,
        prevMessage,
        hasNext,
        hasPrev
    } = useMessageModal();
    const { handleApiError } = useErrorHandler(showMessage);

    const { control, register, handleSubmit, formState: { errors } } = useForm({
        mode: "onBlur"
    });

    const { control: control9, register: register9, handleSubmit: handleSubmitOfPastDisbursement, setValue: setValue7, formState: { errors: errors9 }, } = useForm({
        mode: "onBlur"
    });

    const { control: control10, register: register10, handleSubmit: handleSubmitOfOutstanding, setValue: setValue8, formState: { errors: errors10 }, } = useForm({
        mode: "onBlur"
    });

    const { control: control11, register: register11, handleSubmit: handleSubmitOfRepayment, setValue: setValue9, getValues: getValues9, watch: watch9, formState: { errors: errors11 }, } = useForm({
        mode: "onBlur"
    });

    const { control: control12, register: register12, handleSubmit: handleSubmitOfCommonDto, setValue: setValue10, formState: { errors: errors12 }, } = useForm({
        mode: "onBlur"
    });


    const { fields: fields7, append: append7, remove: remove7 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "pastDisbursement", // unique name for your Field Array
    });

    const { fields: fields8, append: append8, remove: remove8 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "outstanding", // unique name for your Field Array
    });

    const { fields: fields9, append: append9, remove: remove9 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "repayment", // unique name for your Field Array
    });

    const [totalRepayment, setTotalRepayment] = useState([])
    const [totRep, setTotRep] = useState(0)
    const [aeDates, setAeDates] = useState([])
    const [selectedScheme, setSelectedScheme] = useState([])
    const [locked, setLocked] = useState(false)
    const [ifvApp, setIfvApp] = useState({})
    const [isMaker, setMaker] = useState(false)
    const [isChecker, setChecker] = useState(false)
    const [isMakerConvenor, setMakerConvenor] = useState(false)

    const [loading, setLoading] = useState(false)
    const [generalAndRsfb, setGeneralAndRsfb] = useState(false)
    const [rampe, setRampe] = useState(false)
    const [fabia, setFabia] = useState(false)
    const [mserScheme, setMserScheme] = useState(false)
    const [rmseScheme, setRmseScheme] = useState(false)
    const [schemeLabel, setSchemeLabel] = useState('Cost of Fund to SIDBI and Interest Margin')

    useEffect(() => {
        const user = IfvAppraisalService.getCurrentUser();

        setMaker(UserService.isMaker(user))
        setChecker(UserService.isChecker(user))
        setMakerConvenor(UserService.isMakerConvenor(user))

        IfvAppraisalService.getAllSchemesOnIfvId(appId).then(
            (response) => {
                let isRMSEScheme = false
                response.data.forEach((item, index) => {

                    if (item.prFundcode === '01' && item.prSchemeName.includes('SFB') && showSFB) {
                        setGeneralAndRsfb(true)
                    }
                    if (item.prFundname.toLowerCase().includes('rmse')) {
                        setRmseScheme(true)
                        isRMSEScheme = true
                        //setSchemeLabel('For RMSE: Cost of fund to SIDBI and Interest Margin')
                    }
                    if (!item.prFundname.toLowerCase().includes('rmse') && item.prSchemeName === 'MSERS') {
                        setMserScheme(true)
                        // setSchemeLabel('For MSER: Interest Margin')
                    }

                    if (!item.prFundname.toLowerCase().includes('rmse') && item.prSchemecode === '4C') {
                        setFabia(true)
                    }
                    if (!item.prFundname.toLowerCase().includes('rmse') && item.prSchemecode === '4D') {
                        setRampe(true)
                    }

                })
                getIfvAppById(appId, isRMSEScheme)
            },
            (error) => {
                handleApiError(error, 'loading scheme data')
            }
        )
    }, []);

    const [cifNumberOfBank, setCifNumberOfBank] = useState('')

    const getIfvAppById = (appId, isRMSEScheme) => {
        IfvAppraisalService.getIfvAppById(appId).then(
            (response) => {
                setIfvApp(response.data)
                const cifNumber = response.data.cifNumber
                setCifNumberOfBank(cifNumber)
                getAllOutstandings(cifNumber)
                getAllRepayment(cifNumber)
                getCommonData()
                getTblFwdDetail()
                getAllPastDisbursement(response.data.ifvId, cifNumber, isRMSEScheme)
                if (response.data.ifvBankType === 'RRB') {
                    setRRB(true)
                } else {
                    setRRB(false)
                }
            },
            (error) => {
                handleApiError(error, 'loading App Data')
            }
        )
    }

    const getPastDisbursementsOnCifNumber = (cifNumber, isRMSEScheme) => {
        setLoading(true)

        MasterService.getPastDisbursementsOnCifNumber(cifNumber).then(
            (response) => {

                if (response.data.length <= 0) {
                    append7({})
                    showMessage('Empty data received for Past disbursements', 'warning')
                } else {
                    const appData = response.data;
                    fields7.map((val, ind) => {
                        setValue7(`pastDisbursement[${ind}]`, undefined)
                        setSelectedScheme(prevState => ({ ...prevState, [ind]: '' }))
                        setAeDates(prevState => ({ ...prevState, [ind]: '' }))
                        remove7(ind)
                    });
                    appData.forEach((item, index) => {
                        remove7(index)
                        append7({})
                        setValue7(`pastDisbursement[${index}].aeId`, item.aeId)
                        setValue7(`pastDisbursement[${index}].ifvId`, item.ifvId)
                        setValue7(`pastDisbursement[${index}].aePeriodfy`, item.periodFY)
                        setValue7(`pastDisbursement[${index}].aeDate`, new Date(item.dateOfDisburcement))
                        setValue7(`pastDisbursement[${index}].aeAmount`, item.amount)
                        setValue7(`pastDisbursement[${index}].aeScheme`, item.scheme)
                        setValue7(`pastDisbursement[${index}].aeRoi`, item.roi)
                        setValue7(`pastDisbursement[${index}].aeTenure`, item.tenure)

                        //     setSelectedScheme(prevState => ({ ...prevState, [index]: item.aeScheme }))

                        if (item.dateOfDisburcement != null) {
                            setAeDates(prevState => ({ ...prevState, [index]: new Date(item.dateOfDisburcement) }))
                        }

                    });
                }
                setLoading(false)
            },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading Past Disbursements')
            }
        )
    }

    const getOSDetailsOnCifNumber = (cifNumber, isTrue) => {
        if (isTrue === true) {
            setLoading(true)
        }

        MasterService.getOSDetailsOnCifNumber(cifNumber).then(
            (response) => {
                if (response.data.length <= 0) {
                    append8({})
                    showMessage('Empty data received for Outstandings', 'warning')
                } else {

                    fields8.map((val, ind) => {
                        setValue8(`outstanding[${ind}]`, undefined)
                        remove8(ind)
                    })

                    response.data.forEach((item, index) => {
                        //   setValue8(`outstanding[${index}].osId`, item.osId)
                        // setValue8(`outstanding[${index}].ifvId`, item.ifvId)
                        remove8(index)
                        append8({})
                        setValue8(`outstanding[${index}].osPeriodFy`, item.year)
                        setValue8(`outstanding[${index}].osYear`, CommonUtil.roundToTwoDecimals(item.osBegningOfTheYerar))
                        setValue8(`outstanding[${index}].osAmountDisb`, item.amountDisburced)
                        setValue8(`outstanding[${index}].osRepaid`, CommonUtil.roundToTwoDecimals(item.repaid))
                        let sum = parseFloat(item.osBegningOfTheYerar) + parseFloat(item.amountDisburced) - parseFloat(item.repaid)
                        if (sum < 0) {
                            sum = 0;
                        }
                        setValue8(`outstanding[${index}].osEnd`, CommonUtil.roundToTwoDecimals(sum))
                    });
                }
                if (isTrue === true) {
                    setLoading(false)
                }
            },
            (error) => {
                if (isTrue === true) {
                    setLoading(false)
                }
                handleApiError(error, 'loading Outstandings');
            }
        )
    }

    const getFutureRepayDetails = (cifNumber, isTrue) => {
        if (isTrue === true) {
            setLoading(true)
        }
        MasterService.getFutureRepayDetails(cifNumber).then(
            (response) => {
                if (response.data.length <= 0) {
                    append9({});
                    setFutureRep();
                    showMessage('Empty data received for Future Repayments', 'warning')
                } else {

                    let acc = getValues9('repayment[0].rpRefinanceAcc')
                    let track = getValues9('repayment[0].rpRepaymentTrack')

                    fields9.map((val, ind) => {
                        setValue9(`repayment[${ind}]`, undefined)
                        remove9(ind)
                    });

                    const appData = response.data;
                    let tot = 0;
                    appData.forEach((item, index) => {
                        remove9(index)
                        append9({})
                        setValue9(`repayment[${0}].rpRefinanceAcc`, acc)
                        setValue9(`repayment[${0}].rpRepaymentTrack`, track)
                        setValue9(`repayment[${index}].ifvId`, appId)
                        setValue9(`repayment[${index}].rpPeriodfy`, item.year)
                        setValue9(`repayment[${index}].rpQ1`, CommonUtil.roundToTwoDecimals(item.q1))
                        setValue9(`repayment[${index}].rpQ2`, CommonUtil.roundToTwoDecimals(item.q2))
                        setValue9(`repayment[${index}].rpQ3`, CommonUtil.roundToTwoDecimals(item.q3))
                        setValue9(`repayment[${index}].rpQ4`, CommonUtil.roundToTwoDecimals(item.q4))
                        const rpTotal = item.q1 + item.q2 + item.q3 + item.q4;
                        setValue9(`repayment[${index}].rpTotal`, CommonUtil.roundToTwoDecimals(rpTotal))
                        tot = tot + parseFloat(rpTotal)
                    });

                    setTotRep(CommonUtil.roundToTwoDecimals(tot))
                }

                if (isTrue === true) {
                    setLoading(false)
                }

            },
            (error) => {
                if (isTrue === true) {
                    setLoading(false)
                }
                append9({});
                setFutureRep();
                handleApiError(error, 'loading Future Repayments');
            }
        )
    }

    const setFutureRep = () => {
        setValue9(`repayment[0].rpRefinanceAcc`, "")
        setValue9(`repayment[0].rpRepaymentTrack`, "")
        setValue9(`repayment[0].ifvId`, appId)
        setValue9(`repayment[0].rpPeriodfy`, new Date().getFullYear())
        setValue9(`repayment[0].rpQ1`, 0)
        setValue9(`repayment[0].rpQ2`, 0)
        setValue9(`repayment[0].rpQ3`, 0)
        setValue9(`repayment[0].rpQ4`, 0)
        setValue9(`repayment[0].rpTotal`, 0)
    }

    const [editable, setEditable] = useState(false)
    const [appStatus, setAppStatus] = useState('')
    const getTblFwdDetail = () => {
        IfvAppraisalService.getTblFwdDetail(appId)
            .then((response) => {
                const status = response.data.appStatus
                switch (status) {
                    case 'LK':
                        setLocked(true)
                        setEditable(false)
                        setAppStatus('Locked')
                        break
                    case 'NW':
                        setLocked(false)
                        setEditable(true)
                        setAppStatus('New')
                        break
                    case 'CN':
                        setLocked(false)
                        setEditable(false)
                        setAppStatus('Confirmed')
                        break
                    case 'AP':
                        setLocked(false)
                        setEditable(false)
                        setAppStatus('Approved')
                        break
                }
            })
            .catch(error => {
                handleApiError(error, 'loading TBL data')
            })
    }

    const [savePastDisb, setSavePastDisb] = useState(false)

    const getAllPastDisbursement = (ifvId, cifNumber, isRMSEScheme) => {

        IfvAppraisalService.getAllPastDisbursement(ifvId).then(response => {
            const appData = response.data
            if (appData.length > 0) {
                for (let i = 0; i < appData.length; i++) {
                    remove7(i)
                    append7({})
                }
                setSavePastDisb(false)
            }
            else {
                setSavePastDisb(true)
                getPastDisbursementsOnCifNumber(cifNumber, isRMSEScheme)
            }
            appData.forEach((item, index) => {
                setValue7(`pastDisbursement[${index}].aeId`, item.aeId)
                setValue7(`pastDisbursement[${index}].ifvId`, item.ifvId)
                setValue7(`pastDisbursement[${index}].aePeriodfy`, item.aePeriodfy)

                setValue7(`pastDisbursement[${index}].aeAmount`, item.aeAmount)
                setValue7(`pastDisbursement[${index}].aeScheme`, item.aeScheme)
                setValue7(`pastDisbursement[${index}].aeRoi`, item.aeRoi)
                setValue7(`pastDisbursement[${index}].aeTenure`, item.aeTenure)

                setSelectedScheme(prevState => ({ ...prevState, [index]: item.aeScheme }))

                if (!CommonUtil.isEmpty(item.aeDate)) {
                    setValue7(`pastDisbursement[${index}].aeDate`, new Date(item.aeDate))
                    setAeDates(prevState => ({ ...prevState, [index]: new Date(item.aeDate) }))
                }

            });

        },
            (error) => {
                handleApiError(error, 'loading Details of Past Disbursement')
            }
        )
    }

    const onSubmitOfPastDisbursement = (data, e) => {
        setLoading(true)

        const finalData = data['pastDisbursement'].filter(item => !CommonUtil.isEmpty(item))

        finalData.map((item, index) => {
            if (!CommonUtil.isEmpty(aeDates[index])) {
                item['aeDate'] = new Date(aeDates[index])
            }
        })

        IfvAppraisalService.savePastDisbursement(finalData).then((response) => {
            setLoading(false)
            showMessage('Past Disbursement details have been successfully saved!', 'success')
            getAllPastDisbursement(appId, ifvApp.cifNumber, rmseScheme)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving Past Disbursement')
            })
    }

    const [saveOutstandings, setSaveOutstandings] = useState(false)

    const getAllOutstandings = (cifNumber) => {
        IfvAppraisalService.getAllOutstandings(appId).then(response => {
            const appData = response.data
            if (appData.length > 0) {
                for (let i = 0; i < appData.length; i++) {
                    remove8(i)
                    append8({})
                }
                setSaveOutstandings(false)
            }
            else {
                setSaveOutstandings(true)
                getOSDetailsOnCifNumber(cifNumber, false)
            }
            appData.forEach((item, index) => {
                setValue8(`outstanding[${index}].osId`, item.osId)
                setValue8(`outstanding[${index}].ifvId`, item.ifvId)
                setValue8(`outstanding[${index}].osPeriodFy`, item.osPeriodFy)
                setValue8(`outstanding[${index}].osYear`, CommonUtil.roundToTwoDecimals(item.osYear))
                setValue8(`outstanding[${index}].osAmountDisb`, item.osAmountDisb)
                setValue8(`outstanding[${index}].osRepaid`, CommonUtil.roundToTwoDecimals(item.osRepaid))

                //const sum = parseFloat(item.osYear) + parseFloat(item.osAmountDisb) - parseFloat(item.osRepaid);
                let sum = item.osEnd;
                if (sum < 0) {
                    sum = 0;
                }
                setValue8(`outstanding[${index}].osEnd`, CommonUtil.roundToTwoDecimals(sum))

            });

        },
            (error) => {
                handleApiError(error, 'loading Details of outstanding')
            }
        )
    }

    const onSubmitOfOutstanding = (data, e) => {
        setLoading(true)

        const finalData = data['outstanding'].filter(item => !CommonUtil.isEmpty(item))

        IfvAppraisalService.saveAllOutstandings(finalData).then((response) => {
            setLoading(false)
            showMessage('Outstanding details have been successfully saved!', 'success')
            getAllOutstandings(ifvApp.cifNumber)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving Outstandings')
            })
    }

    const [saveRepayment, setSaveRepayment] = useState(false)

    const getAllRepayment = (cifNumber) => {
        IfvAppraisalService.getAllRepayment(appId).then(response => {
            const appData = response.data
            if (appData.length > 0) {
                for (let i = 0; i < appData.length; i++) {
                    remove9(i)
                    append9({})
                }
                setSaveRepayment(false)
            }
            else {
                setSaveRepayment(true)
                getFutureRepayDetails(cifNumber, false)
            }
            let tot = 0;
            appData.forEach((item, index) => {
                setValue9(`repayment[${index}].rpId`, item.rpId)
                setValue9(`repayment[${index}].ifvId`, item.ifvId)
                setValue9(`repayment[${index}].rpRefinanceAcc`, item.rpRefinanceAcc)
                setValue9(`repayment[${index}].rpRepaymentTrack`, item.rpRepaymentTrack)
                setValue9(`repayment[${index}].rpPeriodfy`, item.rpPeriodfy)
                setValue9(`repayment[${index}].rpQ1`, CommonUtil.roundToTwoDecimals(item.rpQ1))
                setValue9(`repayment[${index}].rpQ2`, CommonUtil.roundToTwoDecimals(item.rpQ2))
                setValue9(`repayment[${index}].rpQ3`, CommonUtil.roundToTwoDecimals(item.rpQ3))
                setValue9(`repayment[${index}].rpQ4`, CommonUtil.roundToTwoDecimals(item.rpQ4))
                setValue9(`repayment[${index}].rpTotal`, CommonUtil.roundToTwoDecimals(item.rpTotal))
                tot = tot + parseFloat(item.rpTotal)
            });

            setTotRep(CommonUtil.roundToTwoDecimals(tot))

        },
            (error) => {
                handleApiError(error, 'loading Details of repayment')
            }
        )
    }

    const onSubmitOfRepayment = (data, e) => {
        setLoading(true)
        const finalData = data['repayment'].filter((item) => !CommonUtil.isEmpty(item))
        IfvAppraisalService.saveAllRepayment(finalData).then((response) => {
            showMessage('Repayment details have been successfully saved!', 'success')
            getAllRepayment(ifvApp.cifNumber)
            setLoading(false)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving repayment')
            })
    }

    const getCommonData = () => {
        IfvAppraisalService.getCommonData(appId).then(response => {
            const appData = response.data
            setValue10('sfbId', appData.sfbId)
            setValue10('ifvId', appData.ifvId)
            setValue10('cmMsersData', appData.cmMsersData)
            setValue10('cmRmseData', appData.cmRmseData)
            setValue10('cmRsfbData', appData.cmRsfbData)
            setValue10('cmFabiaData', appData.cmFabiaData)
            setValue10('cmRampeData', appData.cmRampeData)
            setValue10('interestReset', appData.interestReset)
            setCommonId(appData.sfbId)
            setPastDisbNote(appData.pastDisbNote)
            setOutstandingsNote(appData.outstandingsNote)
            setFutureRepNote(appData.futureRepNote)
        },
            (error) => {
                handleApiError(error, 'loading common details')
            }
        )
    }

    const onSubmitOfCommonDto = (data, e) => {
        setLoading(true)
        data.ifvId = appId
        IfvAppraisalService.saveCommonData(data).then((response) => {
            showMessage('Data has been successfully saved!', 'success')
            getCommonData()
            setLoading(false)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving common details')
            })
    }

    function goToNext() {
        navigate('/ifv/sectionFour', {
            state: {
                showSFB: showSFB,
                appId: appId
            }
        });
    }

    const calculateTotalRepayment = (field, index, value) => {
        setValue9(field, value, { shouldValidate: true })

        const Q1 = watch9(`repayment[${index}].rpQ1`) != null ? watch9(`repayment[${index}].rpQ1`) : 0;
        const Q2 = watch9(`repayment[${index}].rpQ2`) != null ? watch9(`repayment[${index}].rpQ2`) : 0;
        const Q3 = watch9(`repayment[${index}].rpQ3`) != null ? watch9(`repayment[${index}].rpQ3`) : 0;
        const Q4 = watch9(`repayment[${index}].rpQ4`) != null ? watch9(`repayment[${index}].rpQ4`) : 0;

        let sum = parseFloat(Q1) + parseFloat(Q2) + parseFloat(Q3) + parseFloat(Q4);
        sum = CommonUtil.roundToTwoDecimals(sum)

        setTotalRepayment(prevState => ({ ...prevState, [index]: sum }))
        setValue9(`repayment[${index}].rpTotal`, sum, { shouldValidate: true })

        calcTotRep()

    }

    const calcTotRep = () => {
        let totSum = 0;
        fields9.map((item, index) => {
            let val = getValues9(`repayment[${index}].rpTotal`)
            if (CommonUtil.isValidNumber(val)) {
                totSum = totSum + parseFloat(val)
            }
        })
        setTotRep(CommonUtil.roundToTwoDecimals(totSum))
    }

    const handleNegativeNo = (e) => {
        const val = e.target.value
        if (!isNaN(val) && parseFloat(val) < 0) {
            e.target.value = ''
        }
    }

    const [pastDisbNote, setPastDisbNote] = useState('');
    const [outstandingsNote, setOutstandingsNote] = useState('');
    const [futureRepNote, setFutureRepNote] = useState('');
    const [commonId, setCommonId] = useState(0);

    const savePastDisbNote = () => {

        // if (CommonUtil.isEmpty(pastDisbNote) && CommonUtil.isEmpty(outstandingsNote) && CommonUtil.isEmpty(futureRepNote)) {
        //     showMessage('Enter data', 'warning')
        //     return
        // }

        setLoading(true)
        const data = {
            sfbId: commonId,
            ifvId: appId,
            pastDisbNote: pastDisbNote,
            outstandingsNote: outstandingsNote,
            futureRepNote: futureRepNote
        }

        IfvAppraisalService.saveCommonData(data).then((response) => {
            showMessage('Data has been successfully saved!', 'success')
            setPastDisbNote(response.data.pastDisbNote)
            setOutstandingsNote(response.data.outstandingsNote)
            setFutureRepNote(response.data.futureRepNote)
            setCommonId(response.data.sfbId)
            setLoading(false)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving..')
            })
    }

    const [rrb, setRRB] = useState(false)

    return (
        <Fragment>
            <div className={loading ? 'frgmnt blur-background' : 'frgmnt'}>
                {appId > 0 && <SectionNavigation activeView={'Section Three'} showSFB={showSFB} appId={appId} />}

                <ProposalHeader
                    bankName={ifvApp.ifvName}
                    appNumber={ifvApp.appNumber}
                    status={appStatus}
                    appId={appId}
                />

                <Accordion flush>
                    <Accordion.Item>
                        <Accordion.Header>Assistance Earlier Availed and Past Dealings Under Refinance Schemes</Accordion.Header>

                        <Accordion.Body>

                            <div className='outer_Wrap outerInr_Wrap'>
                                <form key={8} onSubmit={handleSubmitOfPastDisbursement(onSubmitOfPastDisbursement)}>
                                    <h5 className='HdngTitl'>

                                        <strong>Past Disbursements</strong><span className='cr'>(₹ in crore)</span></h5>

                                    <div className='container-fluid p-0'>
                                        <div className='row row_align'>
                                            <div className='col-md-1'>
                                                <div className='form-group'>
                                                    <label><strong>Sl No</strong></label>
                                                </div>
                                            </div>
                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label className='ms-4 mnr'><strong>Period (FY)</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label className='ml-3'><strong>Date</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label className='ml-3'><strong>Amount</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label><strong>Scheme</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-1'>
                                                <div className='form-group'>
                                                    <label><strong>RoI</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label><strong>Tenure (Months)</strong></label>
                                                </div>
                                            </div>

                                        </div>
                                    </div>


                                    {fields7.map((field, index) => (
                                        <div className='container-fluid p-0'>
                                            <div className='row' eventKey="0" key={field.id}>
                                                <div className='col-md-1'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            {index + 1}
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            {/* <label><strong>FY</strong></label> */}

                                                            <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='number' readOnly
                                                                {...register9(`pastDisbursement[${index}].aePeriodfy`, {
                                                                    required: "FY is required",
                                                                    maxLength: {
                                                                        value: 4,
                                                                        message: "The length of the field is 4"
                                                                    },
                                                                    minLength: {
                                                                        value: 4,
                                                                        message: "The length of the field is 4"
                                                                    },
                                                                })}
                                                            />

                                                            <span className='alert'>
                                                                {errors9.pastDisbursement && errors9.pastDisbursement[index] && errors9.pastDisbursement[index].aePeriodfy && errors9.pastDisbursement[index].aePeriodfy.message}</span>

                                                            <input type='hidden' {...register9(`pastDisbursement[${index}].aeId`)} />
                                                            <input type='hidden' {...register9(`pastDisbursement[${index}].ifvId`)} value={appId} />
                                                        </div>
                                                    </div>
                                                </div>


                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            <Controller
                                                                {...register9(`pastDisbursement[${index}].aeDate`)}
                                                                control={control9}
                                                                render={({ field: { onChange, onBlur, value, ref } }) => (
                                                                    <ReactDatePicker className="form-control"
                                                                        placeholderText="Select date"
                                                                        onChange={(date) => setAeDates(prevState => ({ ...prevState, [index]: new Date(date) }))}
                                                                        selected={aeDates[index] ? new Date(aeDates[index]) : aeDates[index]}
                                                                        onBlur={onBlur}
                                                                        dateFormat="dd/MM/yyyy"
                                                                        readOnly
                                                                    />

                                                                )}

                                                            />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='number' readOnly
                                                                {...register9(`pastDisbursement[${index}].aeAmount`)}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='text' readOnly
                                                                {...register9(`pastDisbursement[${index}].aeScheme`)}
                                                            />
                                                            {/* <select className="form-control"
                                                                {...register9(`pastDisbursement[${index}].aeScheme`, {
                                                                    required: "Scheme is required",
                                                                    onChange: (selected) => setSelectedScheme(prevState => ({ ...prevState, [index]: selected.label }))
                                                                })}
                                                            >
                                                                <option value=""> Please select a scheme</option>
                                                                {schemes.map((item, i) => (
                                                                    <option selected={item.longName === selectedScheme[index]} value={item.longName}>{item.longName}</option>
                                                                ))}
                                                            </select> */}
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className='col-md-1'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='number' readOnly
                                                                step='any'
                                                                {...register9(`pastDisbursement[${index}].aeRoi`)}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='number' readOnly
                                                                step='any'
                                                                {...register9(`pastDisbursement[${index}].aeTenure`)}
                                                            />
                                                            {/* <select className="form-control"
                                                                key={field.id}
                                                                {...register9(`pastDisbursement[${index}].aeTenure`)}
                                                            >
                                                                <option value="">Select Month</option>
                                                                {PrincipalRepayment.map((item, index) => (
                                                                    <option value={item}>{item}</option>
                                                                ))}
                                                            </select> */}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    ))}
                                    {/* <div className="button-container-end">
                                        <button className="remove" type="button" onClick={() => append7({})}>+</button>
                                    </div> */}
                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && savePastDisb && <p className='color-red'>Please save the autofetched data before proceeding.</p>}
                                    </div>

                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && !savePastDisb && <button type='button' className="btn btnPrev" onClick={() => getPastDisbursementsOnCifNumber(cifNumberOfBank, false)}> Sync with MIS <i className="fas fa-sync"></i></button>}
                                        {(editable || (!isMaker && locked)) && <button type='submit' className="save"> {savePastDisb ? 'Save' : 'Update'} <i className="fa fa-circle-check"></i></button>}
                                    </div>
                                    <br />
                                    <div className="button-container-left">
                                        {(editable || (!isMaker && locked)) && !savePastDisb && <p className='color-red'>Note: Kindly update once you click on 'Sync with MIS'.</p>}
                                    </div>
                                </form>


                            </div>

                            {/* Next__________ */}
                            <form key={9} onSubmit={handleSubmitOfOutstanding(onSubmitOfOutstanding)}>
                                <div className='outer_Wrap outerInr_Wrap'>

                                    <h5 className='HdngTitl'>

                                        <strong>Outstanding:</strong><span className='cr'>(₹ in crore)</span></h5>

                                    <div className='container-fluid p-0'>
                                        <div className='row row_align'>
                                            <div className='col-md-1'>
                                                <div className='form-group'>
                                                    <label><strong>Sl No</strong></label>
                                                </div>
                                            </div>
                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label className='ms-4 mnr'><strong>Period (FY)</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label className='ml-3'><strong>O/S at the Beginning of the year</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label><strong>Amount Disbursed</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label className='ms-4'><strong>Repaid</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-3'>
                                                <div className='form-group'>
                                                    <label><strong>O/S at the end of the Period</strong></label>
                                                </div>
                                            </div>

                                        </div>
                                    </div>


                                    {fields8.map((field, index) => (
                                        <div className='container-fluid p-0'>
                                            <div className='row pt-0' eventKey="0" key={field.id}>
                                                <div className='col-md-1'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            {index + 1}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            {/* <label><strong>FY</strong></label> */}
                                                            <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='number' readOnly
                                                                {...register10(`outstanding[${index}].osPeriodFy`, {
                                                                    required: "FY is required",
                                                                    maxLength: {
                                                                        value: 4,
                                                                        message: "The length of the field is 4"
                                                                    },
                                                                    minLength: {
                                                                        value: 4,
                                                                        message: "The length of the field is 4"
                                                                    },
                                                                })}
                                                            />
                                                            <span className='alert'>
                                                                {errors10.outstanding && errors10.outstanding[index] && errors10.outstanding[index].osPeriodFy && errors10.outstanding[index].osPeriodFy.message}</span>
                                                            <input type='hidden' {...register10(`outstanding[${index}].osId`)} />
                                                            <input type='hidden' {...register10(`outstanding[${index}].ifvId`)} value={appId} />
                                                        </div>
                                                    </div>
                                                </div>


                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            <input className='form-control'
                                                                key={field.id}
                                                                type='number' readOnly
                                                                step='any'
                                                                {...register10(`outstanding[${index}].osYear`)}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='number' readOnly
                                                                step='any'
                                                                {...register10(`outstanding[${index}].osAmountDisb`)}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='number' readOnly
                                                                step='any'
                                                                {...register10(`outstanding[${index}].osRepaid`)}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className='col-md-3'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='number' readOnly
                                                                step='any'
                                                                {...register10(`outstanding[${index}].osEnd`)}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>
                                        </div>

                                    ))}


                                    {/* <div className="button-container-end">
                                        <button className="remove" type="button" onClick={() => append8({})}>+</button>
                                    </div> */}



                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && saveOutstandings && <p className='color-red'>Please save the autofetched data before proceeding.</p>}
                                    </div>
                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && !saveOutstandings && <button type='button' className="btn btnPrev" onClick={() => getOSDetailsOnCifNumber(cifNumberOfBank, true)}> Sync with MIS <i className="fas fa-sync"></i></button>}
                                        {(editable || (!isMaker && locked)) && <button type='submit' className="save">{saveOutstandings ? 'Save' : 'Update'} <i className="fa fa-circle-check"></i></button>}
                                    </div>

                                    <br />
                                    <div className="button-container-left">
                                        {(editable || (!isMaker && locked)) && !saveOutstandings && <p className='color-red'>Note: Kindly update once you click on 'Sync with MIS'.</p>}
                                    </div>

                                </div>
                            </form>



                            {/* Next__________ */}
                            <form key={10} onSubmit={handleSubmitOfRepayment(onSubmitOfRepayment)}>
                                <div className='outer_Wrap outerInr_Wrap'>

                                    <div className='container-fluid p-0'>
                                        <div className='row'>
                                            <h5 className='HdngTitl'>Repayment Record :</h5>

                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <div className='branch_on'>
                                                        <label>The existing refinance account with SIDBI is</label>
                                                        <div className='brn_wrp'><input className='form-control'
                                                            {...register11('repayment[0].rpRefinanceAcc')}
                                                            type='text' onChange={(e) => { Pattern.sanitizeInput(e); handleNegativeNo(e) }}

                                                        /></div>
                                                        <label>and categorized as</label>
                                                        <div className='brn_wrp'><input className='form-control'
                                                            {...register11('repayment[0].rpRepaymentTrack')}
                                                            type='text' onChange={(e) => { Pattern.sanitizeInput(e); handleNegativeNo(e) }}

                                                        /></div>
                                                        <label>repayment track record as per RiMV guidelines.</label>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>


                                    <div className='container-fluid mt-5'>

                                        <div className='row row_align'>

                                            <h5 className='HdngTitl'><strong>Future Repayments of Existing Outstanding:</strong><span className='cr'>(₹ in crore)</span></h5>
                                            <div className='col-md-1'>
                                                <div className='form-group'>
                                                    <label><strong>Sl No</strong></label>
                                                </div>
                                            </div>
                                            <div className='col-md-1'>
                                                <div className='form-group'>
                                                    <label><strong>Period (FY)</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label className='ml-3'><strong>Q1</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label><strong>Q2</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label><strong>Q3</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label><strong>Q4</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label><strong>Total Repayment</strong></label>
                                                </div>
                                            </div>

                                        </div>
                                    </div>


                                    {fields9.map((field, index) => (
                                        <div className='container-fluid'>
                                            <div className='row pt-0' eventKey="0" key={field.id}>
                                                <div className='col-md-1'>
                                                    <div className='form-group'>
                                                        {index + 1}
                                                    </div>
                                                </div>

                                                <div className='col-md-1'>
                                                    <div className='form-group'>
                                                        <div className='asis'>
                                                            {/* <label><strong>FY</strong></label> */}
                                                            <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='number' readOnly
                                                                {...register11(`repayment[${index}].rpPeriodfy`, {
                                                                    required: "FY is required",
                                                                    maxLength: {
                                                                        value: 4,
                                                                        message: "The length of the field is 4"
                                                                    },
                                                                    minLength: {
                                                                        value: 4,
                                                                        message: "The length of the field is 4"
                                                                    },
                                                                })}
                                                            />
                                                            <span className='alert'>
                                                                {errors11.repayment && errors11.repayment[index] && errors11.repayment[index].rpPeriodfy && errors11.repayment[index].rpPeriodfy.message}</span>
                                                            <input type='hidden' {...register11(`repayment[${index}].rpId`)} />
                                                            <input type='hidden' {...register11(`repayment[${index}].ifvId`)} value={appId} />
                                                        </div>
                                                    </div>
                                                </div>


                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <input className='form-control'
                                                            key={field.id} // important to include key with field's id
                                                            type='number'
                                                            step='any' readOnly
                                                            {...register11(`repayment[${index}].rpQ1`, {
                                                                onChange: (e) => calculateTotalRepayment(`repayment[${index}].rpQ1`, index, e.target.value)
                                                            })
                                                            }

                                                        />
                                                    </div>
                                                </div>

                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <input className='form-control'
                                                            key={field.id} // important to include key with field's id
                                                            type='number'
                                                            step='any' readOnly
                                                            {...register11(`repayment[${index}].rpQ2`, {
                                                                onChange: (e) => calculateTotalRepayment(`repayment[${index}].rpQ2`, index, e.target.value)
                                                            })}
                                                        />
                                                    </div>
                                                </div>


                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <input className='form-control'
                                                            key={field.id} // important to include key with field's id
                                                            type='number'
                                                            step='any' readOnly
                                                            {...register11(`repayment[${index}].rpQ3`, {
                                                                onChange: (e) => calculateTotalRepayment(`repayment[${index}].rpQ3`, index, e.target.value)
                                                            })}
                                                        />
                                                    </div>
                                                </div>


                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <input className='form-control'
                                                            key={field.id} // important to include key with field's id
                                                            type='number'
                                                            step='any' readOnly
                                                            {...register11(`repayment[${index}].rpQ4`,
                                                                {
                                                                    onChange: (e) => calculateTotalRepayment(`repayment[${index}].rpQ4`, index, e.target.value)
                                                                })}
                                                        />

                                                    </div>
                                                </div>


                                                <div className='col-md-2'>
                                                    <div className='form-group'>
                                                        <input className='form-control'
                                                            key={field.id} // important to include key with field's id
                                                            type='number' readOnly step='any'
                                                            {...register11(`repayment[${index}].rpTotal`)}
                                                            value={totalRepayment[index]}
                                                        />

                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                    ))}

                                    <div className='container-fluid p-0'>
                                        <div className='row'>
                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <label><strong>Total</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-8'>
                                                <div className='form-group'>
                                                    &nbsp;
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <input className='form-control' type='number' step='any' readOnly value={totRep} />
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                    {/* <div className="button-container-end">
                                        <button className="remove" type="button" onClick={() => append9({})}>+</button>
                                    </div> */}
                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && saveRepayment && <p className='color-red'>Please save the autofetched data before proceeding.</p>}
                                    </div>
                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && !saveRepayment && <button type='button' className="btn btnPrev" onClick={() => getFutureRepayDetails(cifNumberOfBank, true)}> Sync with MIS <i className="fas fa-sync"></i></button>}
                                        {(editable || (!isMaker && locked)) && <button type='submit' className="save">{saveRepayment ? 'Save' : 'Update'} <i className="fa fa-circle-check"></i></button>}
                                    </div>

                                    <br />
                                    <div className="button-container-left">
                                        {(editable || (!isMaker && locked)) && !saveRepayment && <p className='color-red'>Note: Kindly update once you click on 'Sync with MIS'.</p>}
                                    </div>


                                </div>
                            </form>

                            <>
                                <div className='form-group'>
                                    <label>
                                        <strong>Past Disbursements Note:</strong>
                                    </label>
                                    <textarea className='form-control'
                                        autoComplete="off" maxLength="4000" value={pastDisbNote}
                                        onChange={(e) => { Pattern.sanitizeInput(e); setPastDisbNote(e.target.value) }}
                                    />

                                </div>
                                <div className='form-group'>
                                    <label>
                                        <strong>Outstanding Note:</strong>
                                    </label>
                                    <textarea className='form-control'
                                        autoComplete="off" maxLength="4000" value={outstandingsNote}
                                        onChange={(e) => { Pattern.sanitizeInput(e); setOutstandingsNote(e.target.value) }}
                                    />

                                </div>
                                <div className='form-group'>
                                    <label>
                                        <strong>Repayment track record:</strong>
                                    </label>
                                    <textarea className='form-control'
                                        autoComplete="off" maxLength="4000" value={futureRepNote}
                                        onChange={(e) => { Pattern.sanitizeInput(e); setFutureRepNote(e.target.value) }}
                                    />

                                </div>
                                <div className='col-md-12'>
                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && <button type='button' onClick={() => savePastDisbNote()} className='save'>Save <i className="fa fa-circle-check"></i></button>}
                                    </div>
                                </div>
                            </>

                        </Accordion.Body>
                    </Accordion.Item>

                    <Accordion.Item eventKey="1">
                        <Accordion.Header>{schemeLabel}</Accordion.Header>

                        <Accordion.Body className='msers'>
                            <form onSubmit={handleSubmitOfCommonDto(onSubmitOfCommonDto)}>
                                <input type='hidden' {...register12('sfbId')} />
                                <input type='hidden' {...register12('ifvId')} value={appId} />
                                {generalAndRsfb && <div className='form-group'>
                                    <label className='prog_lbl'>
                                        <strong>RSFB: </strong>
                                        {/* <div className='prgs'>
                                                    <span className='lft_crt'>{4000 - input['rbiGuidelines'].length} Characters left</span>
                                                    <LinearProgress
                                                        variant="determinate"
                                                        value={input['rbiGuidelines'].length}
                                                    />
                                                </div> */}
                                    </label>

                                    <textarea className='form-control'
                                        {...register12('cmRsfbData', {
                                            maxLength: {
                                                value: 4000,
                                                message: "The maximum length of the field is 4000"
                                            },
                                        })}
                                        autoComplete="off" maxLength="4000"
                                        onChange={(e) => { Pattern.sanitizeInput(e) }}
                                    />
                                    <span className='vldn'>{register12.cmRsfbData && register12.cmRsfbData.message}</span>
                                </div>
                                }

                                {mserScheme && <div className='form-group'>
                                    <label className='prog_lbl'>
                                        <strong>MSERS: </strong>
                                        {/* <div className='prgs'>
                                                    <span className='lft_crt'>{4000 - input['rbiGuidelines'].length} Characters left</span>
                                                    <LinearProgress
                                                        variant="determinate"
                                                        value={input['rbiGuidelines'].length}
                                                    />
                                                </div> */}
                                    </label>

                                    <textarea className='form-control'
                                        {...register12('cmMsersData', {
                                            maxLength: {
                                                value: 4000,
                                                message: "The maximum length of the field is 4000"
                                            },
                                        })}
                                        autoComplete="off" maxLength="4000"
                                        onChange={(e) => { Pattern.sanitizeInput(e) }}
                                    />
                                    <span className='vldn'>{register12.cmMsersData && register12.cmMsersData.message}</span>
                                </div>
                                }

                                {rmseScheme && <div className='form-group'>
                                    <label className='prog_lbl'>
                                        <strong>RMSE: </strong>
                                        {/* <div className='prgs'>
                                                    <span className='lft_crt'>{4000 - input['rbiGuidelines'].length} Characters left</span>
                                                    <LinearProgress
                                                        variant="determinate"
                                                        value={input['rbiGuidelines'].length}
                                                    />
                                                </div> */}
                                    </label>

                                    <textarea className='form-control'
                                        {...register12('cmRmseData', {
                                            maxLength: {
                                                value: 4000,
                                                message: "The maximum length of the field is 4000"
                                            },
                                        })}
                                        autoComplete="off" maxLength="4000"
                                        onChange={(e) => { Pattern.sanitizeInput(e) }}
                                    />
                                    <span className='vldn'>{register12.cmRmseData && register12.cmRmseData.message}</span>
                                </div>
                                }

                                {fabia && <div className='form-group'>
                                    <label className='prog_lbl'>
                                        <strong>FABIA-MSME: </strong>
                                        {/* <div className='prgs'>
                                                    <span className='lft_crt'>{4000 - input['rbiGuidelines'].length} Characters left</span>
                                                    <LinearProgress
                                                        variant="determinate"
                                                        value={input['rbiGuidelines'].length}
                                                    />
                                                </div> */}
                                    </label>

                                    <textarea className='form-control'
                                        {...register12('cmFabiaData', {
                                            maxLength: {
                                                value: 4000,
                                                message: "The maximum length of the field is 4000"
                                            },
                                        })}
                                        autoComplete="off" maxLength="4000"
                                        onChange={(e) => { Pattern.sanitizeInput(e) }}
                                    />
                                    <span className='vldn'>{register12.cmFabiaData && register12.cmFabiaData.message}</span>
                                </div>
                                }

                                {rampe && <div className='form-group'>
                                    <label className='prog_lbl'>
                                        <strong>RAMPE: </strong>
                                        {/* <div className='prgs'>
                                                    <span className='lft_crt'>{4000 - input['rbiGuidelines'].length} Characters left</span>
                                                    <LinearProgress
                                                        variant="determinate"
                                                        value={input['rbiGuidelines'].length}
                                                    />
                                                </div> */}
                                    </label>

                                    <textarea className='form-control'
                                        {...register12('cmRampeData', {
                                            maxLength: {
                                                value: 4000,
                                                message: "The maximum length of the field is 4000"
                                            },
                                        })}
                                        autoComplete="off" maxLength="4000"
                                        onChange={(e) => { Pattern.sanitizeInput(e) }}
                                    />
                                    <span className='vldn'>{register12.cmRampeData && register12.cmRampeData.message}</span>
                                </div>
                                }

                                <div className='form-group'>
                                    <label className='prog_lbl'>
                                        <strong>Interest Reset: </strong>
                                    </label>

                                    <textarea className='form-control'
                                        {...register12('interestReset', {
                                            maxLength: {
                                                value: 4000,
                                                message: "The maximum length of the field is 4000"
                                            },
                                        })}
                                        autoComplete="off" maxLength="4000"
                                        onChange={(e) => { Pattern.sanitizeInput(e) }}
                                    />
                                    <span className='vldn'>{register12.interestReset && register12.interestReset.message}</span>
                                </div>

                                <div className="button-container-center">

                                    {(editable || (!isMaker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                                </div>
                            </form>
                        </Accordion.Body>
                    </Accordion.Item>

                </Accordion>
                <div className="button-container-center">
                    {appId > 0 && <button type='button' className='btn btnPrev' onClick={() => navigate(-1)}><i className="fa fa-arrow-left"></i> Prev</button>}
                    {appId > 0 && <button type='button' className='btn btnNext' onClick={goToNext}>Next <i className="fa fa-arrow-right"></i></button>}
                </div>
            </div>
            {loading && <Loading />}
            <MessageModal
                open={isOpen}
                onClose={hideMessage}
                message={messageConfig.message}
                type={messageConfig.type}
                totalMessages={totalMessages}
                currentIndex={currentIndex}
                onNext={nextMessage}
                onPrev={prevMessage}
                hasNext={hasNext}
                hasPrev={hasPrev}
            />
        </Fragment >
    )
}
export default SectionThree;