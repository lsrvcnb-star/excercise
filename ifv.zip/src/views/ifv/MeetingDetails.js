import { AccessTime } from "@mui/icons-material";
import AddIcon from "@mui/icons-material/Add";
import ArticleIcon from "@mui/icons-material/Article";
import CancelIcon from "@mui/icons-material/Cancel";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import DeleteIcon from "@mui/icons-material/Delete";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ForwardIcon from "@mui/icons-material/Forward";
import ReplyIcon from "@mui/icons-material/Reply";
import SendIcon from "@mui/icons-material/Send";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
import {
  Alert,
  Box,
  Button,
  Collapse,
  Divider,
  FormControl,
  IconButton,
  InputLabel,
  MenuItem,
  Paper,
  Stack,
  styled,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from "@mui/material";
import SelectMUI from "@mui/material/Select";
import ForwardRejectionSummary from "components/ForwardRejectionSummary";
import Loading from "components/Loading";
import MessageModal from "components/MessageModal";
import FileUploadModal from "components/util/FileUploadModal";
import { useErrorHandler } from "hooks/useErrorHandler";
import useMessageModal from "hooks/useMessageModal";
import React, { Fragment, useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import ReactDatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Controller, useFieldArray, useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
import Select from "react-select";
import IfvAppraisalService from "services/IfvAppraisalService";
import MinutesService from "services/MinutesService";
import UserService from "services/UserService";
import Committee from "services/constants/Committee";
import { Decision } from "services/constants/Decision";
import { Purpose } from "services/constants/Purpose";
import CommonUtil from "services/utils/CommonUtil";
import FileUtil from "services/utils/FileUtil";
import Pattern from "services/validators/Pattern";
import ColendingLimitSection from "./ColendingLimitSection";
import GenerateReportModal from "./GenerateReportModal";
import InterestRateResetSection from "./InterestRateResetSection";
import MinutesModal from "./MinutesModal";
import OtherItemsSection from "./OtherItemsSection";

const StyledTableContainer = styled(TableContainer)(({ theme }) => ({
  marginBottom: theme.spacing(3),
  "& .select-container": {
    position: "relative",
    zIndex: 2,
  },
}));
const StyledTableCell = styled(TableCell)(({ theme }) => ({
  "&.MuiTableCell-head": {
    backgroundColor: "#6082B6",
    color: theme.palette.common.white,
    fontWeight: "bold",
    padding: "8px 16px",
    textTransform: "capitalize",
    fontSize: "0.82rem",
    whiteSpace: "nowrap",
    "&:first-of-type": {
      borderTopLeftRadius: 4,
    },
    "&:last-type-of": {
      borderTopRightRadius: 4,
    },
  },
}));
const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  "&:hover": {
    backgroundColor: theme.palette.action.selected,
  },
  // Ensure cells have consistent padding
  "& .MuiTableCell-body": {
    padding: "8px 16px",
  },
}));
// Custom styles for react-select
const selectStyles = {
  control: (base) => ({
    ...base,
    minHeight: "36px",
    borderColor: "#ddd",
    boxShadow: "none",
    "&:hover": {
      borderColor: "#90caf9",
    },
  }),
  menu: (base) => ({
    ...base,
    zIndex: 9999,
    boxShadow: "0 4px 6px rgba(0,0,0,0.1)",
    border: "1px solid #ddd",
  }),
  menuPortal: (base) => ({
    ...base,
    zIndex: 9999,
    minWidth: "150px",
  }),
  option: (base, state) => ({
    ...base,
    backgroundColor: state.isFocused ? "#e3f2fd" : "white",
    color: "#000",
    "&:hover": {
      backgroundColor: "#bbdefb",
    },
  }),
  container: (base) => ({
    ...base,
    width: "100%",
    minWidth: "130px",
  }),
};

const MeetingDetails = () => {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const [mtCode, setMtCode] = useState(
    location.state ? location.state.mtCode : 0
  );
  const [openColending, setOpenColending] = useState(false);
  const [openInterest, setOpenInterest] = useState(false);
  const [openOtherItems, setOpenOtherItems] = useState(false);

  const {
    control,
    register: register1,
    handleSubmit: handleSubmitMeetingDetails,
    setValue: setValue1,
    getValues: getValues1,
    watch,
    formState: { errors: errors1 },
  } = useForm({
    mode: "onBlur",
  });

  const {
    register: register3,
    handleSubmit: handleSubmitOfAlcoMinutes,
    setValue: setValue3,
    getValues: getValues3,
    formState: { errors: errors3 },
  } = useForm({
    mode: "onBlur",
  });

  const {
    fields: fields1,
    append: append1,
    remove: remove1,
  } = useFieldArray({
    control,
    name: "meetingData",
  });

  const { fields: fields3 } = useFieldArray({
    control,
    name: "alcoData",
  });

  const {
    showMessage,
    hideMessage,
    isOpen,
    messageConfig,
    totalMessages,
    currentIndex,
    nextMessage,
    prevMessage,
    hasNext,
    hasPrev,
  } = useMessageModal();
  const { handleApiError } = useErrorHandler(showMessage);
  const [filteredBankOptions, setFilteredBankOptions] = useState([]);
  const [selectedBankOption, setSelectedBankOption] = useState([]);
  const [loading, setLoading] = useState(false);
  const [members, setMembers] = useState([]);
  const [chairManList, setChairManList] = useState([]);
  const [defaultChairManList, setDefaultChairManList] = useState([]);
  const [convenor, setConvenor] = useState([]);
  const [altConvenor, setAltConvenor] = useState([]);
  const [chairman, setChairman] = useState([]);
  const [isMaker, setMaker] = useState(false);
  const [isChecker, setChecker] = useState(false);
  const [isAdminChecker, setAdminChecker] = useState(false);
  const [isMakerConvenor, setMakerConvenor] = useState(false);
  const [hasFile, setHasFile] = useState(false);
  const [approver, setApprover] = useState(false);
  const [authorizeToFwdRejApprove, setAuthorizeToFwdRejApprove] =
    useState(false);
  const [isHigherAuthority, setHigherAuthority] = useState(false);

  useEffect(() => {
    const user = IfvAppraisalService.getCurrentUser();
    setMaker(UserService.isMaker(user));
    setChecker(UserService.isChecker(user));
    setAdminChecker(UserService.isAdminChecker(user));
    setMakerConvenor(UserService.isMakerConvenor(user));
    setHigherAuthority(UserService.isHigherAuthority(user));
    if (mtCode > 0) {
      getSanctionMinutesById(mtCode);
      getMinutesFwdRejDetails(mtCode);
    } else {
      setValue1(
        "note1",
        "The Committee deliberated on IFV proposal for sanction of financial assistance to the following bank on the terms indicated:"
      );
      setValue1(
        "note2",
        "The Committee, after deliberations, sanctioned the proposals and passed the following resolution:\n“RESOLVED THAT the proposal of financial assistance of Rs. crore to the above bank be and are hereby sanctioned.”"
      );
      setValue1(
        "flashNote",
        "The proposal is approved on the terms indicated. Detailed Minutes follows. "
      );
    }
  }, []);

  const getMemberDetails = (cmtCode) => {
    setLoading(true);
    let formattedOptions = [];
    return MinutesService.getMemberDetails(cmtCode).then(
      (response) => {
        var appData = response.data.filter((item) => item.enableFlag === "Y");

        let memberList = [];
        let chairmanObj = {};

        appData.map((item, index) => {
          if (item.cmtType === "CM") {
            chairmanObj = {
              id: item.memberCode,
              name: item.memberName,
            };
          }
          if (item.cmtType === "CV") {
            const convenorObj = {
              id: item.memberCode,
              name: item.memberName,
            };
            setConvenor(convenorObj);
            setValue1("convenorCode", item.memberCode);
          }
          if (item.cmtType === "AC") {
            const altConvenorObj = {
              id: item.memberCode,
              name: item.memberName,
            };
            setAltConvenor(altConvenorObj);
            setValue1("alConvenorCode", item.memberCode);
          }
          if (item.cmtType === "MB") {
            const member = {
              id: item.memberCode,
              name: item.memberName,
            };
            memberList.push(member);
          }
        });
        memberList.push(chairmanObj);
        setMembers(memberList);
        setDefaultMembers(memberList);

        formattedOptions = memberList.map((item) => ({
          value: item.id,
          label: item.name,
        }));

        setDefaultChairManList(memberList);
        setChairManList(memberList);
        setLoading(false);
        return formattedOptions;
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading Members");
        throw new Error("Error occured while loading Members");
      }
    );
  };

  const getCommitteeMembers = (cmtCode) => {
    setLoading(true);
    let formattedOptions = [];
    MinutesService.getMemberDetails(cmtCode).then(
      (response) => {
        var appData = response.data.filter((item) => item.enableFlag === "Y");

        let memberList = [];
        let chairmanObj = {};

        appData.map((item, index) => {
          if (item.cmtType === "CM") {
            chairmanObj = {
              id: item.memberCode,
              name: item.memberName,
            };
          }
          if (item.cmtType === "CV") {
            const convenorObj = {
              id: item.memberCode,
              name: item.memberName,
            };
            setConvenor(convenorObj);
            setValue1("convenorCode", item.memberCode);
          }
          if (item.cmtType === "AC") {
            const altConvenorObj = {
              id: item.memberCode,
              name: item.memberName,
            };
            setAltConvenor(altConvenorObj);
            setValue1("alConvenorCode", item.memberCode);
          }
          if (item.cmtType === "MB") {
            const member = {
              id: item.memberCode,
              name: item.memberName,
            };
            memberList.push(member);
          }
        });
        memberList.push(chairmanObj);
        setMembers(memberList);
        setDefaultMembers(memberList);

        formattedOptions = memberList.map((item) => ({
          value: item.id,
          label: item.name,
        }));

        setOptions(formattedOptions);
        setDefaultOptions(formattedOptions);
        setDefaultChairManList(memberList);
        setChairManList(memberList);
        setLoading(false);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading Members");
        throw new Error("Error occured while loading Members");
      }
    );
  };

  const [sanctionMinutesDtlData, setSanctionMinutesDtlData] = useState([]);
  const [meetingStatus, setMeetingStatus] = useState("");
  const [isAnyOneAgendaCirculated, setIsAnyOneAgendaCirculated] =
    useState(false);
  const [isAnyOneAgendaCreated, setIsAnyOneAgendaCreated] = useState(false);
  const [sanctionDtlStatus, setSanctionDtlStatus] = useState([]);
  const [selectedAppList, setSelectedAppList] = useState([]);
  const [enableLock, setEnableLock] = useState(false);

  const [chairmanChecked, setChairmanChecked] = useState(true);
  const [convenorChecked, setConvenorChecked] = useState(false);
  const [alConvenorChecked, setAlConvenorChecked] = useState(false);

  const [isConvAltConvForwardReject, setConvAltConvForwardReject] =
    useState(false);
  const [isMemberForwardReject, setMemberForwardReject] = useState(false);
  const [isStage2, setStage2] = useState(false);

  const getSanctionMinutesById = (mtCode) => {
    setLoading(true);
    MinutesService.getSanctionMinutesById(mtCode).then(
      (response) => {
        const sanctionMinutesDTO = response.data.sanctionMinutesDTO;
        const sanctionMinutesDtlDTOs = response.data.sanctionMinutesDtlDTOs;
        const fileRepositoryDTOs = response.data.fileRepositoryDTOs;

        const user = IfvAppraisalService.getCurrentUser();

        setAuthorizeToFwdRejApprove(
          sanctionMinutesDTO.currentCheckerId == user.ofrCode
        );

        if (!CommonUtil.isEmpty(sanctionMinutesDTO.forwardedStage2User)) {
          setApprover(
            parseInt(user.ofrEmpId) ===
              parseInt(sanctionMinutesDTO.forwardedStage2User)
          );
        }

        setConvAltConvForwardReject(
          user.ofrEmpId === sanctionMinutesDTO.forwardedStage1User
        );
        setMemberForwardReject(
          user.ofrEmpId === sanctionMinutesDTO.forwardedStage2User
        );
        setStage2(!CommonUtil.isEmpty(sanctionMinutesDTO.forwardedStage2User));

        const isConvenorChecked = CommonUtil.isEmpty(
          sanctionMinutesDTO.convenorCode
        )
          ? false
          : true;
        const isAltConvenorChecked = CommonUtil.isEmpty(
          sanctionMinutesDTO.alConvenorCode
        )
          ? false
          : true;

        setChairmanChecked(
          CommonUtil.isEmpty(sanctionMinutesDTO.chairmanCode) ? false : true
        );

        setConvenorChecked(isConvenorChecked);
        setValue1("convenorCodeSelected", isConvenorChecked);
        setAlConvenorChecked(isAltConvenorChecked);
        setValue1("alConvenorCodeSelected", isAltConvenorChecked);

        let enable = true;

        if (
          sanctionMinutesDtlDTOs != null &&
          sanctionMinutesDtlDTOs.length > 0
        ) {
          sanctionMinutesDtlDTOs.forEach((item, i) => {
            if (
              CommonUtil.isEmpty(item.sancStatus) ||
              item.sancStatus !== "MINCREATED" ||
              CommonUtil.isEmpty(item.sanctDscnStatus)
            ) {
              enable = false;
            }
          });
        } else {
          enable = false;
        }

        setEnableLock(enable);

        if (fileRepositoryDTOs != null) {
          fileRepositoryDTOs.forEach((item, i) => {
            setValue1(
              `fileName[${item.sancMinDetailId}].fileName`,
              item.fileName
            );
            setFileName((prevState) => ({
              ...prevState,
              [item.sancMinDetailId]: item.fileName,
            }));
          });
        }

        setMtCode(mtCode);
        setSanctionMinutesDtlData(sanctionMinutesDtlDTOs);
        setMeetingStatus(sanctionMinutesDTO.sanctStage);
        const commiteeCode = sanctionMinutesDTO.commiteeCode;

        if (commiteeCode === 101) {
          getAllIfvAppsByStatus();
          setIfcc(true);
          setAlco(false);
        }

        if (commiteeCode === 102) {
          getAllAlcoAppsByStatus();
          setIfcc(false);
          setAlco(true);
        }

        setValue1("sanctDetailCode", sanctionMinutesDTO.sanctDetailCode);
        setValue1("agendaId", sanctionMinutesDTO.agendaId);
        setValue1("commiteeCode", sanctionMinutesDTO.commiteeCode);
        if (!CommonUtil.isEmpty(sanctionMinutesDTO.meetingDate)) {
          setValue1("meetingDate", new Date(sanctionMinutesDTO.meetingDate));
        }

        setValue1("meetingPlace", sanctionMinutesDTO.meetingPlace);
        setValue1("meetingNo", sanctionMinutesDTO.meetingNo);
        setValue1("convenorCode", sanctionMinutesDTO.convenorCode);
        setValue1("alConvenorCode", sanctionMinutesDTO.alConvenorCode);
        setValue1("chairmanCode", sanctionMinutesDTO.chairmanCode);
        setValue1("note1", sanctionMinutesDTO.note1);
        setValue1("note2", sanctionMinutesDTO.note2);
        setValue1("flashNote", sanctionMinutesDTO.flashNote);
        setValue1("benchmarkNote", sanctionMinutesDTO.benchmarkNote);
        setCheckedFields({});
        const chairmanC = sanctionMinutesDTO.chairmanCode;
        setValue1("chairmanCode", chairmanC);
        // Fetch member details and proceed with dependent logic
        getMemberDetails(commiteeCode)
          .then((formattedOptions) => {
            setDefaultOptions(formattedOptions);

            const chairmanObj = formattedOptions.find(
              (item) => item["value"] == chairmanC
            );
            const chairman = {
              id: chairmanObj["value"],
              name: chairmanObj["label"],
            };
            setChairman(chairman);

            formattedOptions = formattedOptions.filter(
              (obj) => obj["value"] != chairmanC
            );

            setOptions(formattedOptions);

            // Set selected members
            if (!CommonUtil.isEmpty(sanctionMinutesDTO.memberCode)) {
              const memberArray = sanctionMinutesDTO.memberCode.split(",");
              const selectedMembers = memberArray
                .map((item) =>
                  formattedOptions.find((obj) => obj["value"] === item)
                )
                .filter((item) => !CommonUtil.isEmpty(item));
              setSelectedOption(selectedMembers);
            }
            // Set members on leave
            if (!CommonUtil.isEmpty(sanctionMinutesDTO.grantLeaves)) {
              const leaveArray = sanctionMinutesDTO.grantLeaves.split(",");
              const membersOnLeave = leaveArray
                .map((item) =>
                  formattedOptions.find((obj) => obj["value"] === item)
                )
                .filter((item) => !CommonUtil.isEmpty(item));
              setSelectedMemOption(membersOnLeave);
            }
            setLoading(false);
          })
          .catch((error) => {
            setLoading(false);
            handleApiError(error, "loading Members");
          });

        setIsAnyOneAgendaCirculated(false);
        setIsAnyOneAgendaCreated(false);

        sanctionMinutesDtlDTOs.forEach((item, index) => {
          remove1(index);
          append1({});
          if (commiteeCode === 101) {
            setValue1(`meetingData[${index}].unitName`, item.unitName);
            setValue1(`meetingData[${index}].schemeName`, item.schemeName);
            setValue1(`meetingData[${index}].loanAmount`, item.loanAmount);
          }
          setValue1(`meetingData[${index}].sancDtlCode`, item.sancDtlCode);
          setValue1(
            `meetingData[${index}].sanctStatusCode`,
            item.sanctStatusCode
          );
          setValue1(`meetingData[${index}].agendaId`, item.agendaId);
          setValue1(`meetingData[${index}].agendaNo`, item.agendaNo);
          setValue1(`meetingData[${index}].appid`, item.appid);
          setSelectedBankOption((prevState) => ({
            ...prevState,
            [index]: item.appid,
          }));
          setSelectedAppList((prevState) => ({
            ...prevState,
            [index]: item.appid,
          }));

          setValue1(
            `meetingData[${index}].sanctPurposeStatus`,
            item.sanctPurposeStatus
          );
          setValue1(
            `meetingData[${index}].sanctDscnStatus`,
            item.sanctDscnStatus
          );
          setValue1(`meetingData[${index}].sancStatus`, item.sancStatus);
          setValue1(`meetingData[${index}].remarks`, item.remarks);

          setSanctionDtlStatus((prevState) => ({
            ...prevState,
            [index]: item.sancStatus,
          }));
          if (item.sancStatus === "CIRCULATED") {
            setIsAnyOneAgendaCirculated(true);
          }

          if (item.sancStatus === "CREATED") {
            setIsAnyOneAgendaCreated(true);
          }
        });
        setLoading(false);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading Minutes");
      }
    );
  };

  const onSubmitOfMettingDetails = (data, e) => {
    setLoading(true);

    if (CommonUtil.isEmpty(data.chairmanCode)) {
      showMessage("Chairman cannot be empty", "warning");
      setLoading(false);
      return;
    }

    if (!data.convenorCodeSelected) {
      data.convenorCode = "";
    }

    if (!data.alConvenorCodeSelected) {
      data.alConvenorCode = "";
    }

    delete data.convenorCodeSelected;
    delete data.alConvenorCodeSelected;

    const meetingData = data["meetingData"];
    let isSave = true;
    meetingData.forEach((item, index) => {
      item.agendaNo = ++index;
      if (CommonUtil.isEmpty(item.unitName)) {
        showMessage(
          "Please select application at Agenda No : " + item.agendaNo,
          "warning"
        );
        isSave = false;
      }
    });
    if (isSave === false) {
      setLoading(false);
      return;
    }

    delete data.meetingData;
    delete data.memberData;
    delete data.fileName;
    const user = IfvAppraisalService.getCurrentUser();

    let userName = user.ofrShortName;
    if (CommonUtil.isEmpty(userName)) {
      userName = user.ofrName;
    }

    data.createdBy = userName;
    let mstCodes = "";
    if (selectedOption.length > 0) {
      selectedOption.map((item, index) => {
        mstCodes = mstCodes.concat(item["value"] + ",");
      });
    }
    let grantLeaves = "";
    if (selectedMemOption.length > 0) {
      selectedMemOption.map((item, index) => {
        grantLeaves = grantLeaves.concat(item["value"] + ",");
      });
    }

    if (CommonUtil.isEmpty(mstCodes)) {
      showMessage("Any one member is required!", "warning");
      setLoading(false);
      return;
    }

    data.memberCode = mstCodes;
    data.grantLeaves = grantLeaves;

    let finalData = {
      sanctionMinutesDTO: data,
      sanctionMinutesDtlDTOs: meetingData,
    };

    MinutesService.onSubmitOfMettingDetails(finalData).then(
      (response) => {
        showMessage("Meeting Details have been successfully saved!", "success");
        getSanctionMinutesById(response.data);
        setLoading(false);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "saving Meeting Details");
      }
    );
  };

  const [isAlco, setAlco] = useState(false);
  const [isIfcc, setIfcc] = useState(false);

  const setMeetingDetails = (val) => {
    setIfvAppList([]);
    setIfvApps([]);
    setFilteredBankOptions([]);

    if (mtCode <= 0) {
      fields1.map((field, index) => {
        setValue1(`meetingData[${index}]`, undefined);
        remove1(index);
      });
    }

    setValue1("meetingNo", "");
    setValue1("meetingPlace", "");
    setValue1("agendaId", "");
  };

  const generateAgendaId = (committee, meetingNo) => {
    setValue1("meetingNo", meetingNo);
    setValue1("meetingPlace", "Mumbai");

    const committeeName = Committee[committee];

    let agendaId = "AG" + committeeName + String(meetingNo).padStart(5, "0");
    setValue1("agendaId", agendaId);

    if (fields1.length <= 0) {
      append1({});
    }

    if (committee === "101") {
      setIfcc(true);
      setAlco(false);
      getAllIfvAppsByStatus();
      getCommitteeMembers(committee);
    }

    if (committee === "102") {
      setAlco(true);
      setIfcc(false);
      getAllAlcoAppsByStatus();
      getCommitteeMembers(committee);
    }
  };

  const [ifvApps, setIfvApps] = useState([]);
  const [ifvAppList, setIfvAppList] = useState([]);

  const getAllIfvAppsByStatus = () => {
    setLoading(true);
    IfvAppraisalService.getAllIfvAppsOnStatus("AP").then(
      (response) => {
        const formattedOptions = response.data.map((item) => ({
          value: item.ifvId,
          label: item.appNumber,
        }));
        setIfvApps(response.data);
        setIfvAppList(formattedOptions);
        setFilteredBankOptions(formattedOptions);
        setLoading(false);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "IFV applications");
      }
    );
  };

  const getAllAlcoAppsByStatus = () => {
    setLoading(true);
    MinutesService.getAllAlcoAppsByStatus("AP").then(
      (response) => {
        const formattedOptions = response.data.map((item) => ({
          value: item.alCode,
          label: item.alAppNumber,
        }));
        setIfvApps(response.data);
        setIfvAppList(formattedOptions);
        setFilteredBankOptions(formattedOptions);
        setLoading(false);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "Alco applications");
      }
    );
  };

  const handleAppChange = (selected, index) => {
    setSelectedBankOption((prevState) => ({
      ...prevState,
      [index]: selected.label,
    }));
    setValue1(`meetingData[${index}].appid`, selected.label);

    const committeeCode = getValues1("commiteeCode");
    let ifvApp = {};
    if (parseInt(committeeCode) === 101) {
      ifvApp = ifvApps.find((item) => item.ifvId === selected.value);
      setValue1(`meetingData[${index}].unitName`, ifvApp.ifvName);
      setValue1(`meetingData[${index}].schemeName`, ifvApp.ifvSchemeName);
      setValue1(`meetingData[${index}].loanAmount`, ifvApp.ifvAmount);
    }
    if (parseInt(committeeCode) === 102) {
      //  ifvApp = ifvApps.find(item => item.alCode === selected.value)
      //  setValue1(`meetingData[${index}].dateOfAction`, CommonUtil.formatDate(ifvApp.dateOfAction))
    }
  };

  const handleBankSearch = (inputValue) => {
    if (inputValue === "") {
      setFilteredBankOptions(ifvAppList);
      return;
    }
    const filteredOptions = ifvAppList.filter((option) =>
      option.label.toLowerCase().includes(inputValue.toLowerCase())
    );
    setFilteredBankOptions(filteredOptions);
  };

  const [checkedFields, setCheckedFields] = useState({});

  const deleteMeetingDetails = (index) => {
    setLoading(true);
    const id = getValues1(`meetingData[${index}].sancDtlCode`);
    if (CommonUtil.isValidNumber(id)) {
      MinutesService.deleteMeetingDetails(id).then(
        (response) => {
          setLoading(false);
          navigate(location.pathname, {
            replace: true,
            state: { mtCode: mtCode },
          });
          window.location.reload();
        },
        (error) => {
          setLoading(false);
          handleApiError(error, "deleting Meeting details");
        }
      );
    } else {
      setLoading(false);
      delete selectedBankOption[index];
      remove1(index);
    }
  };

  const [fileName, setFileName] = useState([]);

  const handleFileUpload = (e, id) => {
    try {
      setLoading(true);
      const file = e.target.files[0];
      if (!file) {
        setLoading(false);
        showMessage("Please select a file to upload", "warning");
        return;
      }
      const fileName = file.name;
      const fileExtension = fileName.split(".").pop().toLowerCase();
      const fileSize = file.size / (1024 * 1024);
      if (fileExtension !== "pdf") {
        setLoading(false);
        showMessage("Only PDF files are allowed", "warning");
        e.target.value = "";
        return;
      }
      if (fileSize > 12) {
        setLoading(false);
        showMessage(
          `File size (${fileSize.toFixed(2)}MB) exceeds the limit of 12MB`,
          "warning"
        );
        e.target.value = "";
        return;
      }
      const formData = new FormData();
      formData.append("fileData", file);
      formData.append("sancMinDetailId", id);
      MinutesService.uploadAgendaFile(formData)
        .then((response) => {
          if (!response || !response.data) {
            throw new Error("Invalid response from server");
          }
          const { sancMinDetailId: fileId, fileName: fileNameIns } =
            response.data;
          if (fileId && fileNameIns) {
            setFileName((prevState) => ({
              ...prevState,
              [fileId]: fileNameIns,
            }));
            setReUpload((prevState) => ({ ...prevState, [fileId]: "false" }));
            setValue1(`fileName[${fileId}].fileName`, fileNameIns);
            showMessage("File uploaded successfully!", "success");
          } else {
            throw new Error("Invalid response data");
          }
        })
        .catch((error) => {
          handleApiError(error, "uploading file");
        })
        .finally(() => {
          setLoading(false);
        });
    } catch (error) {
      setLoading(false);
      showMessage(
        "An unexpected error occurred while uploading the file",
        "error"
      );
      console.error("File upload error:", error);
      e.target.value = "";
    }
  };

  const [reUpload, setReUpload] = useState([]);
  const setReUploadFlag = (code) => {
    setReUpload((prevState) => ({ ...prevState, [code]: "true" }));
  };

  const deleteAgendaFile = (id) => {
    if (window.confirm("Are you sure you want to delete the document?")) {
      setLoading(true);
      MinutesService.deleteAgendaFile(id).then(
        (response) => {
          delete fileName[id];
          delete reUpload[id];

          setValue1(`fileName[${id}].fileName`, "");
          setLoading(false);
          showMessage("File deleted successfully!", "success");
        },
        (error) => {
          setLoading(false);
          handleApiError(error, "deleting the file");
        }
      );
    }
  };

  const displayFileDetail = (id) => {
    setLoading(true);
    MinutesService.getFileDetails(id).then(
      (response) => {
        setLoading(false);
        if (response.data && response.data.fileDataBytea != null) {
          FileUtil.viewFile(
            response.data.fileDataBytea,
            response.data.fileName,
            response.data.fileContentType
          );
        } else {
          showMessage("Invalid file", "error");
        }
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading the file");
      }
    );
  };

  const circulateAgenda = (index) => {
    setLoading(true);
    const id = getValues1(`meetingData[${index}].sancDtlCode`);
    MinutesService.circulateAgenda(id).then(
      (response) => {
        setLoading(false);
        getSanctionMinutesById(mtCode);
        showMessage("Agenda circulated successfully!", "success");
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "ciculating the Agenda");
      }
    );
  };

  const [showMinutesModal, setShowMinutesModal] = useState(false);
  const [showAlcoMinutesModal, setAlcoShowMinutesModal] = useState(false);
  const handleAlcoMinutesModalClose = () => setAlcoShowMinutesModal(false);
  const [selectedData, setSelectedData] = useState(null);

  const createMinutes = (index) => {
    const appId = getValues1(`meetingData[${index}].appid`);
    const agendaNo = getValues1(`meetingData[${index}].agendaNo`);
    const agendaId = getValues1("agendaId");
    const sancDtlCode = getValues1(`meetingData[${index}].sancDtlCode`);
    const unitName = getValues1(`meetingData[${index}].unitName`);
    setSelectedData({
      appId,
      agendaNo,
      agendaId,
      sancDtlCode,
      unitName,
    });
    setShowMinutesModal(true);
  };

  const onSubmitOfAlcoMinutes = (data, e) => {
    setLoading(true);
    if (CommonUtil.isEmpty(data["alcoData"])) {
      setLoading(false);
      return;
    }
    let finalData = data["alcoData"].filter(
      (item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.bankName)
    );
    if (CommonUtil.isEmpty(finalData)) {
      setLoading(false);
      return;
    }

    finalData.forEach((item, i) => {
      delete item.schemeAmount;
    });

    MinutesService.saveAllAlcoMinutesData(finalData).then(
      (response) => {
        setLoading(false);
        showMessage("Alco Minutes has been successfully saved!", "success");
        getSanctionMinutesById(mtCode);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "saving alco Minutes Details");
      }
    );
  };

  const calculateSpreadMargin = (field, val, index) => {
    setValue3(field, val);

    let e = getValues3(`alcoData[${index}].interestRate`);
    let f = getValues3(`alcoData[${index}].costOfFunds`);
    let g = parseFloat(e) - parseFloat(f);

    setValue3(`alcoData[${index}].spreadMargin`, g);
  };

  const [showHideProceed, setShowHideProceed] = useState(false);
  const hideProceed = () => setShowHideProceed(false);
  const [showHideForward, setShowHideForward] = useState(false);
  const hideForward = () => setShowHideForward(false);
  const [showHideConvForward, setShowHideConvForward] = useState(false);
  const hideConvForward = () => setShowHideConvForward(false);
  const [showRejectMinutes, setShowRejectMinutes] = useState(false);
  const hideRejectMinutes = () => setShowRejectMinutes(false);

  const updateMinutes = (status) => {
    let data = {
      sanctDetailCode: mtCode,
      sanctStage: status,
    };
    setLoading(true);
    MinutesService.updateSanctionMinutes(data).then(
      (response) => {
        setLoading(false);
        setShowHideProceed(false);
        showMessage("Minutes has been successfully " + status, "success");
        getSanctionMinutesById(mtCode);
      },
      (error) => {
        setLoading(false);
        setShowHideProceed(false);
        handleApiError(error, "updating Minutes Details");
      }
    );
  };

  const approveMinutes = () => {
    if (!hasFile && (isMaker || isChecker || isAdminChecker)) {
      showMessage("Please upload flash minutes document", "warning");
      return;
    }
    if (window.confirm("Are you sure you want to approve the minutes?")) {
      setLoading(true);
      const user = IfvAppraisalService.getCurrentUser();

      MinutesService.approveSanction(mtCode, user.ofrCode).then(
        (response) => {
          setShowHideProceed(false);
          if (response.data === true) {
            showMessage("Minutes has been successfully approved!", "success");
          } else {
            showMessage(
              "Minutes has been successfully approved!, but failed to send data to DFS!",
              "error"
            );
          }
          getSanctionMinutesById(mtCode);
          setLoading(false);
        },
        (error) => {
          setLoading(false);
          setShowHideProceed(false);
          handleApiError(error, "approving the minutes");
        }
      );
    }
  };

  const [meetingNoExists, setMeetingNoExists] = useState(false);

  const checkMeetingNoExistence = (meetingNo) => {
    let committee = getValues1("commiteeCode");
    if (CommonUtil.isEmpty(committee)) {
      setValue1("meetingNo", "");
      showMessage("Please select committee name", "warning");
      return;
    }
    if (CommonUtil.isEmpty(meetingNo)) {
      return;
    }
    if (!/^\d+$/.test(meetingNo)) {
      showMessage("Meeting number must contain only digits", "warning");
      return;
    }

    if (meetingNo.length >= 10) {
      showMessage("Meeting number must be less than 10 digits", "warning");
      return;
    }
    setLoading(true);
    MinutesService.checkMeetingNoExistence(meetingNo, committee).then(
      (response) => {
        setLoading(false);
        if (response.data > 0) {
          setMeetingNoExists(true);
        } else {
          setMeetingNoExists(false);
          generateAgendaId(committee.toString(), meetingNo);
        }
      },
      (error) => {
        setLoading(false);
        setShowHideProceed(false);
        handleApiError(error, "loading meeting no");
      }
    );
  };

  const handleConvenorCheckboxChange = (e) => {
    setConvenorChecked(e.target.checked);
    setValue1("convenorCodeSelected", e.target.checked);
  };

  const handleAlConvenorCheckboxChange = (e) => {
    setAlConvenorChecked(e.target.checked);
    setValue1("alConvenorCodeSelected", e.target.checked);
  };

  const [defaultMembers, setDefaultMembers] = useState([]);

  const setChairmanVal = (id) => {
    let isValid = true;

    if (selectedOption.length > 0) {
      selectedOption.map((item, index) => {
        if (item["value"].includes(id)) {
          showMessage(
            "The member has already been selected. Please remove the member from the member list and try again.",
            "warning"
          );
          isValid = false;
          return;
        }
      });
    }

    if (isValid) {
      setValue1("chairmanCode", id);
      const chairman = members.find((item) => item.id == id);
      const mem = defaultMembers.filter((item) => item.id != id);
      setMembers(mem);
      const defOp = defaultOptions.filter((item) => item["value"] != id);
      setOptions(defOp);
      setChairman(chairman);
      setChairManList(defaultChairManList);
    } else {
      const mem = defaultChairManList.filter((item) => item.id != id);
      setChairManList(mem);
    }
  };

  const [options, setOptions] = useState([]);
  const [defaultOptions, setDefaultOptions] = useState([]);
  const [selectedOption, setSelectedOption] = useState([]);
  const [selectedMemOption, setSelectedMemOption] = useState([]);
  const handleChange = (val) => {
    setSelectedOption(val);
  };
  const handleMemChange = (val) => {
    if (!val) {
      setSelectedMemOption([]);
      return;
    }
    if (val.length > (selectedMemOption?.length || 0)) {
      const newValue = val[val.length - 1].value;
      if (selectedOption && selectedOption.length > 0) {
        const isDuplicate = selectedOption.some(
          (item) => item.value === newValue
        );
        if (isDuplicate) {
          showMessage(
            "The member has already been selected in other sections.",
            "warning"
          );
          return;
        }
      }
    }
    setSelectedMemOption(val);
  };

  const [forwardStage1User, setForwardStage1User] = useState("");
  const [forwardStage2User, setForwardStage2User] = useState("");

  const forwardMinutes = () => {
    let stage;
    let forwardUser;
    if (isMaker || isChecker || isAdminChecker) {
      stage = 1;
      forwardUser = forwardStage1User;
    } else {
      stage = 2;
      forwardUser = forwardStage2User;
    }

    if (CommonUtil.isEmpty(forwardUser)) {
      showMessage("Please select user", "warning");
      return;
    }

    setLoading(true);
    MinutesService.forwardMinutes(mtCode, stage, forwardUser).then(
      (response) => {
        setLoading(false);
        setShowHideForward(false);
        setShowHideConvForward(false);
        showMessage("Minutes has been successfully forwarded", "success");
        getSanctionMinutesById(mtCode);
      },
      (error) => {
        setLoading(false);
        setShowHideProceed(false);
        handleApiError(error, "forwarding the minutes");
      }
    );
  };

  const rejectMinutes = () => {
    if (window.confirm("Are you sure you want to reject the minutes?")) {
      setLoading(true);
      MinutesService.rejectMinutes(mtCode).then(
        (response) => {
          setLoading(false);
          setShowHideForward(false);
          showMessage("Minutes has been rejected", "success");
          setTimeout(() => {
            navigate("/ifv/minutes");
          }, 2000);
        },
        (error) => {
          setLoading(false);
          setShowHideProceed(false);
          handleApiError(error, "rejecting the minutes");
        }
      );
    }
  };

  const [checkerList, setCheckerList] = useState([]);
  const [appChecker, setAppChecker] = useState("");
  const [checkerComment, setCheckerComment] = useState("");
  const [sendBack, setSendBack] = useState(false);

  const getCheckerListForForwarding = () => {
    const user = IfvAppraisalService.getCurrentUser();
    setSendBack(false);
    setLoading(true);
    IfvAppraisalService.getCheckerListForForwarding(0, user.ofrCode).then(
      (response) => {
        setLoading(false);
        setCheckerList(response.data);
        setShowHideForward(true);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading checker list");
      }
    );
  };

  const getUserListForRejectingMinutes = () => {
    setLoading(true);
    setSendBack(true);
    MinutesService.getUserListForRejectingMinutes(mtCode).then(
      (response) => {
        setLoading(false);
        setCheckerList(response.data);
        setShowHideForward(true);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading checker list");
      }
    );
  };

  const forwardMinutesToSelectedUser = (fwdRejFlag) => {
    if (CommonUtil.isEmpty(appChecker)) {
      showMessage("Please select checker to proceed further", "warning");
      return;
    }

    setLoading(true);
    const user = IfvAppraisalService.getCurrentUser();
    let userName = user.ofrShortName;
    if (CommonUtil.isEmpty(userName)) {
      userName = user.ofrName;
    }

    const data = {
      minuteId: mtCode,
      fwdRejFlag: fwdRejFlag,
      ofrCode: user.ofrCode,
      userName: userName,
      checkerId: parseInt(appChecker),
      comment: checkerComment,
    };

    MinutesService.fwdOrRejMinutes(data).then(
      (response) => {
        setLoading(false);
        setShowHideForward(false);
        showMessage(
          `Application has been ${sendBack ? "rejected" : "forwarded"}!`,
          "success"
        );
        getSanctionMinutesById(mtCode);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "sending the application");
      }
    );
  };

  const [fwdRejSummary, setFwdRejSummary] = useState([]);

  const getMinutesFwdRejDetails = (mtCode) => {
    MinutesService.getMinutesFwdRejDetails(mtCode).then(
      (response) => {
        setLoading(false);
        setFwdRejSummary(response.data);
      },
      (error) => {
        setLoading(false);
        handleApiError(error, "loading fwd details");
      }
    );
  };

  return (
    <Fragment>
      <div
        className={
          loading ? "col-md-12 mint blur-background" : "col-md-12 mint"
        }
      >
        <form
          key={1}
          onSubmit={handleSubmitMeetingDetails(onSubmitOfMettingDetails)}
        >
          <input
            type="hidden"
            {...register1("sanctDetailCode")}
            value={mtCode}
          />
          <>
            <div className="row mt-0">
              <div className="col-md-12 p-0">
                <div className="row no-prop alg_adst">
                  <div className="col-md-12">
                    <Box sx={{ display: "flex", justifyContent: "flex-end" }}>
                      {mtCode > 0 && (
                        <GenerateReportModal
                          mtCode={mtCode}
                          trigger={
                            <Button
                              variant="contained"
                              color="primary"
                              startIcon={<ArticleIcon />}
                              sx={{
                                textTransform: "none",
                                fontWeight: "medium",
                                boxShadow: 2,
                              }}
                            >
                              Report
                            </Button>
                          }
                        />
                      )}
                    </Box>
                  </div>
                  <div className="col-md-12 pb-1 pt-3">
                    <h5 className="HdngTitl mb-0">Meeting Details</h5>
                  </div>
                  <div className="col-md-6">
                    {mtCode > 0 && (
                      <h2 className="heading">
                        <strong>Status:</strong> {meetingStatus}
                      </h2>
                    )}
                  </div>
                  <div className="col-md-6">
                    {/* {mtCode > 0 && <h2 className="heading"><strong>Status:</strong> {meetingStatus}</h2>} */}
                  </div>
                  <div className="col pt-4">
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example1">
                        <strong className="mndt">
                          {" "}
                          Committee Name <span className="color-red"> *</span>
                        </strong>
                      </label>
                      {/* <input type="text" id="form3Example1" className="form-control" /> */}
                      <select
                        className="form-select"
                        {...register1("commiteeCode", {
                          onChange: (e) => setMeetingDetails(e.target.value),
                        })}
                        disabled={mtCode > 0}
                      >
                        <option value="">Select the committee</option>
                        {Object.entries(Committee).map(([key, value]) => (
                          <option value={key}>{value}</option>
                        ))}
                      </select>
                      <span className="vldn">
                        {errors1.commiteeCode && errors1.commiteeCode.message}
                      </span>
                    </div>
                  </div>
                  <div className="col pt-4">
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong className="mndt">
                          Meeting No <span className="color-red"> *</span>
                        </strong>
                      </label>
                      <input
                        type="number"
                        className="form-control"
                        max="9999999"
                        min="1"
                        onKeyDown={(e) => CommonUtil.handleNumericInput(e)}
                        {...register1("meetingNo", {
                          required: "Field is required",
                          onChange: (e) =>
                            checkMeetingNoExistence(e.target.value),
                        })}
                      />
                      <span className="vldn">
                        {errors1.meetingNo && errors1.meetingNo.message}
                      </span>
                      <span className="vldn">
                        {meetingNoExists ? "Meeting No already exists!" : ""}
                      </span>
                    </div>
                  </div>
                  <div className="col pt-4">
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong className="mndt">
                          Meeting Place <span className="color-red"> *</span>
                        </strong>
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        {...register1("meetingPlace", {
                          required: "Field is required",
                        })}
                        readOnly
                      />
                      <span className="vldn">
                        {errors1.meetingPlace && errors1.meetingPlace.message}
                      </span>
                    </div>
                  </div>
                  <div className="col pt-4">
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong className="mndt">
                          Meeting Date <span className="color-red"> *</span>
                        </strong>
                      </label>
                      <Controller
                        control={control}
                        name="meetingDate"
                        rules={{
                          required: {
                            value: true,
                            message: "Date is required",
                          },
                          validate: (value) => CommonUtil.validateDate(value),
                        }}
                        render={({
                          field: { onChange, onBlur, value, ref },
                        }) => (
                          <ReactDatePicker
                            className="form-control"
                            onChange={onChange}
                            onBlur={onBlur}
                            selected={value}
                            dateFormat="dd/MM/yyyy"
                            placeholderText="Select date"
                          />
                        )}
                        {...register1("meetingDate")}
                      />
                      <span className="vldn">
                        {errors1.meetingDate && errors1.meetingDate.message}
                      </span>
                    </div>
                  </div>
                  <div className="col pt-4">
                    <div data-mdb-input-init className="form-outline">
                      <label className="form-label" for="form3Example2">
                        <strong>Agenda ID</strong>
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        {...register1("agendaId", {
                          required: "Field is required",
                        })}
                        readOnly
                      />
                      <span className="vldn">
                        {errors1.agendaId && errors1.agendaId.message}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="row no-prop pt-5">
                  <div className="col-md-12 pb-1">
                    <h5 className="HdngTitl">
                      <strong>Members Present</strong>
                    </h5>
                  </div>
                  <div className="col-3">
                    <label className="form-label">
                      <strong>
                        Chairman:<span className="color-red"> *</span>
                      </strong>
                    </label>
                    <div className="form-group">
                      <select
                        className="form-select"
                        onChange={(e) => setChairmanVal(e.target.value)}
                      >
                        <option value="">Please select user</option>
                        {chairManList.map((item, index) => (
                          <option
                            value={item.id}
                            selected={chairman?.id == item.id}
                          >
                            {item.name}
                          </option>
                        ))}
                      </select>
                      {/* <input className="form-check-input" type="checkbox" checked /> */}
                      <input
                        type="hidden"
                        {...register1("chairmanCode")}
                        value={chairman?.id}
                      />
                      {/* <label className="form-check-label" for="form11Example2"> {chairman.name} </label> */}
                    </div>
                  </div>

                  <div className="col-3">
                    <label className="form-label">
                      <strong>
                        Convenor:<span className="color-red"> *</span>
                      </strong>
                    </label>
                    <div className="form-group chks">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        {...register1("convenorCodeSelected")}
                        checked={convenorChecked}
                        onChange={(e) => handleConvenorCheckboxChange(e)}
                      />
                      <input
                        type="hidden"
                        {...register1("convenorCode")}
                        value={convenor.id}
                      />
                      <label
                        className="form-check-label"
                        htmlFor="convenorCheckbox"
                      >
                        {" "}
                        {convenor.name}{" "}
                      </label>
                    </div>
                    <label className="form-label">
                      <strong>Alternate Convenor: </strong>
                    </label>
                    <div className="form-group chks">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id="alConvenorCheckbox"
                        {...register1("alConvenorCodeSelected")}
                        checked={alConvenorChecked}
                        onChange={(e) => handleAlConvenorCheckboxChange(e)}
                      />
                      <input
                        type="hidden"
                        {...register1("alConvenorCode")}
                        value={altConvenor.id}
                      />
                      <label
                        className="form-check-label"
                        htmlFor="alConvenorCheckbox"
                      >
                        {" "}
                        {altConvenor.name}{" "}
                      </label>
                    </div>
                  </div>

                  {/* <div className="col-3">
                                        <label className="form-label"><strong>Alternate Convenor: </strong></label>
                                        <div className="form-group chks">
                                            <input className="form-check-input" type="checkbox"
                                                {...register1('alConvenorCodeSelected')}
                                                defaultChecked={alConvenorChecked}
                                                onChange={(e) => handleAlConvenorCheckboxChange(e)}
                                            />
                                            <input type="hidden" {...register1('alConvenorCode')} value={altConvenor.id} />
                                            <label className="form-check-label" for="form11Example2"> {altConvenor.name} </label>
                                        </div>
                                    </div> */}

                  <div className="col-3">
                    <label className="form-label">
                      <strong>
                        Members:<span className="color-red"> *</span>
                      </strong>
                    </label>
                    <Select
                      isMulti
                      value={selectedOption}
                      onChange={handleChange}
                      options={options}
                    />
                  </div>
                  <div className="col-3">
                    <label className="form-label">
                      <strong>Members on Leave:</strong>
                    </label>

                    <Select
                      isMulti
                      value={selectedMemOption}
                      onChange={handleMemChange}
                      options={options}
                    />
                  </div>
                </div>
              </div>
            </div>

            {isIfcc && (
              <>
                <div className="row">
                  <div className="col-md-12 pb-1">
                    <h5 className="HdngTitl">
                      <strong>Sanction of Financial Assistance to Banks</strong>
                    </h5>
                  </div>

                  <Box>
                    <StyledTableContainer component={Paper} elevation={3}>
                      <Table size="small">
                        {" "}
                        {/* Changed to small for more compact appearance */}
                        <TableHead>
                          <TableRow>
                            <StyledTableCell width="5%">
                              Agenda No
                            </StyledTableCell>
                            <StyledTableCell width="25%">
                              Application No
                            </StyledTableCell>
                            <StyledTableCell width="25%">
                              Unit Name
                            </StyledTableCell>
                            <StyledTableCell
                              width="15%"
                              sx={{ maxWidth: "150px" }}
                            >
                              Purpose
                            </StyledTableCell>
                            <StyledTableCell
                              width="15%"
                              sx={{ maxWidth: "150px" }}
                            >
                              Decision
                            </StyledTableCell>
                            <StyledTableCell width="15%">
                              Create Minutes
                            </StyledTableCell>
                            {(meetingStatus === "" ||
                              meetingStatus === "CREATED") && (
                              <StyledTableCell
                                align="center"
                                sx={{ width: "40px" }}
                              >
                                <IconButton
                                  onClick={() => append1({})}
                                  size="small"
                                  sx={{
                                    bgcolor: "primary.light",
                                    color: "white",
                                    padding: "4px",
                                    "&:hover": {
                                      bgcolor: "primary.main",
                                    },
                                  }}
                                >
                                  <AddIcon fontSize="small" />
                                </IconButton>
                              </StyledTableCell>
                            )}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {fields1.map((field, index) => (
                            <React.Fragment key={field.id}>
                              <StyledTableRow>
                                <TableCell>{index + 1}</TableCell>

                                <TableCell>
                                  <div className="select-container">
                                    <Select
                                      value={filteredBankOptions.find(
                                        (option) =>
                                          option.label ===
                                          selectedBankOption[index]
                                      )}
                                      onChange={(selected) =>
                                        handleAppChange(selected, index)
                                      }
                                      options={filteredBankOptions}
                                      onInputChange={handleBankSearch}
                                      isSearchable
                                      styles={selectStyles}
                                      menuPortalTarget={document.body}
                                      menuPosition={"fixed"}
                                      menuPlacement="auto"
                                    />
                                    <input
                                      type="hidden"
                                      {...register1(
                                        `meetingData[${index}].appid`
                                      )}
                                      value={selectedBankOption[index]}
                                    />
                                    <input
                                      type="hidden"
                                      {...register1(
                                        `meetingData[${index}].sancDtlCode`
                                      )}
                                    />
                                    <input
                                      type="hidden"
                                      {...register1(
                                        `meetingData[${index}].sanctStatusCode`
                                      )}
                                      value={mtCode}
                                    />
                                    <input
                                      type="hidden"
                                      {...register1(
                                        `meetingData[${index}].sancStatus`
                                      )}
                                    />
                                    <input
                                      type="hidden"
                                      {...register1(
                                        `meetingData[${index}].agendaNo`
                                      )}
                                    />
                                  </div>
                                </TableCell>

                                <TableCell>
                                  <input
                                    type="hidden"
                                    {...register1(
                                      `meetingData[${index}].unitName`
                                    )}
                                  />
                                  {watch(`meetingData[${index}].unitName`)}
                                </TableCell>

                                {/* Purpose */}
                                <TableCell
                                  sx={{
                                    maxWidth: "150px",
                                    whiteSpace: "nowrap",
                                  }}
                                >
                                  <TextField
                                    select
                                    fullWidth
                                    size="small"
                                    required
                                    value={
                                      watch(
                                        `meetingData.${index}.sanctPurposeStatus`
                                      ) || ""
                                    }
                                    onChange={(e) =>
                                      setValue1(
                                        `meetingData.${index}.sanctPurposeStatus`,
                                        e.target.value,
                                        {
                                          shouldValidate: true,
                                          shouldDirty: true,
                                        }
                                      )
                                    }
                                  >
                                    <MenuItem value="">Select Purpose</MenuItem>
                                    {Purpose.map((item, idx) => (
                                      <MenuItem key={idx} value={item}>
                                        {item}
                                      </MenuItem>
                                    ))}
                                  </TextField>
                                </TableCell>

                                {/* Decision */}
                                <TableCell
                                  sx={{
                                    maxWidth: "150px",
                                    whiteSpace: "nowrap",
                                  }}
                                >
                                  <TextField
                                    select
                                    fullWidth
                                    size="small"
                                    required
                                    value={
                                      watch(
                                        `meetingData.${index}.sanctDscnStatus`
                                      ) || ""
                                    }
                                    onChange={(e) =>
                                      setValue1(
                                        `meetingData.${index}.sanctDscnStatus`,
                                        e.target.value,
                                        {
                                          shouldValidate: true,
                                          shouldDirty: true,
                                        }
                                      )
                                    }
                                  >
                                    <MenuItem value="">
                                      Select Decision
                                    </MenuItem>
                                    {Decision.map((item, idx) => (
                                      <MenuItem key={idx} value={item}>
                                        {item}
                                      </MenuItem>
                                    ))}
                                  </TextField>
                                </TableCell>

                                {/* Minutes */}
                                <TableCell>
                                  {!CommonUtil.isEmpty(field.sancDtlCode) && (
                                    <Button
                                      variant="contained"
                                      onClick={() => createMinutes(index)}
                                      startIcon={<AccessTime />}
                                      size="small"
                                    >
                                      Minutes
                                    </Button>
                                  )}
                                </TableCell>

                                {(meetingStatus === "" ||
                                  meetingStatus === "CREATED") && (
                                  <TableCell>
                                    <IconButton
                                      onClick={() =>
                                        deleteMeetingDetails(index)
                                      }
                                      size="small"
                                      color="error"
                                    >
                                      <DeleteIcon fontSize="small" />
                                    </IconButton>
                                  </TableCell>
                                )}
                              </StyledTableRow>

                              <TableRow>
                                <TableCell
                                  colSpan={7}
                                  sx={{ paddingTop: 1, paddingBottom: 2 }}
                                >
                                  <TextField
                                    fullWidth
                                    placeholder="Enter remarks..."
                                    {...register1(
                                      `meetingData.${index}.remarks`
                                    )}
                                    onChange={(e) => Pattern.sanitizeInput(e)}
                                  />
                                </TableCell>
                              </TableRow>
                            </React.Fragment>
                          ))}
                        </TableBody>
                      </Table>
                    </StyledTableContainer>
                    {meetingStatus === "CREATED" && (
                      <Alert severity="warning" sx={{ mb: 2 }}>
                        Note: Make sure to save or update the minutes data.
                      </Alert>
                    )}
                    {/* Modified Add Note section */}
                    {(meetingStatus === "CREATED" ||
                      (meetingStatus !== "CREATED" &&
                        !CommonUtil.isEmpty(watch("benchmarkNote")))) && (
                      <Box sx={{ mt: 2 }}>
                        <Typography
                          variant="subtitle1"
                          sx={{
                            mb: 1,
                            textTransform: "capitalize",
                            color: "text.secondary",
                          }}
                        >
                          Add Note (If Any):
                        </Typography>
                        <TextField
                          fullWidth
                          multiline
                          rows={1}
                          size="small"
                          {...register1("benchmarkNote")}
                          onChange={(e) => Pattern.sanitizeInput(e)}
                          error={!!errors1?.benchmarkNote}
                          helperText={errors1?.benchmarkNote?.message}
                          sx={{
                            "& .MuiOutlinedInput-root": {
                              backgroundColor: "background.paper",
                            },
                          }}
                        />
                      </Box>
                    )}
                  </Box>
                </div>
              </>
            )}

            {mtCode > 0 && (
              <Box className="row aDtl">
                {/* ── Co-Lending Details header ── */}
                <Box display="flex" alignItems="center">
                  <div className="col-md-12 pb-1">
                    <h5 className="HdngTitl">
                      <strong>Additional Details</strong>
                      <IconButton onClick={() => setOpen(!open)}>
                        <ExpandMoreIcon
                          style={{
                            transform: open ? "rotate(180deg)" : "rotate(0deg)",
                            transition: "0.3s",
                          }}
                        />
                      </IconButton>
                    </h5>
                  </div>
                </Box>

                {/* ── Three collapsible sub-sections ── */}
                <Collapse in={open} timeout="auto" unmountOnExit>
                  <Box display="flex" flexDirection="column" gap={2} mt={1}>
                    {/* 1. Sanction of Co-Lending Limit to Bank */}
                    <Paper variant="outlined">
                      <Box
                        display="flex"
                        justifyContent="space-between"
                        alignItems="center"
                        px={2}
                        py={1.5}
                        sx={{ cursor: "pointer", userSelect: "none" }}
                        onClick={() => setOpenColending((prev) => !prev)}
                      >
                        <Typography variant="subtitle2" fontWeight="bold">
                          Sanction of Co-Lending Limit to Bank
                        </Typography>
                        <IconButton size="small">
                          {openColending ? (
                            <ExpandLessIcon />
                          ) : (
                            <ExpandMoreIcon />
                          )}
                        </IconButton>
                      </Box>
                      <Divider />
                      <Box px={2} pb={openColending ? 2 : 0}>
                        <ColendingLimitSection
                          minuteSanctionId={mtCode}
                          open={openColending}
                          isEditable={meetingStatus !== "APPROVED"}
                        />
                      </Box>
                    </Paper>

                    {/* 2. Interest Rate Reset */}
                    <Paper variant="outlined">
                      <Box
                        display="flex"
                        justifyContent="space-between"
                        alignItems="center"
                        px={2}
                        py={1.5}
                        sx={{ cursor: "pointer", userSelect: "none" }}
                        onClick={() => setOpenInterest((prev) => !prev)}
                      >
                        <Typography variant="subtitle2" fontWeight="bold">
                          Interest Rate Reset
                        </Typography>
                        <IconButton size="small">
                          {openInterest ? (
                            <ExpandLessIcon />
                          ) : (
                            <ExpandMoreIcon />
                          )}
                        </IconButton>
                      </Box>
                      <Divider />
                      <Box px={2} pb={openInterest ? 2 : 0}>
                        <InterestRateResetSection
                          minuteSanctionId={mtCode}
                          open={openInterest}
                          isEditable={meetingStatus !== "APPROVED"}
                        />
                      </Box>
                    </Paper>

                    {/* 3. Other Items */}
                    <Paper variant="outlined">
                      <Box
                        display="flex"
                        justifyContent="space-between"
                        alignItems="center"
                        px={2}
                        py={1.5}
                        sx={{ cursor: "pointer", userSelect: "none" }}
                        onClick={() => setOpenOtherItems((prev) => !prev)}
                      >
                        <Typography variant="subtitle2" fontWeight="bold">
                          Other Items
                        </Typography>
                        <IconButton size="small">
                          {openOtherItems ? (
                            <ExpandLessIcon />
                          ) : (
                            <ExpandMoreIcon />
                          )}
                        </IconButton>
                      </Box>
                      <Divider />
                      <Box px={2} pb={openOtherItems ? 2 : 0}>
                        <OtherItemsSection
                          minuteSanctionId={mtCode}
                          open={openOtherItems}
                          isEditable={meetingStatus !== "APPROVED"}
                        />
                      </Box>
                    </Paper>
                  </Box>
                </Collapse>
              </Box>
            )}

            {mtCode > 0 && (
              <div className="button-container-left">
                <FileUploadModal
                  minuteId={mtCode}
                  onFileChange={setHasFile}
                  status={meetingStatus}
                />
              </div>
            )}

            <div className="button-container-center">
              {(meetingStatus === "" ||
                meetingStatus === "CREATED" ||
                meetingStatus === "CIRCULATED") && (
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  endIcon={<CheckCircleIcon />}
                  sx={{
                    textTransform: "none",
                    margin: "4px",
                  }}
                >
                  Save
                </Button>
              )}

              {enableLock &&
                meetingStatus === "LOCKED" &&
                authorizeToFwdRejApprove && (
                  <Button
                    variant="contained"
                    onClick={() => getUserListForRejectingMinutes()}
                    startIcon={<ReplyIcon />}
                    sx={{
                      textTransform: "none",
                      margin: "4px",
                      backgroundColor: "#f39c12",
                      "&:hover": {
                        backgroundColor: "#e67e22",
                      },
                    }}
                  >
                    Reject
                  </Button>
                )}

              {((enableLock &&
                meetingStatus === "LOCKED" &&
                authorizeToFwdRejApprove) ||
                (meetingStatus === "CREATED" &&
                  (isMaker || isChecker || isAdminChecker))) && (
                <Button
                  variant="contained"
                  color="success"
                  onClick={() => approveMinutes()}
                  endIcon={<ThumbUpIcon />}
                  sx={{
                    textTransform: "none",
                    margin: "4px",
                  }}
                >
                  Approve
                </Button>
              )}

              {enableLock &&
                meetingStatus === "CREATED" &&
                (isMaker || isChecker || isAdminChecker) && (
                  <Button
                    variant="contained"
                    onClick={() => getCheckerListForForwarding()}
                    endIcon={<ForwardIcon />}
                    sx={{
                      textTransform: "none",
                      margin: "4px",
                      backgroundColor: "#3498db",
                      "&:hover": {
                        backgroundColor: "#2980b9",
                      },
                    }}
                  >
                    Forward Minutes
                  </Button>
                )}

              {enableLock &&
                meetingStatus === "LOCKED" &&
                authorizeToFwdRejApprove &&
                !isHigherAuthority && (
                  <Button
                    variant="contained"
                    onClick={() => getCheckerListForForwarding()}
                    endIcon={<ForwardIcon />}
                    sx={{
                      textTransform: "none",
                      margin: "4px",
                      backgroundColor: "#3498db",
                      "&:hover": {
                        backgroundColor: "#2980b9",
                      },
                    }}
                  >
                    Accept & Forward
                  </Button>
                )}
            </div>
            <br />
            {mtCode > 0 && (
              <Box>
                {" "}
                <ForwardRejectionSummary mtCode={mtCode} />{" "}
              </Box>
            )}
          </>
        </form>
      </div>

      <Modal
        style={{ marginTop: "200px" }}
        show={showHideProceed}
        onHide={hideProceed}
      >
        <Modal.Body>
          <div className="conatiner text-center">
            <div className="row">
              <div className="col-sm-12">
                <h5>Forward to Chairman:</h5>
                <select className="form-control">
                  <option value={chairman?.id}>
                    <strong>{chairman?.name}</strong>
                  </option>
                </select>
              </div>
            </div>
          </div>

          <br />
          <div className="row text-center">
            <div className="col-sm-12 text-center">
              <button
                type="button"
                className="btn btnRegister"
                onClick={hideProceed}
              >
                Cancel <i className="fa fa-times"></i>
              </button>
              &nbsp;
              {meetingStatus === "CIRCULATED" && (
                <button
                  type="button"
                  className="btn btnProceed"
                  onClick={() => updateMinutes("SUBMITTED")}
                >
                  Proceed <i className="fa fa-circle-check"></i>
                </button>
              )}
            </div>
          </div>
        </Modal.Body>
      </Modal>

      <Modal
        style={{ marginTop: "200px" }}
        show={showHideForward}
        onHide={hideForward}
      >
        <Modal.Body style={{ padding: "15px" }}>
          <Box sx={{ textAlign: "center" }}>
            <Typography
              variant="subtitle1"
              gutterBottom
              sx={{ fontWeight: "bold", mb: 1 }}
            >
              {sendBack ? "Reject Minutes" : "Forward Minutes"}
            </Typography>
            <FormControl fullWidth size="small" sx={{ mb: 2 }}>
              <InputLabel id="user-select-label">Please select user</InputLabel>
              <SelectMUI
                labelId="user-select-label"
                id="user-select"
                label="Please select user"
                defaultValue=""
                onChange={(e) => setAppChecker(e.target.value)}
              >
                <MenuItem value="">Please select user</MenuItem>
                {checkerList.map((item, index) => (
                  <MenuItem key={index} value={item.ofrCode}>
                    {item.ofrName} {item.ofrMiddleName} {item.ofrLastName}
                  </MenuItem>
                ))}
              </SelectMUI>
            </FormControl>
            <Typography
              variant="subtitle1"
              sx={{ fontWeight: "normal", mb: 1, textTransform: "none" }}
            >
              Add Comments (If any)
            </Typography>
            <TextField
              fullWidth
              multiline
              rows={2}
              size="small"
              variant="outlined"
              onChange={(e) => {
                Pattern.sanitizeInput(e);
                setCheckerComment(e.target.value);
              }}
              sx={{ mb: 2 }}
            />
          </Box>
          <Stack
            direction="row"
            spacing={2}
            justifyContent="center"
            sx={{ mt: 1 }}
          >
            <Button
              variant="outlined"
              color="error"
              startIcon={<CancelIcon />}
              onClick={hideForward}
              size="small"
            >
              Cancel
            </Button>
            <Button
              variant="contained"
              color="primary"
              endIcon={<SendIcon />}
              onClick={() => forwardMinutesToSelectedUser(sendBack ? "R" : "F")}
              size="small"
            >
              Proceed
            </Button>
          </Stack>
        </Modal.Body>
      </Modal>
      <Modal
        style={{ marginTop: "200px" }}
        show={showHideConvForward}
        onHide={hideConvForward}
      >
        <Modal.Body>
          <div className="conatiner text-center">
            <div className="row">
              <div className="col-sm-12">
                <h5>Forward to IFV-CGM / any other member of the committee:</h5>

                <select
                  className="form-select"
                  onChange={(e) => setForwardStage2User(e.target.value)}
                >
                  <option value="">
                    <strong>Please select a member of the committee</strong>
                  </option>
                  <option value={chairman?.id}>
                    <strong>{chairman?.name}</strong>
                  </option>
                  {selectedOption.map((item, index) => (
                    <option key={index} value={item.value}>
                      <strong>{item.label}</strong>
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <br />
          <div className="row text-center">
            <div className="col-sm-12 text-center">
              <button
                type="button"
                className="btn btnRegister"
                onClick={hideConvForward}
              >
                Cancel <i className="fa fa-times"></i>
              </button>
              &nbsp;
              {meetingStatus === "LOCKED" && (
                <button
                  type="button"
                  className="btn btnProceed"
                  onClick={() => forwardMinutes()}
                >
                  Forward <i className="fa fas fa-share"></i>
                </button>
              )}
            </div>
          </div>
        </Modal.Body>
      </Modal>
      <Modal
        style={{ marginTop: "200px" }}
        show={showRejectMinutes}
        onHide={hideRejectMinutes}
      >
        <Modal.Body>
          <div className="conatiner text-center">
            <div className="row">
              <div className="col-sm-12">
                <h5>Send Back:</h5>

                {/* <select className="form-select" onChange={(e) => setForwardStage1User(e.target.value)}>
                                    <option value=''><strong>Please select convenor/alternate convenor</strong></option>
                                     <option value={creator.id}><strong>{creator.name}</strong></option>
                               
                                </select> */}
              </div>
            </div>
          </div>

          <br />
          <div className="row text-center">
            <div className="col-sm-12 text-center">
              <button
                type="button"
                className="btn btnRegister"
                onClick={hideRejectMinutes}
              >
                Cancel <i className="fa fa-times"></i>
              </button>
              &nbsp;
              {meetingStatus === "LOCKED" && (
                <button
                  type="button"
                  className="btn btnProceed"
                  onClick={() => forwardMinutes()}
                >
                  Forward <i className="fa fas fa-share"></i>
                </button>
              )}
            </div>
          </div>
        </Modal.Body>
      </Modal>

      <MinutesModal
        open={showMinutesModal}
        onClose={() => {
          setShowMinutesModal(false);
          getSanctionMinutesById(mtCode);
        }}
        status={meetingStatus}
        {...selectedData}
      />

      {loading && <Loading />}
      <MessageModal
        open={isOpen}
        onClose={hideMessage}
        message={messageConfig.message}
        type={messageConfig.type}
        totalMessages={totalMessages}
        currentIndex={currentIndex}
        onNext={nextMessage}
        onPrev={prevMessage}
        hasNext={hasNext}
        hasPrev={hasPrev}
      />
    </Fragment>
  );
};

export default MeetingDetails;