import {
  Add as AddIcon,
  CheckCircle as CheckCircleIcon,
  Download as DownloadIcon,
  KeyboardArrowDown as ExpandIcon,
  KeyboardArrowUp as CollapseIcon,
  Refresh as RefreshIcon
} from "@mui/icons-material";
import {
  Alert,
  Autocomplete,
  Box,
  Button,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormControlLabel,
  FormLabel,
  IconButton,
  LinearProgress,
  Paper,
  Radio,
  RadioGroup,
  Snackbar,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Tooltip,
  Typography
} from "@mui/material";
import {
  keepPreviousData,
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQuery,
  useQueryClient
} from "@tanstack/react-query";
import {
  MaterialReactTable,
  useMaterialReactTable
} from "material-react-table";
import { useEffect, useMemo, useRef, useState } from "react";
import BeneficiaryApiService from "services/BeneficiaryApiService";
import IfvAppraisalService from "services/IfvAppraisalService";
import Pattern from "services/validators/Pattern";
import * as XLSX from "xlsx";
import ValidationStatusBanner from "./beneficiary/ValidationStatusBanner";

const queryClient = new QueryClient();

const JOB_STORAGE_KEY = "beneficiary_current_job";

const saveJobToStorage = (jobId, status = "PROCESSING") => {
  try {
    const jobData = {
      jobId,
      status,
      timestamp: new Date().toISOString(),
    };
    localStorage.setItem(JOB_STORAGE_KEY, JSON.stringify(jobData));
  } catch (error) {
    console.error("Failed to save job to storage:", error);
  }
};

const getJobFromStorage = () => {
  try {
    const stored = localStorage.getItem(JOB_STORAGE_KEY);
    if (stored) {
      const jobData = JSON.parse(stored);
      // Check if job is not older than 24 hours
      const timestamp = new Date(jobData.timestamp);
      const now = new Date();
      const hoursDiff = (now - timestamp) / (1000 * 60 * 60);

      if (hoursDiff < 24) {
        return jobData;
      } else {
        // Clear old job
        localStorage.removeItem(JOB_STORAGE_KEY);
      }
    }
  } catch (error) {
    console.error("Failed to retrieve job from storage:", error);
  }
  return null;
};

const clearJobFromStorage = () => {
  try {
    localStorage.removeItem(JOB_STORAGE_KEY);
  } catch (error) {
    console.error("Failed to clear job from storage:", error);
  }
};

// Nested Documents Table Component
function DocumentsTable({ cifNumber }) {
  const queryClient = useQueryClient();
  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: 5,
  });
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  const { data, isError, isFetching, isLoading } = useQuery({
    queryKey: [
      "beneficiary-documents",
      cifNumber,
      pagination.pageIndex,
      pagination.pageSize,
    ],
    queryFn: () =>
      BeneficiaryApiService.fetchBeneficiaryDocuments({
        cifNumber,
        start: pagination.pageIndex,
        size: pagination.pageSize,
      }),
    placeholderData: keepPreviousData,
    enabled: !!cifNumber,
  });

  const deleteDocMutation = useMutation({
    mutationFn: (id) => BeneficiaryApiService.deleteDocument(id),
    onSuccess: () => {
      queryClient.invalidateQueries(["beneficiary-documents", cifNumber]);
      setSnackbar({
        open: true,
        message: "Document deleted successfully!",
        severity: "success",
      });
    },
    onError: () => {
      setSnackbar({
        open: true,
        message: "Failed to delete document",
        severity: "error",
      });
    },
  });

  const handleDownload = async (id, fileName) => {
    try {
      await BeneficiaryApiService.downloadDocument(id, fileName);
      setSnackbar({
        open: true,
        message: "Document downloaded successfully.",
        severity: "success",
      });
    } catch (error) {
      const status = error?.response?.status;

      setSnackbar({
        open: true,
        message:
          status === 404 ? "File not found." : "Failed to download document.",
        severity: "error",
      });
    }
  };

  const documentColumns = useMemo(
    () => [
      {
        header: "Sl No",
        size: 70,
        Cell: ({ row, table }) => {
          const { pageIndex, pageSize } = table.getState().pagination ?? {
            pageIndex: 0,
            pageSize: Number.MAX_SAFE_INTEGER,
          };
          return pageIndex * pageSize + row.index + 1;
        },
      },
      {
        accessorKey: "fileName",
        header: "File Name",
        size: 100,
        Cell: ({ cell }) => (
          <Tooltip title={cell.getValue()}>
            <Typography variant="body2" noWrap>
              {cell.getValue()}
            </Typography>
          </Tooltip>
        ),
      },
      {
        accessorKey: "uploadDateTime",
        header: "Upload Date",
        size: 150,
        Cell: ({ cell }) => {
          const date = new Date(cell.getValue());
          return date.toLocaleString();
        },
      },
      {
        id: "refOrLoan",
        header: "Ref No / Loan Acc No",
        size: 150,
        accessorFn: (row) => row?.benRefNo ?? row?.loanAccountNo ?? "",
        Cell: ({ cell }) => {
          const value = cell.getValue();
          return (
            <Tooltip title={value || ""}>
              <Typography variant="body2" noWrap>
                {value || "-"}
              </Typography>
            </Tooltip>
          );
        },
      },
      {
        accessorKey: "remarks",
        header: "Remarks",
        size: 200,
        Cell: ({ cell }) => (
          <Tooltip title={cell.getValue() || ""}>
            <Typography variant="body2" noWrap>
              {cell.getValue() || "-"}
            </Typography>
          </Tooltip>
        ),
      },
    ],
    []
  );

  const documentsTable = useMaterialReactTable({
    columns: documentColumns,
    data: data?.content ?? [],
    rowCount: data?.totalElements ?? 0,
    manualPagination: true,
    enableRowActions: true,
    positionActionsColumn: "last",
    state: {
      isLoading,
      pagination,
      showAlertBanner: isError,
      showProgressBars: isFetching,
    },
    onPaginationChange: setPagination,
    enableColumnFilters: false,
    enableSorting: false,
    enableTopToolbar: false,
    muiTableBodyRowProps: { hover: false },
    muiTablePaperProps: {
      elevation: 0,
      sx: { boxShadow: "none" },
    },
    renderRowActions: ({ row }) => (
      <Box sx={{ display: "flex", gap: 0.2 }}>
        <Tooltip title="Download">
          <IconButton
            color="primary"
            onClick={() =>
              handleDownload(row.original.id, row.original.fileName)
            }
          >
            <DownloadIcon />
          </IconButton>
        </Tooltip>
        {/* <Tooltip title="Delete">
          <IconButton
            color="error"
            onClick={() => {
              if (window.confirm('Are you sure you want to delete this document?')) {
                deleteDocMutation.mutate(row.original.id);
              }
            }}
          >
            <DeleteIcon />
          </IconButton>
        </Tooltip> */}
      </Box>
    ),
  });

  return (
    <>
      <Box
        sx={{
          p: 2,
          backgroundColor: "#fff",
          width: "100%",
          margin: "auto",
          border: "1px solid #c4dced",
          borderRadius: "6px",
        }}
      >
        <Typography
          variant="subtitle2"
          gutterBottom
          sx={{ mb: 2, fontWeight: 600, textTransform: "none" }}
        >
          Uploaded Documents for CIF: {cifNumber}
        </Typography>
        <MaterialReactTable table={documentsTable} />
      </Box>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          sx={{ width: "100%" }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
}

// Job Status Component
function JobStatusBanner({ jobId, onJobComplete, onJobStatusChange }) {
  const [jobStatus, setJobStatus] = useState(null);
  const pollingIntervalRef = useRef(null);

  const fetchJobStatus = async () => {
    if (!jobId) return;

    try {
      const response = await BeneficiaryApiService.processingStatus(jobId);
      setJobStatus(response);

      // Update storage with current status
      if (response.status !== "NOT_FOUND") {
        saveJobToStorage(jobId, response.status);
      }

      // Notify parent of status change
      if (onJobStatusChange) {
        onJobStatusChange(response.status);
      }

      // Stop polling if job is complete or failed
      if (
        response.status === "COMPLETED" ||
        response.status === "FAILED" ||
        response.status === "NOT_FOUND"
      ) {
        if (pollingIntervalRef.current) {
          clearInterval(pollingIntervalRef.current);
          pollingIntervalRef.current = null;
        }

        if (response.status === "COMPLETED") {
          clearJobFromStorage();
          onJobComplete();
        } else if (response.status === "FAILED") {
          clearJobFromStorage();
        }
      }
    } catch (error) {
      console.error("Error fetching job status:", error);
    }
  };

  useEffect(() => {
    if (jobId) {
      // Fetch immediately
      fetchJobStatus();

      // Start polling every 5 seconds
      pollingIntervalRef.current = setInterval(fetchJobStatus, 5000);
    }

    // Cleanup on unmount or when jobId changes
    return () => {
      if (pollingIntervalRef.current) {
        clearInterval(pollingIntervalRef.current);
      }
    };
  }, [jobId]);

  if (!jobStatus || jobStatus.status === "NOT_FOUND") {
    return null;
  }

  const isProcessing =
    jobStatus.status === "PROCESSING" || jobStatus.status === "IN_PROGRESS";
  const isCompleted = jobStatus.status === "COMPLETED";
  const isFailed = jobStatus.status === "FAILED";

  return (
    <Paper
      elevation={3}
      sx={{
        p: 2,
        mb: 2,
        backgroundColor: isCompleted
          ? "#e8f5e9"
          : isFailed
          ? "#ffebee"
          : "#e3f2fd",
        border: `1px solid ${
          isCompleted ? "#4caf50" : isFailed ? "#f44336" : "#2196f3"
        }`,
      }}
    >
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          mb: 1,
        }}
      >
        <Typography
          variant="h6"
          sx={{ display: "flex", alignItems: "center", gap: 1 }}
        >
          {isProcessing && <CircularProgress size={20} />}
          {isCompleted && <CheckCircleIcon color="success" />}
          {isFailed && <Typography color="error">✗</Typography>}
          DFS Upload Status: {jobStatus.status}
        </Typography>
        {/* <Typography variant="caption" color="text.secondary">
          Job ID: {jobId}
        </Typography> */}
      </Box>

      {isProcessing && (
        <>
          <LinearProgress
            variant="determinate"
            value={jobStatus.progressPercentage || 0}
            sx={{ mb: 1, height: 8, borderRadius: 4 }}
          />
          <Typography variant="body2" sx={{ mb: 1 }}>
            Progress: {jobStatus.progressPercentage || 0}%
          </Typography>
        </>
      )}

      <Box sx={{ display: "flex", gap: 3 }}>
        <Typography variant="body2">
          Processed: <strong>{jobStatus.processedRecords || 0}</strong>
        </Typography>
        <Typography variant="body2" color="error">
          Failed: <strong>{jobStatus.failedRecords || 0}</strong>
        </Typography>
      </Box>

      {jobStatus.lastUpdated && (
        <Typography
          variant="caption"
          color="text.secondary"
          sx={{ mt: 1, display: "block" }}
        >
          Last Updated: {new Date(jobStatus.lastUpdated).toLocaleString()}
        </Typography>
      )}
    </Paper>
  );
}

function BeneficiaryTable() {
  const user = IfvAppraisalService.getCurrentUser();
  const queryClient = useQueryClient();
  const [columnFilters, setColumnFilters] = useState([]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [sorting, setSorting] = useState([]);
  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: 10,
  });
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [uploadFile, setUploadFile] = useState(null);
  const [fileLoading, setFileLoading] = useState(false);
  const [uploadData, setUploadData] = useState({
    bankName: "",
    cifNumber: "",
    loanAccountNo: "",
    benPreDisbFlag: "N",
    remarks: "",
    userCode: "",
    disbDate: "",
  });
  const [selectedBank, setSelectedBank] = useState(null);
  const [selectedLoanAccount, setSelectedLoanAccount] = useState(null);
  const [bankOptions, setBankOptions] = useState([]);
  const [loanAccountOptions, setLoanAccountOptions] = useState([]);
  const [loadingBanks, setLoadingBanks] = useState(false);
  const [loadingLoanAccounts, setLoadingLoanAccounts] = useState(false);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });
  const [currentJobId, setCurrentJobId] = useState(null);
  const [isJobProcessing, setIsJobProcessing] = useState(false);
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);

  const [disbursementDates, setDisbursementDates] = useState([]);
  const [selectedDisbDate, setSelectedDisbDate] = useState(null);
  const [loadingDisbDate, setLoadingDisbDate] = useState(false);

  const [verticalOptions, setVerticalOptions] = useState([]);
  const [selectedVertical, setSelectedVertical] = useState(null);
  const [loadingVerticals, setLoadingVerticals] = useState(false);

  const MAX_UI_ERRORS = 20;
  const [validationErrors, setValidationErrors] = useState([]);
  const [errorDialogOpen, setErrorDialogOpen] = useState(false);

  const fileInputRef = useRef(null);

  // new state — add near your other useState calls
  const [validationJobId, setValidationJobId] = useState(null);
  const [pendingForwardJobId, setPendingForwardJobId] = useState(null); // lets us retry the forward call if it fails

  // STEP 1: kick off validation
  const validateMutation = useMutation({
    mutationFn: ({ file, data }) =>
      BeneficiaryApiService.uploadAndValidateBeneficiary({ file, data }),

    onSuccess: (response) => {
      if (!response?.success) {
        setSnackbar({
          open: true,
          message: response?.message || "Failed to initiate validation",
          severity: "error",
        });
        return;
      }

      const jobId = response?.data?.jobId;
      if (!jobId) {
        setSnackbar({
          open: true,
          message: "No job ID returned from server",
          severity: "error",
        });
        return;
      }

      setValidationJobId(jobId);
      handleCloseDialog();
      setSnackbar({
        open: true,
        message: "File uploaded. Validating…",
        severity: "info",
      });
    },

    onError: (error) => {
      const errorMessage =
        error?.message ||
        error?.errors?.[0] ||
        "Failed to upload beneficiary file";
      setSnackbar({ open: true, message: errorMessage, severity: "error" });
    },
  });

  // STEP 3: only called once validation status === COMPLETED
  const forwardMutation = useMutation({
    mutationFn: (jobId) => BeneficiaryApiService.forwardBeneficiaryData(jobId),

    onSuccess: (response, jobId) => {
      if (!response?.success) {
        setSnackbar({
          open: true,
          message:
            response?.message ||
            "Failed to initiate beneficiary data forwarding",
          severity: "error",
        });
        return;
      }

      const forwardedJobId = response.message || jobId;
      setCurrentJobId(forwardedJobId);
      setIsJobProcessing(true);
      saveJobToStorage(forwardedJobId, "PROCESSING");
      setPendingForwardJobId(null);

      setSnackbar({
        open: true,
        message: "Validation passed. Beneficiary data forwarding initiated…",
        severity: "success",
      });
    },

    onError: (error, jobId) => {
      // keep the jobId around so the user can retry without re-uploading
      setPendingForwardJobId(jobId);
      setSnackbar({
        open: true,
        message: error?.message || "Failed to forward beneficiary data to DFS",
        severity: "error",
      });
    },
  });

  // STEP 2 (failure branch): fetch the errors once validation fails
  const fetchValidationErrors = async (jobId, status) => {
    try {
      const errors = await BeneficiaryApiService.getValidationErrors(jobId);

      if (errors?.length) {
        setValidationErrors(errors);
        setErrorDialogOpen(true);
        setSnackbar({
          open: true,
          message: `${errors.length} validation errors found`,
          severity: "error",
        });
      } else {
        setSnackbar({
          open: true,
          message: status?.errorMessage || "Validation failed",
          severity: "error",
        });
      }
    } catch (e) {
      setSnackbar({
        open: true,
        message: "Validation failed and errors could not be retrieved",
        severity: "error",
      });
    } finally {
      setValidationJobId(null);
    }
  };

  // callbacks handed to ValidationStatusBanner
  const handleValidationCompleted = (jobId) => {
    setValidationJobId(null); // stop the validation polling loop
    setPendingForwardJobId(jobId);
    forwardMutation.mutate(jobId); // STEP 3 fires only here
  };

  const handleValidationFailed = (jobId, status) => {
    fetchValidationErrors(jobId, status);
  };

  const downloadErrorReport = () => {
    if (!validationErrors.length) return;

    const excelData = validationErrors.map((err) => ({
      "Row Number": err.rowNumber,
      "Field Name": err.fieldName,
      "Error Message": err.errorMessage,
      "Field Value": err.fieldValue,
    }));

    const worksheet = XLSX.utils.json_to_sheet(excelData);

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Validation Errors");

    XLSX.writeFile(workbook, "Beneficiary_Validation_Errors.xlsx");
  };

  // Load job from storage on mount
  useEffect(() => {
    const storedJob = getJobFromStorage();
    if (
      storedJob &&
      storedJob.status !== "COMPLETED" &&
      storedJob.status !== "FAILED"
    ) {
      setCurrentJobId(storedJob.jobId);
      setIsJobProcessing(true);
      setSnackbar({
        open: true,
        message: "Resuming tracking of previous job...",
        severity: "info",
      });
    }
  }, []);

  useEffect(() => {
    const fetchVerticals = async () => {
      try {
        setLoadingVerticals(true);
        const verticals = await BeneficiaryApiService.getIfvVerticals();

        const options = verticals.map((v) => ({
          value: v.slSidbiProductLine,
          label: v.vcName,
        }));

        setVerticalOptions(options);
      } catch (error) {
        setSnackbar({
          open: true,
          message: "Failed to load verticals",
          severity: "error",
        });
      } finally {
        setLoadingVerticals(false);
      }
    };

    if (uploadDialogOpen) {
      fetchVerticals();
    }
  }, [uploadDialogOpen]);

  const handleVerticalChange = async (event, newValue) => {
    setSelectedVertical(newValue);
    setSelectedBank(null);
    setBankOptions([]);
    setLoanAccountOptions([]);

    if (!newValue) return;

    try {
      setLoadingBanks(true);

      const banks = await BeneficiaryApiService.fetchCustomersOnVertical(
        newValue.value
      );

      const options = banks.map((b) => ({
        value: b.custCd,
        label: b.cname,
        customerCode: b.custCd,
        customerLongName: b.cname,
      }));

      setBankOptions(options);
    } catch (error) {
      setSnackbar({
        open: true,
        message: "Failed to load banks",
        severity: "error",
      });
    } finally {
      setLoadingBanks(false);
    }
  };

  // Fetch loan accounts when bank is selected and benPreDisbFlag is 'N'
  useEffect(() => {
    const fetchLoanAccounts = async () => {
      if (!selectedBank?.customerCode || uploadData.benPreDisbFlag === "Y") {
        setLoanAccountOptions([]);
        return;
      }

      try {
        setLoadingLoanAccounts(true);
        const loanAccounts = await BeneficiaryApiService.fetchLoanAccNoOnCif(
          selectedBank.customerCode
        );
        const options = loanAccounts.map((account) => ({
          value: account,
          label: account,
        }));
        setLoanAccountOptions(options);

        if (options.length === 0) {
          setUploadData((prev) => ({
            ...prev,
            benPreDisbFlag: "Y",
            loanAccountNo: "",
          }));
          setSnackbar({
            open: true,
            message:
              "No loan accounts found. Pre-disbursement flag set to Yes.",
            severity: "info",
          });
        }
      } catch (error) {
        setSnackbar({
          open: true,
          message: "Failed to load loan accounts",
          severity: "error",
        });
        setLoanAccountOptions([]);
        setUploadData((prev) => ({
          ...prev,
          benPreDisbFlag: "Y",
          loanAccountNo: "",
        }));
      } finally {
        setLoadingLoanAccounts(false);
      }
    };

    fetchLoanAccounts();
  }, [selectedBank, uploadData.benPreDisbFlag]);

  const fetchDisbursementDate = async (accNo) => {
    if (!accNo) {
      setDisbursementDates([]);
      setSelectedDisbDate(null);
      setUploadData((prev) => ({
        ...prev,
        disbDate: "",
      }));
      return;
    }

    try {
      setLoadingDisbDate(true);

      const response = await BeneficiaryApiService.fetchDisbDateOnAccNo(accNo);

      const dates = Array.isArray(response) ? response : [response];

      const options = dates.map((d) => ({
        value: d.disbDate || d,
        label: d.disbDate || d,
      }));

      setDisbursementDates(options);
    } catch (error) {
      setSnackbar({
        open: true,
        message: "Failed to fetch disbursement dates",
        severity: "error",
      });

      setDisbursementDates([]);
    } finally {
      setLoadingDisbDate(false);
    }
  };

  const handleDisbDateChange = (event, newValue) => {
    setSelectedDisbDate(newValue);

    setUploadData((prev) => ({
      ...prev,
      disbDate: newValue?.value || "",
    }));
  };

  const { data, isError, isFetching, isLoading } = useQuery({
    queryKey: [
      "beneficiaries",
      pagination.pageIndex,
      pagination.pageSize,
      columnFilters,
      globalFilter,
      sorting,
    ],
    queryFn: () =>
      BeneficiaryApiService.fetchBeneficiaries({
        start: pagination.pageIndex,
        size: pagination.pageSize,
        filters: JSON.stringify(columnFilters),
        sorting: JSON.stringify(sorting),
        globalFilter,
      }),
    placeholderData: keepPreviousData,
  });

  const uploadMutation = useMutation({
    mutationFn: (jobId) => BeneficiaryApiService.forwardBeneficiaryData(jobId),

    onSuccess: (response) => {
      if (!response?.success) {
        const errors = response?.data?.errors || [];

        if (errors.length > 0) {
          setValidationErrors(errors);
          setErrorDialogOpen(true);

          setSnackbar({
            open: true,
            message: `${errors.length} validation errors found`,
            severity: "error",
          });

          return;
        }

        setSnackbar({
          open: true,
          message: response?.message || "Validation failed",
          severity: "error",
        });

        return;
      }

      console.log("Upload API Response:", response);

      if (response?.message) {
        setCurrentJobId(response.message);
        setIsJobProcessing(true);
        saveJobToStorage(response.message, "PROCESSING");
      }

      handleCloseDialog();

      setSnackbar({
        open: true,
        message: "Beneficiary upload initiated! Processing in progress...",
        severity: "success",
      });
    },

    onError: (error) => {
      console.error("Upload failed", error);

      const errorMessage =
        error?.message || error?.errors?.[0] || "Failed to upload beneficiary";

      setSnackbar({
        open: true,
        message: errorMessage,
        severity: "error",
      });
    },
  });

  const handleJobComplete = () => {
    setIsJobProcessing(false);
    queryClient.invalidateQueries(["beneficiaries"]);
    setSnackbar({
      open: true,
      message: "Beneficiary processing completed successfully!",
      severity: "success",
    });
  };

  const handleJobStatusChange = (status) => {
    if (status === "FAILED") {
      setIsJobProcessing(false);
      setSnackbar({
        open: true,
        message: "Job processing failed. Please check the records.",
        severity: "error",
      });
    }
  };

  const columns = useMemo(
    () => [
      {
        header: "Sl No",
        size: 70,
        Cell: ({ row, table }) => {
          const { pageIndex, pageSize } = table.getState().pagination ?? {
            pageIndex: 0,
            pageSize: Number.MAX_SAFE_INTEGER,
          };
          return pageIndex * pageSize + row.index + 1;
        },
      },
      {
        accessorKey: "bankName",
        header: "Bank Name",
        size: 250,
      },
      {
        accessorKey: "cifNumber",
        header: "CIF Number",
        size: 150,
      },
    ],
    []
  );

  const isValidationInProgress = !!validationJobId;

  const isAnyJobRunning =
    isJobProcessing ||
    isValidationInProgress ||
    validateMutation.isPending ||
    forwardMutation.isPending;

  const table = useMaterialReactTable({
    columns,
    data: data?.content ?? [],
    rowCount: data?.totalElements ?? 0,
    manualPagination: true,
    manualSorting: true,
    manualFiltering: true,
    enableExpanding: true,
    enableExpandAll: false,
    positionActionsColumn: "last",
    state: {
      columnFilters,
      globalFilter,
      isLoading,
      pagination,
      showAlertBanner: isError,
      showProgressBars: isFetching,
      sorting,
    },
    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
    onPaginationChange: setPagination,
    onSortingChange: setSorting,
    renderDetailPanel: ({ row }) => (
      <DocumentsTable cifNumber={row.original.cifNumber} />
    ),
    renderTopToolbarCustomActions: () => (
      <Box sx={{ display: "flex", gap: 2 }}>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => {
            if (isAnyJobRunning) {
              setSnackbar({
                open: true,
                message:
                  "Please wait for the current job to complete before uploading another file.",
                severity: "warning",
              });
              return;
            }
            setUploadDialogOpen(true);
          }}
          disabled={isAnyJobRunning}
        >
          Upload Beneficiary Data
        </Button>
        {currentJobId && (
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={() => setStatusDialogOpen(true)}
          >
            Check DFS Upload Status
          </Button>
        )}
      </Box>
    ),
    muiExpandButtonProps: ({ row }) => ({
      children: row.getIsExpanded() ? <CollapseIcon /> : <ExpandIcon />,
    }),
  });

  const handleCloseDialog = () => {
    setUploadDialogOpen(false);
    setUploadFile(null);
    setFileLoading(false);
    setSelectedBank(null);
    setSelectedLoanAccount(null);
    setLoanAccountOptions([]);
    setSelectedDisbDate(null);
    setDisbursementDates([]);
    setUploadData({
      bankName: "",
      cifNumber: "",
      loanAccountNo: "",
      benPreDisbFlag: "N",
      remarks: "",
      userCode: "",
      disbDate: "",
    });
    setSelectedVertical(null);
    setVerticalOptions([]);
  };

  const handleBankChange = (event, newValue) => {
    setSelectedBank(newValue);
    setSelectedLoanAccount(null);
    setLoanAccountOptions([]);
    setSelectedDisbDate(null);
    setDisbursementDates([]);

    if (newValue) {
      setUploadData({
        ...uploadData,
        bankName: newValue.customerLongName,
        cifNumber: newValue.customerCode,
        loanAccountNo: "",
        disbDate: "",
      });
    } else {
      setUploadData({
        ...uploadData,
        bankName: "",
        cifNumber: "",
        loanAccountNo: "",
        disbDate: "",
      });
    }
  };

  const handleLoanAccountChange = async (event, newValue) => {
    setSelectedLoanAccount(newValue);

    const accNo = newValue?.value || "";

    setUploadData({
      ...uploadData,
      loanAccountNo: accNo,
      disbDate: "",
    });

    setSelectedDisbDate(null);
    setDisbursementDates([]);

    if (accNo) {
      await fetchDisbursementDate(accNo);
    }
  };

  const handlePreDisbFlagChange = (event) => {
    const newValue = event.target.value;
    setUploadData({
      ...uploadData,
      benPreDisbFlag: newValue,
      loanAccountNo: newValue === "Y" ? "" : uploadData.loanAccountNo,
      disbDate: newValue === "Y" ? "" : uploadData.disbDate,
    });

    // Clear loan account selection and disbursement date when switching to 'Y'
    if (newValue === "Y") {
      setSelectedLoanAccount(null);
      setSelectedDisbDate(null);
      setDisbursementDates([]);
    }
  };

  const MAX_SIZE_BYTES = 50 * 1024 * 1024;

  const isExcelFile = (file) => {
    if (!file) return false;

    const allowedMimeTypes = [
      "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ];
    const isMimeOk = allowedMimeTypes.includes(file.type);

    const name = file.name?.toLowerCase() || "";
    const hasValidExtension = name.endsWith(".xls") || name.endsWith(".xlsx");

    return isMimeOk || hasValidExtension;
  };

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileLoading(true);

    await new Promise((resolve) => setTimeout(resolve, 100));

    setUploadFile(file);
    setFileLoading(false);
    e.target.value = "";
  };

  const handleUploadSubmit = () => {
    if (!uploadFile) {
      setSnackbar({
        open: true,
        message: "Please select a file",
        severity: "warning",
      });
      return;
    }

    if (!isExcelFile(uploadFile)) {
      setSnackbar({
        open: true,
        message: "Invalid file type. Please upload an XLS or XLSX file.",
        severity: "error",
      });
      return;
    }

    if (uploadFile.size > MAX_SIZE_BYTES) {
      setSnackbar({
        open: true,
        message: "File is too large. Max allowed size is 50 MB.",
        severity: "error",
      });
      return;
    }

    if (!uploadData.bankName || !uploadData.cifNumber) {
      setSnackbar({
        open: true,
        message: "Please select a bank",
        severity: "warning",
      });
      return;
    }

    if (uploadData.benPreDisbFlag === "N" && !uploadData.loanAccountNo) {
      setSnackbar({
        open: true,
        message: "Please select a loan account",
        severity: "warning",
      });
      return;
    }

    if (uploadData.benPreDisbFlag === "N" && !uploadData.disbDate) {
      setSnackbar({
        open: true,
        message: "Please select disbursement date",
        severity: "warning",
      });
      return;
    }

    if (!uploadData.remarks.trim()) {
      setSnackbar({
        open: true,
        message: "Please enter remarks",
        severity: "warning",
      });
      return;
    }

    const completeUploadData = {
      ...uploadData,
      uploadBy: user?.ofrName,
      userCode: user?.ofrCode,
    };

    console.log("Uploading with data:", completeUploadData);

    validateMutation.mutate({
      file: uploadFile,
      data: completeUploadData,
    });
  };

  const displayErrors = validationErrors.slice(0, MAX_UI_ERRORS);
  const hasMoreErrors = validationErrors.length > MAX_UI_ERRORS;

  const isBusy =
    validateMutation.isPending || forwardMutation.isPending || fileLoading;

  return (
    <>
      {validationJobId && (
        <ValidationStatusBanner
          jobId={validationJobId}
          onCompleted={handleValidationCompleted}
          onFailed={handleValidationFailed}
        />
      )}
      {forwardMutation.isError && pendingForwardJobId && (
        <Alert
          severity="error"
          sx={{ mb: 2 }}
          action={
            <Button
              color="inherit"
              size="small"
              onClick={() => forwardMutation.mutate(pendingForwardJobId)}
            >
              Retry
            </Button>
          }
        >
          Validation passed but forwarding to DFS failed. You can retry without
          re-uploading.
        </Alert>
      )}

      {currentJobId && isJobProcessing && (
        <JobStatusBanner
          jobId={currentJobId}
          onJobComplete={handleJobComplete}
          onJobStatusChange={handleJobStatusChange}
        />
      )}

      <MaterialReactTable table={table} />

      <Dialog
        open={uploadDialogOpen}
        onClose={handleCloseDialog}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Upload Beneficiary Data</DialogTitle>
        <DialogContent>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 2, mt: 2 }}>
            <Autocomplete
              value={selectedVertical}
              onChange={handleVerticalChange}
              options={verticalOptions}
              getOptionLabel={(option) => option.label}
              loading={loadingVerticals}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Select Vertical"
                  required
                  InputProps={{
                    ...params.InputProps,
                    endAdornment: (
                      <>
                        {loadingVerticals ? (
                          <CircularProgress size={20} />
                        ) : null}
                        {params.InputProps.endAdornment}
                      </>
                    ),
                  }}
                />
              )}
              isOptionEqualToValue={(option, value) =>
                option.value === value.value
              }
            />

            <Autocomplete
              value={selectedBank}
              onChange={handleBankChange}
              options={bankOptions}
              getOptionLabel={(option) => option.label}
              loading={loadingBanks}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Select Bank"
                  required
                  InputProps={{
                    ...params.InputProps,
                    endAdornment: (
                      <>
                        {loadingBanks ? (
                          <CircularProgress color="inherit" size={20} />
                        ) : null}
                        {params.InputProps.endAdornment}
                      </>
                    ),
                  }}
                />
              )}
              isOptionEqualToValue={(option, value) =>
                option.value === value.value
              }
              disabled={!selectedVertical || loadingBanks}
            />

            <TextField
              label="CIF Number"
              value={uploadData.cifNumber}
              disabled
              fullWidth
              InputProps={{
                readOnly: true,
              }}
            />

            <FormControl component="fieldset">
              <FormLabel
                component="legend"
                sx={{ fontSize: "0.875rem", mb: 1 }}
              >
                Pre-Disbursement Flag <span style={{ color: "red" }}>*</span>
              </FormLabel>
              <RadioGroup
                row
                value={uploadData.benPreDisbFlag}
                onChange={handlePreDisbFlagChange}
              >
                <FormControlLabel value="Y" control={<Radio />} label="Yes" />
                <FormControlLabel
                  value="N"
                  control={<Radio />}
                  label="No"
                  //  disabled={loanAccountOptions.length === 0 && selectedBank}
                />
              </RadioGroup>
            </FormControl>

            {uploadData.benPreDisbFlag === "Y" ? (
              <Alert severity="info" sx={{ mt: 1 }}>
                Beneficiary reference number will be auto-generated from the
                system.
              </Alert>
            ) : (
              <>
                <Autocomplete
                  value={selectedLoanAccount}
                  onChange={handleLoanAccountChange}
                  options={loanAccountOptions}
                  getOptionLabel={(option) => option.label}
                  loading={loadingLoanAccounts}
                  disabled={!selectedBank || loadingLoanAccounts}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Select Loan Account"
                      required
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {loadingLoanAccounts ? (
                              <CircularProgress color="inherit" size={20} />
                            ) : null}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                  isOptionEqualToValue={(option, value) =>
                    option.value === value.value
                  }
                  noOptionsText={
                    selectedBank
                      ? "No loan accounts found"
                      : "Please select a bank first"
                  }
                />

                <Autocomplete
                  value={selectedDisbDate}
                  onChange={handleDisbDateChange}
                  options={disbursementDates}
                  getOptionLabel={(option) => option.label}
                  loading={loadingDisbDate}
                  disabled={!selectedLoanAccount || loadingDisbDate}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Select Disbursement Date"
                      required
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {loadingDisbDate ? (
                              <CircularProgress size={20} />
                            ) : null}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                  isOptionEqualToValue={(option, value) =>
                    option.value === value.value
                  }
                />
              </>
            )}

            <TextField
              label="Remarks"
              value={uploadData.remarks}
              onChange={(e) => {
                Pattern.sanitizeInput(e);
                setUploadData({ ...uploadData, remarks: e.target.value });
              }}
              fullWidth
              required
              multiline
              rows={1}
              placeholder="Enter remarks for this beneficiary"
            />

            <Box>
              <Button
                variant="outlined"
                component="label"
                startIcon={
                  fileLoading ? <CircularProgress size={20} /> : <AddIcon />
                }
                fullWidth
                disabled={fileLoading}
                sx={{
                  justifyContent: "flex-start",
                  textAlign: "left",
                  textTransform: "none",
                }}
              >
                {fileLoading ? (
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      gap: 1,
                      width: "100%",
                    }}
                  >
                    <Typography>Loading file...</Typography>
                  </Box>
                ) : uploadFile ? (
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      gap: 1,
                      width: "100%",
                    }}
                  >
                    <Typography noWrap sx={{ flex: 1 }}>
                      {uploadFile.name}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      ({(uploadFile.size / 1024).toFixed(2)} KB)
                    </Typography>
                  </Box>
                ) : (
                  "Select File to Upload"
                )}
                <input
                  type="file"
                  hidden
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                  accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
                  disabled={fileLoading}
                />
              </Button>

              {fileLoading && (
                <Box sx={{ mt: 1 }}>
                  <LinearProgress />
                  <Typography
                    variant="caption"
                    color="text.secondary"
                    sx={{ mt: 0.5, display: "block" }}
                  >
                    Processing file...
                  </Typography>
                </Box>
              )}

              {uploadFile && !fileLoading && (
                <Button
                  size="small"
                  color="error"
                  onClick={() => {
                    setUploadFile(null);

                    if (fileInputRef.current) {
                      fileInputRef.current.value = "";
                    }
                  }}
                  sx={{ mt: 1 }}
                >
                  Remove File
                </Button>
              )}
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          {isBusy && (
            <Box
              display="flex"
              alignItems="center"
              gap={1}
              sx={{ mr: "auto" }}
              aria-live="polite"
              role="status"
            >
              <CircularProgress size={18} />
              <Typography variant="body2" color="text.secondary">
                Uploading… Please don't close this dialog.
              </Typography>
            </Box>
          )}

          <Button onClick={handleCloseDialog} disabled={isBusy}>
            Cancel
          </Button>
          <Button
            onClick={handleUploadSubmit}
            variant="contained"
            disabled={isBusy}
          >
            {validateMutation.isPending ? (
              <CircularProgress size={24} />
            ) : (
              "Upload"
            )}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Job Status Check Dialog */}
      <Dialog
        open={statusDialogOpen}
        onClose={() => setStatusDialogOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>DFS Upload Status</DialogTitle>
        <DialogContent>
          {currentJobId && (
            <JobStatusBanner
              jobId={currentJobId}
              onJobComplete={handleJobComplete}
              onJobStatusChange={handleJobStatusChange}
            />
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setStatusDialogOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={errorDialogOpen}
        onClose={() => setErrorDialogOpen(false)}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>Validation Errors ({validationErrors.length})</DialogTitle>

        <DialogContent>
          {hasMoreErrors && (
            <Alert severity="warning" sx={{ mb: 2 }}>
              Showing first 20 errors. Download the report for full details.
            </Alert>
          )}

          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Row</TableCell>
                <TableCell>Field</TableCell>
                <TableCell>Error</TableCell>
                <TableCell>Value</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {displayErrors.map((err, index) => (
                <TableRow key={index}>
                  <TableCell>{err.rowNumber}</TableCell>
                  <TableCell>{err.fieldName}</TableCell>
                  <TableCell>{err.errorMessage}</TableCell>
                  <TableCell>{err.fieldValue}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </DialogContent>

        <DialogActions>
          {hasMoreErrors && (
            <Button variant="contained" onClick={downloadErrorReport}>
              Download Full Error Report
            </Button>
          )}

          <Button onClick={() => setErrorDialogOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          sx={{ width: "100%" }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
}

export default function BeneficiarySummaryPage() {
  return (
    <QueryClientProvider client={queryClient}>
      <BeneficiaryTable />
    </QueryClientProvider>
  );
}
