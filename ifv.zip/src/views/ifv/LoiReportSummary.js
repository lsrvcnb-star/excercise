import DownloadIcon from '@mui/icons-material/Download';
import RefreshIcon from '@mui/icons-material/Refresh';
import { Box, IconButton, Tooltip } from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import {
    QueryClient,
    QueryClientProvider,
    keepPreviousData,
    useQuery
} from '@tanstack/react-query';
import axios from 'axios';
import { format } from 'date-fns';
import {
    MaterialReactTable,
    useMaterialReactTable,
} from 'material-react-table';
import { useEffect, useMemo, useState } from 'react';
import MinutesService from 'services/MinutesService';
import FileUtil from 'services/utils/FileUtil';
import { getJwtToken } from 'services/utils/JwtUtil';

const LoiSummary = () => {
    const [columnFilters, setColumnFilters] = useState([]);
    const [globalFilter, setGlobalFilter] = useState('');
    const [sorting, setSorting] = useState([]);
    const [loading, setLoading] = useState(null);
    const [pagination, setPagination] = useState({
        pageIndex: 0,
        pageSize: 10,
    });
    const {
        data: queryData,
        isError,
        isRefetching,
        isLoading,
        refetch,
        error,
    } = useQuery({
        queryKey: [
            'table-data',
            columnFilters,
            globalFilter,
            pagination.pageIndex,
            pagination.pageSize,
            sorting,
        ],
        queryFn: async () => {
            const url = new URL(`${process.env.REACT_APP_API_ENDPOINT}loi-details/getAllOnUserTypeOnPage`);
            url.searchParams.set('start', `${pagination.pageIndex * pagination.pageSize}`);
            url.searchParams.set('size', `${pagination.pageSize}`);
            url.searchParams.set('filters', JSON.stringify(columnFilters ?? []));
            url.searchParams.set('globalFilter', globalFilter);
            url.searchParams.set('sorting', JSON.stringify(sorting ?? []));
            try {
                const response = await axios.get(url.href, {
                    headers: { Authorization: `Bearer ${getJwtToken()}` },
                });
                return response.data;
            } catch (error) {
                console.error('Backend error while loading data:', error);
                alert('ERR_BAD_RESPONSE');
                throw error;
            }
        },
        placeholderData: keepPreviousData,
    });
    const tableData = queryData?.content ?? [];
    const totalRows = queryData?.totalElements ?? 0;
    useEffect(() => {
        if (isError && error) {
            console.error('Query error:', error);
            alert('ERR_BAD_RESPONSE');
        }
    }, [isError, error]);
    const columns = useMemo(() => [
        {
            accessorKey: 'ifvNo',
            header: 'IFV No',
            size: 200,
        },
        {
            accessorKey: 'ifvName',
            header: 'IFV Name',
            size: 100,
        },
        {
            accessorKey: 'ifvDate',
            header: 'IFV Date',
            size: 100,
            Cell: ({ cell }) => format(new Date(cell.getValue()), 'dd-MM-yyyy'),
        },
        {
            accessorKey: 'loiUser',
            header: 'LoI User',
            size: 150,
        },
    ], []);
    const handleDownload = async (id) => {
        setLoading(id);
        try {
            const response = await MinutesService.findByLoiId(id);
            FileUtil.downloadFile(response.data.fileDataBytea, response.data.fileName, "application/pdf");
        } catch (error) {
            const resMessage =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            console.log(resMessage);
            alert('Error occurred while generating report')
        } finally {
            setLoading(null);
        }
    };
    const table = useMaterialReactTable({
        columns,
        data: tableData,
        createDisplayMode: 'modal',
        editDisplayMode: 'modal',
        enableEditing: true,
        getRowId: (row) => row.id,
        muiTableContainerProps: {
            sx: {
                minHeight: '500px',
            },
        },
        initialState: { showColumnFilters: true },
        manualFiltering: true,
        manualPagination: true,
        manualSorting: true,
        muiToolbarAlertBannerProps: isError
            ? {
                color: 'error',
                children: error?.response?.data?.message || 'Error loading data',
            }
            : undefined,
        onColumnFiltersChange: setColumnFilters,
        onGlobalFilterChange: setGlobalFilter,
        onPaginationChange: setPagination,
        onSortingChange: setSorting,
        renderTopToolbarCustomActions: () => (
            <Tooltip arrow title="Refresh Data">
                <IconButton onClick={() => refetch()}>
                    <RefreshIcon />
                </IconButton>
            </Tooltip>
        ),
        renderRowActions: ({ row, table }) => (
            <Box sx={{ display: 'flex' }}>
                <Tooltip title="Download">
                    <IconButton
                        onClick={() => handleDownload(row.original.id)}
                        sx={{ color: loading === row.original.id ? 'gray' : 'primary.main' }}
                        disabled={loading === row.original.id}
                    >
                        {loading === row.original.id ? (
                            <CircularProgress size={24} />
                        ) : (
                            <DownloadIcon />
                        )}
                    </IconButton>
                </Tooltip>
            </Box >
        ),
        rowCount: totalRows,
        state: {
            columnFilters,
            globalFilter,
            isLoading,
            pagination,
            showAlertBanner: isError,
            showProgressBars: isRefetching,
            sorting,
        },
        enableRowNumbers: true,
        rowNumberDisplayMode: 'static',
        muiDetailPanelProps: () => ({
            sx: (theme) => ({
                backgroundColor:
                    theme.palette.mode === 'dark'
                        ? 'rgba(255,210,244,0.1)'
                        : 'rgba(0,0,0,0.1)',
            }),
        }),
    });
    return <MaterialReactTable table={table} />;
};
const queryClient = new QueryClient();
const LoiReportsSummary = () => (
    <QueryClientProvider client={queryClient}>
        <LoiSummary />
    </QueryClientProvider>
);
export default LoiReportsSummary;