import Loading from 'components/Loading';
import MessageModal from 'components/MessageModal';
import ProposalHeader from 'components/ProposalHeader';
import SectionNavigation from 'components/SectionNavigation';
import { useErrorHandler } from 'hooks/useErrorHandler';
import useMessageModal from 'hooks/useMessageModal';
import { Fragment, useEffect, useState } from 'react';
import Accordion from 'react-bootstrap/Accordion';
import ReactDatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { Controller, useFieldArray, useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
import IfvAppraisalService from 'services/IfvAppraisalService';
import UserService from 'services/UserService';
import CommonUtil from 'services/utils/CommonUtil';
import Pattern from 'services/validators/Pattern';

const SectionOne = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const showSFB = location.state ? location.state.showSFB : null;
  const appId = location.state ? location.state.appId : 0;
  const [loading, setLoading] = useState(false);

  const { control, register, handleSubmit, formState: { errors } } = useForm({
    mode: "onBlur"
  });

  const { control: control2, register: register2, handleSubmit: handleSubmitOfKeyProducts, setValue, getValues: getValues2, formState: { errors: errors2 }, } = useForm({
    mode: "onBlur"
  });

  const { control: control3, register: register3, handleSubmit: handleSubmitOfChiefFuncBoard, setValue: setValue3, getValues: getValues3, formState: { errors: errors3 }, } = useForm({
    mode: "onBlur"
  });

  const { control: control5, register: register5, handleSubmit: handleSubmitOfKeyInvestors, setValue: setValue5, getValues: getValues5, formState: { errors: errors5 }, } = useForm({
    mode: "onBlur",
    // defaultValues: {
    //   keyInvestors: [{ kiHolder: "Individual" }, { kiHolder: "Staff" }, { kiHolder: "Pvt. Ltd. Company" }, { kiHolder: "Partnership" },
    //   { kiHolder: "Proprietorship" }, { kiHolder: "Trust" }, { kiHolder: "Public Ltd. Company" }, { kiHolder: "H.U.F." }, { kiHolder: "Others" },
    //   { kiHolder: "LLP(Limited Liability Partnership)" }, { kiHolder: "Other Institutions" }, { kiHolder: "AOP/UnIncorporated Association" }, { kiHolder: "Association/Club" }]
    // },
  });

  const { control: control7, register: register7, handleSubmit: handleSubmitOfKeyOtherInvestors, setValue: setValue7, getValues: getValues7, formState: { errors: errors7 }, } = useForm({
    mode: "onBlur",
    defaultValues: {
      otherKeyInvestors: [{ kiHolder: "Promoter" }, { kiHolder: "Promoter group" }, { kiHolder: "Investor" }, { kiHolder: "Non-Promotors" },
      ]
    },
  });

  const { control: ucbBorrowersDetailContol, register: ucbBorrDetailRegister, handleSubmit: handleSubmitOfUcbBorrowersDetail, setValue: setValueOfUcbBorrowers, getValues: getValuesOfUcbBorrowers, formState: { errors: errorsInUcbBorrowers }, } = useForm({
    mode: "onBlur"
  });

  const { fields: fields1, append: append1, remove: remove1 } = useFieldArray({
    control, // control props comes from useForm (optional: if you are using FormContext)
    name: "kycDto", // unique name for your Field Array
  });

  const { fields: fields2, append: append2, remove: remove2 } = useFieldArray({
    control, // control props comes from useForm (optional: if you are using FormContext)
    name: "chiefBoard", // unique name for your Field Array
  });

  const { fields: fields4, append: append4, remove: remove4 } = useFieldArray({
    control: control5, // control props comes from useForm (optional: if you are using FormContext)
    name: "keyInvestors", // unique name for your Field Array
  });

  const { fields: fields6, append: append6, remove: remove6 } = useFieldArray({
    control, // control props comes from useForm (optional: if you are using FormContext)
    name: "otherKeyInvestors", // unique name for your Field Array
  });

  const { fields: fields11, append: append11, remove: remove11 } = useFieldArray({
    control, // control props comes from useForm (optional: if you are using FormContext)
    name: "kycDto1", // unique name for your Field Array
  });

  const { fields: fields12, append: append12, remove: remove12 } = useFieldArray({
    control, // control props comes from useForm (optional: if you are using FormContext)
    name: "kycDto2", // unique name for your Field Array
  });

  const {
    showMessage,
    hideMessage,
    isOpen,
    messageConfig,
    totalMessages,
    currentIndex,
    nextMessage,
    prevMessage,
    hasNext,
    hasPrev
  } = useMessageModal();
  const { handleApiError } = useErrorHandler(showMessage);

  const [sharePortfolio, setSharePortfolio] = useState('')
  const [sfShareholdingpattern, setShareHoldingPattern] = useState('')
  const [ucb, setUcb] = useState(false)
  const [rrb, setRRB] = useState(false)
  const [ucbSegPortfolioDate, setUcbSegPortfolioDate] = useState('')
  const [ucbSeg2PortfolioDate, setUcbSeg2PortfolioDate] = useState('')
  const [locked, setLocked] = useState(false)
  const [ifvApp, setIfvApp] = useState({})
  const [editable, setEditable] = useState(false)
  const [isMaker, setMaker] = useState(false)

  useEffect(() => {
    if (showSFB === null) {
      alert('Invalid scheme')
      navigate(-1);
    }
    const user = IfvAppraisalService.getCurrentUser();
    setMaker(UserService.isMaker(user))

    IfvAppraisalService.getIfvAppById(appId).then(response => {
      setIfvApp(response.data)
      if (response.data.ifvBankType === 'UCB') {
        setUcb(true)
        setRRB(false)
        getUcbBorrowersDetailByIfvId()
      } else if (response.data.ifvBankType === 'RRB') {
        setUcb(false)
        setRRB(true)
      } else {
        setUcb(false)
        setRRB(false)
      }
    })
      .catch(error => {
        handleApiError(error, 'loading IFV application')
      })
    if (appId > 0) {
      getKeyProductsByIfvId()
      getChiefBoardByIfvId()
      getKeyInvestorsByIfvId()
      getTblFwdDetail()
      getCommonData()
    }
  }, []);

  const [appStatus, setAppStatus] = useState('')

  const getTblFwdDetail = () => {
    IfvAppraisalService.getTblFwdDetail(appId)
      .then((response) => {
        const status = response.data.appStatus
        switch (status) {
          case 'LK':
            setLocked(true)
            setEditable(false)
            setAppStatus('Locked')
            break
          case 'NW':
            setLocked(false)
            setEditable(true)
            setAppStatus('New')
            break
          case 'CN':
            setLocked(false)
            setEditable(false)
            setAppStatus('Confirmed')
            break
          case 'AP':
            setLocked(false)
            setEditable(false)
            setAppStatus('Approved')
            break
        }
      })
      .catch(error => {
        handleApiError(error, 'loading TBL data')
      })
  }

  const [sumOfSeg1Portfolio, setSumOfSeg1Portfolio] = useState(0)
  const [sumOfSeg2Portfolio, setSumOfSeg2Portfolio] = useState(0)

  const getKeyProductsByIfvId = () => {
    setLoading(true)
    IfvAppraisalService.getKeyProductsByIfvId(appId).then(response => {
      const appData = response.data.listKycDto

      if (!CommonUtil.isEmpty(response.data.sfbCommondtDTO)) {
        if (response.data.sfbCommondtDTO.sfbShareportfoliodate != null) {
          setSharePortfolio(new Date(response.data.sfbCommondtDTO.sfbShareportfoliodate))
        }

        if (response.data.sfbCommondtDTO.ucbSegPortfolioDate != null) {
          setUcbSegPortfolioDate(new Date(response.data.sfbCommondtDTO.ucbSegPortfolioDate))
        }

        if (response.data.sfbCommondtDTO.ucbSeg2PortfolioDate != null) {
          setUcbSeg2PortfolioDate(new Date(response.data.sfbCommondtDTO.ucbSeg2PortfolioDate))
        }

        if (response.data.sfbCommondtDTO.ucbSeg2Note != null) {
          setUcbSeg2Note(response.data.sfbCommondtDTO.ucbSeg2Note)
        }

        if (!CommonUtil.isEmpty(response.data.sfbCommondtDTO.sfbId)) {
          setChiefFuncId(response.data.sfbCommondtDTO.sfbId)
        }
      }

      const topFiveKycData = appData?.filter(item => item.kycType === 'TopFiveKyc' || CommonUtil.isEmpty(item.kycType))
      const ucbSegmentOneData = appData?.filter(item => item.kycType === 'UcbSegmentOne')
      const ucbSegment2Data = appData?.filter(item => item.kycType === 'UcbSegmentTwo')

      if (topFiveKycData.length <= 0) {
        for (let i = 0; i < 5; i++) {
          append1({})
        }
      }
      if (ucbSegmentOneData.length <= 0) {
        for (let i = 0; i < 5; i++) {
          append11({})
        }
      }
      if (ucbSegment2Data.length <= 0) {
        for (let i = 0; i < 5; i++) {
          append12({})
        }
      }
      topFiveKycData.forEach((item, index) => {
        remove1(index)
        append1({})
        setValue(`kycDto[${index}].kycId`, item.kycId)
        setValue(`kycDto[${index}].ifvId`, item.ifvId)
        setValue(`kycDto[${index}].kycProductName`, item.kycProductName)
        setValue(`kycDto[${index}].kycAmount`, item.kycAmount)
        setValue(`kycDto[${index}].kycShareProfile`, item.kycShareProfile)
      });
      let seg1Os = 0
      let seg1Portfolio = 0
      ucbSegmentOneData.forEach((item, index) => {
        remove11(index)
        append11({})
        setValue(`kycDto1[${index}].kycId`, item.kycId)
        setValue(`kycDto1[${index}].ifvId`, item.ifvId)
        setValue(`kycDto1[${index}].kycProductName`, item.kycProductName)
        setValue(`kycDto1[${index}].kycAmount`, item.kycAmount)
        setValue(`kycDto1[${index}].kycShareProfile`, item.kycShareProfile)
        seg1Os = parseFloat(seg1Os) + parseFloat(item.kycAmount)
        seg1Portfolio = parseFloat(seg1Portfolio) + parseFloat(item.kycShareProfile)
      });
      setSumOfSeg1Os(CommonUtil.roundToTwoDecimals(seg1Os))
      setSumOfSeg1Portfolio(seg1Portfolio)

      let seg2Os = 0
      let seg2Portfolio = 0
      ucbSegment2Data.forEach((item, index) => {
        remove12(index)
        append12({})
        setValue(`kycDto2[${index}].kycId`, item.kycId)
        setValue(`kycDto2[${index}].ifvId`, item.ifvId)
        setValue(`kycDto2[${index}].kycProductName`, item.kycProductName)
        setValue(`kycDto2[${index}].kycAmount`, item.kycAmount)
        setValue(`kycDto2[${index}].kycShareProfile`, item.kycShareProfile)
        seg2Os = parseFloat(seg2Os) + parseFloat(item.kycAmount)
        seg2Portfolio = parseFloat(seg2Portfolio) + parseFloat(item.kycShareProfile)
      });

      setSumOfSeg2Os(CommonUtil.roundToTwoDecimals(seg2Os))
      setSumOfSeg2Portfolio(seg2Portfolio)
      setLoading(false)
    })
      .catch(error => {
        setLoading(false)
        handleApiError(error, 'loading details of Key Products')
      })
  }

  const getChiefBoardByIfvId = () => {
    IfvAppraisalService.getChiefBoardByIfvId(appId).then(response => {
      const appData = response.data

      if (appData.length > 0) {
        for (let i = 0; i < appData.length; i++) {
          remove2(i)
          append2({})
        }
      }
      else {
        for (let i = 0; i < 3; i++) {
          append2({})
        }
      }

      appData.forEach((item, index) => {
        setValue3(`chiefBoard[${index}].cbId`, item.cbId)
        setValue3(`chiefBoard[${index}].ifvId`, item.ifvId)
        setValue3(`chiefBoard[${index}].cbName`, item.cbName)
        setValue3(`chiefBoard[${index}].cbDesignation`, item.cbDesignation)
        setValue3(`chiefBoard[${index}].cbRemarks`, item.cbRemarks)
      });
    })
      .catch(error => {
        handleApiError(error, 'loading Chief Functionality & Board')
      })

  }

  const [sumOfkeyInvestorCountOne, setSumOfkeyInvestorCountOne] = useState(0)
  const [sumOfkeyInvestorHoldingOne, setSumOfkeyInvestorHoldingOne] = useState(0)
  const [sumOfkeyInvestorProportionOne, setSumOfkeyInvestorProportionOne] = useState(0)
  const [sumOfOtherkeyInvestorProportionOne, setSumOfOtherkeyInvestorProportionOne] = useState(0)

  const [sumOfSeg1Os, setSumOfSeg1Os] = useState(0)
  const [sumOfSeg2Os, setSumOfSeg2Os] = useState(0)

  const getKeyInvestorsByIfvId = () => {

    IfvAppraisalService.getKeyInvestorsByIfvId(appId).then(response => {
      const appData = response.data.listInvestorDTO

      if (response.data.sfbCommondtDTO != null && response.data.sfbCommondtDTO.sfShareholdingpattern != null) {
        setShareHoldingPattern(new Date(response.data.sfbCommondtDTO.sfShareholdingpattern))
        setKeyInvestorsNote(response.data.sfbCommondtDTO.cmKeyInvestorsNote)
      }

      const keyData = appData.filter(item => item.kiType !== 'Other');
      const otherKeyData = appData.filter(item => item.kiType === 'Other');

      let sum1 = 0, sum2 = 0, sum3 = 0;

      if (keyData.length > 0) {

        keyData.forEach((item, index) => {
          remove4(index)
          append4({})
          setValue5(`keyInvestors[${index}].kiId`, item.kiId)
          setValue5(`keyInvestors[${index}].ifvId`, item.ifvId)
          setValue5(`keyInvestors[${index}].kiHolder`, item.kiHolder)
          setValue5(`keyInvestors[${index}].kiCount`, item.kiCount)
          setValue5(`keyInvestors[${index}].kiHolding`, item.kiHolding)
          setValue5(`keyInvestors[${index}].kiPproportion`, item.kiPproportion)

          sum1 = sum1 + item.kiCount;
          sum2 = sum2 + item.kiHolding;
          sum3 = sum3 + item.kiPproportion;

        });
      }
      setSumOfkeyInvestorCountOne(CommonUtil.roundToTwoDecimals(sum1))
      setSumOfkeyInvestorHoldingOne(CommonUtil.roundToTwoDecimals(sum2))
      setSumOfkeyInvestorProportionOne(CommonUtil.roundToTwoDecimals(sum3))

      let sum9 = 0;

      if (otherKeyData.length > 0) {
        for (let i = 0; i < otherKeyData.length; i++) {
          remove6(i)
          append6({})
        }
        otherKeyData.forEach((item, index) => {
          setValue7(`otherKeyInvestors[${index}].kiId`, item.kiId)
          setValue7(`otherKeyInvestors[${index}].ifvId`, item.ifvId)
          setValue7(`otherKeyInvestors[${index}].kiHolder`, item.kiHolder)
          setValue7(`otherKeyInvestors[${index}].kiCount`, item.kiCount)
          setValue7(`otherKeyInvestors[${index}].kiHolding`, item.kiHolding)
          setValue7(`otherKeyInvestors[${index}].kiPproportion`, item.kiPproportion)
          setValue7(`otherKeyInvestors[${index}].kiType`, item.kiType)
          sum9 = sum9 + item.kiPproportion
        });

        setSumOfOtherkeyInvestorProportionOne(CommonUtil.roundToTwoDecimals(sum9))
      } else {
        for (let i = 0; i < 4; i++) {
          append6({})
        }
      }
    },
      (error) => {
        handleApiError(error, 'loading Key Investors')
      })
  }

  const onSubmitOfKeyProducts = (data, e) => {
    setLoading(true)
    const res = CommonUtil.validateDate(sharePortfolio)
    if (res === true) {
    } else {
      setLoading(false)
      showMessage('Please enter valid % share in portfolio date', 'warning')
      return
    }

    if (ucb) {
      const res1 = CommonUtil.validateDate(ucbSegPortfolioDate)
      if (res1 === true) {
      } else {
        setLoading(false)
        showMessage('Please enter valid % share in portfolio date', 'warning')
        return
      }
    }

    const sfbCommondtDTO = {
      ifvId: appId,
      sfbShareportfoliodate: sharePortfolio,
      ucbSegPortfolioDate: ucbSegPortfolioDate,
      ucbSeg2PortfolioDate: ucbSeg2PortfolioDate,
      ucbSeg2Note: ucbSeg2Note
    }

    const listKycDto = data['kycDto'].filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.kycProductName))

    if (CommonUtil.isEmpty(listKycDto)) {
      setLoading(false)
      showMessage('Please enter data', 'warning')
      return
    }

    let finalKYCData = listKycDto

    if (ucb) {
      const listKycDto1 = data['kycDto1']?.filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.kycProductName))
      if (!CommonUtil.isEmpty(listKycDto1)) {
        finalKYCData = [...finalKYCData, ...listKycDto1]
      }

      const listKycDto2 = data['kycDto2']?.filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.kycProductName))
      if (!CommonUtil.isEmpty(listKycDto2)) {
        finalKYCData = [...finalKYCData, ...listKycDto2]
      }
    }

    const finalData = {
      listKycDto: finalKYCData,
      sfbCommondtDTO: sfbCommondtDTO
    }

    IfvAppraisalService.saveKeyProducts(finalData).then((response) => {
      getKeyProductsByIfvId()
      setLoading(false)
      showMessage('Key product details have been successfully saved!', 'success')
    },
      (error) => {
        setLoading(false)
        handleApiError(error, 'saving Key Products')
      })
  }

  const onSubmitOfKeyInvestors = (data, e) => {
    setLoading(true)
    const sfbCommondtDTO = {
      ifvId: appId,
      cmKeyInvestorsNote: keyInvestorsNote
    }

    const listInvestorDTO = data['keyInvestors'].filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.kiHolder))
    if (CommonUtil.isEmpty(listInvestorDTO)) {
      setLoading(false)
      showMessage('Please enter data', 'warning')
      return
    }

    const finalData = {
      listInvestorDTO: listInvestorDTO,
      sfbCommondtDTO: sfbCommondtDTO
    }

    IfvAppraisalService.saveKeyInvestors(finalData).then((response) => {
      getKeyInvestorsByIfvId()
      setLoading(false)
      showMessage('Key Investors details have been successfully saved!', 'success')
    },
      (error) => {
        setLoading(false)
        handleApiError(error, 'saving Key Investors')
      })
  }

  const onSubmitOfOtherKeyInvestors = (data, e) => {
    setLoading(true)
    const sfbCommondtDTO = {
      ifvId: appId,
      cmKeyInvestorsNote: keyInvestorsNote
    }

    const listInvestorDTO = data['otherKeyInvestors'].filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.kiHolder) && !CommonUtil.isEmpty(item.kiPproportion))
    if (CommonUtil.isEmpty(listInvestorDTO)) {
      setLoading(false)
      showMessage('Please enter data', 'warning')
      return
    }

    const finalData = {
      listInvestorDTO: listInvestorDTO,
      sfbCommondtDTO: sfbCommondtDTO
    }

    IfvAppraisalService.saveKeyInvestors(finalData).then((response) => {
      getKeyInvestorsByIfvId()
      setLoading(false)
      showMessage('Key Investors details have been successfully saved!', 'success')
    },
      (error) => {
        setLoading(false)
        handleApiError(error, 'saving Key Investors')
      })
  }

  function goToNext() {
    navigate('/ifv/sectionTwo', {
      state: {
        showSFB: showSFB,
        appId: appId
      }
    });
  }

  function goToPrev() {
    navigate('/ifv/basic', {
      state: {
        showSFB: showSFB,
        appId: appId
      }
    });
  }

  const calculateKiCountOne = (field, value) => {
    setValue5(field, value, { shouldValidate: true })
    let sum = 0;
    fields4.map((item, index) => {
      const val = getValues5(`keyInvestors[${index}].kiCount`)
      const holder = getValues5(`keyInvestors[${index}].kiHolder`)

      if (holder === 'Promoter' || holder === 'Promoter group' || holder === 'Investor'
        || holder === 'Non-Promotors') {

        if (CommonUtil.isValidNumber(val)) {
          sum = sum + parseFloat(val)
        }
      }
    })
    setSumOfkeyInvestorCountOne(sum)
  }

  const handleKeyDetailsDelete = (index) => {
    setLoading(true)
    const id = getValues2(`kycDto[${index}].kycId`)
    if (CommonUtil.isValidNumber(id)) {
      IfvAppraisalService.deleteKyc(id).then((response) => {
        setValue(`kycDto[${index}]`, undefined)
        remove1(index)
        getKeyProductsByIfvId()
        setLoading(false)
        showMessage('Key detail deleted successfully!', 'success')
      },
        (error) => {
          setLoading(false)
          handleApiError(error, 'deleting key details')
        }
      )
    } else {
      setValue(`kycDto[${index}]`, undefined)
      remove1(index)
      setLoading(false)
    }
  }

  const handleKeyDetails1Delete = (index) => {
    setLoading(true)
    const id = getValues2(`kycDto1[${index}].kycId`)
    if (CommonUtil.isValidNumber(id)) {
      IfvAppraisalService.deleteKyc(id).then((response) => {
        setValue(`kycDto1[${index}]`, undefined)
        remove11(index)
        getKeyProductsByIfvId()
        setLoading(false)
        showMessage('Key detail deleted successfully!', 'success')
      },
        (error) => {
          setLoading(false)
          handleApiError(error, 'deleting key details')
        }
      )
    } else {
      setValue(`kycDto1[${index}]`, undefined)
      remove11(index)
      setLoading(false)
    }
  }

  const deleteOtherKeyInvestors = (index) => {
    setLoading(true)
    const id = getValues7(`otherKeyInvestors[${index}].kiId`)
    const noOfProp = getValues7(`otherKeyInvestors[${index}].kiPproportion`)
    if (CommonUtil.isValidNumber(id)) {
      IfvAppraisalService.deleteOtherKeyInvestors(id).then((response) => {
        setValue7(`otherKeyInvestors[${index}]`, undefined)
        remove6(index)
        setSumOfOtherkeyInvestorProportionOne(CommonUtil.roundToTwoDecimals(sumOfOtherkeyInvestorProportionOne - noOfProp))
        getKeyInvestorsByIfvId()
        setLoading(false)
        showMessage('Other key investors detail deleted successfully!', 'success')
      },
        (error) => {
          setLoading(false)
          handleApiError(error, 'deleting Other key investors')
        }
      )
    } else {
      setValue7(`otherKeyInvestors[${index}]`, undefined)
      remove6(index)
      setSumOfOtherkeyInvestorProportionOne(CommonUtil.roundToTwoDecimals(sumOfOtherkeyInvestorProportionOne - noOfProp))
      setLoading(false)
    }
  }

  const deleteKeyInvestors = (index) => {
    setLoading(true)
    const id = getValues5(`keyInvestors[${index}].kiId`)
    const noOfProp = getValues5(`keyInvestors[${index}].kiPproportion`)
    if (CommonUtil.isValidNumber(id)) {
      IfvAppraisalService.deleteOtherKeyInvestors(id).then((response) => {
        setValue5(`keyInvestors[${index}]`, undefined)
        remove4(index)
        setSumOfOtherkeyInvestorProportionOne(CommonUtil.roundToTwoDecimals(sumOfOtherkeyInvestorProportionOne - noOfProp))
        getKeyInvestorsByIfvId()
        setLoading(false)
        showMessage('Key investors detail deleted successfully!', 'success')
      },
        (error) => {
          handleApiError(error, 'deleting key investors')
        }
      )
    } else {
      setValue5(`otherKeyInvestors[${index}]`, undefined)
      remove4(index)
      setSumOfOtherkeyInvestorProportionOne(CommonUtil.roundToTwoDecimals(sumOfOtherkeyInvestorProportionOne - noOfProp))
      setLoading(false)
    }
  }

  const calculateOtherKycTotal = (field, value) => {
    setValue7(field, value, { shouldValidate: true })
    let sum = 0;
    fields6.map((item, index) => {
      let val = getValues7(`otherKeyInvestors[${index}].kiPproportion`)
      if (CommonUtil.isValidNumber(val)) {
        sum = sum + parseFloat(val)
      }

    })
    setSumOfOtherkeyInvestorProportionOne(CommonUtil.roundToTwoDecimals(sum))
  }

  const [chiefFunc, setChiefFunc] = useState('')
  const [geoAreaNote, setGeoAreaNote] = useState('')
  const [chiefFuncId, setChiefFuncId] = useState(null)

  const [ucsRegulatoryEnvironment, setUcsRegulatoryEnvironment] = useState('')
  const [ucsBriefParticulars, setUcsBriefParticulars] = useState('')
  const [ucsDirectorExposure, setUcsDirectorExposure] = useState('')
  const [ucsInstitutionalBorrowings, setUcsInstitutionalBorrowings] = useState('')

  const [ucbSeg2Note, setUcbSeg2Note] = useState('')

  const saveChiefFunc = () => {
    setLoading(true)
    const data = {
      ifvId: appId,
      cmChiefFuncNote: chiefFunc,
      sfbId: chiefFuncId,
      cmGeoAreaNote: geoAreaNote,
      ucsRegulatoryEnvironment: ucsRegulatoryEnvironment,
      ucsBriefParticulars: ucsBriefParticulars,
      ucsDirectorExposure: ucsDirectorExposure,
      ucsInstitutionalBorrowings: ucsInstitutionalBorrowings

    }

    IfvAppraisalService.saveCommonData(data).then((response) => {
      showMessage('Data has been successfully saved!', 'success')
      setChiefFunc(response.data.cmChiefFuncNote)
      setGeoAreaNote(response.data.cmGeoAreaNote)
      setChiefFuncId(response.data.sfbId)
      setUcsRegulatoryEnvironment(response.data.ucsRegulatoryEnvironment)
      setUcsBriefParticulars(response.data.ucsBriefParticulars)
      setUcsInstitutionalBorrowings(response.data.ucsInstitutionalBorrowings)
      setUcsDirectorExposure(response.data.ucsDirectorExposure)
      setLoading(false)
    },
      (error) => {
        setLoading(false)
        handleApiError(error, 'saving..')
      })
  }

  const getCommonData = () => {
    // setLoading(true)
    IfvAppraisalService.getCommonData(appId).then(response => {
      if (!CommonUtil.isEmpty(response.data.cmChiefFuncNote)) {
        setChiefFunc(response.data.cmChiefFuncNote)
      }
      if (!CommonUtil.isEmpty(response.data.cmGeoAreaNote)) {
        setGeoAreaNote(response.data.cmGeoAreaNote)
      }

      if (!CommonUtil.isEmpty(response.data.ucsRegulatoryEnvironment)) {
        setUcsRegulatoryEnvironment(response.data.ucsRegulatoryEnvironment)
      } else {
        setUcsRegulatoryEnvironment('In terms of section 35(6) of the Banking Regulation Act, 1949, RRBs are regulated by RBI and supervised/inspected by NABARD.\nThe financials of RRBs are being monitored by RBI by way of “Empowered Committee of RRBs”, the meeting of which would be conducted on a quarterly basis under the chairmanship of the Regional Director, RBI of that jurisdiction.')
      }

      if (!CommonUtil.isEmpty(response.data.ucsBriefParticulars)) {
        setUcsBriefParticulars(response.data.ucsBriefParticulars)
      }

      if (!CommonUtil.isEmpty(response.data.ucsInstitutionalBorrowings)) {
        setUcsInstitutionalBorrowings(response.data.ucsInstitutionalBorrowings)
      }

      if (!CommonUtil.isEmpty(response.data.ucsDirectorExposure)) {
        setUcsDirectorExposure(response.data.ucsDirectorExposure)
      }

      setChiefFuncId(response.data.sfbId)

      setKeyInvestorsNote(response.data.cmKeyInvestorsNote)
      setLoading(false)
    },
      (error) => {
        setLoading(false)
        handleApiError(error, 'loading..')
      })
  }

  const getUcbBorrowersDetailByIfvId = () => {
    setLoading(true)
    IfvAppraisalService.getUcbBorrowersDetailByIfvId(appId).then(response => {
      const appData = response.data
      setValueOfUcbBorrowers('id', appData.id)
      setValueOfUcbBorrowers('ifvId', appId)
      setValueOfUcbBorrowers('totBorrowers', appData.totBorrowers)
      setValueOfUcbBorrowers('totMsmeCustomers', appData.totMsmeCustomers)
      setValueOfUcbBorrowers('totCorpBorrowers', appData.totCorpBorrowers)
      setValueOfUcbBorrowers('remarks', appData.remarks)

      setLoading(false)
    },
      (error) => {
        setLoading(false)
        handleApiError(error, 'loading details of Top Borrowers')
      }
    )
  }

  const onSubmitOfUcbBorrowersDetail = (data, e) => {
    setLoading(true)

    IfvAppraisalService.saveUcbBorrowersDetail(data).then((response) => {
      getUcbBorrowersDetailByIfvId()
      setLoading(false)
      showMessage('UCB borrowers details have been successfully saved!', 'success')
    },
      (error) => {
        setLoading(false)
        handleApiError(error, 'saving UCB borrowers details')
      })
  }

  const [keyInvestorsNote, setKeyInvestorsNote] = useState('')

  return (
    <Fragment>
      <div className={loading ? 'frgmnt blur-background' : 'frgmnt'}>
        {appId > 0 && <SectionNavigation activeView={'Section One'} showSFB={showSFB} appId={appId} />}
        <ProposalHeader
          bankName={ifvApp.ifvName}
          appNumber={ifvApp.appNumber}
          status={appStatus}
          appId={appId}
        />

        <Accordion defaultActiveKey="0" flush>
          {!rrb && <form key={2} onSubmit={handleSubmitOfKeyProducts(onSubmitOfKeyProducts)}>
            <Accordion.Item eventKey="0">
              <Accordion.Header>Details of key products <span className='clred_light'>* Applicable for {ucb ? 'UCB' : 'SFB/RRB'} only</span></Accordion.Header>
              <Accordion.Body>

                {ucb ? <>

                  <div className='shr_hlr'>
                    <h4>Segment wise portfolio of {ifvApp.ifvName} is given below:</h4>
                  </div>

                  <div className='row'>

                    <div className='col-md-4'>
                      <div className='form-group'>
                        <label className='ml-4'><strong>Segment</strong></label>
                      </div>
                    </div>

                    <div className='col-md-3'>
                      <div className='form-group'>
                        <label className='ml-2'><strong>O/s. as on (&#8377; Cr.)</strong></label>
                      </div>
                    </div>

                    <div className='col-md-4'>
                      <div className='form-group'>
                        <label><strong>% share in portfolio </strong> <Controller
                          control={control2}
                          name='ucbSegPortfolioDate'

                          render={({ field: { onChange, onBlur, value, ref } }) => (
                            <ReactDatePicker className="form-control"
                              placeholderText="Select date"
                              selected={ucbSegPortfolioDate}
                              onChange={(date) => setUcbSegPortfolioDate(new Date(date))}
                              onBlur={onBlur}
                              dateFormat="dd/MM/yyyy"
                            />
                          )}
                        /></label>
                      </div>
                    </div>
                    <div className='col-md-1'>

                    </div>
                  </div>

                  {fields11.map((field, index) => (
                    <div className='container-fluid'>
                      <div className='row pt-0' eventKey="0" key={field.id}>

                        <div className='col-md-4'>
                          <div className='form-group'>
                            <input className='form-control'
                              key={field.id} // important to include key with field's id
                              type='text'
                              {...register2(`kycDto1[${index}].kycProductName`, {
                                required: "Field is required",
                                onChange: (e) => { Pattern.sanitizeInput(e) },
                                validate: (value) => {
                                  if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                  if (/\d/.test(value)) return 'Field should not contain any numbers';
                                  return true;
                                },
                              })}
                            />
                            <span className='vldn'>{errors2.kycDto1 && errors2.kycDto1[index]?.kycProductName && errors2.kycDto1[index]?.kycProductName.message}</span>
                            <input type='hidden' {...register2(`kycDto1[${index}].ifvId`)} value={appId} />
                            <input type='hidden' {...register2(`kycDto1[${index}].kycId`)} />
                            <input type='hidden' {...register2(`kycDto1[${index}].kycType`)} value='UcbSegmentOne' />
                          </div>
                        </div>

                        <div className='col-md-3'>
                          <div className='form-group'>
                            <input className='form-control'
                              key={field.id} // important to include key with field's id
                              type='number' step='any'
                              {...register2(`kycDto1[${index}].kycAmount`,
                                {
                                  required: "Amount is required",
                                  validate: (value) => {
                                    if (value < 0) return "Invalid value";
                                    //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
                                    if (!/^\d{1,8}(\.\d{1,2})?$/.test(value)) return "Enter up to 8 digits with up to 2 decimals";
                                    return true;
                                  },
                                })}
                            />
                            <span className='vldn'>{errors2.kycDto1 && errors2.kycDto1[index]?.kycAmount && errors2.kycDto1[index]?.kycAmount.message}</span>
                          </div>
                        </div>

                        <div className='col-md-4'>
                          <div className='form-group'>
                            <input className='form-control'
                              key={field.id} // important to include key with field's id
                              type='number' step='any'
                              {...register2(`kycDto1[${index}].kycShareProfile`,
                                {
                                  required: "Field is required",
                                  validate: (value) => {
                                    if (value < 0) return "Invalid value";
                                    //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
                                    if (!/^(100(\.0{1,2})?|\d{1,2}(\.\d{1,2})?)$/.test(value)) return "Enter up to 100 with up to 2 decimal places";
                                    return true;
                                  },
                                })}
                            />
                            <span className='vldn'>{errors2.kycDto1 && errors2.kycDto1[index]?.kycShareProfile && errors2.kycDto1[index]?.kycShareProfile.message}</span>
                          </div>
                        </div>
                        <div className='col-md-1'>
                          <div className='form-group'>
                            {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                              onClick={() => handleKeyDetails1Delete(index)}></i>}
                          </div>
                        </div>

                      </div>
                    </div>
                  ))}

                  <div className='row p-3'>
                    <div className='col-md-4'>
                      <div className='form-group'>
                        <label><strong>Total</strong></label>
                      </div>
                    </div>

                    <div className='col-md-3'>
                      <div className='form-group'>
                        <input className='form-control' type='number' value={sumOfSeg1Os} readOnly />
                      </div>
                    </div>

                    <div className='col-md-4'>
                      <div className='form-group'>
                        <input className='form-control' type='number' value={sumOfSeg1Portfolio} readOnly />
                      </div>
                    </div>
                  </div>

                  <div className="button-container-end">
                    <button type="button" className='remove' onClick={() => append11({})}>+</button>
                  </div>


                  <div className='shr_hlr'>
                    <h4>Out of the above, the top 5 products are given below:</h4>

                  </div>

                  <div className='row'>

                    <div className='col-md-4'>
                      <div className='form-group'>
                        <label className='ml-4'><strong>Name of product</strong></label>
                      </div>
                    </div>

                    <div className='col-md-3'>
                      <div className='form-group'>
                        <label className='ml-2'><strong>Amount (In crores)</strong></label>
                      </div>
                    </div>

                    <div className='col-md-4'>
                      <div className='form-group'>
                        <label><strong>% share in portfolio</strong> <Controller
                          control={control2}
                          name='sfbShareportfoliodate'

                          render={({ field: { onChange, onBlur, value, ref } }) => (
                            <ReactDatePicker className="form-control"
                              placeholderText="Select date"
                              selected={sharePortfolio}
                              onChange={(date) => setSharePortfolio(new Date(date))}
                              onBlur={onBlur}
                              //    selected={value}
                              dateFormat="dd/MM/yyyy"
                            />
                          )}
                        /></label>
                      </div>
                    </div>
                    <div className='col-md-1'>

                    </div>
                  </div>

                  {fields1.map((field, index) => (
                    <div className='container-fluid'>
                      <div className='row pt-0' eventKey="0" key={field.id}>

                        <div className='col-md-4'>
                          <div className='form-group'>
                            <input className='form-control'
                              key={field.id} // important to include key with field's id
                              type='text'
                              {...register2(`kycDto[${index}].kycProductName`, {
                                required: "Field is required",
                                onChange: (e) => { Pattern.sanitizeInput(e) },
                                validate: (value) => {
                                  if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                  if (/\d/.test(value)) return 'Field should not contain any numbers';
                                  return true;
                                },
                              })}
                            />
                            <span className='vldn'>{errors2.kycDto && errors2.kycDto[index]?.kycProductName && errors2.kycDto[index]?.kycProductName.message}</span>
                            <input type='hidden' {...register2(`kycDto[${index}].ifvId`)} value={appId} />
                            <input type='hidden' {...register2(`kycDto[${index}].kycId`)} />
                            <input type='hidden' {...register2(`kycDto[${index}].kycType`)} value='TopFiveKyc' />
                          </div>
                        </div>

                        <div className='col-md-3'>
                          <div className='form-group'>
                            <input className='form-control'
                              key={field.id} // important to include key with field's id
                              type='number' step='any'
                              {...register2(`kycDto[${index}].kycAmount`,
                                {
                                  required: "Amount is required",
                                  validate: (value) => {
                                    if (value < 0) return "Invalid value";
                                    //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
                                    if (!/^\d{1,8}(\.\d{1,2})?$/.test(value)) return "Enter up to 8 digits with up to 2 decimals";
                                    return true;
                                  },
                                })}
                            />
                            <span className='vldn'>{errors2.kycDto && errors2.kycDto[index]?.kycAmount && errors2.kycDto[index]?.kycAmount.message}</span>
                          </div>
                        </div>

                        <div className='col-md-4'>
                          <div className='form-group'>
                            <input className='form-control'
                              key={field.id} // important to include key with field's id
                              type='number' step='any'
                              {...register2(`kycDto[${index}].kycShareProfile`,
                                {
                                  required: "Field is required",
                                  validate: (value) => {
                                    if (value < 0) return "Invalid value";
                                    //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
                                    if (!/^(100(\.0{1,2})?|\d{1,2}(\.\d{1,2})?)$/.test(value)) return "Enter up to 100 with up to 2 decimal places";
                                    return true;
                                  },
                                })}
                            />
                            <span className='vldn'>{errors2.kycDto && errors2.kycDto[index]?.kycShareProfile && errors2.kycDto[index]?.kycShareProfile.message}</span>
                          </div>
                        </div>
                        <div className='col-md-1'>
                          <div className='form-group'>
                            {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                              onClick={() => handleKeyDetailsDelete(index)}></i>}
                          </div>
                        </div>

                      </div>
                    </div>
                  ))}
                  <div className="button-container-end">
                    <button type="button" className='remove' onClick={() => append1({})}>+</button>
                  </div>
                  <div className='form-group'>
                    <textarea className='form-control'
                      autoComplete="off" maxLength="4000" value={ucbSeg2Note}
                      onChange={(e) => { Pattern.sanitizeInput(e); setUcbSeg2Note(e.target.value) }}
                    />
                  </div>
                  <div className="button-container-center">
                    {(editable || (!isMaker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                  </div>
                </> :
                  <>
                    <div className='shr_hlr'>
                      <h4>The top 5 products are given below:</h4>
                    </div>
                    <div className='row'>

                      <div className='col-md-4'>
                        <div className='form-group'>
                          <label className='ml-4'><strong>Name of Product</strong></label>
                        </div>
                      </div>

                      <div className='col-md-3'>
                        <div className='form-group'>
                          <label className='ml-2'><strong>Amount (In crores)</strong></label>
                        </div>
                      </div>

                      <div className='col-md-4'>
                        <div className='form-group'>
                          <label><strong>% share in portfolio</strong> <Controller
                            control={control2}
                            name='sfbShareportfoliodate'

                            render={({ field: { onChange, onBlur, value, ref } }) => (
                              <ReactDatePicker className="form-control"
                                placeholderText="Select date"
                                selected={sharePortfolio}
                                onChange={(date) => setSharePortfolio(new Date(date))}
                                onBlur={onBlur}
                                dateFormat="dd/MM/yyyy"
                              />
                            )}
                          /></label>
                        </div>
                      </div>
                      <div className='col-md-1'>
                      </div>
                    </div>

                    {fields1.map((field, index) => (
                      <div className='container-fluid'>
                        <div className='row pt-0' eventKey="0" key={field.id}>

                          <div className='col-md-4'>
                            <div className='form-group'>
                              <input className='form-control'
                                key={field.id} // important to include key with field's id
                                type='text'
                                {...register2(`kycDto[${index}].kycProductName`, {
                                  required: "Field is required",
                                  onChange: (e) => { Pattern.sanitizeInput(e) },
                                  validate: (value) => {
                                    if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                    if (/\d/.test(value)) return 'Field should not contain any numbers';
                                    return true;
                                  },
                                })}
                              />
                              <span className='vldn'>{errors2.kycDto && errors2.kycDto[index]?.kycProductName && errors2.kycDto[index]?.kycProductName.message}</span>
                              <input type='hidden' {...register2(`kycDto[${index}].ifvId`)} value={appId} />
                              <input type='hidden' {...register2(`kycDto[${index}].kycId`)} />
                            </div>
                          </div>

                          <div className='col-md-3'>
                            <div className='form-group'>
                              <input className='form-control'
                                key={field.id} // important to include key with field's id
                                type='number' step='any'
                                {...register2(`kycDto[${index}].kycAmount`,
                                  {
                                    required: "Amount is required",
                                    validate: (value) => {
                                      if (value < 0) return "Invalid value";
                                      //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
                                      if (!/^\d{1,8}(\.\d{1,2})?$/.test(value)) return "Enter up to 8 digits with up to 2 decimals";
                                      return true;
                                    },
                                  })}
                              />
                              <span className='vldn'>{errors2.kycDto && errors2.kycDto[index]?.kycAmount && errors2.kycDto[index]?.kycAmount.message}</span>
                            </div>
                          </div>

                          <div className='col-md-4'>
                            <div className='form-group'>
                              <input className='form-control'
                                key={field.id} // important to include key with field's id
                                type='number' step='any'
                                {...register2(`kycDto[${index}].kycShareProfile`,
                                  {
                                    required: "Field is required",
                                    validate: (value) => {
                                      if (value < 0) return "Invalid value";
                                      //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
                                      if (!/^(100(\.0{1,2})?|\d{1,2}(\.\d{1,2})?)$/.test(value)) return "Enter up to 100 with up to 2 decimal places";
                                      return true;
                                    },
                                  })}
                              />
                              <span className='vldn'>{errors2.kycDto && errors2.kycDto[index]?.kycShareProfile && errors2.kycDto[index]?.kycShareProfile.message}</span>
                            </div>
                          </div>
                          <div className='col-md-1'>
                            <div className='form-group'>
                              {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                onClick={() => handleKeyDetailsDelete(index)}></i>}
                            </div>
                          </div>

                        </div>
                      </div>
                    ))}
                    <div className="button-container-end">
                      <button type="button" className='remove' onClick={() => append1({})}>+</button>
                    </div>

                    {rrb && <div className='form-group'>
                      <textarea className='form-control'
                        autoComplete="off" maxLength="4000" value={ucbSeg2Note}
                        onChange={(e) => { Pattern.sanitizeInput(e); setUcbSeg2Note(e.target.value) }}
                      />

                    </div>
                    }
                    <div className="button-container-center">
                      {(editable || (!isMaker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                    </div>

                  </>}
              </Accordion.Body>
            </Accordion.Item>
          </form>
          }
          {ucb &&
            <Accordion.Item eventKey="6">
              <Accordion.Header>Top 10 Borrowers <span className='clred_light'>* Applicable for UCB only </span>
              </Accordion.Header>
              <Accordion.Body>

                <form key={21} onSubmit={handleSubmitOfUcbBorrowersDetail(onSubmitOfUcbBorrowersDetail)}>
                  <input type='hidden' {...ucbBorrDetailRegister('ifvId')} value={appId} />
                  <input type='hidden' {...ucbBorrDetailRegister('id')} />

                  {/* <div className='row'>
                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label className='ml-4'><strong>Sl No</strong></label>
                      </div>
                    </div>
                    <div className='col-md-4'>
                      <div className='form-group'>
                        <label className='ml-4'><strong>Customer Name</strong></label>
                      </div>
                    </div>

                    <div className='col-md-3'>
                      <div className='form-group'>
                        <label className='ml-2'><strong>Total O/s (&#8377; in Lakh)</strong></label>
                      </div>
                    </div>

                    <div className='col-md-3'>
                      <div className='form-group'>
                        <label><strong>Nature of Activity</strong> </label>
                      </div>
                    </div>
                    <div className='col-md-1'>

                    </div>
                  </div>

                  {fields21.map((field, index) => (
                    <div className='container-fluid'>
                      <div className='row pt-0' eventKey="0" key={field.id}>
                        <div className='col-md-1'>
                          <div className='form-group'>
                            {index + 1}
                          </div>
                        </div>
                        <div className='col-md-4'>
                          <div className='form-group'>
                            <input className='form-control'
                              key={field.id} // important to include key with field's id
                              type='text'
                              {...register21(`topBorrowers[${index}].customerName`, {
                                required: "Field is required",
                                onChange: (e) => { Pattern.sanitizeInput(e) },
                                validate: (value) => {
                                  if (/\d/.test(value)) return 'Field should not contain any numbers';
                                  return true;
                                },
                              })}
                            />
                            <span className='vldn'>{errors21.topBorrowers && errors21.topBorrowers[index]?.customerName && errors21.topBorrowers[index]?.customerName.message}</span>
                            <input type='hidden' {...register21(`topBorrowers[${index}].ifvId`)} value={appId} />
                            <input type='hidden' {...register21(`topBorrowers[${index}].id`)} />
                          </div>
                        </div>

                        <div className='col-md-3'>
                          <div className='form-group'>
                            <input className='form-control'
                              key={field.id} // important to include key with field's id
                              type='number' step='any'
                              {...register21(`topBorrowers[${index}].totalOs`,
                                {
                                  required: "Amount is required",
                                  validate: (value) => {
                                    if (value < 0) return "Invalid value";
                                    //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
                                    if (!/^\d{1,8}(\.\d{1,2})?$/.test(value)) return "Enter up to 8 digits with up to 2 decimals";
                                    return true;
                                  },
                                  onChange: (e) => calculateTotOs(index, e.target.value)
                                })}
                            />
                            <span className='vldn'>{errors21.topBorrowers && errors21.topBorrowers[index]?.totalOs && errors21.topBorrowers[index]?.totalOs.message}</span>
                          </div>
                        </div>

                        <div className='col-md-3'>
                          <div className='form-group'>
                            <input className='form-control'
                              key={field.id} // important to include key with field's id
                              type='text'
                              {...register21(`topBorrowers[${index}].natureOfActivity`,
                                {
                                  //  required: "Field is required",
                                  onChange: (e) => { Pattern.sanitizeInput(e) },
                                })}
                            />
                            <span className='vldn'>{errors21.topBorrowers && errors21.topBorrowers[index]?.natureOfActivity && errors21.topBorrowers[index]?.natureOfActivity.message}</span>
                          </div>
                        </div>
                        <div className='col-md-1'>
                          <div className='form-group'>
                            {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                              onClick={() => deleteTopBorrowers(index)}></i>}
                          </div>
                        </div>

                      </div>
                    </div>
                  ))}

                  <div className='row p-3'>
                    <div className='col-md-1'>

                    </div>
                    <div className='col-md-4'>
                      <div className='form-group'>
                        <label><strong>Total</strong></label>
                      </div>
                    </div>

                    <div className='col-md-3'>
                      <div className='form-group'>
                        <input className='form-control' type='number' value={sumOfTotalOs} readOnly />
                      </div>
                    </div>

                    <div className='col-md-3'>
                      <div className='form-group'>

                      </div>
                    </div>
                  </div>

                  <div className="button-container-end">
                    <button type="button" className='remove' onClick={() => append21({})}>+</button>
                  </div> */}

                  {/* <div className='form-group'>
                    <textarea className='form-control'
                      autoComplete="off" maxLength="4000" {...register21(`topBorrowers[${0}].borrowerNote`)}
                      onChange={(e) => Pattern.sanitizeInput(e)}
                    />

                  </div> */}
                  <div className="row mt-0">
                    <div className="col-md-12 p-0">
                      <div className="row no-prop alg_adst">
                        <div className="col pt-4">
                          <div data-mdb-input-init className="form-outline">
                            <label className="form-label" for="form3Example1"><strong className='mndt'>Total number of borrowers:</strong>
                            </label>
                            <input type="number" className="form-control" {...ucbBorrDetailRegister('totBorrowers', {
                              validate: (value) => {
                                if (CommonUtil.isEmpty(value)) return true;
                                if (value <= 0) return "Invalid value";
                                return true;
                              },
                            })} />
                            <span className='vldn'>{errorsInUcbBorrowers.totBorrowers && errorsInUcbBorrowers.totBorrowers.message}</span>
                          </div>
                        </div>
                        <div className="col pt-4">
                          <div data-mdb-input-init className="form-outline">
                            <label className="form-label" for="form3Example1"><strong className='mndt'>Total number of MSME customers:</strong>
                            </label>
                            <input type="number" className="form-control" {...ucbBorrDetailRegister('totMsmeCustomers', {
                              validate: (value) => {
                                if (CommonUtil.isEmpty(value)) return true;
                                if (value <= 0) return "Invalid value";
                                return true;
                              },
                            })} />
                            <span className='vldn'>{errorsInUcbBorrowers.totMsmeCustomers && errorsInUcbBorrowers.totMsmeCustomers.message}</span>
                          </div>
                        </div>
                        <div className="col pt-4">
                          <div data-mdb-input-init className="form-outline">
                            <label className="form-label" for="form3Example1"><strong className='mndt'>Total number of corporate borrowers:</strong>
                            </label>
                            <input type="number" className="form-control" {...ucbBorrDetailRegister('totCorpBorrowers', {
                              validate: (value) => {
                                if (CommonUtil.isEmpty(value)) return true;
                                if (value <= 0) return "Invalid value";
                                return true;
                              },
                            })} />
                            <span className='vldn'>{errorsInUcbBorrowers.totCorpBorrowers && errorsInUcbBorrowers.totCorpBorrowers.message}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <br />

                  <div className='form-group'>
                    <textarea className='form-control'
                      autoComplete="off" maxLength="4000" {...ucbBorrDetailRegister('remarks')}
                      onChange={(e) => Pattern.sanitizeInput(e)}
                    />
                  </div>

                  <div className="button-container-center">
                    {(editable || (!isMaker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                  </div>
                </form>
              </Accordion.Body>
            </Accordion.Item>
          }
          {(ucb || rrb) &&
            <Accordion.Item eventKey="4">
              <Accordion.Header>Regulatory Environment & Brief Particulars <span className='clred_light'>* Applicable for UCB/RRB only </span>
              </Accordion.Header>
              <Accordion.Body>

                <div className='form-group'>
                  <label>
                    <strong>Regulatory Environment:</strong>
                  </label>
                  <textarea className='form-control'
                    autoComplete="off" maxLength="4000" value={ucsRegulatoryEnvironment}
                    onChange={(e) => { Pattern.sanitizeInput(e); setUcsRegulatoryEnvironment(e.target.value) }}
                  />

                </div>
                <br />
                {ucb && <div className='form-group'>
                  <label>
                    <strong>Brief particulars of credit and risk control mechanism of the bank:</strong>
                  </label>
                  <textarea className='form-control'
                    autoComplete="off" maxLength="4000" value={ucsBriefParticulars}
                    onChange={(e) => { Pattern.sanitizeInput(e); setUcsBriefParticulars(e.target.value) }}
                  />

                </div>
                }
                <div className='col-md-12'>
                  <div className="button-container-center">
                    {(editable || (!isMaker && locked)) && <button type='button' onClick={() => saveChiefFunc()} className='save'>Save <i className="fa fa-circle-check"></i></button>}
                  </div>
                </div>

              </Accordion.Body>

            </Accordion.Item>
          }
          {!rrb && <Accordion.Item eventKey="1">
            <Accordion.Header>Chief Functionary & Board <span className='clred_light'>* Applicable for SFB/RRB only </span>
            </Accordion.Header>
            <Accordion.Body>

              <div className='form-group'>
                <textarea className='form-control'
                  autoComplete="off" maxLength="4000" value={chiefFunc}
                  onChange={(e) => { Pattern.sanitizeInput(e); setChiefFunc(e.target.value) }}
                />

              </div>
              <div className='col-md-12'>
                <div className="button-container-center">
                  {(editable || (!isMaker && locked)) && <button type='button' onClick={() => saveChiefFunc()} className='save'>Save <i className="fa fa-circle-check"></i></button>}
                </div>
              </div>
            </Accordion.Body>
          </Accordion.Item>
          }
          <Accordion.Item eventKey="2">
            <Accordion.Header>Area of Operation-Geographical <span className='clred_light'>* Applicable for SFB/RRB only </span>
            </Accordion.Header>
            <Accordion.Body>
              <div className='form-group'>
                <textarea className='form-control'
                  autoComplete="off" maxLength="4000" value={geoAreaNote}
                  onChange={(e) => { Pattern.sanitizeInput(e); setGeoAreaNote(e.target.value) }}
                />

              </div>
              <div className='col-md-12'>
                <div className="button-container-center">
                  {(editable || (!isMaker && locked)) && <button type='button' onClick={() => saveChiefFunc()} className='save'>Save <i className="fa fa-circle-check"></i></button>}
                </div>
              </div>
            </Accordion.Body>

          </Accordion.Item>

          {!ucb && !rrb && <Accordion.Item eventKey="3">
            <Accordion.Header>Key Investors (if any, domestic/foreign other than promoters) <span className='clred_light'>* Applicable for SFB only  </span>
            </Accordion.Header>
            <Accordion.Body>

              {/* Started other key investors */}
              <form key={6} onSubmit={handleSubmitOfKeyOtherInvestors(onSubmitOfOtherKeyInvestors)}>

                <div className='form-group'>
                  <input type='text' className='form-control'
                    autoComplete="off" maxLength="4000" value={keyInvestorsNote}
                    onChange={(e) => { Pattern.sanitizeInput(e); setKeyInvestorsNote(e.target.value) }}
                  />

                </div>

                <h4><strong>Key Investors</strong></h4>
                <div className='row'>
                  <div className='col-md-6'>
                    <div className='form-group'>
                      <label className='ml-4'>HOLDER</label>
                    </div>
                  </div>

                  {/* <div className='col-md-3'>
                    <div className='form-group'>
                      <label className='ml-2'>COUNT</label>
                    </div>
                  </div>

                  <div className='col-md-3'>
                    <div className='form-group'>
                      <label className='ml-2'>HOLDING</label>
                    </div>
                  </div> */}

                  <div className='col-md-5'>
                    <div className='form-group'>
                      <label className='ml-2'>PROPORTION(IN % AGE)</label>
                    </div>
                  </div>
                  <div className='col-md-1'>
                    <div className='form-group'>
                    </div>
                  </div>
                </div>

                {fields6.map((field, index) => (
                  <div className='container-fluid'>
                    <input type='hidden' key={field.id} {...register7(`otherKeyInvestors[${index}].ifvId`)} value={appId} />
                    <input type='hidden' key={field.id} {...register7(`otherKeyInvestors[${index}].kiId`)} />
                    <input type='hidden' key={field.id} {...register7(`otherKeyInvestors[${index}].kiType`)} value="Other" />

                    <div className='row pt-0' key={field.id}>
                      <div className='col-md-6'>
                        <div className='form-group'>
                          <input className='form-control'
                            key={field.id} // important to include key with field's id
                            type='text'
                            {...register7(`otherKeyInvestors[${index}].kiHolder`, {
                              required: "Field is required",
                              onChange: (e) => { Pattern.sanitizeInput(e) },
                              validate: (value) => {
                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                if (/\d/.test(value)) return 'Field should not contain any numbers';
                                return true;
                              },

                            })}
                          />
                          <span className='vldn'>{errors7.otherKeyInvestors && errors7.otherKeyInvestors[index]?.kiHolder && errors7.otherKeyInvestors[index]?.kiHolder.message}</span>
                        </div>
                      </div>

                      {/* <div className='col-md-3'>
                        <div className='form-group'>
                          <input className='form-control'
                            key={field.id} // important to include key with field's id
                            type='number'
                            step='0.01'
                            {...register7(`otherKeyInvestors[${index}].kiCount`, {
                              onChange: (e) => calculateKiCountOne(`otherKeyInvestors[${index}].kiCount`, parseFloat(e.target.value, 10))
                            })}
                          />
                        </div>
                      </div>

                      <div className='col-md-3'>
                        <div className='form-group'>
                          <input className='form-control'
                            key={field.id} // important to include key with field's id
                            type='number'
                            step='0.01'
                            {...register7(`otherKeyInvestors[${index}].kiHolding`)}
                          />
                        </div>
                      </div> */}

                      <div className='col-md-5'>
                        <div className='form-group'>
                          <input className='form-control'
                            key={field.id} // important to include key with field's id
                            type='number'
                            step='any'
                            {...register7(`otherKeyInvestors[${index}].kiPproportion`,
                              {
                                /// required: "Field is required",
                                validate: (value) => {
                                  if (value < 0) return "Invalid value";
                                  if (!/^(100(\.0{1,2})?|\d{1,2}(\.\d{1,2})?)$/.test(value)) return "Enter up to 100 with up to 2 decimal places";
                                  return true;
                                },
                                onChange: (e) => calculateOtherKycTotal(`otherKeyInvestors[${index}].kiPproportion`, e.target.value)
                              })}
                          />
                          <span className='vldn'>{errors7.otherKeyInvestors && errors7.otherKeyInvestors[index]?.kiPproportion && errors7.otherKeyInvestors[index]?.kiPproportion.message}</span>
                        </div>
                      </div>
                      <div className='col-md-1'>
                        <div className='form-group'>
                          {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                            onClick={() => deleteOtherKeyInvestors(index)}></i>}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                <div className='row p-3'>
                  <div className='col-md-6'>
                    <div className='form-group'>
                      <label><strong>Total</strong></label>
                    </div>
                  </div>

                  {/* <div className='col-md-3'>
                    <div className='form-group'>
                      <input className='form-control' type='number' value={sumOfOtherkeyInvestorCountOne} readOnly />
                    </div>
                  </div>

                  <div className='col-md-3'>
                    <div className='form-group'>
                      <input className='form-control' type='number' value={sumOfOtherkeyInvestorHoldingOne} readOnly />
                    </div>
                  </div> */}

                  <div className='col-md-5'>
                    <div className='form-group'>
                      <input className='form-control' type='number' value={sumOfOtherkeyInvestorProportionOne} readOnly />
                    </div>
                  </div>
                </div>
                <div className="button-container-end">
                  <button type="button" className='remove' onClick={() => append6({})}>+</button>
                </div>
                <div className='col-md-12'>
                  <div className="button-container-center">
                    {(editable || (!isMaker && locked)) && <button type='submit' className="save">Save <i className="fa fa-circle-check"></i></button>}
                  </div>
                </div>
              </form>
              <hr className='hr' />
            </Accordion.Body>

          </Accordion.Item>
          }
          {(ucb) &&
            <Accordion.Item eventKey="5">
              <Accordion.Header>Exposure to Directors & Institutional Borrowings <span className='clred_light'>* Applicable for UCB/RRB only </span>
              </Accordion.Header>
              <Accordion.Body>

                {ucb && <div className='form-group'>
                  <label>
                    <strong>Exposure to Directors:</strong>
                  </label>
                  <textarea className='form-control'
                    autoComplete="off" maxLength="4000" value={ucsDirectorExposure}
                    onChange={(e) => { Pattern.sanitizeInput(e); setUcsDirectorExposure(e.target.value) }}
                  />

                </div>
                }
                <br />
                <div className='form-group'>
                  <label>
                    <strong>Institutional Borrowings:</strong>
                  </label>
                  <textarea className='form-control'
                    autoComplete="off" maxLength="4000" value={ucsInstitutionalBorrowings}
                    onChange={(e) => { Pattern.sanitizeInput(e); setUcsInstitutionalBorrowings(e.target.value) }}
                  />

                </div>

                <div className='col-md-12'>
                  <div className="button-container-center">
                    {(editable || (!isMaker && locked)) && <button type='button' onClick={() => saveChiefFunc()} className='save'>Save <i className="fa fa-circle-check"></i></button>}
                  </div>
                </div>
              </Accordion.Body>
            </Accordion.Item>
          }
          {(ucb || rrb) && <Accordion.Item eventKey="7">
            <Accordion.Header>Key Investors (if any, domestic/foreign other than promoters) <span className='clred_light'>* Applicable for UCB/RRB only  </span>
            </Accordion.Header>
            <Accordion.Body>

              <form key={6} onSubmit={handleSubmitOfKeyInvestors(onSubmitOfKeyInvestors)}>

                <div className='form-group'>
                  <input type='text' className='form-control'
                    autoComplete="off" maxLength="4000" value={keyInvestorsNote}
                    onChange={(e) => { Pattern.sanitizeInput(e); setKeyInvestorsNote(e.target.value) }}
                  />

                </div>

                <h4><strong>Key Investors</strong></h4>
                <div className='row'>
                  <div className='col-md-1'>
                    <div className='form-group'>
                      <label className='ml-4'><strong>Sl No</strong></label>
                    </div>
                  </div>
                  <div className='col-md-4'>
                    <div className='form-group'>
                      <label className='ml-4'><strong>Particulars</strong></label>
                    </div>
                  </div>

                  <div className='col-md-2'>
                    <div className='form-group'>
                      <label className='ml-2'><strong>% Age of Shares</strong></label>
                    </div>
                  </div>

                  {ucb && <div className='col-md-2'>
                    <div className='form-group'>
                      <label className='ml-2'><strong>No of Members</strong></label>
                    </div>
                  </div>}

                  <div className='col-md-2'>
                    <div className='form-group'>
                      <label className='ml-2'><strong>Amount (In &#8377; {rrb ? 'Crore' : 'lakh'})</strong></label>
                    </div>
                  </div>
                  <div className='col-md-1'>
                    <div className='form-group'>
                    </div>
                  </div>
                </div>

                {fields4.map((field, index) => (
                  <div className='container-fluid'>
                    <input type='hidden' key={field.id} {...register5(`keyInvestors[${index}].ifvId`)} value={appId} />
                    <input type='hidden' key={field.id} {...register5(`keyInvestors[${index}].kiId`)} />
                    <input type='hidden' key={field.id} {...register5(`keyInvestors[${index}].kiType`)} value="UCB" />

                    <div className='row pt-0' key={field.id}>
                      <div className='col-md-1'>
                        <div className='form-group'>
                          {index + 1}
                        </div>
                      </div>
                      <div className='col-md-4'>
                        <div className='form-group'>
                          <input className='form-control'
                            key={field.id} // important to include key with field's id
                            type='text'
                            {...register5(`keyInvestors[${index}].kiHolder`, {
                              required: "Field is required",
                              onChange: (e) => { Pattern.sanitizeInput(e) },
                              validate: (value) => {
                                if (/\d/.test(value)) return 'Field should not contain any numbers';
                                return true;
                              },

                            })}
                          />
                          <span className='vldn'>{errors5.keyInvestors && errors5.keyInvestors[index]?.kiHolder && errors5.keyInvestors[index]?.kiHolder.message}</span>
                        </div>
                      </div>

                      <div className='col-md-2'>
                        <div className='form-group'>
                          <input className='form-control'
                            key={field.id} // important to include key with field's id
                            type='number'
                            step='any'
                            {...register5(`keyInvestors[${index}].kiPproportion`,
                              {
                                /// required: "Field is required",
                                validate: (value) => {
                                  if (value < 0) return "Invalid value";
                                  if (!/^(100(\.0{1,2})?|\d{1,2}(\.\d{1,2})?)$/.test(value)) return "Enter up to 100 with up to 2 decimal places";
                                  return true;
                                },
                                onChange: (e) => calculateOtherKycTotal(`keyInvestors[${index}].kiPproportion`, e.target.value)
                              })}
                          />
                          <span className='vldn'>{errors5.keyInvestors && errors5.keyInvestors[index]?.kiPproportion && errors5.keyInvestors[index]?.kiPproportion.message}</span>
                        </div>
                      </div>

                      {ucb && <div className='col-md-2'>
                        <div className='form-group'>
                          <input className='form-control'
                            key={field.id} // important to include key with field's id
                            type='number'
                            step='0.01'
                            {...register5(`keyInvestors[${index}].kiCount`, {
                              onChange: (e) => calculateKiCountOne(`keyInvestors[${index}].kiCount`, parseFloat(e.target.value, 10))
                            })}
                          />
                        </div>
                      </div>}

                      <div className='col-md-2'>
                        <div className='form-group'>
                          <input className='form-control'
                            key={field.id} // important to include key with field's id
                            type='number'
                            step='0.01'
                            {...register5(`keyInvestors[${index}].kiHolding`)}
                          />
                        </div>
                      </div>

                      <div className='col-md-1'>
                        <div className='form-group'>
                          {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                            onClick={() => deleteKeyInvestors(index)}></i>}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                <div className='row p-3'>
                  <div className='col-md-1'>

                  </div>
                  <div className='col-md-4'>
                    <div className='form-group'>
                      <label><strong>Total</strong></label>
                    </div>
                  </div>

                  <div className='col-md-2'>
                    <div className='form-group'>
                      <input className='form-control' type='number' value={sumOfkeyInvestorProportionOne} readOnly />
                    </div>
                  </div>

                  {ucb && <div className='col-md-2'>
                    <div className='form-group'>
                      <input className='form-control' type='number' value={sumOfkeyInvestorCountOne} readOnly />
                    </div>
                  </div>}

                  <div className='col-md-2'>
                    <div className='form-group'>
                      <input className='form-control' type='number' value={sumOfkeyInvestorHoldingOne} readOnly />
                    </div>
                  </div>
                </div>
                <div className="button-container-end">
                  <button type="button" className='remove' onClick={() => append4({})}>+</button>
                </div>
                <div className='col-md-12'>
                  <div className="button-container-center">
                    {(editable || (!isMaker && locked)) && <button type='submit' className="save">Save <i className="fa fa-circle-check"></i></button>}
                  </div>
                </div>
              </form>
              <hr className='hr' />
            </Accordion.Body>
          </Accordion.Item>
          }
        </Accordion>

      </div>

      <div className="button-container-center">
        {appId > 0 && <button type='button' className='btn btnPrev' onClick={goToPrev}><i className="fa fa-arrow-left"></i> Prev</button>}
        {appId > 0 && <button type='button' className='btn btnNext' onClick={goToNext}>Next <i className="fa fa-arrow-right"></i></button>}
      </div>
      {loading && <Loading />}
      <MessageModal
        open={isOpen}
        onClose={hideMessage}
        message={messageConfig.message}
        type={messageConfig.type}
        totalMessages={totalMessages}
        currentIndex={currentIndex}
        onNext={nextMessage}
        onPrev={prevMessage}
        hasNext={hasNext}
        hasPrev={hasPrev}
      />
    </Fragment >
  )
}
export default SectionOne;