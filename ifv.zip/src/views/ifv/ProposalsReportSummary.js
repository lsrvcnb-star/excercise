import DownloadIcon from '@mui/icons-material/Download';
import RefreshIcon from '@mui/icons-material/Refresh';
import { Box, IconButton, Tooltip, Typography } from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import {
    QueryClient,
    QueryClientProvider,
    keepPreviousData,
    useQuery
} from '@tanstack/react-query';
import axios from 'axios';
import {
    MaterialReactTable,
    useMaterialReactTable,
} from 'material-react-table';
import { useMemo, useState } from 'react';
import { useLocation } from "react-router-dom";
import IfvAppraisalService from 'services/IfvAppraisalService';
import CommonUtil from 'services/utils/CommonUtil';
import FileUtil from 'services/utils/FileUtil';
import { getJwtToken } from 'services/utils/JwtUtil';

const PropSummary = () => {
    const [loading, setLoading] = useState(null);
    const [columnFilters, setColumnFilters] = useState([]);
    const [globalFilter, setGlobalFilter] = useState('');
    const [sorting, setSorting] = useState([]);
    const location = useLocation();
    const mode = location.state?.mode;
    const [pagination, setPagination] = useState({
        pageIndex: 0,
        pageSize: 10,
    });
    const {
        data: queryData,
        isError,
        isRefetching,
        isLoading,
        refetch,
        error,
    } = useQuery({
        queryKey: [
            'table-data',
            columnFilters, //refetch when columnFilters changes
            globalFilter, //refetch when globalFilter changes
            pagination.pageIndex, //refetch when pagination.pageIndex changes
            pagination.pageSize, //refetch when pagination.pageSize changes
            sorting, //refetch when sorting changes
        ],
        queryFn: async () => {
            const user = IfvAppraisalService.getCurrentUser();
            const url = process.env.REACT_APP_API_ENDPOINT + 'ifv/ifcapp/getAllOnUserTypeOnPage/report/' + user.ofrCode;
            const fetchURL = new URL(url);
            fetchURL.searchParams.set(
                'start',
                `${pagination.pageIndex * pagination.pageSize}`,
            );

            fetchURL.searchParams.set('size', `${pagination.pageSize}`);
            fetchURL.searchParams.set('filters', JSON.stringify(columnFilters ?? []));
            fetchURL.searchParams.set('globalFilter', globalFilter ?? '');
            fetchURL.searchParams.set('sorting', JSON.stringify(sorting ?? []));
            fetchURL.searchParams.set('status', mode ?? '');

            const token = getJwtToken();
            try {
                const response = await axios.get(fetchURL.href, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                return response.data;
            } catch (error) {
                console.error('Backend error while loading data:', error);
                throw error;
            }

        },
        placeholderData: keepPreviousData, //don't go to 0 rows when refetching or paginating to next page
    });
    const tableData = queryData?.content ?? [];
    const totalRows = queryData?.totalElements ?? 0;

    const columns = useMemo(
        () => [
            {
                accessorKey: 'ifvName',
                header: 'Name of the Bank',
                size: 200,
            },
            {
                accessorKey: 'appNumber',
                header: 'Application No',
                size: 100,
            },
            {
                accessorKey: 'createdDate',
                header: 'Application Date',
                size: 100,
            },
            {
                accessorKey: 'schemeName',
                header: 'Scheme / Applied Amount',
                size: 150,
            },
            {
                accessorKey: 'status',
                header: 'Status',
                size: 50,
            },
        ],
        [],
    );
    const table = useMaterialReactTable({
        columns,
        data: tableData, // Ensure to pass the correct table data here
        initialState: { showColumnFilters: true },
        manualFiltering: true, //turn off built-in client-side filtering
        manualPagination: true, //turn off built-in client-side pagination
        manualSorting: true, //turn off built-in client-side sorting
        muiToolbarAlertBannerProps: isError
            ? {
                color: 'error',
                children: 'Error loading data',
            }
            : undefined,
        onColumnFiltersChange: setColumnFilters,
        onGlobalFilterChange: setGlobalFilter,
        onPaginationChange: setPagination,
        onSortingChange: setSorting,
        renderTopToolbarCustomActions: () => (
            <Tooltip arrow title="Refresh Data">
                <IconButton onClick={() => refetch()}>
                    <RefreshIcon />
                </IconButton>
            </Tooltip>
        ),
        rowCount: totalRows,
        state: {
            columnFilters,
            globalFilter,
            isLoading,
            pagination,
            showAlertBanner: isError,
            showProgressBars: isRefetching,
            sorting,
        },
        createDisplayMode: 'modal',
        editDisplayMode: 'modal',
        enableEditing: true,
        getRowId: (row) => row.id,
        enableRowNumbers: true,
        rowNumberDisplayMode: 'static',
        // enableExpandAll: false,
        renderRowActions: ({ row, table }) => (
            <Box sx={{ display: 'flex' }}>
                <Tooltip title="Download">
                    <IconButton
                        onClick={() => handleDownload(row.original.ifvId)}
                        sx={{ color: loading === row.original.ifvId ? 'gray' : 'primary.main' }}
                        disabled={loading === row.original.ifvId}
                    >
                        {loading === row.original.ifvId ? (
                            <CircularProgress size={24} />
                        ) : (
                            <DownloadIcon />
                        )}
                    </IconButton>
                </Tooltip>
            </Box >
        ),
        muiDetailPanelProps: () => ({
            sx: (theme) => ({
                backgroundColor:
                    theme.palette.mode === 'dark'
                        ? 'rgba(255,210,244,0.1)'
                        : 'rgba(0,0,0,0.1)',
            }),
        }),
        //custom expand button rotation
        muiExpandButtonProps: ({ row, table }) => ({
            onClick: () => table.setExpanded({ [row.id]: !row.getIsExpanded() }), //only 1 detail panel open at a time
            sx: {
                transform: row.getIsExpanded() ? 'rotate(180deg)' : 'rotate(-90deg)',
                transition: 'transform 0.2s',
            },
        }),
        //conditionally render detail panel
        renderDetailPanel: ({ row }) =>
            row.original.ifvName ? (
                <Box
                    sx={{
                        display: 'grid',
                        margin: 'auto',
                        gridTemplateColumns: '1fr 1fr',
                        width: '75%',
                    }}
                >

                    <Typography>Maker Name: <strong>{row.original.makerName}</strong></Typography>
                    <Typography><strong>{row.original.sfb}</strong></Typography>
                    <Typography>CIF Number: <strong>{row.original.cifNumber}</strong> </Typography>
                    <Typography></Typography>

                    {row.original.checker1 && <Typography>Checker 1: <strong>{row.original.checker1}</strong> </Typography>}
                    {row.original.checker2 && <Typography>Checker 2: <strong>{row.original.checker2}</strong> </Typography>}
                    {row.original.checker3 && <Typography>Checker 3: <strong>{row.original.checker3}</strong> </Typography>}
                    {row.original.checker4 && <Typography>Checker 4: <strong>{row.original.checker4}</strong> </Typography>}
                    {row.original.checker && CommonUtil.isEmpty(row.original.approvedBy) && <Typography>Pending with: <strong>{row.original.checker}</strong></Typography>}
                    {row.original.approvedBy && <Typography>Approved By: <strong>{row.original.approvedBy}</strong></Typography>}
                </Box>
            ) : null,
    });
    const handleDownload = async (ifvId) => {
        setLoading(ifvId);
        try {
            const response = await IfvAppraisalService.findByFileIfvIdAndFileModule(ifvId, null);
            FileUtil.downloadFile(response.data.fileDataBytea, response.data.fileName, "application/pdf");
        } catch (error) {
            const resMessage =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            console.log(resMessage);
            alert('Error occurred while generating report')
        } finally {
            setLoading(null);
        }
    };
    return <MaterialReactTable table={table} />;
};

const queryClient = new QueryClient();
const AppraisalReportSummary = () => (
    <QueryClientProvider client={queryClient}>
        <PropSummary />
    </QueryClientProvider>
);
export default AppraisalReportSummary;