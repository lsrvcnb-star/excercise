import { Box, Tab, Tabs } from '@mui/material';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import Select from 'react-select';
import IfvAppraisalService from 'services/IfvAppraisalService';
const RRBGeographicalAreaTabs = ({
    control4,
    register4,
    errors4,
    getValues,
    setValue,
    trigger,
    appId,
    editable,
    isMaker,
    locked,
    showMessage,
    filteredStatesOptionsForRRB,
    handleStateSearchForRRB,
    onDataPrepare,
    forceFetch,
}) => {
    const [tabs, setTabs] = useState([{
        id: Date.now(),
        state: null,
        districts: [{ id: Date.now() }],
        grandTotal: 0
    }]);
    const [activeTab, setActiveTab] = useState(0);
    const [isLoading, setIsLoading] = useState(true);
    useEffect(() => {
        const fetchRRBGeographicalAreas = async () => {
            if (!appId) {
                showMessage('Application ID is required', 'error');
                setIsLoading(false);
                return;
            }
            try {
                setIsLoading(true);
                const response = await IfvAppraisalService.getAllOnIfvIdOnST(appId);
                const processedData = Array.isArray(response.data.listAreasGeographicalDTO) ? response.data.listAreasGeographicalDTO : [];
                if (processedData.length > 0) {
                    const transformedTabs = processedData.reduce((acc, item) => {
                        let stateTab = acc.find(tab => tab.state?.label === item.rrbStateName);
                        if (!stateTab) {
                            stateTab = {
                                id: item.agId || Date.now(),
                                state: {
                                    label: item.rrbStateName,
                                    value: item.rrbStateName
                                },
                                districts: [],
                                grandTotal: 0
                            };
                            acc.push(stateTab);
                        }
                        stateTab.districts.push({
                            id: item.agId,
                            name: item.agState,
                            branches: item.agBranch,
                            isExisting: true
                        });
                        stateTab.grandTotal += item.agBranch || 0;
                        return acc;
                    }, []);
                    setTabs(transformedTabs);
                }
            } catch (error) {
                console.error('Failed to fetch RRB geographical areas:', error);
                showMessage('Failed to load geographical areas', 'error');
                setTabs([{
                    id: Date.now(),
                    state: null,
                    districts: [{ id: Date.now() }],
                    grandTotal: 0
                }]);
            } finally {
                setIsLoading(false);
            }
        };
        fetchRRBGeographicalAreas();
    }, [appId, forceFetch]);

    const deleteDistrictFromDB = async (districtId) => {
        try {
            await IfvAppraisalService.deleteAeStates(districtId);
            showMessage('District deleted successfully', 'success');
            return true;
        } catch (error) {
            console.error('Failed to delete district:', error);
            showMessage('Failed to delete district', 'error');
            return false;
        }
    };
    const deleteStateFromDB = async (stateId) => {
        try {
            alert(stateId)
            await IfvAppraisalService.deleteGeographicalArea(stateId);
            showMessage('State deleted successfully', 'success');
            return true;
        } catch (error) {
            console.error('Failed to delete state:', error);
            showMessage('Failed to delete state', 'error');
            return false;
        }
    };
    const handleAddTab = () => {
        const newTab = {
            id: Date.now(),
            state: null,
            districts: [{ id: Date.now(), agId: Date.now() }]
        };
        setTabs(prevTabs => [...prevTabs, newTab]);
        setActiveTab(tabs.length);
    };
    const handleRemoveTab = async (tabIdToRemove) => {
        const tabToRemove = tabs.find(tab => tab.id === tabIdToRemove);

        if (tabToRemove.state && tabToRemove.state.value) {
            const isDeleted = await deleteStateFromDB(tabToRemove.id);

            if (!isDeleted) {
                return;
            }
        }

        const updatedTabs = tabs.filter(tab => tab.id !== tabIdToRemove);

        if (updatedTabs.length === 0) {
            updatedTabs.push({
                id: Date.now(),
                state: null,
                districts: [{ id: Date.now() }],
                grandTotal: 0
            });
        }

        setTabs(updatedTabs);
        setActiveTab(0);

        updatedTabs.forEach((tab, tabIndex) => {
            tab.districts.forEach((district, districtIndex) => {
                setValue(`district_${tab.id}_${districtIndex}`, '');
                setValue(`branches_${tab.id}_${districtIndex}`, '');
            });
        });
    };
    const calculateTabGrandTotal = (tab) => {
        return tab.districts.reduce((total, district) =>
            total + (parseInt(district.branches) || 0), 0);
    };
    const handleTabChange = (event, newValue) => {
        setActiveTab(newValue);
    };
    const handleStateChange = (tabIndex, selected) => {
        const updatedTabs = [...tabs];
        updatedTabs[tabIndex].state = selected;
        setTabs(updatedTabs);
    };
    const handleAddDistrict = (tabIndex) => {
        const currentTab = tabs[tabIndex];
        const updatedTabs = [...tabs];
        const newDistrict = {
            id: Date.now(),
            branches: 0,
            name: ''
        };
        updatedTabs[tabIndex].districts.push(newDistrict);
        setTabs(updatedTabs);
    };
    const handleRemoveDistrict = async (tabIndex, districtIndex) => {
        const updatedTabs = [...tabs];
        const removedDistrict = updatedTabs[tabIndex].districts[districtIndex];

        if (removedDistrict.isExisting) {
            const isDeleted = await deleteDistrictFromDB(removedDistrict.id);

            if (!isDeleted) {
                return;
            }
        }

        updatedTabs[tabIndex].grandTotal -= removedDistrict.branches || 0;
        updatedTabs[tabIndex].districts.splice(districtIndex, 1);

        if (updatedTabs[tabIndex].districts.length === 0) {
            updatedTabs.splice(tabIndex, 1);
            setActiveTab(0);
        }

        setTabs(updatedTabs);

        setValue(`district_${removedDistrict.id}`, '');
        setValue(`branches_${removedDistrict.id}`, '');
    };
    const prepareRRBGeographicalArea = () => {
        const preparationErrors = [];
        const stateNames = tabs.map(tab => tab.state?.label).filter(Boolean);
        const uniqueStateNames = new Set(stateNames);
        if (uniqueStateNames.size !== stateNames.length) {
            showMessage('Multiple tabs cannot have the same state', 'error');
            return null;
        }

        const preparedData = tabs.flatMap((tab, tabIndex) => {
            if (!tab.state) {
                preparationErrors.push(`Please select a state for Area ${tabIndex + 1}`);
                return [];
            }
            const grandTotal = calculateTabGrandTotal(tab);
            tab.grandTotal = grandTotal;
            return tab.districts.map((district, districtIndex) => {
                const districtFieldName = `district_${tab.id}_${districtIndex}`;
                const branchesFieldName = `branches_${tab.id}_${districtIndex}`;
                const districtName = getValues(districtFieldName);
                const branches = parseInt(getValues(branchesFieldName) || 0, 10);
                if (!districtName) {
                    preparationErrors.push(`Please enter district name for Area ${tabIndex + 1}, District ${districtIndex + 1}`);
                }
                if (branches <= 0) {
                    preparationErrors.push(`Please enter valid number of branches for Area ${tabIndex + 1}, District ${districtIndex + 1}`);
                }
                return {
                    agId: district.id,
                    ifvId: appId,
                    agState: districtName || '',
                    agBranch: branches,
                    agType: 'ST',
                    rrbStateName: tab.state?.label || '',
                };
            }).filter(item => item.agState && item.agBranch > 0);
        });
        if (preparationErrors.length > 0) {
            showMessage(preparationErrors.join('\n'), 'error');
            return null;
        }
        return preparedData;
    };
    useEffect(() => {
        if (onDataPrepare) {
            onDataPrepare(prepareRRBGeographicalArea);
        }
        tabs.forEach((tab, tabIndex) => {
            if (tab.state) {
                setValue(`state_${tab.id}`, tab.state);
            }
            tab.districts.forEach((district, districtIndex) => {
                if (district.isExisting || !getValues(`district_${tab.id}_${districtIndex}`)) {
                    setValue(`district_${tab.id}_${districtIndex}`, district.name);
                    setValue(`branches_${tab.id}_${districtIndex}`, district.branches);
                }
            });
        });
    }, [tabs, setValue]);
    return (
        <Box sx={{ width: '100%' }}>
            <Box sx={{ borderBottom: 1, borderColor: 'divider', display: 'flex', alignItems: 'center' }}>
                <Tabs
                    value={activeTab}
                    onChange={handleTabChange}
                    aria-label="RRB geographical areas"
                    variant="scrollable"
                    scrollButtons="auto"
                >
                    {tabs.map((tab, index) => (
                        <Tab key={tab.id} label={`Area ${index + 1}`} />
                    ))}
                </Tabs>
                {(editable || (!isMaker && locked)) && (

                    <div className="button-container-end">
                        <button className='remove' type="button" onClick={handleAddTab}>+ Add State</button>
                    </div>
                )}
            </Box>
            {tabs.map((tab, tabIndex) => (
                activeTab === tabIndex && (
                    <Box key={tab.id} sx={{ p: 3 }}>
                        <div className='row mb-3'>
                            <div className='col-md-6'>
                                <Select
                                    value={tab.state}
                                    onChange={(selected) => handleStateChange(tabIndex, selected)}
                                    options={filteredStatesOptionsForRRB}
                                    onInputChange={handleStateSearchForRRB}
                                    isSearchable
                                    placeholder="Select State"
                                />
                            </div>

                            <div className='col-md-6'>

                                <div className="button-container-end">
                                    {(editable || (!isMaker && locked)) && <button className='remove' style={{ backgroundColor: 'red' }} type="button" onClick={() => handleRemoveTab(tab.id)}>Remove State</button>}
                                </div>
                            </div>

                        </div>
                        {tab.districts.map((district, districtIndex) => (
                            <div className='row mb-2' key={district.id}>
                                <div className='col-md-6'>
                                    <input
                                        type='text'
                                        className={`form-control ${errors4[`district_${tab.id}_${districtIndex}`] ? 'is-invalid' : ''}`}
                                        placeholder="Enter District"
                                        {...register4(`district_${tab.id}_${districtIndex}`, {
                                            required: "District name is required"
                                        })}
                                    />
                                    {errors4[`district_${tab.id}_${districtIndex}`] && (
                                        <div className="invalid-feedback">
                                            {errors4[`district_${tab.id}_${districtIndex}`].message}
                                        </div>
                                    )}
                                </div>
                                <div className='col-md-5'>
                                    <input
                                        type='number'
                                        className={`form-control ${errors4[`branches_${tab.id}_${districtIndex}`] ? 'is-invalid' : ''}`}
                                        placeholder="Number of Branches"
                                        {...register4(`branches_${tab.id}_${districtIndex}`, {
                                            required: "Branches field is required",
                                            min: { value: 1, message: "At least 1 branch required" },
                                            max: { value: 1000, message: "Maximum 1000 branches allowed" }
                                        })}
                                    />
                                    {errors4[`branches_${tab.id}_${districtIndex}`] && (
                                        <div className="invalid-feedback">
                                            {errors4[`branches_${tab.id}_${districtIndex}`].message}
                                        </div>
                                    )}
                                </div>

                                <div className='col-md-1'>
                                    <div className='form-group'>
                                        {(editable || (!isMaker && locked)) && <i className="fa fa-trash" aria-hidden="true"
                                            onClick={() => handleRemoveDistrict(tabIndex, districtIndex)}></i>}
                                    </div>
                                </div>
                            </div>
                        ))}
                        {(editable || (!isMaker && locked)) && (

                            <div className='col-md-12'>
                                <div className="button-container-end">
                                    <button className='remove' type="button" onClick={() => handleAddDistrict(tabIndex)}>+</button>
                                </div>
                            </div>
                        )}

                        <div className='container-fluid p-0'>
                            <div className='row'>
                                <div className='col-md-6'>
                                    <div className='form-group'>
                                        <label><strong>Grand Total</strong></label>
                                    </div>
                                </div>
                                <div className='col-md-5'>
                                    <div className='form-group'>
                                        <input
                                            className='form-control'
                                            type='number'
                                            value={calculateTabGrandTotal(tab)}
                                            readOnly
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </Box>
                )
            ))}
        </Box>
    );
};
RRBGeographicalAreaTabs.propTypes = {
    control4: PropTypes.object.isRequired,
    register4: PropTypes.func.isRequired,
    errors4: PropTypes.object.isRequired,
    getValues: PropTypes.func.isRequired,
    setValue: PropTypes.func.isRequired,
    trigger: PropTypes.func,
    appId: PropTypes.number.isRequired,
    editable: PropTypes.bool,
    isMaker: PropTypes.bool,
    locked: PropTypes.bool,
    showMessage: PropTypes.func.isRequired,
    filteredStatesOptionsForRRB: PropTypes.array.isRequired,
    handleStateSearchForRRB: PropTypes.func.isRequired,
    onDataPrepare: PropTypes.func,
    initialData: PropTypes.oneOfType([
        PropTypes.array,
        PropTypes.arrayOf(PropTypes.shape({
            agId: PropTypes.number,
            rrbStateName: PropTypes.string,
            agState: PropTypes.string,
            agBranch: PropTypes.number
        }))
    ]),
    debugInitialDataPassing: PropTypes.func,
    forceFetch: PropTypes.number
};

export default RRBGeographicalAreaTabs;