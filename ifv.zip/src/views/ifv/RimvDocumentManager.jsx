import {
    Cancel as RejectedIcon,
    CheckCircle as ApprovedIcon,
    Close as CloseIcon,
    Delete as DeleteIcon,
    Description as FileIcon,
    Download as DownloadIcon,
    HourglassEmpty as PendingIcon,
    PictureAsPdf as PdfIcon,
    TableChart as ExcelIcon,
    Upload as UploadIcon,
    Visibility as ViewIcon
} from "@mui/icons-material";
import {
    Alert,
    Box,
    Button,
    Card,
    CardContent,
    Chip,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    IconButton,
    LinearProgress,
    Paper,
    Snackbar,
    Stack,
    TextField,
    Tooltip,
    Typography
} from "@mui/material";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import { useState } from "react";
import { getJwtToken } from "services/utils/JwtUtil";
import Pattern from "services/validators/Pattern";

const API_BASE_URL = process.env.REACT_APP_API_ENDPOINT;

const getFileIcon = (fileType) => {
  const type = fileType?.toLowerCase();
  if (type?.includes("pdf")) return <PdfIcon sx={{ color: "#D32F2F" }} />;
  return <ExcelIcon sx={{ color: "#2E7D32" }} />;
};

const formatDateTime = (dateString) => {
  if (!dateString) return "N/A";
  return new Date(dateString).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

const extractFileName = (filePath) => {
  if (!filePath) return "";
  const parts = filePath.split(/[\\/]/);
  return parts.pop() || "";
};

const getStatusConfig = (status) => {
  const configs = {
    P: {
      label: "In Progress",
      bgcolor: "#FFF8E1",
      borderColor: "#FFB300",
      color: "#F57C00",
      icon: <PendingIcon sx={{ color: "#F57C00" }} />,
    },
    R: {
      label: "Rejected",
      bgcolor: "#FFEBEE",
      borderColor: "#E53935",
      color: "#C62828",
      icon: <RejectedIcon sx={{ color: "#C62828" }} />,
    },
    A: {
      label: "Approved",
      bgcolor: "#E8F5E9",
      borderColor: "#43A047",
      color: "#2E7D32",
      icon: <ApprovedIcon sx={{ color: "#2E7D32" }} />,
    },
  };
  return configs[status] || configs.P;
};

const DocumentRow = ({ doc, onDelete, onView, onDownload, data }) => {
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  return (
    <>
      <Paper
        elevation={1}
        sx={{
          p: 2,
          mb: 1.5,
          display: "flex",
          alignItems: "center",
          gap: 2,
          "&:hover": { boxShadow: 3, bgcolor: "action.hover" },
          transition: "all 0.2s",
        }}
      >
        <Box>{getFileIcon(doc.fileType)}</Box>

        <Box sx={{ flex: 1, minWidth: 0 }}>
          <Typography
            variant="subtitle2"
            noWrap
            sx={{ fontWeight: 600, mb: 0.5 }}
          >
            {doc.fileName}
          </Typography>
          <Stack direction="row" spacing={1} flexWrap="wrap">
            <Typography variant="caption" color="text.secondary">
              {formatDateTime(doc.uploadedDateTime)}
            </Typography>
          </Stack>
          {doc.remarks && (
            <Typography
              variant="caption"
              color="text.secondary"
              sx={{ display: "block", mt: 0.5, fontStyle: "italic" }}
            >
              {doc.remarks}
            </Typography>
          )}
        </Box>

        <Stack direction="row" spacing={1}>
          {doc.fileType?.toLowerCase().includes("pdf") && (
            <Tooltip title="View PDF">
              <IconButton
                size="small"
                color="primary"
                onClick={() => onView(doc)}
              >
                <ViewIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          )}
          <Tooltip title="Download">
            <IconButton
              size="small"
              color="success"
              onClick={() => onDownload(doc)}
            >
              <DownloadIcon fontSize="small" />
            </IconButton>
          </Tooltip>
          {data.fwdStatus === "N" && (
            <Tooltip title="Delete">
              <IconButton
                size="small"
                color="error"
                onClick={() => setDeleteDialogOpen(true)}
              >
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          )}
        </Stack>
      </Paper>

      <Dialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        maxWidth="xs"
      >
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          Are you sure you want to delete <strong>{doc.fileName}</strong>?
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
          <Button
            onClick={() => {
              onDelete(doc.id);
              setDeleteDialogOpen(false);
            }}
            variant="contained"
            color="error"
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default function RimvDocumentManager({ data }) {
  const queryClient = useQueryClient();
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [remarks, setRemarks] = useState("");
  const [uploadProgress, setUploadProgress] = useState(0);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });
  const [pdfViewerOpen, setPdfViewerOpen] = useState(false);
  const [pdfUrl, setPdfUrl] = useState("");
  const ifvRimvAppId = data.id;

  const { data: documents = [], isLoading } = useQuery({
    queryKey: ["rimvDocuments", ifvRimvAppId],
    queryFn: async () => {
      const response = await axios.get(
        `${API_BASE_URL}rimv/getAllDocsOnIfvRimvAppId/${ifvRimvAppId}`,
        { headers: { Authorization: `Bearer ${getJwtToken()}` } }
      );
      return response.data;
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (formData) => {
      const response = await axios.post(
        `${API_BASE_URL}rimv/uploadRimvDocument`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${getJwtToken()}`,
            "Content-Type": "multipart/form-data",
          },
          onUploadProgress: (e) =>
            setUploadProgress(Math.round((e.loaded * 100) / e.total)),
        }
      );
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["rimvDocuments", ifvRimvAppId]);
      setUploadDialogOpen(false);
      setSelectedFile(null);
      setRemarks("");
      setUploadProgress(0);
      setSnackbar({
        open: true,
        message: "Document uploaded successfully!",
        severity: "success",
      });
    },
    onError: (error) => {
      setSnackbar({
        open: true,
        message: error.response?.data?.message || "Upload failed",
        severity: "error",
      });
      setUploadProgress(0);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (documentId) => {
      await axios.delete(
        `${API_BASE_URL}rimv/deleteRimvDocument/${documentId}`,
        {
          headers: { Authorization: `Bearer ${getJwtToken()}` },
        }
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["rimvDocuments", ifvRimvAppId]);
      setSnackbar({
        open: true,
        message: "Document deleted successfully!",
        severity: "success",
      });
    },
    onError: () => {
      setSnackbar({
        open: true,
        message: "Failed to delete document",
        severity: "error",
      });
    },
  });

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const allowed = [
      "application/pdf",
      "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ];
    const maxSize = 50 * 1024 * 1024;

    if (!allowed.includes(file.type)) {
      setSnackbar({
        open: true,
        message: "Only PDF, XLS, XLSX allowed",
        severity: "error",
      });
      return;
    }
    if (file.size > maxSize) {
      setSnackbar({
        open: true,
        message: "File must be < 50MB",
        severity: "error",
      });
      return;
    }
    setSelectedFile(file);
  };

  const handleUpload = () => {
    if (!selectedFile) return;
    const formData = new FormData();
    formData.append("file", selectedFile);
    formData.append("ifvRimvAppId", ifvRimvAppId);
    if (remarks) formData.append("remarks", remarks);
    uploadMutation.mutate(formData);
  };

  const handleView = async (doc) => {
    try {
      const response = await axios.get(
        `${API_BASE_URL}rimv/viewRimvDocument/${doc.id}`,
        {
          headers: { Authorization: `Bearer ${getJwtToken()}` },
          responseType: "blob",
        }
      );
      const url = URL.createObjectURL(response.data);
      setPdfUrl(url);
      setPdfViewerOpen(true);
    } catch (error) {
      setSnackbar({
        open: true,
        message: "Failed to load document",
        severity: "error",
      });
    }
  };

  const handleDownload = async (doc) => {
    try {
      const response = await axios.get(
        `${API_BASE_URL}rimv/downloadRimvDocument/${doc.id}`,
        {
          headers: { Authorization: `Bearer ${getJwtToken()}` },
          responseType: "blob",
        }
      );
      const url = URL.createObjectURL(response.data);
      const link = document.createElement("a");
      link.href = url;
      link.download = doc.fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      setSnackbar({
        open: true,
        message: "Download failed",
        severity: "error",
      });
    }
  };

  const handleViewRimvFile = async (rimvFilePath) => {
    try {
      const token = getJwtToken();

      const response = await axios.post(
        `${API_BASE_URL}rimv/handleViewOrDownloadRimvUploads`,
        {
          filePath: rimvFilePath,
          action: "view",
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          responseType: "blob",
        }
      );

      const url = URL.createObjectURL(response.data);
      setPdfUrl(url);
      setPdfViewerOpen(true);
    } catch (err) {
      setSnackbar({
        open: true,
        message: "Failed to load document",
        severity: "error",
      });
    }
  };

  const handleDownloadRimvFile = async (rimvFilePath) => {
    try {
      const token = getJwtToken();

      const response = await axios.post(
        `${API_BASE_URL}rimv/handleViewOrDownloadRimvUploads`,
        {
          filePath: rimvFilePath,
          action: "download",
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          responseType: "blob",
        }
      );

      const fileName = extractFileName(rimvFilePath);

      const url = URL.createObjectURL(response.data);
      const link = document.createElement("a");
      link.href = url;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      setSnackbar({
        open: true,
        message: "Download failed",
        severity: "error",
      });
    }
  };

  const statusConfig = getStatusConfig(data.fwdStatus);

  return (
    <Box sx={{ p: 2, bgcolor: "grey.50" }}>
      <Box sx={{ display: "flex", gap: 4, mb: 2 }}>
        {data.singleScaleRating && (
          <Typography variant="body2">
            <strong style={{ color: statusConfig.color }}>
              Single Scale Rating:
            </strong>{" "}
            {data.singleScaleRating}
          </Typography>
        )}

        {data.combinedRating && (
          <Typography variant="body2">
            <strong style={{ color: statusConfig.color }}>
              Combined Rating:
            </strong>{" "}
            {data.combinedRating}
          </Typography>
        )}
      </Box>

      {data.fwdStatus !== "N" && (
        <Card
          variant="outlined"
          sx={{
            mb: 3,
            bgcolor: statusConfig.bgcolor,
            borderColor: statusConfig.borderColor,
            borderWidth: 2,
          }}
        >
          <CardContent>
            <Stack spacing={2}>
              {/* Status Header */}
              <Box
                sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}
              >
                {statusConfig.icon}
                <Chip
                  label={statusConfig.label}
                  sx={{
                    bgcolor: "white",
                    color: statusConfig.color,
                    fontWeight: 600,
                    borderColor: statusConfig.borderColor,
                    borderWidth: 1,
                    borderStyle: "solid",
                  }}
                />
              </Box>

              {/* Forward Comments */}
              <Box>
                <Typography
                  variant="subtitle2"
                  sx={{
                    fontWeight: 600,
                    color: statusConfig.color,
                    mb: 0.5,
                  }}
                >
                  Forwarded Comments:
                </Typography>
                <Typography variant="body2" sx={{ color: "text.primary" }}>
                  {data.fwdComments || "N/A"}
                </Typography>
              </Box>

              {/* RIMV Comments */}
              {data.rimvComments && (
                <Box>
                  <Typography
                    variant="subtitle2"
                    sx={{
                      fontWeight: 600,
                      color: statusConfig.color,
                      mb: 0.5,
                    }}
                  >
                    RIMV Comments:
                  </Typography>
                  <Typography variant="body2" sx={{ color: "text.primary" }}>
                    {data.rimvComments}
                  </Typography>
                </Box>
              )}

              {/* RIMV Validation File */}
              {data.rimvFilePath && (
                <Box>
                  <Typography
                    variant="subtitle2"
                    sx={{
                      fontWeight: 600,
                      color: statusConfig.color,
                      mb: 1,
                    }}
                  >
                    RIMV Validation File:
                  </Typography>
                  <Paper
                    elevation={1}
                    sx={{
                      p: 2,
                      display: "flex",
                      alignItems: "center",
                      gap: 2,
                      bgcolor: "white",
                      border: "1px solid",
                      borderColor: "divider",
                    }}
                  >
                    <PdfIcon sx={{ color: "#D32F2F", fontSize: 32 }} />

                    <Box sx={{ flex: 1, minWidth: 0 }}>
                      <Typography
                        variant="body2"
                        sx={{
                          fontWeight: 600,
                          mb: 0.5,
                        }}
                      >
                        {extractFileName(data.rimvFilePath)}
                      </Typography>
                      {/* <Typography
                                                variant="caption"
                                                color="text.secondary"
                                                sx={{
                                                    display: 'block',
                                                    overflow: 'hidden',
                                                    textOverflow: 'ellipsis',
                                                    whiteSpace: 'nowrap'
                                                }}
                                            >
                                                {data.rimvFilePath}
                                            </Typography> */}
                    </Box>

                    <Stack direction="row" spacing={1}>
                      <Tooltip title="View PDF">
                        <IconButton
                          size="small"
                          color="primary"
                          onClick={() => handleViewRimvFile(data.rimvFilePath)}
                          sx={{
                            bgcolor: "primary.50",
                            "&:hover": { bgcolor: "primary.100" },
                          }}
                        >
                          <ViewIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Download">
                        <IconButton
                          size="small"
                          color="success"
                          onClick={() =>
                            handleDownloadRimvFile(data.rimvFilePath)
                          }
                          sx={{
                            bgcolor: "success.50",
                            "&:hover": { bgcolor: "success.100" },
                          }}
                        >
                          <DownloadIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </Stack>
                  </Paper>
                </Box>
              )}
            </Stack>
          </CardContent>
        </Card>
      )}

      <Card variant="outlined">
        <CardContent>
          {data.fwdStatus === "N" && (
            <Box
              sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}
            >
              <Typography variant="h6">
                Documents ({documents.length})
              </Typography>
              <Button
                variant="contained"
                size="small"
                startIcon={<UploadIcon />}
                onClick={() => setUploadDialogOpen(true)}
              >
                Upload Document
              </Button>
            </Box>
          )}

          {isLoading ? (
            <Box sx={{ display: "flex", justifyContent: "center", p: 3 }}>
              <CircularProgress />
            </Box>
          ) : documents.length === 0 ? (
            <Box sx={{ textAlign: "center", py: 4, color: "text.secondary" }}>
              <FileIcon sx={{ fontSize: 48, opacity: 0.3, mb: 1 }} />
              <Typography>Please upload at least one document.</Typography>
            </Box>
          ) : (
            documents.map((doc) => (
              <DocumentRow
                key={doc.id}
                doc={doc}
                onDelete={deleteMutation.mutate}
                onView={handleView}
                onDownload={handleDownload}
                data={data}
              />
            ))
          )}
        </CardContent>
      </Card>

      <Dialog
        open={uploadDialogOpen}
        onClose={() => setUploadDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Upload Document</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 1 }}>
            <Button variant="outlined" component="label" fullWidth>
              {selectedFile ? selectedFile.name : "Choose File"}
              <input
                type="file"
                hidden
                onChange={handleFileSelect}
                accept=".pdf,.xls,.xlsx"
              />
            </Button>
            {selectedFile && (
              <Alert severity="info">
                <strong>{selectedFile.name}</strong> -{" "}
                {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB
              </Alert>
            )}
            <TextField
              label="Remarks (Optional)"
              multiline
              rows={2}
              value={remarks}
              onChange={(e) => {
                Pattern.sanitizeInput(e);
                setRemarks(e.target.value);
              }}
              fullWidth
            />
            {uploadProgress > 0 && uploadProgress < 100 && (
              <Box>
                <LinearProgress variant="determinate" value={uploadProgress} />
                <Typography variant="caption" sx={{ mt: 0.5 }}>
                  Uploading... {uploadProgress}%
                </Typography>
              </Box>
            )}
            <Typography variant="caption" color="text.secondary">
              Allowed: PDF, XLS, XLSX | Max size: 50MB
            </Typography>
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setUploadDialogOpen(false)}>Cancel</Button>
          <Button
            onClick={handleUpload}
            variant="contained"
            disabled={!selectedFile || uploadMutation.isPending}
          >
            {uploadMutation.isPending ? "Uploading..." : "Upload"}
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={pdfViewerOpen}
        onClose={() => setPdfViewerOpen(false)}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          Document Viewer
          <IconButton onClick={() => setPdfViewerOpen(false)}>
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent sx={{ p: 0, height: "80vh" }}>
          {pdfUrl && (
            <iframe
              src={pdfUrl}
              style={{ width: "100%", height: "100%", border: "none" }}
              title="PDF Viewer"
            />
          )}
        </DialogContent>
      </Dialog>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          severity={snackbar.severity}
          onClose={() => setSnackbar({ ...snackbar, open: false })}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}
