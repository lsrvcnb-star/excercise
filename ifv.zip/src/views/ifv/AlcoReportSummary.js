import DownloadIcon from '@mui/icons-material/Download';
import RefreshIcon from '@mui/icons-material/Refresh';
import { Box, IconButton, Tooltip } from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import {
    QueryClient,
    QueryClientProvider,
    keepPreviousData,
    useQuery
} from '@tanstack/react-query';
import axios from 'axios';
import { format } from 'date-fns';
import {
    MaterialReactTable,
    useMaterialReactTable,
} from 'material-react-table';
import { useMemo, useState } from 'react';
import IfvAppraisalService from 'services/IfvAppraisalService';
import FileUtil from 'services/utils/FileUtil';
import { getJwtToken } from 'services/utils/JwtUtil';

const AlcoReportSummary = () => {
    const [columnFilters, setColumnFilters] = useState([]);
    const [globalFilter, setGlobalFilter] = useState('');
    const [sorting, setSorting] = useState([]);
    const [loading, setLoading] = useState(null);
    const [pagination, setPagination] = useState({
        pageIndex: 0,
        pageSize: 10,
    });
    const {
        data: queryData,
        isError,
        isRefetching,
        isLoading,
        refetch,
        error,
    } = useQuery({
        queryKey: [
            'table-data',
            columnFilters,
            globalFilter,
            pagination.pageIndex,
            pagination.pageSize,
            sorting,
        ],
        queryFn: async () => {
            const url = process.env.REACT_APP_API_ENDPOINT + 'ifv/alcoproposal/getAlcoReportDataOnPage';
            const fetchURL = new URL(url);
            fetchURL.searchParams.set('start', `${pagination.pageIndex * pagination.pageSize}`);
            fetchURL.searchParams.set('size', `${pagination.pageSize}`);
            fetchURL.searchParams.set('filters', JSON.stringify(columnFilters ?? []));
            fetchURL.searchParams.set('globalFilter', globalFilter ?? '');
            fetchURL.searchParams.set('sorting', JSON.stringify(sorting ?? []));
            const token = getJwtToken();
            const response = await axios.get(fetchURL.href, {
                headers: { Authorization: `Bearer ${token}` },
            });
            return response.data;
        },
        placeholderData: keepPreviousData,
    });
    const tableData = queryData?.content ?? [];
    const totalRows = queryData?.totalElements ?? 0;
    const columns = useMemo(
        () => [
            {
                accessorKey: 'alAppNumber',
                header: 'Alco App Number',
                size: 200,
            },
            {
                accessorKey: 'dateOfAction',
                header: 'Created Date',
                size: 100,
                Cell: ({ cell }) => format(new Date(cell.getValue()), 'dd-MM-yyyy'),
            },
            {
                accessorKey: 'makerName',
                header: 'Maker Name',
                size: 100,
            },
            {
                accessorKey: 'status',
                header: 'Status',
                size: 150,
            },
        ],
        [],
    );
    const handleDownload = async (alCode) => {
        setLoading(alCode);
        try {
            const response = await IfvAppraisalService.findByFileAlcoId(alCode);
            FileUtil.downloadFile(response.data.fileDataBytea, response.data.fileName, "application/pdf");
        } catch (error) {
            const resMessage =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            console.log(resMessage);
            alert('Error occurred while generating report')
        } finally {
            setLoading(null);
        }
    };
    const table = useMaterialReactTable({
        columns,
        data: tableData,
        createDisplayMode: 'modal',
        editDisplayMode: 'modal',
        enableEditing: true,
        getRowId: (row) => row.id,
        muiTableContainerProps: {
            sx: {
                minHeight: '500px',
            },
        },
        initialState: { showColumnFilters: true },
        manualFiltering: true,
        manualPagination: true,
        manualSorting: true,
        muiToolbarAlertBannerProps: isError
            ? {
                color: 'error',
                children: error?.response?.data?.message || 'Error loading data',
            }
            : undefined,
        onColumnFiltersChange: setColumnFilters,
        onGlobalFilterChange: setGlobalFilter,
        onPaginationChange: setPagination,
        onSortingChange: setSorting,
        renderTopToolbarCustomActions: () => (
            <Tooltip arrow title="Refresh Data">
                <IconButton onClick={() => refetch()}>
                    <RefreshIcon />
                </IconButton>
            </Tooltip>
        ),
        renderRowActions: ({ row, table }) => (
            <Box sx={{ display: 'flex' }}>
                <Tooltip title="Download">
                    <IconButton
                        onClick={() => handleDownload(row.original.alCode)}
                        sx={{ color: loading === row.original.alCode ? 'gray' : 'primary.main' }}
                        disabled={loading === row.original.alCode}
                    >
                        {loading === row.original.alCode ? (
                            <CircularProgress size={24} />
                        ) : (
                            <DownloadIcon />
                        )}
                    </IconButton>
                </Tooltip>
            </Box >
        ),
        rowCount: totalRows,
        state: {
            columnFilters,
            globalFilter,
            isLoading,
            pagination,
            showAlertBanner: isError,
            showProgressBars: isRefetching,
            sorting,
        },
        enableRowNumbers: true,
        rowNumberDisplayMode: 'static',
        muiDetailPanelProps: () => ({
            sx: (theme) => ({
                backgroundColor:
                    theme.palette.mode === 'dark'
                        ? 'rgba(255,210,244,0.1)'
                        : 'rgba(0,0,0,0.1)',
            }),
        }),
    });
    return <MaterialReactTable table={table} />;
};
const queryClient = new QueryClient();
const AlcoReportsReactQuery = () => (
    <QueryClientProvider client={queryClient}>
        <AlcoReportSummary />
    </QueryClientProvider>
);
export default AlcoReportsReactQuery;