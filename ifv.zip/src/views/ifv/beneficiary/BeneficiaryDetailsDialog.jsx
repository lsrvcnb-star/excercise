import {
  Box,
  Button,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Grid,
  Typography
} from "@mui/material";
import { format } from "date-fns";

export default function BeneficiaryDetailsDialog({
  open,
  onClose,
  selectedRow,
}) {
  if (!selectedRow) return null;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle
        sx={{
          bgcolor: "primary.main",
          color: "white",
          fontWeight: 600,
        }}
      >
        Beneficiary Details
      </DialogTitle>

      <DialogContent sx={{ mt: 2 }}>
        <Box
          sx={{
            p: 2,
            borderRadius: 2,
            backgroundColor: "#f8fafc",
            border: "1px solid #e2e8f0",
            mb: 2,
          }}
        >
          <Grid container spacing={2}>
            <Grid item xs={4}>
              <Typography variant="caption">Bank Name</Typography>
              <Typography fontWeight={600}>
                {selectedRow.bankName || "-"}
              </Typography>
            </Grid>

            <Grid item xs={4}>
              <Typography variant="caption">CIF Number</Typography>
              <Typography fontWeight={600}>
                {selectedRow.cifNumber || "-"}
              </Typography>
            </Grid>

            <Grid item xs={4}>
              <Typography variant="caption">Beneficiary Ref No</Typography>
              <Typography fontWeight={600}>
                {selectedRow.benRefNo || "-"}
              </Typography>
            </Grid>

            {/* <Grid item xs={4}>
              <Typography variant="caption">Scheme</Typography>
              <Typography fontWeight={600}>
                {selectedRow.scheme || "-"}
              </Typography>
            </Grid>

            <Grid item xs={4}>
              <Typography variant="caption">
                Refinance Amount (₹ in Cr)
              </Typography>
              <Typography fontWeight={600}>
                {selectedRow.refinanceAmount || "-"}
              </Typography>
            </Grid> */}

            <Grid item xs={4}>
              <Typography variant="caption">Submitted By</Typography>
              <Typography>{selectedRow.uploadBy || "-"}</Typography>
            </Grid>

            <Grid item xs={8}>
              <Typography variant="caption">File Name</Typography>
              <Typography>{selectedRow.fileName || "-"}</Typography>
            </Grid>
          </Grid>
        </Box>

        <Divider sx={{ mb: 2 }} />

        <Grid container spacing={2}>
          <Grid item xs={6}>
            <Typography variant="caption">Status</Typography>
            <Box mt={1}>
              <Chip
                size="small"
                label={selectedRow.status}
                color={
                  selectedRow.status === "RETURNED"
                    ? "error"
                    : selectedRow.status === "SUBMITTED"
                    ? "success"
                    : "warning"
                }
              />
            </Box>
          </Grid>

          <Grid item xs={6}>
            <Typography variant="caption">Validated at Bank</Typography>
            <Box mt={1}>
              <Chip
                size="small"
                label={
                  selectedRow.validated?.toUpperCase() === "Y" ? "Yes" : "No"
                }
                color={
                  selectedRow.validated?.toUpperCase() === "Y"
                    ? "success"
                    : "default"
                }
              />
            </Box>
          </Grid>
        </Grid>

        <Box mt={3}>
          <Typography variant="subtitle2" fontWeight={600}>
            Remarks
          </Typography>
          <Box
            sx={{
              p: 2,
              borderRadius: 2,
              backgroundColor: "#fafafa",
              border: "1px solid #e0e0e0",
            }}
          >
            {selectedRow.remarks || "No remarks available"}
          </Box>
        </Box>

        {selectedRow.status === "RETURNED" && (
          <Box mt={3}>
            <Typography variant="subtitle2" fontWeight={600} color="error.main">
              Return Details
            </Typography>

            <Box
              sx={{
                p: 2,
                borderRadius: 2,
                backgroundColor: "#fff5f5",
                border: "1px solid #fecaca",
              }}
            >
              <Typography>
                <strong>Returned By:</strong> {selectedRow.returnBy || "-"}
              </Typography>

              <Typography sx={{ mt: 1 }} color="error.main">
                <strong>Return Remarks:</strong>{" "}
                {selectedRow.returnRemarks || "-"}
              </Typography>
            </Box>
          </Box>
        )}

        {selectedRow.status === "SUBMITTED" && (
          <Box mt={3}>
            <Typography
              variant="subtitle2"
              fontWeight={600}
              color="success.main"
              gutterBottom
            >
              DFS Submission Details
            </Typography>

            <Box
              sx={{
                p: 2,
                borderRadius: 2,
                backgroundColor: "#f0fdf4",
                border: "1px solid #bbf7d0",
              }}
            >
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography variant="caption" color="text.secondary">
                    Loan Account No
                  </Typography>
                  <Typography fontWeight={600}>
                    {selectedRow.loanAccountNo || "-"}
                  </Typography>
                </Grid>

                <Grid item xs={6}>
                  <Typography variant="caption" color="text.secondary">
                    Pre Disbursement
                  </Typography>
                  <Typography fontWeight={600}>
                    {selectedRow.benPreDisbFlag?.toUpperCase() === "Y"
                      ? "Yes"
                      : "No"}
                  </Typography>
                </Grid>

                <Grid item xs={6}>
                  <Typography variant="caption" color="text.secondary">
                    Disbursement Date
                  </Typography>
                  <Typography fontWeight={600}>
                    {selectedRow.disbDate || "-"}
                  </Typography>
                </Grid>

                <Grid item xs={6}>
                  <Typography variant="caption" color="text.secondary">
                    IFV Submitted By
                  </Typography>
                  <Typography fontWeight={600}>
                    {selectedRow.ifvSubmitBy || "-"}
                  </Typography>
                </Grid>

                <Grid item xs={6}>
                  <Typography variant="caption" color="text.secondary">
                    IFV Submitted Date
                  </Typography>
                  <Typography fontWeight={600}>
                    {selectedRow.ifvSubmittedDate
                      ? format(
                          new Date(selectedRow.ifvSubmittedDate),
                          "dd-MMM-yyyy HH:mm:ss"
                        )
                      : "-"}
                  </Typography>
                </Grid>

                {selectedRow.ifvFileName && (
                  <Grid item xs={6}>
                    <Typography variant="caption" color="text.secondary">
                      IFV Submitted File Name
                    </Typography>
                    <Typography fontWeight={600}>
                      {selectedRow.ifvFileName}
                    </Typography>
                  </Grid>
                )}

                <Grid item xs={12}>
                  <Typography variant="caption" color="text.secondary">
                    IFV Remarks
                  </Typography>

                  <Box
                    sx={{
                      mt: 1,
                      p: 1.5,
                      borderRadius: 1,
                      backgroundColor: "#ffffff",
                      border: "1px solid #d1fae5",
                    }}
                  >
                    <Typography>
                      {selectedRow.ifvRemarks || "No remarks available"}
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Box>
        )}
      </DialogContent>

      <DialogActions>
        <Button variant="contained" onClick={onClose}>
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
}
