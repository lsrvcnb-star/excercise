import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorIcon from "@mui/icons-material/Error";
import {
    Alert,
    Box,
    CircularProgress,
    LinearProgress,
    Paper,
    Typography
} from "@mui/material";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import BeneficiaryApiService from "services/BeneficiaryApiService";

const VALIDATION_POLL_INTERVAL_MS = 5000;

/**
 * Polls beneficiary upload validation status until it settles.
 * Fires onCompleted(jobId, status) or onFailed(jobId, status) exactly once.
 */
export default function ValidationStatusBanner({
  jobId,
  onCompleted,
  onFailed,
}) {
  const firedRef = useRef(false);

  const { data: status } = useQuery({
    queryKey: ["validation-status", jobId],
    queryFn: () => BeneficiaryApiService.getBeneficiaryUploadStatus(jobId),
    enabled: !!jobId,
    refetchInterval: (query) => {
      const s = query.state.data?.status;
      // stop polling once we hit a terminal state
      return s === "COMPLETED" || s === "FAILED"
        ? false
        : VALIDATION_POLL_INTERVAL_MS;
    },
    refetchIntervalInBackground: true,
  });

  // reset the "already fired" guard whenever we start tracking a new job
  useEffect(() => {
    firedRef.current = false;
  }, [jobId]);

  useEffect(() => {
    if (!status || firedRef.current) return;

    if (status.status === "COMPLETED") {
      firedRef.current = true;
      onCompleted?.(jobId, status);
    } else if (status.status === "FAILED") {
      firedRef.current = true;
      onFailed?.(jobId, status);
    }
  }, [status, jobId, onCompleted, onFailed]);

  if (!status) return null;

  const isInProgress =
    status.status === "PENDING" || status.status === "IN_PROGRESS";
  const isCompleted = status.status === "COMPLETED";
  const isFailed = status.status === "FAILED";

  return (
    <Paper
      elevation={3}
      sx={{
        p: 2,
        mb: 2,
        backgroundColor: isCompleted
          ? "#e8f5e9"
          : isFailed
          ? "#ffebee"
          : "#e3f2fd",

        border: `1px solid ${
          isCompleted ? "#4caf50" : isFailed ? "#f44336" : "#2196f3"
        }`,
      }}
    >
      <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}>
        {isInProgress && <CircularProgress size={20} />}
        {isCompleted && <CheckCircleIcon color="success" />}
        {isFailed && <ErrorIcon color="error" />}
        <Typography variant="h6">Validation Status: {status.status}</Typography>
      </Box>

      {isInProgress && (
        <>
          <LinearProgress
            variant="determinate"
            value={status.progressPercentage || 0}
            sx={{ mb: 1, height: 8, borderRadius: 4 }}
          />
          <Typography variant="body2">
            Progress: {status.progressPercentage || 0}% (
            {status.processedRows || 0}/{status.totalRowsInFile || 0} rows)
          </Typography>
        </>
      )}

      {isCompleted && (
        <Typography variant="body2">
          Valid: <strong>{status.validRecords || 0}</strong> / Total:{" "}
          <strong>{status.totalRecords || 0}</strong>
          {status.invalidRecords > 0 && ` · Invalid: ${status.invalidRecords}`}
        </Typography>
      )}

      {isFailed && (
        <Alert severity="error" sx={{ mt: 1 }}>
          {status.errorMessage ||
            "Validation failed. Fetching error details..."}
        </Alert>
      )}
    </Paper>
  );
}
