import {
  Add as AddIcon,
  CheckCircle as CheckCircleIcon,
  Download as DownloadIcon,
  Reply as ReplyIcon,
  Send as SendIcon,
  Visibility as VisibilityIcon
} from "@mui/icons-material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import {
  Alert,
  Autocomplete,
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormControlLabel,
  FormLabel,
  IconButton,
  LinearProgress,
  Radio,
  RadioGroup,
  Snackbar,
  TextField,
  Tooltip,
  Typography
} from "@mui/material";
import {
  keepPreviousData,
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQuery,
  useQueryClient
} from "@tanstack/react-query";
import { format } from "date-fns";
import {
  MaterialReactTable,
  useMaterialReactTable
} from "material-react-table";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import BeneficiaryApiService from "services/BeneficiaryApiService";
import IfvAppraisalService from "services/IfvAppraisalService";
import Pattern from "services/validators/Pattern";
import BeneficiaryDetailsDialog from "./BeneficiaryDetailsDialog";
import ValidationStatusBanner from "./ValidationStatusBanner";

const queryClient = new QueryClient();

const JOB_STORAGE_KEY = "beneficiary_dfs_current_job";

const saveJobToStorage = (jobId, status = "PROCESSING") => {
  try {
    localStorage.setItem(
      JOB_STORAGE_KEY,
      JSON.stringify({ jobId, status, timestamp: new Date().toISOString() })
    );
  } catch (error) {
    console.error("Failed to save job to storage:", error);
  }
};

const getJobFromStorage = () => {
  try {
    const stored = localStorage.getItem(JOB_STORAGE_KEY);
    if (stored) {
      const jobData = JSON.parse(stored);
      const hoursDiff =
        (new Date() - new Date(jobData.timestamp)) / (1000 * 60 * 60);
      if (hoursDiff < 24) return jobData;
      localStorage.removeItem(JOB_STORAGE_KEY);
    }
  } catch (error) {
    console.error("Failed to retrieve job from storage:", error);
  }
  return null;
};

const clearJobFromStorage = () => {
  try {
    localStorage.removeItem(JOB_STORAGE_KEY);
  } catch (error) {
    console.error("Failed to clear job from storage:", error);
  }
};

// Same JobStatusBanner as your first file — consider extracting to a shared component file.
function JobStatusBanner({ jobId, onJobComplete, onJobStatusChange }) {
  const [jobStatus, setJobStatus] = useState(null);
  const pollingIntervalRef = useRef(null);

  const fetchJobStatus = async () => {
    if (!jobId) return;
    try {
      const response = await BeneficiaryApiService.processingStatus(jobId);
      setJobStatus(response);

      if (response.status !== "NOT_FOUND") {
        saveJobToStorage(jobId, response.status);
      }

      if (onJobStatusChange) onJobStatusChange(response.status);

      if (["COMPLETED", "FAILED", "NOT_FOUND"].includes(response.status)) {
        if (pollingIntervalRef.current) {
          clearInterval(pollingIntervalRef.current);
          pollingIntervalRef.current = null;
        }
        if (response.status === "COMPLETED") {
          clearJobFromStorage();
          onJobComplete();
        } else if (response.status === "FAILED") {
          clearJobFromStorage();
        }
      }
    } catch (error) {
      console.error("Error fetching job status:", error);
    }
  };

  useEffect(() => {
    if (jobId) {
      fetchJobStatus();
      pollingIntervalRef.current = setInterval(fetchJobStatus, 5000);
    }
    return () => {
      if (pollingIntervalRef.current) clearInterval(pollingIntervalRef.current);
    };
  }, [jobId]);

  if (!jobStatus || jobStatus.status === "NOT_FOUND") return null;

  const isProcessing =
    jobStatus.status === "PROCESSING" || jobStatus.status === "IN_PROGRESS";
  const isCompleted = jobStatus.status === "COMPLETED";
  const isFailed = jobStatus.status === "FAILED";

  return (
    <Box
      sx={{
        p: 2,
        mb: 2,
        backgroundColor: isCompleted
          ? "#E8F5E9"
          : isFailed
          ? "#FFEBEE"
          : "#E3F2FD",
        border: `1px solid ${
          isCompleted ? "#4CAF50" : isFailed ? "#F44336" : "#2196F3"
        }`,
        borderRadius: 1,
      }}
    >
      <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1 }}>
        {isProcessing && <CircularProgress size={20} />}
        {isCompleted && <CheckCircleIcon color="success" />}
        {isFailed && <Typography color="error">✗</Typography>}
        <Typography variant="subtitle1">
          DFS Upload Status: {jobStatus.status}
        </Typography>
      </Box>

      {isProcessing && (
        <>
          <LinearProgress
            variant="determinate"
            value={jobStatus.progressPercentage || 0}
            sx={{ mb: 1, height: 8, borderRadius: 4 }}
          />
          <Typography variant="body2" sx={{ mb: 1 }}>
            Progress: {jobStatus.progressPercentage || 0}%
          </Typography>
        </>
      )}

      <Box sx={{ display: "flex", gap: 3 }}>
        <Typography variant="body2">
          Processed: <strong>{jobStatus.processedRecords || 0}</strong>
        </Typography>
        <Typography variant="body2" color="error">
          Failed: <strong>{jobStatus.failedRecords || 0}</strong>
        </Typography>
      </Box>
    </Box>
  );
}

function BeneficiarySummaryTable() {
  const user = IfvAppraisalService.getCurrentUser();
  const queryClient = useQueryClient();

  const navigate = useNavigate();

  const [selectedRow, setSelectedRow] = useState(null);
  const [globalFilter, setGlobalFilter] = useState("");
  const [sorting, setSorting] = useState([
    { id: "uploadDateTime", desc: true },
  ]);
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 10 });

  const [returnDialogOpen, setReturnDialogOpen] = useState(false);
  const [returnRemarks, setReturnRemarks] = useState("");
  const [selectedReturnRow, setSelectedReturnRow] = useState(null);
  const [returning, setReturning] = useState(false);
  const [downloadingFiles, setDownloadingFiles] = useState({});

  // ---- Upload / Submit-to-DFS dialog state ----
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [selectedSubmitRow, setSelectedSubmitRow] = useState(null); // row we're submitting to DFS
  const [uploadFile, setUploadFile] = useState(null);
  const [fileLoading, setFileLoading] = useState(false);
  const [uploadData, setUploadData] = useState({
    benRefNo: "",
    benPreDisbFlag: "N",
    loanAccountNo: "",
    disbDate: "",
    remarks: "",
    submitBy: "",
    proceedWithBankUploadFile: "Y",
  });

  const [selectedLoanAccount, setSelectedLoanAccount] = useState(null);
  const [loanAccountOptions, setLoanAccountOptions] = useState([]);
  const [loadingLoanAccounts, setLoadingLoanAccounts] = useState(false);

  const [disbursementDates, setDisbursementDates] = useState([]);
  const [selectedDisbDate, setSelectedDisbDate] = useState(null);
  const [loadingDisbDate, setLoadingDisbDate] = useState(false);

  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });
  const [currentJobId, setCurrentJobId] = useState(null);
  const [isJobProcessing, setIsJobProcessing] = useState(false);
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);

  const MAX_UI_ERRORS = 20;
  const [validationErrors, setValidationErrors] = useState([]);
  const [errorDialogOpen, setErrorDialogOpen] = useState(false);

  const fileInputRef = useRef(null);

  const [validationJobId, setValidationJobId] = useState(null);
  const [pendingForwardJobId, setPendingForwardJobId] = useState(null);

  const { data, isLoading, isFetching, isError, error, refetch } = useQuery({
    queryKey: ["beneficiary-summary", pagination, sorting, globalFilter],
    queryFn: () =>
      BeneficiaryApiService.fetchBeneficiaryUploadsForAllBanks({
        page: pagination.pageIndex,
        size: pagination.pageSize,
        globalFilter,
        sortField: sorting?.[0]?.id,
        sortDirection: sorting?.[0]?.desc ? "desc" : "asc",
      }),
    placeholderData: keepPreviousData,
  });

  // ---- STEP 1: kick off validation ----
  const validateMutation = useMutation({
    mutationFn: ({ file, data }) =>
      BeneficiaryApiService.uploadAndValidateBeneficiary({ file, data }),

    onSuccess: (response) => {
      if (!response?.success) {
        setSnackbar({
          open: true,
          message: response?.message || "Failed to initiate validation",
          severity: "error",
        });
        return;
      }

      const jobId = response?.data?.jobId;
      if (!jobId) {
        setSnackbar({
          open: true,
          message: "No job ID returned from server",
          severity: "error",
        });
        return;
      }

      const status = response?.data?.status;

      handleCloseDialog();

      if (status === "VALIDATED") {
        setSnackbar({
          open: true,
          message:
            "Bank uploaded file already validated. Initiating DFS submission...",
          severity: "info",
        });

        forwardMutation.mutate(jobId);
        return;
      }

      setValidationJobId(jobId);

      setSnackbar({
        open: true,
        message: "File uploaded. Validating...",
        severity: "info",
      });
    },

    onError: (error) => {
      const errorMessage =
        error?.message ||
        error?.errors?.[0] ||
        "Failed to upload beneficiary file";
      setSnackbar({ open: true, message: errorMessage, severity: "error" });
    },
  });

  // ---- STEP 3: forward to DFS, called once validation COMPLETED ----
  const forwardMutation = useMutation({
    mutationFn: (jobId) => BeneficiaryApiService.forwardBeneficiaryData(jobId),

    onSuccess: (response, jobId) => {
      if (!response?.success) {
        setSnackbar({
          open: true,
          message:
            response?.message ||
            "Failed to initiate beneficiary data forwarding",
          severity: "error",
        });
        return;
      }

      const forwardedJobId = response.message || jobId;
      setCurrentJobId(forwardedJobId);
      setIsJobProcessing(true);
      saveJobToStorage(forwardedJobId, "PROCESSING");
      setPendingForwardJobId(null);

      setSnackbar({
        open: true,
        message: "Validation passed. Beneficiary data forwarding initiated…",
        severity: "success",
      });

      refetch();
    },

    onError: (error, jobId) => {
      setPendingForwardJobId(jobId);
      setSnackbar({
        open: true,
        message: error?.message || "Failed to forward beneficiary data to DFS",
        severity: "error",
      });
    },
  });

  // ---- STEP 2 (failure branch): fetch errors once validation fails ----
  const fetchValidationErrors = async (jobId, status) => {
    try {
      const errors = await BeneficiaryApiService.getValidationErrors(jobId);
      if (errors?.length) {
        setValidationErrors(errors);
        setErrorDialogOpen(true);
        setSnackbar({
          open: true,
          message: `${errors.length} validation errors found`,
          severity: "error",
        });
      } else {
        setSnackbar({
          open: true,
          message: status?.errorMessage || "Validation failed",
          severity: "error",
        });
      }
    } catch (e) {
      setSnackbar({
        open: true,
        message: "Validation failed and errors could not be retrieved",
        severity: "error",
      });
    } finally {
      setValidationJobId(null);
    }
  };

  const handleValidationCompleted = (jobId) => {
    setValidationJobId(null);
    setPendingForwardJobId(jobId);
    forwardMutation.mutate(jobId);
  };

  const handleValidationFailed = (jobId, status) => {
    fetchValidationErrors(jobId, status);
  };

  const downloadErrorReport = async () => {
    if (!validationErrors.length) return;
    const XLSX = await import("xlsx");
    const excelData = validationErrors.map((err) => ({
      "Row Number": err.rowNumber,
      "Field Name": err.fieldName,
      "Error Message": err.errorMessage,
      "Field Value": err.fieldValue,
    }));
    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Validation Errors");
    XLSX.writeFile(workbook, "Beneficiary_Validation_Errors.xlsx");
  };

  // Resume any in-flight DFS job on mount
  useEffect(() => {
    const storedJob = getJobFromStorage();
    if (
      storedJob &&
      storedJob.status !== "COMPLETED" &&
      storedJob.status !== "FAILED"
    ) {
      setCurrentJobId(storedJob.jobId);
      setIsJobProcessing(true);
      setSnackbar({
        open: true,
        message: "Resuming tracking of previous job...",
        severity: "info",
      });
    }
  }, []);

  // Fetch loan accounts for the row's CIF whenever the dialog is open and flag is 'N'
  useEffect(() => {
    const fetchLoanAccounts = async () => {
      if (
        !uploadDialogOpen ||
        !selectedSubmitRow?.cifNumber ||
        uploadData.benPreDisbFlag === "Y"
      ) {
        setLoanAccountOptions([]);
        return;
      }

      try {
        setLoadingLoanAccounts(true);
        const loanAccounts = await BeneficiaryApiService.fetchLoanAccNoOnCif(
          selectedSubmitRow.cifNumber
        );
        const options = loanAccounts.map((account) => ({
          value: account,
          label: account,
        }));
        setLoanAccountOptions(options);

        if (options.length === 0) {
          setUploadData((prev) => ({
            ...prev,
            benPreDisbFlag: "Y",
            loanAccountNo: "",
          }));
          setSnackbar({
            open: true,
            message:
              "No loan accounts found. Pre-disbursement flag set to Yes.",
            severity: "info",
          });
        }
      } catch (error) {
        setSnackbar({
          open: true,
          message: "Failed to load loan accounts",
          severity: "error",
        });
        setLoanAccountOptions([]);
        setUploadData((prev) => ({
          ...prev,
          benPreDisbFlag: "Y",
          loanAccountNo: "",
        }));
      } finally {
        setLoadingLoanAccounts(false);
      }
    };

    fetchLoanAccounts();
  }, [uploadDialogOpen, selectedSubmitRow, uploadData.benPreDisbFlag]);

  const fetchDisbursementDate = async (accNo) => {
    if (!accNo) {
      setDisbursementDates([]);
      setSelectedDisbDate(null);
      setUploadData((prev) => ({ ...prev, disbDate: "" }));
      return;
    }

    try {
      setLoadingDisbDate(true);
      const response = await BeneficiaryApiService.fetchDisbDateOnAccNo(accNo);
      const dates = Array.isArray(response) ? response : [response];
      const options = dates.map((d) => ({
        value: d.disbDate || d,
        label: d.disbDate || d,
      }));
      setDisbursementDates(options);
    } catch (error) {
      setSnackbar({
        open: true,
        message: "Failed to fetch disbursement dates",
        severity: "error",
      });
      setDisbursementDates([]);
    } finally {
      setLoadingDisbDate(false);
    }
  };

  const handleLoanAccountChange = async (event, newValue) => {
    setSelectedLoanAccount(newValue);
    const accNo = newValue?.value || "";
    setUploadData((prev) => ({ ...prev, loanAccountNo: accNo, disbDate: "" }));
    setSelectedDisbDate(null);
    setDisbursementDates([]);
    if (accNo) await fetchDisbursementDate(accNo);
  };

  const handleDisbDateChange = (event, newValue) => {
    setSelectedDisbDate(newValue);
    setUploadData((prev) => ({ ...prev, disbDate: newValue?.value || "" }));
  };

  const handlePreDisbFlagChange = (event) => {
    const newValue = event.target.value;
    setUploadData((prev) => ({
      ...prev,
      benPreDisbFlag: newValue,
      loanAccountNo: newValue === "Y" ? "" : prev.loanAccountNo,
      disbDate: newValue === "Y" ? "" : prev.disbDate,
    }));

    if (newValue === "Y") {
      setSelectedLoanAccount(null);
      setSelectedDisbDate(null);
      setDisbursementDates([]);
    }
  };

  const MAX_SIZE_BYTES = 50 * 1024 * 1024;

  const isExcelFile = (file) => {
    if (!file) return false;
    const allowedMimeTypes = [
      "application/vnd.ms-excel",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ];
    const isMimeOk = allowedMimeTypes.includes(file.type);
    const name = file.name?.toLowerCase() || "";
    const hasValidExtension = name.endsWith(".xls") || name.endsWith(".xlsx");
    return isMimeOk || hasValidExtension;
  };

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 100));
    setUploadFile(file);
    setFileLoading(false);
    e.target.value = "";
  };

  // Opens the upload dialog scoped to a specific row (replaces the old direct API call)
  const handleOpenSubmitToDFS = (row) => {
    setSelectedSubmitRow(row);
    setUploadData({
      benRefNo: row.benRefNo,
      benPreDisbFlag: "N",
      loanAccountNo: "",
      disbDate: "",
      remarks: "",
      submitBy: user?.ofrName,
      proceedWithBankUploadFile: "Y",
    });
    setSelectedLoanAccount(null);
    setSelectedDisbDate(null);
    setLoanAccountOptions([]);
    setDisbursementDates([]);
    setUploadFile(null);
    setUploadDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setUploadDialogOpen(false);
    setSelectedSubmitRow(null);
    setUploadFile(null);
    setFileLoading(false);
    setSelectedLoanAccount(null);
    setLoanAccountOptions([]);
    setSelectedDisbDate(null);
    setDisbursementDates([]);
    setUploadData({
      benRefNo: "",
      benPreDisbFlag: "N",
      loanAccountNo: "",
      disbDate: "",
      remarks: "",
      submitBy: "",
      proceedWithBankUploadFile: "Y",
    });
  };

  const handleUploadSubmit = () => {
    if (uploadData.proceedWithBankUploadFile === "N") {
      if (!uploadFile) {
        setSnackbar({
          open: true,
          message: "Please select a file",
          severity: "warning",
        });
        return;
      }

      if (!isExcelFile(uploadFile)) {
        setSnackbar({
          open: true,
          message: "Only XLSX files are allowed",
          severity: "error",
        });
        return;
      }

      if (uploadFile.size > MAX_SIZE_BYTES) {
        setSnackbar({
          open: true,
          message: "File size must not exceed 50 MB",
          severity: "error",
        });
        return;
      }
    }

    if (uploadData.benPreDisbFlag === "N" && !uploadData.loanAccountNo) {
      setSnackbar({
        open: true,
        message: "Please select a loan account",
        severity: "warning",
      });
      return;
    }

    if (uploadData.benPreDisbFlag === "N" && !uploadData.disbDate) {
      setSnackbar({
        open: true,
        message: "Please select disbursement date",
        severity: "warning",
      });
      return;
    }

    if (!uploadData.remarks.trim()) {
      setSnackbar({
        open: true,
        message: "Please enter remarks",
        severity: "warning",
      });
      return;
    }

    const completeUploadData = {
      ...uploadData,
      submitBy: user?.ofrName,
    };

    validateMutation.mutate({ file: uploadFile, data: completeUploadData });
  };

  const displayErrors = validationErrors.slice(0, MAX_UI_ERRORS);
  const hasMoreErrors = validationErrors.length > MAX_UI_ERRORS;

  const isValidationInProgress = !!validationJobId;
  const isAnyJobRunning =
    isJobProcessing ||
    isValidationInProgress ||
    validateMutation.isPending ||
    forwardMutation.isPending;

  const isBusy =
    validateMutation.isPending || forwardMutation.isPending || fileLoading;

  const handleDownload = async (filePath, fileName) => {
    setDownloadingFiles((prev) => ({ ...prev, [filePath]: true }));
    try {
      const result = await BeneficiaryApiService.downloadAppDocument(
        filePath,
        fileName
      );

      if (!result.success) {
        setSnackbar({
          open: true,
          severity: "error",
          message: result.message,
        });
      }
    } catch (err) {
      setSnackbar({
        open: true,
        severity: "error",
        message: err?.message || "Failed to download file.",
      });
    } finally {
      setDownloadingFiles((prev) => ({
        ...prev,
        [filePath]: false,
      }));
    }
  };

  const handleReturnApplication = async () => {
    if (!returnRemarks.trim()) {
      setSnackbar({
        open: true,
        message: "Please enter return remarks before proceeding.",
        severity: "warning",
      });
      return;
    }

    try {
      setReturning(true);

      const response = await BeneficiaryApiService.returnForwardedApplication({
        benRefNo: selectedReturnRow.benRefNo,
        returnRemarks: returnRemarks.trim(),
        returnBy: user.ofrName,
      });

      setSelectedRow(null);
      setReturnDialogOpen(false);
      setSelectedReturnRow(null);

      await refetch();

      queryClient.invalidateQueries({
        queryKey: ["beneficiary-summary"],
      });

      setSnackbar({
        open: true,
        message:
          response?.message ||
          "Application has been returned to the bank successfully.",
        severity: "success",
      });
    } catch (error) {
      setSnackbar({
        open: true,
        message:
          error?.response?.data?.errors?.[0] ||
          error?.response?.data?.message ||
          "Unable to return the application. Please try again.",
        severity: "error",
      });
    } finally {
      setReturning(false);
    }
  };

  const handleJobComplete = async () => {
    setIsJobProcessing(false);

    await queryClient.invalidateQueries({
      queryKey: ["beneficiary-summary"],
    });

    await refetch();

    setSnackbar({
      open: true,
      message:
        "Beneficiary data has been transferred to DFS successfully. Please check the submission status in the Submitted Summary section.",
      severity: "success",
    });
  };

  const handleJobStatusChange = (status) => {
    if (status === "FAILED") {
      setIsJobProcessing(false);
      setSnackbar({
        open: true,
        message: "Job processing failed. Please check the records.",
        severity: "error",
      });
    }
  };

  const columns = useMemo(
    () => [
      {
        header: "Sl No",
        size: 70,
        enableSorting: false,
        Cell: ({ row, table }) => {
          const { pageIndex, pageSize } = table.getState().pagination;
          return pageIndex * pageSize + row.index + 1;
        },
      },
      { accessorKey: "bankName", header: "Bank Name", size: 150 },
      { accessorKey: "benRefNo", header: "Beneficiary Ref No", size: 100 },
      {
        accessorKey: "validated",
        header: "Validated",
        size: 100,
        Cell: ({ cell }) =>
          cell.getValue()?.toUpperCase() === "Y" ? "Yes" : "No",
      },
      {
        accessorKey: "uploadDateTime",
        header: "Upload Date",
        Cell: ({ cell }) =>
          cell.getValue()
            ? format(new Date(cell.getValue()), "dd-MMM-yyyy")
            : "-",
        size: 100,
      },
      {
        accessorKey: "status",
        header: "Status",
        size: 100,
        Cell: ({ cell }) => {
          const status = cell.getValue()?.toUpperCase();

          const styles = {
            PENDING: {
              bgcolor: "#FFF3E0",
              color: "#E65100",
            },
            VALIDATED: {
              bgcolor: "#E3F2FD",
              color: "#1565C0",
            },
            SUBMITTED: {
              bgcolor: "#E8F5E9",
              color: "#2E7D32",
            },
            RETURNED: {
              bgcolor: "#FFEBEE",
              color: "#C62828",
            },
          };

          return (
            <Chip
              label={status}
              size="small"
              sx={{
                fontWeight: 600,
                ...styles[status],
              }}
            />
          );
        },
      },
    ],
    []
  );

  const table = useMaterialReactTable({
    columns,
    data: data?.content ?? [],
    rowCount: data?.totalElements ?? 0,
    enableRowActions: true,
    positionActionsColumn: "last",
    // displayColumnDefOptions: {
    //   "mrt-row-actions": {
    //     header: "Actions",
    //     size: 140,
    //   },
    // },
    manualPagination: true,
    manualSorting: true,
    manualFiltering: true,
    onPaginationChange: setPagination,
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    state: {
      pagination,
      sorting,
      globalFilter,
      isLoading,
      showProgressBars: isFetching,
      showAlertBanner: isError,
    },
    renderRowActions: ({ row }) => (
      <Box sx={{ display: "flex", gap: 1 }}>
        <Tooltip title="View Details">
          <IconButton
            color="primary"
            disabled={isAnyJobRunning}
            onClick={() => setSelectedRow(row.original)}
          >
            <VisibilityIcon />
          </IconButton>
        </Tooltip>

        <Tooltip title="Download XLSX">
          <IconButton
            color="success"
            disabled={
              isAnyJobRunning || downloadingFiles[row.original.filePath]
            }
            onClick={() =>
              handleDownload(row.original.filePath, row.original.fileName)
            }
          >
            {downloadingFiles[row.original.filePath] ? (
              <CircularProgress size={20} />
            ) : (
              <DownloadIcon />
            )}
          </IconButton>
        </Tooltip>

        {(row.original.status === "PENDING" ||
          row.original.status === "VALIDATED") && (
          <>
            <Tooltip title="Submit To DFS">
              <IconButton
                color="warning"
                disabled={isAnyJobRunning}
                onClick={() => {
                  if (isAnyJobRunning) {
                    setSnackbar({
                      open: true,
                      message:
                        "Please wait for the current job to complete before submitting another.",
                      severity: "warning",
                    });
                    return;
                  }
                  handleOpenSubmitToDFS(row.original);
                }}
              >
                <SendIcon />
              </IconButton>
            </Tooltip>

            <Tooltip title="Return Application">
              <IconButton
                color="error"
                disabled={isAnyJobRunning}
                onClick={() => {
                  setSelectedReturnRow(row.original);
                  setReturnRemarks("");
                  setReturnDialogOpen(true);
                }}
              >
                <ReplyIcon />
              </IconButton>
            </Tooltip>
          </>
        )}
      </Box>
    ),
    muiTableHeadCellProps: {
      sx: { backgroundColor: "#E3F2FD", fontWeight: "bold" },
    },
  });

  return (
    <>
      {isError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error?.message ?? "Failed to fetch records"}
        </Alert>
      )}

      {validationJobId && (
        <ValidationStatusBanner
          jobId={validationJobId}
          onCompleted={handleValidationCompleted}
          onFailed={handleValidationFailed}
        />
      )}

      {forwardMutation.isError && pendingForwardJobId && (
        <Alert
          severity="error"
          sx={{ mb: 2 }}
          action={
            <Button
              color="inherit"
              size="small"
              onClick={() => forwardMutation.mutate(pendingForwardJobId)}
            >
              Retry
            </Button>
          }
        >
          Validation passed but forwarding to DFS failed. You can retry without
          re-uploading.
        </Alert>
      )}

      {currentJobId && isJobProcessing && (
        <JobStatusBanner
          jobId={currentJobId}
          onJobComplete={handleJobComplete}
          onJobStatusChange={handleJobStatusChange}
        />
      )}

      {!isAnyJobRunning && (
        <Box
          sx={{
            mb: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Button
            variant="outlined"
            startIcon={<ArrowBackIcon />}
            disabled={isAnyJobRunning}
            onClick={() => navigate("/ifv/beneficiaryDashboard")}
          >
            Back
          </Button>
        </Box>
      )}

      <MaterialReactTable table={table} />

      <BeneficiaryDetailsDialog
        open={Boolean(selectedRow)}
        selectedRow={selectedRow}
        onClose={() => setSelectedRow(null)}
      />

      {/* Submit to DFS dialog */}
      <Dialog
        open={uploadDialogOpen}
        onClose={handleCloseDialog}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Submit Beneficiary to DFS</DialogTitle>
        <DialogContent>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 2, mt: 2 }}>
            <Box
              sx={{
                mb: 2,
                p: 1.5,
                bgcolor: "#f8f9fa",
                borderRadius: 1,
              }}
            >
              <Box sx={{ display: "flex", gap: 4, mb: 1 }}>
                <Typography variant="body2">
                  <strong>Bank Name:</strong> {selectedSubmitRow?.bankName}
                </Typography>

                <Typography variant="body2">
                  <strong>CIF Number:</strong> {selectedSubmitRow?.cifNumber}
                </Typography>
              </Box>

              {/* <Box sx={{ display: "flex", gap: 4 }}>
                <Typography variant="body2">
                  <strong>Scheme:</strong> {selectedSubmitRow?.scheme}
                </Typography>

                <Typography variant="body2">
                  <strong>Refinance Amount:</strong> ₹{" "}
                  {selectedSubmitRow?.refinanceAmount} Cr
                </Typography>
              </Box> */}
            </Box>

            <TextField
              label="Beneficiary Ref No"
              value={uploadData.benRefNo}
              disabled
              fullWidth
              InputProps={{ readOnly: true }}
            />

            <FormControl component="fieldset">
              <FormLabel
                component="legend"
                sx={{ fontSize: "0.875rem", mb: 1 }}
              >
                Pre-Disbursement Flag <span style={{ color: "red" }}>*</span>
              </FormLabel>
              <RadioGroup
                row
                value={uploadData.benPreDisbFlag}
                onChange={handlePreDisbFlagChange}
              >
                <FormControlLabel value="Y" control={<Radio />} label="Yes" />
                <FormControlLabel value="N" control={<Radio />} label="No" />
              </RadioGroup>
            </FormControl>

            {uploadData.benPreDisbFlag === "Y" ? (
              <Alert severity="info" sx={{ mt: 1 }}>
                Beneficiary reference number will be auto-generated from the
                system.
              </Alert>
            ) : (
              <>
                <Autocomplete
                  value={selectedLoanAccount}
                  onChange={handleLoanAccountChange}
                  options={loanAccountOptions}
                  getOptionLabel={(option) => option.label}
                  loading={loadingLoanAccounts}
                  disabled={loadingLoanAccounts}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Select Loan Account"
                      required
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {loadingLoanAccounts ? (
                              <CircularProgress color="inherit" size={20} />
                            ) : null}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                  isOptionEqualToValue={(option, value) =>
                    option.value === value.value
                  }
                  noOptionsText="No loan accounts found"
                />

                <Autocomplete
                  value={selectedDisbDate}
                  onChange={handleDisbDateChange}
                  options={disbursementDates}
                  getOptionLabel={(option) => option.label}
                  loading={loadingDisbDate}
                  disabled={!selectedLoanAccount || loadingDisbDate}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Select Disbursement Date"
                      required
                      InputProps={{
                        ...params.InputProps,
                        endAdornment: (
                          <>
                            {loadingDisbDate ? (
                              <CircularProgress size={20} />
                            ) : null}
                            {params.InputProps.endAdornment}
                          </>
                        ),
                      }}
                    />
                  )}
                  isOptionEqualToValue={(option, value) =>
                    option.value === value.value
                  }
                />
              </>
            )}

            <TextField
              label="Remarks"
              value={uploadData.remarks}
              onChange={(e) => {
                Pattern.sanitizeInput(e);
                setUploadData((prev) => ({ ...prev, remarks: e.target.value }));
              }}
              fullWidth
              required
              multiline
              rows={1}
              placeholder="Enter remarks for this beneficiary"
            />

            <FormControl component="fieldset">
              <FormLabel
                component="legend"
                sx={{
                  fontSize: "0.875rem",
                  mb: 1,
                  color: "text.primary",
                  fontWeight: 500,
                }}
              >
                Proceed with Bank Uploaded File{" "}
                <span style={{ color: "red" }}>*</span>
              </FormLabel>

              <RadioGroup
                row
                value={uploadData.proceedWithBankUploadFile}
                onChange={(e) =>
                  setUploadData((prev) => ({
                    ...prev,
                    proceedWithBankUploadFile: e.target.value,
                  }))
                }
              >
                <FormControlLabel value="Y" control={<Radio />} label="Yes" />
                <FormControlLabel value="N" control={<Radio />} label="No" />
              </RadioGroup>
            </FormControl>

            {uploadData.proceedWithBankUploadFile === "Y" &&
              selectedSubmitRow?.validated === "Y" && (
                <Alert severity="success">
                  Bank-uploaded beneficiary data has already been validated. It
                  will be submitted to DFS directly.
                </Alert>
              )}
            {uploadData.proceedWithBankUploadFile === "Y" &&
              selectedSubmitRow?.validated !== "Y" && (
                <Alert severity="info">
                  Validation has not been completed for the Bank-uploaded
                  beneficiary data. Upon successful validation, the data will be
                  submitted to DFS.
                </Alert>
              )}

            {uploadData.proceedWithBankUploadFile === "N" && (
              <Box>
                <Button
                  variant="outlined"
                  component="label"
                  startIcon={
                    fileLoading ? <CircularProgress size={20} /> : <AddIcon />
                  }
                  fullWidth
                  disabled={fileLoading}
                  sx={{
                    justifyContent: "flex-start",
                    textAlign: "left",
                    textTransform: "none",
                  }}
                >
                  {fileLoading ? (
                    <Typography>Loading file...</Typography>
                  ) : uploadFile ? (
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        gap: 1,
                        width: "100%",
                      }}
                    >
                      <Typography noWrap sx={{ flex: 1 }}>
                        {uploadFile.name}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        ({(uploadFile.size / 1024).toFixed(2)} KB)
                      </Typography>
                    </Box>
                  ) : (
                    "Select File to Upload"
                  )}
                  <input
                    type="file"
                    hidden
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
                    disabled={fileLoading}
                  />
                </Button>

                {fileLoading && (
                  <Box sx={{ mt: 1 }}>
                    <LinearProgress />
                    <Typography
                      variant="caption"
                      color="text.secondary"
                      sx={{ mt: 0.5, display: "block" }}
                    >
                      Processing file...
                    </Typography>
                  </Box>
                )}

                {uploadFile && !fileLoading && (
                  <Button
                    size="small"
                    color="error"
                    onClick={() => {
                      setUploadFile(null);
                      if (fileInputRef.current) fileInputRef.current.value = "";
                    }}
                    sx={{ mt: 1 }}
                  >
                    Remove File
                  </Button>
                )}
              </Box>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          {isBusy && (
            <Box
              display="flex"
              alignItems="center"
              gap={1}
              sx={{ mr: "auto" }}
              aria-live="polite"
              role="status"
            >
              <CircularProgress size={18} />
              <Typography variant="body2" color="text.secondary">
                Submitting… Please don't close this dialog.
              </Typography>
            </Box>
          )}
          <Button onClick={handleCloseDialog} disabled={isBusy}>
            Cancel
          </Button>
          <Button
            onClick={handleUploadSubmit}
            variant="contained"
            disabled={isBusy}
          >
            {validateMutation.isPending ? (
              <CircularProgress size={24} />
            ) : (
              "Submit"
            )}
          </Button>
        </DialogActions>
      </Dialog>

      {/* DFS status check dialog */}
      <Dialog
        open={statusDialogOpen}
        onClose={() => setStatusDialogOpen(false)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>DFS Upload Status</DialogTitle>
        <DialogContent>
          {currentJobId && (
            <JobStatusBanner
              jobId={currentJobId}
              onJobComplete={handleJobComplete}
              onJobStatusChange={handleJobStatusChange}
            />
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setStatusDialogOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Validation errors dialog */}
      <Dialog
        open={errorDialogOpen}
        onClose={() => setErrorDialogOpen(false)}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>Validation Errors ({validationErrors.length})</DialogTitle>
        <DialogContent>
          {hasMoreErrors && (
            <Alert severity="warning" sx={{ mb: 2 }}>
              Showing first 20 errors. Download the report for full details.
            </Alert>
          )}
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <th style={{ textAlign: "left" }}>Row</th>
                <th style={{ textAlign: "left" }}>Field</th>
                <th style={{ textAlign: "left" }}>Error</th>
                <th style={{ textAlign: "left" }}>Value</th>
              </tr>
            </thead>
            <tbody>
              {displayErrors.map((err, index) => (
                <tr key={index}>
                  <td>{err.rowNumber}</td>
                  <td>{err.fieldName}</td>
                  <td>{err.errorMessage}</td>
                  <td>{err.fieldValue}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </DialogContent>
        <DialogActions>
          {hasMoreErrors && (
            <Button variant="contained" onClick={downloadErrorReport}>
              Download Full Error Report
            </Button>
          )}
          <Button onClick={() => setErrorDialogOpen(false)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* Return application dialog (unchanged) */}
      <Dialog
        open={returnDialogOpen}
        onClose={() => !returning && setReturnDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle
          sx={{ bgcolor: "error.main", color: "white", fontWeight: 600 }}
        >
          Return Application to Bank
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <Typography sx={{ mb: 2 }}>
            Please provide remarks explaining why the application is being
            returned.
          </Typography>
          <TextField
            fullWidth
            multiline
            rows={2}
            label="Return Remarks"
            value={returnRemarks}
            onChange={(e) => setReturnRemarks(e.target.value)}
            required
            inputProps={{ maxLength: 1000 }}
            helperText={`${returnRemarks.length}/1000`}
          />
        </DialogContent>
        <DialogActions sx={{ p: 2 }}>
          <Button
            onClick={() => setReturnDialogOpen(false)}
            disabled={returning}
          >
            Cancel
          </Button>
          <Button
            variant="contained"
            color="error"
            disabled={!returnRemarks.trim() || returning}
            onClick={handleReturnApplication}
          >
            {returning ? "Returning..." : "Return to Bank"}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={5000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
        sx={{
          mt: 6, // push down from top a little
        }}
      >
        <Alert
          severity={snackbar.severity}
          variant="filled"
          sx={{ minWidth: 450 }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
}

export default function ViewAndManageBeneficiary() {
  return (
    <QueryClientProvider client={queryClient}>
      <BeneficiarySummaryTable />
    </QueryClientProvider>
  );
}
