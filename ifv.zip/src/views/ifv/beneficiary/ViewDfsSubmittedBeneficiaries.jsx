import CloudDownloadIcon from "@mui/icons-material/CloudDownload";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import CircularProgress from "@mui/material/CircularProgress";

import { Visibility as VisibilityIcon } from "@mui/icons-material";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFnsV3";

import {
  Alert,
  Box,
  Button,
  IconButton,
  Snackbar,
  Tooltip
} from "@mui/material";

import {
  keepPreviousData,
  QueryClient,
  QueryClientProvider,
  useQuery
} from "@tanstack/react-query";

import {
  MaterialReactTable,
  useMaterialReactTable
} from "material-react-table";

import { format } from "date-fns";
import { useMemo, useState } from "react";

import BeneficiaryApiService from "services/BeneficiaryApiService";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import { useNavigate } from "react-router-dom";
import BeneficiaryDetailsDialog from "./BeneficiaryDetailsDialog";

const queryClient = new QueryClient();

function BeneficiarySummaryTable() {
  const [selectedRow, setSelectedRow] = useState(null);
  const navigate = useNavigate();

  const [globalFilter, setGlobalFilter] = useState("");
  const [columnFilters, setColumnFilters] = useState([]);

  const [sorting, setSorting] = useState([
    {
      id: "ifvSubmittedDate",
      desc: true,
    },
  ]);

  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: 10,
  });

  const [downloadingFiles, setDownloadingFiles] = useState({});

  const submittedDateFilter = columnFilters.find(
    (f) => f.id === "ifvSubmittedDate"
  )?.value;

  const { data, isLoading, isFetching, isError, error } = useQuery({
    queryKey: [
      "dfs-submitted-beneficiaries",
      pagination,
      sorting,
      globalFilter,
      columnFilters,
    ],
    queryFn: () =>
      BeneficiaryApiService.fetchDfsSubmittedBeneficiaries({
        page: pagination.pageIndex,
        size: pagination.pageSize,

        globalFilter,

        bankName: columnFilters.find((f) => f.id === "bankName")?.value || "",

        bnRefNo: columnFilters.find((f) => f.id === "benRefNo")?.value || "",

        fileName: columnFilters.find((f) => f.id === "fileName")?.value || "",

        ifvSubmitBy:
          columnFilters.find((f) => f.id === "ifvSubmitBy")?.value || "",

        ifvSubmittedDateFrom: submittedDateFilter?.[0] || null,

        ifvSubmittedDateTo: submittedDateFilter?.[1] || null,

        sortField: sorting?.[0]?.id,
        sortDirection: sorting?.[0]?.desc ? "desc" : "asc",
      }),
    placeholderData: keepPreviousData,
  });

  const [snackbar, setSnackbar] = useState({
    open: false,
    severity: "error",
    message: "",
  });

  const handleDownload = async (filePath, fileName) => {
    setDownloadingFiles((prev) => ({ ...prev, [filePath]: true }));
    try {
      const result = await BeneficiaryApiService.downloadAppDocument(
        filePath,
        fileName
      );

      if (!result.success) {
        setSnackbar({
          open: true,
          severity: "error",
          message: result.message,
        });
      }
    } catch (err) {
      setSnackbar({
        open: true,
        severity: "error",
        message: err?.message || "Failed to download file.",
      });
    } finally {
      setDownloadingFiles((prev) => ({
        ...prev,
        [filePath]: false,
      }));
    }
  };

  const columns = useMemo(
    () => [
      {
        header: "Sl No",
        size: 70,
        enableSorting: false,
        Cell: ({ row, table }) => {
          const { pageIndex, pageSize } = table.getState().pagination;

          return pageIndex * pageSize + row.index + 1;
        },
      },

      {
        accessorKey: "bankName",
        header: "Bank Name",
        size: 150,
      },

      {
        accessorKey: "benRefNo",
        header: "Beneficiary Ref No",
        size: 100,
      },

      {
        accessorKey: "fileName",
        header: "File Name",
        size: 100,
      },

      {
        accessorKey: "ifvSubmittedDate",
        header: "Submitted Date",
        filterVariant: "date-range",
        Cell: ({ cell }) =>
          cell.getValue()
            ? format(new Date(cell.getValue()), "dd-MMM-yyyy hh:mm a")
            : "-",
      },
    ],
    []
  );

  const table = useMaterialReactTable({
    columns,

    data: data?.content ?? [],

    rowCount: data?.totalElements ?? 0,

    manualPagination: true,
    manualSorting: true,
    manualFiltering: true,
    enableRowActions: true,
    positionActionsColumn: "last",

    onPaginationChange: setPagination,
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    onColumnFiltersChange: setColumnFilters,

    state: {
      pagination,
      sorting,
      globalFilter,
      columnFilters,
      isLoading,
      showProgressBars: isFetching,
      showAlertBanner: isError,
    },

    renderRowActions: ({ row }) => (
      <Box sx={{ display: "flex", gap: 1 }}>
        <Tooltip title="View Details">
          <IconButton
            color="primary"
            onClick={() => setSelectedRow(row.original)}
          >
            <VisibilityIcon />
          </IconButton>
        </Tooltip>

        {/* Bank Uploaded File */}
        <Tooltip title="Download Bank Uploaded File">
          <IconButton
            color="success"
            disabled={downloadingFiles[row.original.filePath]}
            onClick={() =>
              handleDownload(row.original.filePath, row.original.fileName)
            }
          >
            {downloadingFiles[row.original.filePath] ? (
              <CircularProgress size={20} />
            ) : (
              <CloudDownloadIcon />
            )}
          </IconButton>
        </Tooltip>

        {/* IFV Uploaded File */}
        {row.original.ifvFilePath && (
          <Tooltip title="Download IFV Uploaded File">
            <IconButton
              color="secondary"
              disabled={downloadingFiles[row.original.ifvFilePath]}
              onClick={() =>
                handleDownload(
                  row.original.ifvFilePath,
                  row.original.ifvFileName
                )
              }
            >
              {downloadingFiles[row.original.ifvFilePath] ? (
                <CircularProgress size={20} />
              ) : (
                <DownloadForOfflineIcon />
              )}
            </IconButton>
          </Tooltip>
        )}
      </Box>
    ),

    muiTableHeadCellProps: {
      sx: {
        backgroundColor: "#E3F2FD",
        fontWeight: "bold",
      },
    },
  });

  return (
    <>
      {isError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error?.message ?? "Failed to fetch records"}
        </Alert>
      )}

      <Box
        sx={{
          mb: 2,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Button
          variant="outlined"
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate("/ifv/beneficiaryDashboard")}
        >
          Back
        </Button>
      </Box>

      <MaterialReactTable table={table} />

      <BeneficiaryDetailsDialog
        open={Boolean(selectedRow)}
        selectedRow={selectedRow}
        onClose={() => setSelectedRow(null)}
      />

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() =>
          setSnackbar((prev) => ({
            ...prev,
            open: false,
          }))
        }
      >
        <Alert
          severity={snackbar.severity}
          onClose={() =>
            setSnackbar((prev) => ({
              ...prev,
              open: false,
            }))
          }
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
}

export default function ViewDfsSubmittedBeneficiaries() {
  return (
    <QueryClientProvider client={queryClient}>
      <LocalizationProvider dateAdapter={AdapterDateFns}>
        <BeneficiarySummaryTable />
      </LocalizationProvider>
    </QueryClientProvider>
  );
}
