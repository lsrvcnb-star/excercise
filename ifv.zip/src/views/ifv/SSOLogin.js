import Cookies from "js-cookie";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import IfvAppraisalService from "services/IfvAppraisalService";
import CommonUtil from "services/utils/CommonUtil";

export default function SSOLogin() {
    const navigate = useNavigate();

    useEffect(() => {
        (async () => {
            const userId = Cookies.get('UserID');
            console.log("Cookie User ID:::", userId);

            if (CommonUtil.isEmpty(userId)) {
                alert('Error occurred while loading IFV App');
                return;
            }

            try {
                const encUserId = await CommonUtil.encryptPassword(userId);
                const response = await IfvAppraisalService.ssoIfvLogin(encUserId);
                console.log("Data:::", response.data);
                if (response.data && response.data.jwttoken != null) {
                    sessionStorage.removeItem("jwtToken");
                    sessionStorage.removeItem("user");
                    sessionStorage.setItem("jwtToken", response.data.jwttoken);
                    sessionStorage.setItem("user", JSON.stringify(response.data.data));
                    navigate('/ifv/dashboard');
                } else {
                    if (response.data && response.data.message != null) {
                        alert(response.data.message);
                    } else {
                        alert('Failed to load the IFV App');
                    }
                }
            } catch (error) {
                const resMessage =
                    (error.response && error.response.data && error.response.data.message) ||
                    error.message ||
                    error.toString();

                alert('Error occurred while loading the IFV: ' + resMessage);
                navigate('/login');
            }
        })();
    }, [navigate]);

}