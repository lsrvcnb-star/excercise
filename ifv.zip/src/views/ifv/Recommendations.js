import Loading from 'components/Loading';
import { Fragment, useEffect, useState } from 'react';
import {
    Modal
} from "react-bootstrap";
import 'react-datepicker/dist/react-datepicker.css';
import { useFieldArray, useForm } from "react-hook-form";
import IfvAppraisalService from 'services/IfvAppraisalService';
import CommonUtil from 'services/utils/CommonUtil';

const Recommendations = () => {
    const { control: control2, register: register2, handleSubmit: handleSubmitOfRecommendations, setValue: setValue2, getValues: getValues2, formState: { errors: errors2 }, } = useForm({
        mode: "onBlur"
    });

    const { fields: fields2, append: append2, remove: remove2 } = useFieldArray({
        control: control2, // control props comes from useForm (optional: if you are using FormContext)
        name: "recommendations", // unique name for your Field Array
    });

    const [loading, setLoading] = useState(false)
    const [showMsg, setShowMsg] = useState(false)
    const [message, setMessage] = useState('')
    const hideMsg = () => setShowMsg(false);

    useEffect(() => {
        showRecommendationsModal()
    }, []);

    const showRecommendationsModal = () => {
        setLoading(true)
        IfvAppraisalService.getAllOnMstParticulars("Recommendation").then(
            (response) => {

                response.data.forEach((item, index) => {
                    remove2(index)
                    append2({})

                    setValue2(`recommendations[${index}].mstCode`, item.mstCode)
                    setValue2(`recommendations[${index}].mstParticulars`, item.mstParticulars)
                    setValue2(`recommendations[${index}].mstRemarks`, item.mstRemarks)
                    setValue2(`recommendations[${index}].mstOrder`, item.mstOrder)
                    setValue2(`recommendations[${index}].mstFlg`, item.mstFlg)
                    setValue2(`recommendations[${index}].status`, item.mstFlg === 'N' ? 'Enable' : 'Disable')
                });

                setLoading(false)

            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                setLoading(false)
                setMessage('Error occured while loading recommendations: ' + resMessage)
                setShowMsg(true)
            }
        )


    }

    const handleRecommendationsDelete = (index) => {
        const id = getValues2(`recommendations[${index}].mstCode`)
        if (CommonUtil.isValidNumber(id)) {
            setMessage('Cannot be deleted')
            setShowMsg(true)
            // IfvAppraisalService.deleteOtherCondition(id).then((response) => {
            //     setValue2(`recommendations[${index}]`, undefined)
            //     remove2(index)
            //     setMessage('Recommendations deleted successfully!')
            //     setShowMsg(true)
            // },
            //     (error) => {
            //         const resMessage =
            //             (error.response &&
            //                 error.response.data &&
            //                 error.response.data.message) ||
            //             error.message ||
            //             error.toString();

            //         setMessage('Error occured while deleting recommendations: ' + resMessage)
            //         setShowMsg(true)
            //     }
            // )
        } else {
            remove2(index)
        }
    }

    const handleEnableDisable = (index) => {
        setLoading(true)
        const id = getValues2(`recommendations[${index}].mstCode`)
        const flag = getValues2(`recommendations[${index}].mstFlg`)
        const updateFlag = flag === 'Y' ? 'N' : 'Y'
        if (CommonUtil.isValidNumber(id)) {
            const data = {
                mstCode: id,
                mstFlg: updateFlag
            }
            IfvAppraisalService.updateOtherConditions(data).then((response) => {
                setLoading(false)
                setValue2(`recommendations[${index}].status`, response.data.mstFlg === 'Y' ? 'Disable' : 'Enable')
                setValue2(`recommendations[${index}].mstFlg`, updateFlag)
                var msg = response.data.mstFlg === 'Y' ? 'Enabled' : 'Disabled'
                setMessage('Sl No - ' + (index + 1) + ', Recommendations ' + msg + ' successfully!')
                setShowMsg(true)
            },
                (error) => {
                    const resMessage =
                        (error.response &&
                            error.response.data &&
                            error.response.data.message) ||
                        error.message ||
                        error.toString();
                    setLoading(false)
                    setMessage('Error occured while updating recommendations: ' + resMessage)
                    setShowMsg(true)
                }
            )

        } else {
            setLoading(false)
            alert('Something went wrong!')
        }
    }

    const onSubmitOfRecommendations = (data, e) => {
        setLoading(true)
        let finaData = data['recommendations']
        finaData.forEach((item, i) => {
            if(CommonUtil.isEmpty(item.mstFlg)){
                item.mstFlg = 'Y'
            }
            delete item.status
        })
        IfvAppraisalService.saveAllOtherConditions(finaData).then((response) => {
            setLoading(false)
            showRecommendationsModal()
            setMessage('Recommendations details have been successfully saved!')
            setShowMsg(true)
        },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();
                setLoading(false)
                setMessage('Error occured while saving recommendations: ' + resMessage)
                setShowMsg(true)
            })
    }

    return (
        <Fragment>
            <div className={loading ? 'frgmnt blur-background' : 'frgmnt'}>
                <form key={2} onSubmit={handleSubmitOfRecommendations(onSubmitOfRecommendations)} className='cndn'>
                <div className='container-fluid'>
                    <div className='row nrsn'>
                        <div className='col-md-1'>
                            <div className='form-group'>
                                <label className='ml-4'><strong>Sl No</strong></label>
                            </div>
                        </div>

                        <div className='col-md-8'>
                            <div className='form-group'>
                                <label className='ml-2'><strong>Condition</strong></label>
                            </div>
                        </div>

                        <div className='col-md-1'>
                            <div className='form-group'>
                                <label><strong>Order</strong> </label>
                            </div>
                        </div>
                        <div className='col-md-1'>

                        </div>
                        <div className='col-md-1'>

                        </div>

                    </div>
                    </div>

                    {fields2.map((field, index) => (
                        <div className='container-fluid'>
                            <div className='row pt-0' key={field.id}>
                                <div className='col-md-1'>
                                    <div className='form-group'>
                                        {index + 1}
                                    </div>
                                </div>
                                <div className='col-md-8'>
                                    <div className='form-group'>
                                        <textarea className='form-control'
                                            key={field.id} // important to include key with field's id
                                            {...register2(`recommendations[${index}].mstRemarks`)}
                                        />
                                        <input type='hidden' {...register2(`recommendations[${index}].mstParticulars`)} value="Recommendation" />
                                        <input type='hidden' {...register2(`recommendations[${index}].mstCode`)} />
                                        <input type='hidden' {...register2(`recommendations[${index}].mstFlg`)} value='Y' />
                                    </div>
                                </div>

                                <div className='col-md-1'>
                                    <div className='form-group'>
                                        <input className='form-control'
                                            key={field.id} // important to include key with field's id
                                            type='text'
                                            {...register2(`recommendations[${index}].mstOrder`)}
                                        />
                                    </div>
                                </div>

                                <div className='col-md-1'>
                                    <div className='form-group'>
                                        <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                            onClick={() => handleRecommendationsDelete(index)}></i>
                                    </div>
                                </div>

                                <div className='col-md-1'>
                                    <div className='form-group'>
                                        <input type='button' key={field.id} className="dsblBtn" {...register2(`recommendations[${index}].status`)} onClick={() => handleEnableDisable(index)} />
                                    </div>
                                </div>

                            </div>
                        </div>
                    ))}
                    <div className='col-md-12'>
                        <div className="button-container-end">
                            <button type="button" className='addBtn' onClick={() => append2({})}>+</button>
                        </div>
                    </div>

                    <div className="button-container-center">
                        <button type='submit' className='save btn btnSave'>Save <i className="fa fa-circle-check"></i></button>
                    </div>
                </form>
            </div>

            <Modal style={{ marginTop: "200px" }} show={showMsg} onHide={hideMsg}>

                <Modal.Body >
                    <div className="conatiner text-center">
                        <div className="row">
                            <div className="col-sm-12">
                            <h5 className= {message.includes('Error')? 'alertMsg':'loadMsg'}>{message}</h5>
                                {/* <h5 className="loadMsg">{message}</h5> */}
                            </div>
                        </div>
                    </div>
                 
                    <div className="row text-center">
                        <div className="col-sm-12 text-center">
                            <button type="button" className=" btn  btnRegister  themebutton" onClick={hideMsg}>OK</button>
                        </div>
                    </div>

                </Modal.Body>
            </Modal>
            {loading && <Loading />}
        </Fragment >
    )
}
export default Recommendations;