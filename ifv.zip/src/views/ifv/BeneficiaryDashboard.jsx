import { Card, Col, Container, Row } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
const ReportCard = ({ icon, title, path, state }) => {
    const navigate = useNavigate();
    const handleClick = (e) => {
        e.preventDefault();
        navigate(path, state);
    };
    return (
        <Col lg="3" sm="6">
            <Card className="card-stats">
                <Card.Body>
                    <Row>
                        <Col xs="5">
                            <div className="icon-big text-center icon-warning">
                                <i className={`fa ${icon}`}></i>
                            </div>
                        </Col>
                        <Col xs="7">
                            <div className="numbers">
                                <p className="card-category">{title}</p>
                                {/* <Card.Title as="h4">-</Card.Title> */}
                            </div>
                        </Col>
                    </Row>
                </Card.Body>
                <Card.Footer>
                    <hr />
                    <div className="stats">
                        <a href="#" onClick={handleClick} className="hvr-icon-wobble-horizontal">
                            Know More <i className="fa fa-arrow-right hvr-icon"></i>
                        </a>
                    </div>
                </Card.Footer>
            </Card>
        </Col>
    );
};
const BeneficiaryDashboard = () => {
    const reportCards = [
        {
            icon: 'fa-file-upload text-primary',
            title: 'Review Bank Submitted Beneficiaries',
            path: '/ifv/viewUploadedFiles',
            state: { mode: '' }
        },
        {
            icon: 'fa-users-cog text-success',
            title: 'View Beneficiaries Submitted to DFS',
            path: '/ifv/manageBeneficiaryDetails',
        },
    ];
    return (
        <div>
            <Container fluid>
                <Row>
                    <div className="col-md-12 p-0">
                        <div className="ds_wrap">
                            <h5>Beneficiary Details</h5>
                            <div className="row m-2 mb-4">
                                {reportCards.map((card, index) => (
                                    <ReportCard key={index} {...card} />
                                ))}
                            </div>
                        </div>
                    </div>
                </Row>
            </Container>
        </div>
    );
};
export default BeneficiaryDashboard;