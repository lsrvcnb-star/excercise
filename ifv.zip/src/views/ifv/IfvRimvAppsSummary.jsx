import {
    Add as AddIcon, Delete as DeleteIcon,
    KeyboardArrowDown as ExpandIcon, KeyboardArrowUp as CollapseIcon
} from "@mui/icons-material";

import SendIcon from "@mui/icons-material/Send";

import {
    Alert,
    Autocomplete,
    Badge,
    Box,
    Button,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    FormControl,
    IconButton,
    InputLabel,
    MenuItem,
    Select,
    Snackbar,
    Tab,
    Tabs,
    TextField,
    Tooltip
} from "@mui/material";
import {
    keepPreviousData, QueryClient,
    QueryClientProvider, useMutation,
    useQuery,
    useQueryClient
} from "@tanstack/react-query";
import {
    MaterialReactTable,
    useMaterialReactTable
} from "material-react-table";
import { useEffect, useMemo, useState } from "react";
import IfvAppraisalService from "services/IfvAppraisalService";
import MasterService from "services/MasterService";
import * as rimvApi from "services/rimvApi";
import Pattern from "services/validators/Pattern";
import RimvDocumentManager from "./RimvDocumentManager";

const queryClient = new QueryClient();

const STATUS_MAP = {
  N: "New",
  P: "In Progress",
  A: "Approved",
  R: "Rejected",
};

const STATUS_TABS = [
  { label: "New", value: "N" },
  { label: "In Progress", value: "P" },
  { label: "Rejected", value: "R" },
  { label: "Approved", value: "A" },
];

function IfvRimvAppsSummary() {
  const user = IfvAppraisalService.getCurrentUser();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("N");
  const [columnFilters, setColumnFilters] = useState([]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [sorting, setSorting] = useState([]);
  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: 10,
  });
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteId, setDeleteId] = useState(null);

  const [forwardDialogOpen, setForwardDialogOpen] = useState(false);
  const [forwardData, setForwardData] = useState({
    ifvRimvAppId: null,
    fwdComments: "",
    fwdUserId: null,
    fwdBy: "",
  });

  const [uploadData, setUploadData] = useState({
    bankName: "",
    cifNumber: "",
    singleScaleRating:"",
    combinedRating:"",
  });
  const [selectedBank, setSelectedBank] = useState(null);
  const [bankOptions, setBankOptions] = useState([]);
  const [loadingBanks, setLoadingBanks] = useState(false);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success",
  });

  // Fetch status counts
  const { data: statusCounts } = useQuery({
    queryKey: ["rimvAppCounts"],
    queryFn: rimvApi.getCountOfRimvApps,
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  useEffect(() => {
    setColumnFilters([{ id: "fwdStatus", value: activeTab }]);
    setPagination({ pageIndex: 0, pageSize: 10 });
  }, [activeTab]);

  useEffect(() => {
    const fetchBankOptions = async () => {
      try {
        setLoadingBanks(true);
        const bcmCif = await MasterService.getAllBcmCif();
        const options = bcmCif.data.map((item) => ({
          value: item.customerCode,
          label: `${item.customerLongName} >> (${item.customerCode})`,
          customerLongName: item.customerLongName,
          customerCode: item.customerCode,
        }));
        setBankOptions(options);
      } catch (error) {
        setSnackbar({
          open: true,
          message: "Failed to load bank options",
          severity: "error",
        });
      } finally {
        setLoadingBanks(false);
      }
    };

    if (uploadDialogOpen) {
      fetchBankOptions();
    }
  }, [uploadDialogOpen]);

  const { data, isError, isFetching, isLoading } = useQuery({
    queryKey: [
      "ifvRimvApps",
      pagination.pageIndex,
      pagination.pageSize,
      columnFilters,
      globalFilter,
      sorting,
    ],
    queryFn: () =>
      rimvApi.fetchIfvRimvApps({
        start: pagination.pageIndex,
        size: pagination.pageSize,
        filters: JSON.stringify(columnFilters),
        sorting: JSON.stringify(sorting),
        globalFilter,
      }),
    placeholderData: keepPreviousData,
  });

  const createMutation = useMutation({
    mutationFn: (data) =>
      rimvApi.createIfvRimvApp({
        ...data,
        currentUserId: user?.ofrCode,
        currentUserName: user?.ofrShortName,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries(["ifvRimvApps"]);
      queryClient.invalidateQueries(["rimvAppCounts"]);
      handleCloseDialog();
      setSnackbar({
        open: true,
        message: "RiMV Application created successfully!",
        severity: "success",
      });
    },
    onError: (error) => {
      setSnackbar({
        open: true,
        message: "Failed to create RiMV Application",
        severity: "error",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: rimvApi.deleteIfvRimvApp,
    onSuccess: () => {
      queryClient.invalidateQueries(["ifvRimvApps"]);
      queryClient.invalidateQueries(["rimvAppCounts"]);
      setDeleteDialogOpen(false);
      setDeleteId(null);
      setSnackbar({
        open: true,
        message: "RiMV Application deleted successfully!",
        severity: "success",
      });
    },
    onError: (error) => {
      setSnackbar({
        open: true,
        message: "Failed to delete RiMV Application",
        severity: "error",
      });
    },
  });

  const forwardMutation = useMutation({
    mutationFn: rimvApi.forwardDocumentsToRimv,
    onSuccess: () => {
      queryClient.invalidateQueries(["ifvRimvApps"]);
      queryClient.invalidateQueries(["rimvAppCounts"]);
      handleCloseForwardDialog();
      setSnackbar({
        open: true,
        message: "Documents forwarded successfully!",
        severity: "success",
      });
    },
    onError: (error) => {
      if (error.status === 404) {
        setSnackbar({
          open: true,
          message: "Please upload at least one document.",
          severity: "error",
        });
      } else {
        setSnackbar({
          open: true,
          message: "Failed to forward documents",
          severity: "error",
        });
      }
    },
  });

  const columns = useMemo(
    () => [
      {
        accessorKey: "rimvRefId",
        header: "Rimv Ref Id",
        size: 100,
      },
      {
        accessorKey: "bankName",
        header: "Bank Name",
        size: 250,
      },
      {
        accessorKey: "cifNumber",
        header: "CIF Number",
        size: 150,
      },
      {
        accessorKey: "fwdStatus",
        header: "Status",
        size: 120,
        enableColumnFilter: false,
        enableGlobalFilter: false,
        Cell: ({ cell }) => {
          const status = cell.getValue();
          return STATUS_MAP[status] || status || "-";
        },
      },
    ],
    []
  );

  const hasNWRows = useMemo(
    () => (data?.content ?? []).some((r) => r.fwdStatus === "N"),
    [data]
  );

  const table = useMaterialReactTable({
    columns,
    data: data?.content ?? [],
    rowCount: data?.totalElements ?? 0,
    manualPagination: true,
    manualSorting: true,
    manualFiltering: true,
    enableExpanding: true,
    enableExpandAll: false,
    enableRowActions: hasNWRows,
    positionActionsColumn: "last",
    state: {
      columnFilters,
      globalFilter,
      isLoading,
      pagination,
      showAlertBanner: isError,
      showProgressBars: isFetching,
      sorting,
    },
    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
    onPaginationChange: setPagination,
    onSortingChange: setSorting,
    renderTopToolbarCustomActions: () => (
      <Button
        variant="contained"
        startIcon={<AddIcon />}
        onClick={() => setUploadDialogOpen(true)}
      >
        Create RiMV Application
      </Button>
    ),
    renderRowActions: ({ row }) =>
      row.original.fwdStatus === "N" && (
        <Box sx={{ display: "flex", gap: 0.1 }}>
          <Tooltip title="Delete">
            <IconButton
              color="error"
              onClick={() => {
                setDeleteId(row.original.id);
                setDeleteDialogOpen(true);
              }}
            >
              <DeleteIcon />
            </IconButton>
          </Tooltip>
          <Tooltip title="Forward">
            <IconButton
              color="primary"
              onClick={() => {
                setForwardData({
                  ifvRimvAppId: row.original.id,
                  fwdComments: "",
                  fwdUserId: user?.ofrCode,
                  fwdBy: user?.ofrShortName,
                });
                setForwardDialogOpen(true);
              }}
            >
              <SendIcon />
            </IconButton>
          </Tooltip>
        </Box>
      ),
    muiExpandButtonProps: ({ row }) => ({
      children: row.getIsExpanded() ? <CollapseIcon /> : <ExpandIcon />,
    }),
    renderDetailPanel: ({ row }) => <RimvDocumentManager data={row.original} />,
  });

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleCloseDialog = () => {
    setUploadDialogOpen(false);
    setSelectedBank(null);
    setUploadData({ bankName: "", cifNumber: "" });
  };

  const handleCloseForwardDialog = () => {
    setForwardDialogOpen(false);
    setForwardData({
      ifvRimvAppId: null,
      fwdComments: "",
      fwdUserId: null,
      fwdBy: "",
    });
  };

  const handleBankChange = (event, newValue) => {
    setSelectedBank(newValue);
    if (newValue) {
      setUploadData({
        bankName: newValue.customerLongName,
        cifNumber: newValue.customerCode,
      });
    } else {
      setUploadData({
        bankName: "",
        cifNumber: "",
      });
    }
  };

  const handleCreate = () => {
    if (!uploadData.cifNumber || !uploadData.bankName) {
      setSnackbar({
        open: true,
        message: "Please select a bank",
        severity: "warning",
      });
      return;
    }
    createMutation.mutate(uploadData);
  };

  const handleDelete = () => {
    if (deleteId) {
      deleteMutation.mutate(deleteId);
    }
  };

  const handleForward = () => {
    if (!forwardData.fwdComments.trim()) {
      setSnackbar({
        open: true,
        message: "Please add comments",
        severity: "warning",
      });
      return;
    }
    forwardMutation.mutate(forwardData);
  };

  // Get count for a specific status
  const getStatusCount = (status) => {
    return statusCounts?.[status] || 0;
  };

  // Get badge color based on status
  const getBadgeColor = (status) => {
    switch (status) {
      case "N":
        return "primary";
      case "P":
        return "warning";
      case "R":
        return "error";
      case "A":
        return "success";
      default:
        return "default";
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Tab Navigation with Count Badges */}
      <Box sx={{ borderBottom: 1, borderColor: "divider", mb: 2 }}>
        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          aria-label="status tabs"
          sx={{
            "& .MuiTab-root": {
              minHeight: 48,
              textTransform: "none",
              fontSize: "0.95rem",
              fontWeight: 500,
            },
          }}
        >
          {STATUS_TABS.map((tab) => (
            <Tab
              key={tab.value}
              label={
                <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                  <span>{tab.label}</span>
                  <Badge
                    badgeContent={getStatusCount(tab.value)}
                    color={getBadgeColor(tab.value)}
                    max={999}
                    sx={{
                      "& .MuiBadge-badge": {
                        fontWeight: 600,
                        minWidth: "24px",
                        height: "24px",
                        borderRadius: "12px",
                        fontSize: "0.75rem",
                      },
                    }}
                  />
                </Box>
              }
              value={tab.value}
            />
          ))}
        </Tabs>
      </Box>

      <MaterialReactTable table={table} />

      {/* Create Dialog */}
      <Dialog
        open={uploadDialogOpen}
        onClose={handleCloseDialog}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Create RiMV Application</DialogTitle>
        <DialogContent>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 2, mt: 2 }}>
            <Autocomplete
              value={selectedBank}
              onChange={handleBankChange}
              options={bankOptions}
              getOptionLabel={(option) => option.label}
              loading={loadingBanks}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Select Bank"
                  required
                  InputProps={{
                    ...params.InputProps,
                    endAdornment: (
                      <>
                        {loadingBanks ? (
                          <CircularProgress color="inherit" size={20} />
                        ) : null}
                        {params.InputProps.endAdornment}
                      </>
                    ),
                  }}
                />
              )}
              isOptionEqualToValue={(option, value) =>
                option.value === value.value
              }
            />

            <TextField
              label="CIF Number"
              value={uploadData.cifNumber}
              disabled
              fullWidth
              InputProps={{
                readOnly: true,
              }}
            />

            <TextField
              label="Bank Name"
              value={uploadData.bankName}
              disabled
              fullWidth
              InputProps={{
                readOnly: true,
              }}
            />

            <FormControl fullWidth>
              <InputLabel id="single-scale-rating-label">
                Single Scale Rating
              </InputLabel>
              <Select
                labelId="single-scale-rating-label"
                value={uploadData.singleScaleRating || ""}
                label="Select Single Scale Rating"
                onChange={(e) =>
                  setUploadData({
                    ...uploadData,
                    singleScaleRating: e.target.value,
                  })
                }
              >
                {Array.from({ length: 10 }, (_, i) => (
                  <MenuItem key={i + 1} value={`S${i + 1}`}>
                    {`S${i + 1}`}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl fullWidth>
              <InputLabel id="combined-rating-label">
                Combined Rating
              </InputLabel>
              <Select
                labelId="combined-rating-label"
                value={uploadData.combinedRating || ""}
                label="Select Combined Rating"
                onChange={(e) =>
                  setUploadData({
                    ...uploadData,
                    combinedRating: e.target.value,
                  })
                }
              >
                {Array.from({ length: 10 }, (_, i) => (
                  <MenuItem key={i + 1} value={`C${i + 1}`}>
                    {`C${i + 1}`}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button
            onClick={handleCreate}
            variant="contained"
            disabled={createMutation.isPending}
          >
            {createMutation.isPending ? "Creating..." : "Create"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Forward Dialog */}
      <Dialog
        open={forwardDialogOpen}
        onClose={handleCloseForwardDialog}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Forward Documents to RiMV</DialogTitle>
        <DialogContent>
          <Box sx={{ display: "flex", flexDirection: "column", gap: 2, mt: 2 }}>
            <TextField
              label="Comments"
              value={forwardData.fwdComments}
              onChange={(e) => {
                Pattern.sanitizeInput(e);
                setForwardData((prev) => ({
                  ...prev,
                  fwdComments: e.target.value,
                }));
              }}
              multiline
              rows={2}
              required
              fullWidth
              placeholder="Enter comments for forwarding..."
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseForwardDialog}>Cancel</Button>
          <Button
            onClick={handleForward}
            variant="contained"
            disabled={forwardMutation.isPending}
            startIcon={<SendIcon />}
          >
            {forwardMutation.isPending ? "Forwarding..." : "Forward"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        maxWidth="xs"
        fullWidth
      >
        <DialogTitle>Confirm Delete</DialogTitle>
        <DialogContent>
          Are you sure you want to delete this RiMV Application? This action
          cannot be undone.
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
          <Button
            onClick={handleDelete}
            variant="contained"
            color="error"
            disabled={deleteMutation.isPending}
          >
            {deleteMutation.isPending ? "Deleting..." : "Delete"}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          sx={{ width: "100%" }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

export default function IfvRimvAppsSummaryPage() {
  return (
    <QueryClientProvider client={queryClient}>
      <IfvRimvAppsSummary />
    </QueryClientProvider>
  );
}
