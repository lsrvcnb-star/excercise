import Loading from 'components/Loading';
import { Fragment, useEffect, useState } from 'react';
import {
    Modal
} from "react-bootstrap";
import 'react-datepicker/dist/react-datepicker.css';
import { useFieldArray, useForm } from "react-hook-form";
import IfvAppraisalService from 'services/IfvAppraisalService';
import CommonUtil from 'services/utils/CommonUtil';

const OtherConditions = () => {

    const { control: control1, register: register1, handleSubmit: handleSubmitOfOtherConditions, setValue: setValue1, getValues: getValues1, formState: { errors: errors1 }, } = useForm({
        mode: "onBlur"
    });

    const { fields: fields1, append: append1, remove: remove1 } = useFieldArray({
        control: control1, // control props comes from useForm (optional: if you are using FormContext)
        name: "otherConditions", // unique name for your Field Array
    });

    const [loading, setLoading] = useState(false)
    const [showMsg, setShowMsg] = useState(false)
    const [message, setMessage] = useState('')
    const hideMsg = () => setShowMsg(false);

    useEffect(() => {
        showOtherConditionsModal()
    }, []);

    const showOtherConditionsModal = () => {

        setLoading(true)
        IfvAppraisalService.getAllOnMstParticulars("Other Conditions").then(
            (response) => {

                response.data.forEach((item, index) => {
                    remove1(index)
                    append1({})

                    setValue1(`otherConditions[${index}].mstCode`, item.mstCode)
                    setValue1(`otherConditions[${index}].mstParticulars`, item.mstParticulars)
                    setValue1(`otherConditions[${index}].mstRemarks`, item.mstRemarks)
                    setValue1(`otherConditions[${index}].mstOrder`, item.mstOrder)
                    setValue1(`otherConditions[${index}].status`, item.mstFlg === 'Y' ? 'Disable' : 'Enable')
                    setValue1(`otherConditions[${index}].mstFlg`, item.mstFlg)
                });

                setLoading(false)

            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                setLoading(false)
                setMessage('Error occured while loading Other Conditions: ' + resMessage)
                setShowMsg(true)
            }
        )


    }

    const handleotherConditionDelete = (index) => {
        const id = getValues1(`otherConditions[${index}].mstCode`)
        if (CommonUtil.isValidNumber(id)) {
            setMessage('Error: Cannot delete records that have already been used in any of the IFV applications. The admin can only disable it. The disabled records will not be displayed on the dropdown list.')
            setShowMsg(true)
            // IfvAppraisalService.deleteOtherCondition(id).then((response) => {
            //     setValue1(`otherConditions[${index}]`, undefined)
            //     remove1(index)
            //     setMessage('Other condition deleted successfully!')
            //     setShowMsg(true)
            // },
            //     (error) => {
            //         const resMessage =
            //             (error.response &&
            //                 error.response.data &&
            //                 error.response.data.message) ||
            //             error.message ||
            //             error.toString();

            //         setMessage('Error occured while deleting other conditions: ' + resMessage)
            //         setShowMsg(true)
            //     }
            // )
        } else {
            remove1(index)
        }
    }

    const handleEnableDisable = (index) => {
        setLoading(true)
        const id = getValues1(`otherConditions[${index}].mstCode`)
        const flag = getValues1(`otherConditions[${index}].mstFlg`)
        const updateFlag = flag === 'Y' ? 'N' : 'Y'
        if (CommonUtil.isValidNumber(id)) {
            const data = {
                mstCode: id,
                mstFlg: updateFlag
            }
            IfvAppraisalService.updateOtherConditions(data).then((response) => {
                setLoading(false)
                setValue1(`otherConditions[${index}].status`, response.data.mstFlg === 'Y' ? 'Disable' : 'Enable')
                setValue1(`otherConditions[${index}].mstFlg`, updateFlag)
                var msg = response.data.mstFlg === 'Y' ? 'Enabled' : 'Disabled'
                setMessage('Sl No - ' + (index + 1) + ', Other condition ' + msg + ' successfully!')
                setShowMsg(true)
            },
                (error) => {
                    const resMessage =
                        (error.response &&
                            error.response.data &&
                            error.response.data.message) ||
                        error.message ||
                        error.toString();
                    setLoading(false)
                    setMessage('Error occured while updating other conditions: ' + resMessage)
                    setShowMsg(true)
                }
            )

        } else {
            setLoading(false)
            alert('Something went wrong!')
        }
    }

    const onSubmitOfOtherCondition = (data, e) => {
        setLoading(true)
        let finaData = data['otherConditions']
        finaData.forEach((item, i) => {
            if(CommonUtil.isEmpty(item.mstFlg)){
                item.mstFlg = 'Y'
            }
            
            delete item.status
        })

        IfvAppraisalService.saveAllOtherConditions(finaData).then((response) => {
            setLoading(false)
            showOtherConditionsModal()
            setMessage('Other conditions details have been successfully saved!')
            setShowMsg(true)
        },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();
                setLoading(false)
                setMessage('Error occured while saving other conditions: ' + resMessage)
                setShowMsg(true)
            })
    }

    return (
        <Fragment>
            <div className={loading ? 'frgmnt blur-background' : 'frgmnt'}>
                <form key={1} onSubmit={handleSubmitOfOtherConditions(onSubmitOfOtherCondition)} className='cndn'>

                <div className='container-fluid'>
                    <div className='row nrsn'>
                        <div className='col-md-1'>
                            <div className='form-group'>
                                <label><strong>Sl No</strong></label>
                            </div>
                        </div>

                        <div className='col-md-8'>
                            <div className='form-group'>
                                <label><strong>Condition</strong></label>
                            </div>
                        </div>

                        <div className='col-md-1'>
                            <div className='form-group'>
                                <label><strong>Order</strong> </label>
                            </div>
                        </div>
                        <div className='col-md-1'>
                            <div className='form-group'>

                            </div>
                        </div>
                        <div className='col-md-1'>
                            <div className='form-group'>
                            </div>
                        </div>

                    </div>
                    </div>

                    {fields1.map((field, index) => (
                        <div className='container-fluid'>
                            <div className='row pt-0' key={field.id}>
                                <div className='col-md-1'>
                                    <div className='form-group'>
                                        {index + 1}
                                    </div>
                                </div>
                                <div className='col-md-8'>
                                    <div className='form-group'>
                                        <textarea className='form-control'
                                            key={field.id} // important to include key with field's id
                                            {...register1(`otherConditions[${index}].mstRemarks`,{
                                                required:'Field is required'
                                            })}
                                        />
                                        <span className='vldn'>{errors1.otherConditions && errors1.otherConditions[index]?.mstRemarks && errors1.otherConditions[index]?.mstRemarks.message}</span>
                                        <input type='hidden' {...register1(`otherConditions[${index}].mstParticulars`)} value="Other Conditions" />
                                        <input type='hidden' {...register1(`otherConditions[${index}].mstCode`)} />
                                        <input type='hidden' {...register1(`otherConditions[${index}].mstFlg`)} />
                                    </div>
                                </div>

                                <div className='col-md-1'>
                                    <div className='form-group'>
                                        <input className='form-control'
                                            key={field.id} // important to include key with field's id
                                            type='text'
                                            {...register1(`otherConditions[${index}].mstOrder`,{
                                                required:'Field is required'
                                            })}
                                        />
                                        <span className='vldn'>{errors1.otherConditions && errors1.otherConditions[index]?.mstOrder && errors1.otherConditions[index]?.mstOrder.message}</span>
                                    </div>
                                </div>

                                <div className='col-md-1'>
                                    <div className='form-group'>
                                        <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                            onClick={() => handleotherConditionDelete(index)}></i>
                                    </div>
                                </div>

                                <div className='col-md-1'>
                                    <div className='form-group'>
                                        <input type='button' key={field.id} className="dsblBtn" {...register1(`otherConditions[${index}].status`)} onClick={() => handleEnableDisable(index)} />
                                    </div>
                                </div>

                            </div>
                        </div>
                    ))}
                    <div className='col-md-12'>
                        <div className="button-container-end">
                            <button type="button" className='addBtn' onClick={() => append1({})}>+</button>
                        </div>

                    </div>

                    <div className="button-container-center">
                        <button type='submit' className='save btn btnSave'>Save <i className="fa fa-circle-check"></i></button>
                    </div>
                </form>
                <Modal style={{ marginTop: "200px" }} show={showMsg} onHide={hideMsg}>

                    <Modal.Body >
                        <div className="conatiner text-center">
                            <div className="row">
                                <div className="col-sm-12">
                                <h5 className= {message.includes('Error')? 'alertMsg':'loadMsg'}>{message}</h5>
                                    {/* <h5 className="loadMsg">{message}</h5> */}
                                </div>
                            </div>
                        </div>
                       
                        <div className="row text-center">
                            <div className="col-sm-12 text-center">
                                <button type="button" className=" btn  btnRegister  themebutton" onClick={hideMsg}>OK</button>
                            </div>
                        </div>

                    </Modal.Body>
                </Modal>
                {loading && <Loading />}
            </div>
        </Fragment >
    )
}
export default OtherConditions;