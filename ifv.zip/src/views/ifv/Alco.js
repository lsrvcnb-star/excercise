import Loading from 'components/Loading';
import { Fragment, useEffect, useState } from 'react';
import {
  Modal
} from "react-bootstrap";
import Accordion from 'react-bootstrap/Accordion';
import 'react-datepicker/dist/react-datepicker.css';
import { useFieldArray, useForm } from "react-hook-form";
import { useNavigate, useLocation } from "react-router-dom";
import Select from 'react-select';
import IfvAppraisalService from 'services/IfvAppraisalService';
import UserService from 'services/UserService';
import { PrincipalRepayment } from 'services/constants/PrincipalRepayment';
import CommonUtil from 'services/utils/CommonUtil';
import FileUtil from 'services/utils/FileUtil';
import Pattern from 'services/validators/Pattern';

const AlocDetails = () => {

  const { control, register: register1, handleSubmit: handleSubmitOfAlcoProposal, setValue: setValue1, getValues: getValues1, formState: { errors: errors1 } } = useForm({
    mode: "onBlur"
  });

  const { control: control2, register: register2, handleSubmit: handleSubmitOfAlcoData, setValue: setValue2, getValues: getValues2, formState: { errors: errors2 }, } = useForm({
    mode: "onBlur"
  });

  const { control: control3, register: register3, handleSubmit: handleSubmitOfBenchMarkRepository, setValue: setValue3, getValues: getValues3, formState: { errors: errors3 }, } = useForm({
    mode: "onBlur"
  });

  const { control: control4, register: register4, handleSubmit: handleSubmitOfBenchMarkRepositorySfbs, setValue: setValue4, getValues: getValues4, formState: { errors: errors4 }, } = useForm({
    mode: "onBlur"
  });


  const { fields: fields1, append: append1, remove: remove1 } = useFieldArray({
    control, // control props comes from useForm (optional: if you are using FormContext)
    name: "alcoData", // unique name for your Field Array
  });

  const { fields: fields2, append: append2, remove: remove2 } = useFieldArray({
    control, // control props comes from useForm (optional: if you are using FormContext)
    name: "benchMarkRepoBanks", // unique name for your Field Array
  });

  const { fields: fields3, append: append3, remove: remove3 } = useFieldArray({
    control, // control props comes from useForm (optional: if you are using FormContext)
    name: "benchMarkRepoSmallFinanceBanks", // unique name for your Field Array
  });

  const navigate = useNavigate();
  const location = useLocation();
  const [alCode, setAlCode] = useState(location.state ? location.state.alCode : 0)

  const [showMsg, setShowMsg] = useState(false);
  const [message, setMessage] = useState('')
  const hideMsg = () => setShowMsg(false)
  const [ifvAppList, setIfvAppList] = useState([])
  const [filteredBankOptions, setFilteredBankOptions] = useState([])
  const [selectedBankOption, setSelectedBankOption] = useState([]);
  const [ifvApps, setIfvApps] = useState([])
  const [enableLock, setEnableLock] = useState(false)
  const [totRep, setTotRep] = useState(0)
  const [isMaker, setMaker] = useState(false)
  const [isChecker, setChecker] = useState(false)
  const [isMakerConvenor, setMakerConvenor] = useState(false)
  const [isHigherAuthority, setHigherAuthority] = useState(false)
  const [showLockUnlockMsg, setShowLockUnlockMsg] = useState(false)
  const hideLockUnlockMsg = () => {
    setShowLockUnlockMsg(false)
    
    navigate('/ifv/dashboard');
  }

  useEffect(() => {
    const user = IfvAppraisalService.getCurrentUser();

    setMaker(UserService.isMaker(user))
    setChecker(UserService.isChecker(user))
    setMakerConvenor(UserService.isMakerConvenor(user))
    setHigherAuthority(UserService.isHigherAuthority(user))
    getAllBanks()
    getAllOnMstParticulars()
    if (alCode > 0) {
      getAllAlcoData()
      getAllBenchMarkRepoOnAlCodeAndBankType()
      getAllBenchMarkRepoSfbs()
      getTblFwdDetailByAlCode(alCode)

    } else {
      setEditable(true)
    }

  }, []);



  const getAllBanks = () => {

    IfvAppraisalService.getAllIfvApps().then(response => {
      const formattedOptions = response.data.map((item) => ({
        value: item.ifvId,
        label: item.ifvName,
      }))
      setIfvApps(response.data)
      setIfvAppList(formattedOptions)
      setFilteredBankOptions(formattedOptions)
    },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();

        setMessage('Error occured while loading IFV applications' + resMessage)
        setShowMsg(true)
      }
    )
  }
  const [options, setOptions] = useState([])
  const [selectedOption, setSelectedOption] = useState([])
  const handleChange = (val) => {
    setSelectedOption(val);
  };
  const getAllOnMstParticulars = () => {

    IfvAppraisalService.getAllOnMstParticulars("Recommendation").then(
      (response) => {

        const filteredData = response.data.filter((item) => item.mstFlg === 'Y')

        const formattedOptions = filteredData.map((item) => ({
          value: parseInt(item.mstCode),
          label: item.mstRemarks,
        }))
        setOptions(formattedOptions)
        if (alCode > 0) {
          getAlcoProposalById(formattedOptions, alCode)
        }

      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();

        setMessage('Error occured while loading Recommendation: ' + resMessage)
        setShowMsg(true)
      }
    )
  }

  const [appStatus, setAppStatus] = useState('')
  const [locked, setLocked] = useState(false)
  const [editable, setEditable] = useState(false)
  const [isConfirmed, setConfirmed] = useState(false)
  const [isApproved, setApproved] = useState(false)

  const getTblFwdDetailByAlCode = (alCode) => {

    IfvAppraisalService.getTblFwdDetailByAlCode(alCode).then(
      (response) => {
        const status = response.data.appStatus

        if (status === 'LK') {
          setLocked(true)
          setEditable(false)
          setAppStatus('Locked')
        }
        if (status === 'NW') {
          setLocked(false)
          setEditable(true)
          setAppStatus('New')
          setConfirmed(false)
        }
        if (status === 'CN') {
          setLocked(false)
          setEditable(false)
          setConfirmed(true)
          setAppStatus('Confirmed')
        }
        if (status === 'AP') {
          setLocked(false)
          setEditable(false)
          setApproved(true)
          setAppStatus('Approved')
        }
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();

        setMessage('Error occured while loading TBL FWD Details')
        setShowMsg(true)
      }
    )
  }

  const [background, setBackground] = useState('')
  const [presentProposal, setPresentProposal] = useState('')
  const [alcoProposal, setAlcoProposal] = useState({})
  const getAlcoProposalById = (formattedOptions, alCode) => {
    IfvAppraisalService.getAlcoProposalById(alCode).then(
      (response) => {
        var appData = response.data
        setAlcoProposal(appData)
        setAlCode(appData.alCode)
        setValue1('alTenor', appData.alTenor)
        setValue1('al1yr', appData.al1yr)
        setValue1('al3yr', appData.al3yr)
        setValue1('alBackground', appData.alBackground)
        setValue1('alPresntProposal', appData.alPresntProposal)

        if (appData.alRecommendation != null) {
          const arrayOne = appData.alRecommendation.split(',')
          let otherConditions = []

          arrayOne.map((item, index) => {
            const it = formattedOptions.find(obj => obj['value'] === parseInt(item));
            if (it !== undefined) {
              otherConditions.push(it)
            }
          })
          setSelectedOption(otherConditions)
        }



      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();

        setMessage('Error occured while loading Alco proposals')
        setShowMsg(true)
      }
    )
  }



  const onSubmitOfAlcoProposal = (data, e) => {
    setLoading(true)
    let mstCodes = "";
    // data.alBackground = background
    // data.alPresntProposal = presentProposal
    const user = IfvAppraisalService.getCurrentUser()
    data.ofrCode = user.ofrCode
    data.ofrName = user.ofrName

    if (selectedOption.length > 0) {
      selectedOption.map((item, index) => {
        mstCodes = mstCodes.concat(item['value'] + ',')
      })
      data.alRecommendation = mstCodes
    }

    if (alCode > 0) {
      data.alCode = alCode
      IfvAppraisalService.updateAlcoProposal(data).then((response) => {
        setLoading(false)
        setMessage('Alco Proposals have been successfully updated!')
        getAlcoProposalById(options, alCode)
        setShowMsg(true)
      },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
          setLoading(false)
          setMessage('Error occured while updating Alco Proposals: ' + resMessage)
          setShowMsg(true)
        })
    } else {
      IfvAppraisalService.saveAlcoProposal(data).then((response) => {
        setLoading(false)
        setMessage('Alco Proposals have been successfully saved!')
        setAlCode(response.data.alCode)
        getAlcoProposalById(options, response.data.alCode)
        getTblFwdDetailByAlCode(response.data.alCode)
        setShowMsg(true)
      },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
          setLoading(false)
          setMessage('Error occured while saving Alco Proposals: ' + resMessage)
          setShowMsg(true)
        })
    }
  }

  const getAllAlcoData = () => {
    setLoading(true)
    IfvAppraisalService.getAllAlcoDataOnAlCode(alCode).then(
      (response) => {
        var appData = response.data
        if (appData.length > 0) {
          for (let i = 0; i < appData.length; i++) {
            remove1(i)
            append1({})
          }
        }
        else {
          append1({})
        }
        let sum = 0;
        appData.forEach((item, index) => {
          setValue2(`alcoData[${index}].dtCode`, item.dtCode)
          setValue2(`alcoData[${index}].alCode`, item.alCode)
          setValue2(`alcoData[${index}].ifvId`, item.ifvId)
          setValue2(`alcoData[${index}].dtAppl`, item.dtAppl)
          setValue2(`alcoData[${index}].dtBankname`, item.dtBankname)
          setSelectedBankOption(prevState => ({ ...prevState, [index]: item.dtBankname }));
          setValue2(`alcoData[${index}].dtSchemeAndAmount`, item.dtAmount + ' / ' + item.dtScheme)

          setValue2(`alcoData[${index}].dtScheme`, item.dtScheme)
          setValue2(`alcoData[${index}].dtAmount`, item.dtAmount)
          setValue2(`alcoData[${index}].fundCode`, item.fundCode)

          setValue2(`alcoData[${index}].dtPeriod`, item.dtPeriod)
          setValue2(`alcoData[${index}].dtRoi`, item.dtRoi)
          setValue2(`alcoData[${index}].dtCostOfFunds`, item.dtCostOfFunds)
          setValue2(`alcoData[${index}].dtSpeedmargin`, item.dtSpeedmargin)
          setValue2(`alcoData[${index}].dtPrinicipalRep`, item.dtPrinicipalRep)
          sum = sum + parseFloat(item.dtAmount)
        });
        setTot(sum)
        setLoading(false)
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        setLoading(false)
        setMessage('Error occured while loading Alco Data')
        setShowMsg(true)
      }
    )
  }
  const onSubmitOfAlcoData = (data, e) => {
    setLoading(true)
    let finalData = data['alcoData']

    finalData = finalData.filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.dtBankname))

    if (CommonUtil.isEmpty(finalData)) {
      setLoading(false)
      setMessage('Please enter data')
      setShowMsg(true)
      return
    }

    finalData.forEach((item, i) => {
      delete item.dtSchemeAndAmount
    })

    IfvAppraisalService.saveAllAlcoData(finalData).then((response) => {
      setLoading(false)
      getAllAlcoData()
      setMessage('Alco data have been successfully saved!')
      setShowMsg(true)
    },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        setLoading(false)
        setMessage('Error occured while saving Alco data: ' + resMessage)
        setShowMsg(true)
      })
  }
  const getAllBenchMarkRepoOnAlCodeAndBankType = () => {
    setLoading(true)
    IfvAppraisalService.getAllBenchMarkRepoOnAlCodeAndBankType(alCode, "Banks").then(
      (response) => {
        var appData = response.data
        if (appData.length > 0) {
          for (let i = 0; i < appData.length; i++) {
            remove2(i)
            append2({})
          }
        }
        else {
          append2({})
        }
        appData.forEach((item, index) => {
          setValue3(`benchMarkRepoBanks[${index}].bmCode`, item.bmCode)
          setValue4(`benchMarkRepoBanks[${index}].alCode`, item.alCode)
          setValue3(`benchMarkRepoBanks[${index}].ifvId`, item.ifvId)
          setValue3(`benchMarkRepoBanks[${index}].bmBanktype`, item.bmBanktype)
          setValue3(`benchMarkRepoBanks[${index}].bmBankmeetingdate`, item.bmBankmeetingdate)
          setValue3(`benchMarkRepoBanks[${index}].bmRemarks`, item.bmRemarks)
        });
        setLoading(false)
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        setLoading(false)
        setMessage('Error occured while loading Benchmark details' + resMessage)
        setShowMsg(true)
      }
    )
  }
  const onSubmitOfBenchMarkRepoBanks = (data, e) => {
    setLoading(true)
    const finalData = data['benchMarkRepoBanks'].filter(item => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.bmBankmeetingdate))
    if (CommonUtil.isEmpty(finalData)) {
      setLoading(false)
      return
    }
    IfvAppraisalService.saveAllBenchMarkRepo(finalData).then((response) => {
      setLoading(false)
      getAllBenchMarkRepoOnAlCodeAndBankType()
      setMessage('Benchmark data have been successfully saved!')
      setShowMsg(true)
    },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        setLoading(false)
        setMessage('Error occured while saving Benchmark data: ' + resMessage)
        setShowMsg(true)
      })
  }

  const getAllBenchMarkRepoSfbs = () => {
    setLoading(true)
    IfvAppraisalService.getAllBenchMarkRepoOnAlCodeAndBankType(alCode, "SFBs").then(
      (response) => {
        var appData = response.data
        if (appData.length > 0) {
          for (let i = 0; i < appData.length; i++) {
            remove3(i)
            append3({})
          }
        }
        else {
          append3({})
        }
        appData.forEach((item, index) => {
          setValue4(`benchMarkRepoSmallFinanceBanks[${index}].bmCode`, item.bmCode)
          setValue4(`benchMarkRepoSmallFinanceBanks[${index}].alCode`, item.alCode)
          setValue4(`benchMarkRepoSmallFinanceBanks[${index}].ifvId`, item.ifvId)
          setValue4(`benchMarkRepoSmallFinanceBanks[${index}].bmBanktype`, item.bmBanktype)
          setValue4(`benchMarkRepoSmallFinanceBanks[${index}].bmBankmeetingdate`, item.bmBankmeetingdate)
          setValue4(`benchMarkRepoSmallFinanceBanks[${index}].bmRemarks`, item.bmRemarks)
        });
        setLoading(false)
      },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        setLoading(false)
        setMessage('Error occured while loading Benchmark details')
        setShowMsg(true)
      }
    )
  }
  const onSubmitOfBenchMarkRepoSFBs = (data, e) => {
    setLoading(true)
    const finalData = data['benchMarkRepoSmallFinanceBanks'].filter(item => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.bmBankmeetingdate))
    if (CommonUtil.isEmpty(finalData)) {
      setLoading(false)
      return
    }
    IfvAppraisalService.saveAllBenchMarkRepo(finalData).then((response) => {
      setLoading(false)
      getAllBenchMarkRepoSfbs()
      setMessage('Benchmark data have been successfully saved!')
      setShowMsg(true)
    },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        setLoading(false)
        setMessage('Error occured while saving Benchmark data: ' + resMessage)
        setShowMsg(true)
      })
  }

  const handleBankSearch = (inputValue) => {
    if (inputValue === "") { setFilteredBankOptions(ifvAppList); return; }
    const filteredOptions = ifvAppList.filter((option) =>
      option.label.toLowerCase().includes(inputValue.toLowerCase())
    );
    setFilteredBankOptions(filteredOptions);
  }

  const [tot, setTot] = useState([])

  const handleSchemeName = (selected, index) => {
    setLoading(true)
    //const ifvApp = ifvApps.find(item => item.ifvId === selected.value)
    let currentIndex = parseInt(index)

    IfvAppraisalService.getAllSchemesOnIfvId(selected.value).then(response => {
      response.data.forEach((item, i) => {
        remove1(currentIndex)
        append1({})
        setSelectedBankOption(prevState => ({ ...prevState, [index++]: selected.label }));
        setValue2(`alcoData[${currentIndex}].dtBankname`, selected.label)
        setValue2(`alcoData[${currentIndex}].dtSchemeAndAmount`, item.prAmount + ' / ' + item.prSchemeName)
        setValue2(`alcoData[${currentIndex}].dtScheme`, item.prSchemeName)
        setValue2(`alcoData[${currentIndex}].dtAmount`, item.prAmount)
        setValue2(`alcoData[${currentIndex}].ifvId`, item.ifvId)
        setValue2(`alcoData[${currentIndex}].dtPeriod`, item.prTenure)
        setValue2(`alcoData[${currentIndex}].dtRoi`, item.prRoi)
        setValue2(`alcoData[${currentIndex}].dtAppl`, alcoProposal.alAppNumber)
        setValue2(`alcoData[${currentIndex}].fundCode`, item.prFundcode)
        setValue2(`alcoData[${currentIndex}].schemeCode`, item.prSchemecode)
        setValue2(`alcoData[${currentIndex}].prId`, item.prId)

        ++currentIndex
      })
      setLoading(false)
    },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        setLoading(false)
        setMessage('Error occured while loading cSchemes' + resMessage)
        setShowMsg(true)
      }
    )


  };

  const calculateSpreadMargin = (field, val, index) => {
    setValue2(field, val)

    let e = getValues2(`alcoData[${index}].dtRoi`)
    let f = getValues2(`alcoData[${index}].dtCostOfFunds`)
    let g = parseFloat(e) - parseFloat(f)

    setValue2(`alcoData[${index}].dtSpeedmargin`, g)
  }

  const generateReport = () => {
    setLoading(true)
    IfvAppraisalService.generateAlcoReport(alCode).then((response) => {
      setLoading(false)
      if (response.data && response.data != null) {

        FileUtil.downloadFile(response.data.fileDataBytea, response.data.fileName, "application/pdf")
      } else {
        setMessage('Invalid file')
        setShowMsg(true)
      }

    },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        setLoading(false)
        setMessage('Error occured while generating report: ' + resMessage)
        setShowMsg(true)
      }
    )
  }

  const updateDocument = (status) => {
    setLoading(true)
    const user = IfvAppraisalService.getCurrentUser()
    const data = {
      alCode: alCode,
      ofrCode: user.ofrCode,
      ofrName: user.ofrName
    }

    let statusName = "";

    if (status === 'LK') {
      statusName = 'Locked'
    } else if (status === 'AP') {
      statusName = 'Approved'
    } else if (status === 'UL') {
      statusName = 'Unlocked'
    } else if (status === 'AP') {
      statusName = 'Approved'
    } else if (status === 'CN') {
      statusName = 'Confirmed'
    }

    IfvAppraisalService.updateDocument(data, status).then((response) => {
      setLoading(false)
      getTblFwdDetailByAlCode(alCode)
      setMessage('Application has been ' + statusName)
      setShowLockUnlockMsg(true)
    },
      (error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        setLoading(false)
        setMessage('Error occured: ' + resMessage)
        setShowMsg(true)
      }
    )
  }

  const [loading, setLoading] = useState(false);

  const deleteAlcoData = (index) => {
    setLoading(true)
    const id = getValues2(`alcoData[${index}].dtCode`)
    const name = getValues2(`alcoData[${index}].dtBankname`)
    if (CommonUtil.isValidNumber(id)) {
      IfvAppraisalService.deleteAlcoData(name).then((response) => {
        // setValue2(`alcoData[${index}]`, undefined)
        // remove1(index)
        // setMessage('Alco detail deleted successfully!')
        // setShowMsg(true)

        setLoading(false)
        navigate(location.pathname, {
          replace: true,
          state: { alCode: alCode }
        });
        window.location.reload();


      },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
          setLoading(false)
          setMessage('Error occured while deleting Alco: ' + resMessage)
          setShowMsg(true)
        }
      )
    } else {

      if (CommonUtil.isEmpty(name)) {
        setValue2(`alcoData[${index}]`, null)
        setSelectedBankOption(prevState => ({ ...prevState, [index]: '' }))
        remove1(index)
      } else {
        fields1.map((field, i) => {
          var v = getValues2(`alcoData[${i}].dtBankname`)

          if (name === v) {
            setSelectedBankOption(prevState => ({ ...prevState, [i]: '' }))
            setValue2(`alcoData[${i}]`, null)
            remove1(i)
          }
        })
      }

      setLoading(false)
    }
  }

  const handleBenchMarkADelete = (index) => {
    setLoading(true)
    const id = getValues3(`benchMarkRepoBanks[${index}].bmCode`)
    if (CommonUtil.isValidNumber(id)) {
      IfvAppraisalService.handleBenchMarkADelete(id).then((response) => {
        setValue3(`benchMarkRepoBanks[${index}]`, null)
        remove2(index)
        setMessage('Benchmark data has been deleted successfully!')
        setShowMsg(true)

        setLoading(false)
      },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
          setLoading(false)
          setMessage('Error occured while deleting Benchmark: ' + resMessage)
          setShowMsg(true)
        }
      )
    } else {

      setValue3(`benchMarkRepoBanks[${index}]`, null)
      remove2(index)

      setLoading(false)
    }
  }

  const handleBenchMarkBDelete = (index) => {
    setLoading(true)
    const id = getValues4(`benchMarkRepoSmallFinanceBanks[${index}].bmCode`)
    if (CommonUtil.isValidNumber(id)) {
      IfvAppraisalService.handleBenchMarkADelete(id).then((response) => {
        setValue4(`benchMarkRepoSmallFinanceBanks[${index}]`, null)
        remove3(index)
        setMessage('Benchmark data has been deleted successfully!')
        setShowMsg(true)

        setLoading(false)
      },
        (error) => {
          const resMessage =
            (error.response &&
              error.response.data &&
              error.response.data.message) ||
            error.message ||
            error.toString();
          setLoading(false)
          setMessage('Error occured while deleting Benchmark: ' + resMessage)
          setShowMsg(true)
        }
      )
    } else {

      setValue4(`benchMarkRepoSmallFinanceBanks[${index}]`, null)
      remove3(index)

      setLoading(false)
    }
  }

  return (
    <Fragment>
      <div className={loading ? 'frgmnt blur-background' : 'frgmnt'}>
        <div className="row">
          <div className="col-md-4">
            <h2 className="heading"><strong>ALCO App Number:</strong> {alcoProposal.alAppNumber}</h2>
          </div>
          <div className="col-md-4">
            <h2 className="heading"><strong>Status:</strong> {appStatus}</h2>
          </div>
          <div className="col-md-4 text-end">

            {alCode > 0 && <button type="button"
              className="btn btnRegister themebutton" onClick={() => generateReport()}><i className="fa fa-file-signature"></i> Generate Report</button>}
          </div>
        </div>
        <br />
        <Accordion flush>

          <Accordion.Item>
            <Accordion.Header>Proposal to Sub-Committee of ALCO for fixing of Interest Rate for Refinance</Accordion.Header>
            <Accordion.Body>
              <form key={2} onSubmit={handleSubmitOfAlcoProposal(onSubmitOfAlcoProposal)}>
                {/* <h4 className='mt-0 prop'><strong>Proposal to Sub-Committee of ALCO for fixing of Interest Rate for Refinance </strong></h4> */}
                <div className='form-group msersWrap bg_alc mt-2'>
                  <h5 className='pt-3'><strong>Background:</strong></h5>
                  <div className='row mt-3'>
                    <div className='col-md-12'>
                      {/* <p>ALCO, at its various meetings, has approved the benchmark rates for refinance assistance for Banks/ SFBs as indicated in <strong>Annexure.</strong></p> */}

                      <textarea className='form-control'
                        {...register1('alBackground')}
                        onChange={(e) => Pattern.sanitizeInput(e)}
                      />

                    </div>
                  </div>



                  <h5 className='mt-4'><strong>Present Proposal:</strong></h5>
                  <div className='row mt-3'>
                    <div className='col-md-12'>
                      {/* <p>IFV has negotiated interest rate and other terms for refinance under MSER scheme with the following bank based on the clause Nos.A.2 & A.5 of the <strong>Annexure</strong> as under:</p> */}
                      <textarea className='form-control'
                        {...register1('alPresntProposal')}
                        onChange={(e) => Pattern.sanitizeInput(e)}
                      />
                    </div>
                  </div>


                  <div className='form-group msersWrap mt-4'>

                    <div className='row mt-3'>
                      <div className='col-md-12'>
                        <p># TRMV indicated the cost of funds vide its e-mail dated 18-01-2023.</p>
                        <p>TRMV has advised AAA Bonds yield as on 24-01-2024 as under:</p>

                        <div className='row justify-content-start'>
                          <div className='col-md-8'>
                            <div className='tenor'>
                              <div className='row'>
                                <div className='col-md-4'><strong>Tenor</strong></div>
                                <div className='col-md-4'><strong>1 YR</strong></div>
                                <div className='col-md-4'><strong>3 YR</strong></div>
                              </div>

                              <div className='row'>
                                <div className='col-md-4'>
                                  <div className='form-group'>
                                    <input type='hidden' className='form-control' placeholder='Tenor'
                                      {...register1('alCode')} />
                                    <input type='text' className='form-control' placeholder='Tenor'
                                      {...register1('alTenor')} value='Yield (%)' />
                                  </div>
                                </div>
                                <div className='col-md-4'>
                                  <div className='form-group'>
                                    <input type='number' className='form-control' placeholder='1 YR'
                                      step='any'
                                      {...register1('al1yr', {
                                        validate: (value) => {
                                          if (value < 0) return "Negative numbers are not allowed";
                                          return true;
                                        },
                                      })} />
                                    <span className='vldn'>{errors1.al1yr && errors1.al1yr.message}</span>
                                  </div>
                                </div>
                                <div className='col-md-4'>
                                  <div className='form-group'>
                                    <input type='number' step='any' className='form-control' placeholder='3 YR'
                                      {...register1('al3yr', {
                                        validate: (value) => {
                                          if (value < 0) return "Negative numbers are not allowed";
                                          return true;
                                        },
                                      })} />
                                    <span className='vldn'>{errors1.al3yr && errors1.al3yr.message}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <p>Since specific cost is available from TRMV, the same has been utilized. </p>
                      </div>

                    </div>
                    <div className='row mt-3'>
                      <div className='col-md-12'>
                        <div className='form-group'>
                          <label><strong>Recommendation</strong></label>
                          <Select
                            isMulti
                            value={selectedOption}
                            onChange={handleChange}
                            options={options}
                          />
                        </div>
                      </div>
                    </div>


                  </div>
                  <div className="button-container-center">
                    {(editable || (isChecker && locked)) && <button type='submit' className='btn btnSave'>Save <i className="fa fa-circle-check"></i></button>}
                  </div>
                </div>

              </form>
            </Accordion.Body>
          </Accordion.Item>
          {alCode > 0 && <>

            <Accordion.Item eventKey='1'>
              <Accordion.Header>ALCO Data</Accordion.Header>
              <Accordion.Body className='ac_spc'>
                <form key={1} onSubmit={handleSubmitOfAlcoData(onSubmitOfAlcoData)}>
                  <div className='row scme'>
                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label className='ml-2'><strong>SL. No.</strong></label>
                      </div>
                    </div>

                    <div className='col-md-2'>
                      <div className='form-group'>
                        <label className='ml-4'> <strong>Name of the Bank</strong></label>
                      </div>
                    </div>

                    <div className='col-md-2'>
                      <div className='form-group'>
                        <label className='ml-2'><strong>Amount (cr.) / Scheme </strong></label>
                      </div>
                    </div>

                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label><strong>Period in months</strong></label>
                      </div>
                    </div>

                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label><strong>Rate of Interest (% p.a.)</strong> </label>
                      </div>
                    </div>

                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label><strong>Cost of funds (% p.a.) #</strong></label>
                      </div>
                    </div>

                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label><strong>Spread/ Margin</strong></label>
                      </div>
                    </div>

                    <div className='col-md-2'>
                      <div className='form-group'>
                        <label><strong>Principal Repayment </strong></label>
                      </div>
                    </div>

                    <div className='col-md-1'>

                    </div>
                  </div>

                  <div className='row mt-2'>
                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label className='ml-2'><strong>a</strong></label>
                      </div>
                    </div>

                    <div className='col-md-2'>
                      <div className='form-group'>
                        <label className='ml-3'><strong className='aln_cntr'> b</strong></label>
                      </div>
                    </div>

                    <div className='col-md-2'>
                      <div className='form-group'>
                        <label className='ml-1'><strong className='aln_cntr'> c </strong></label>
                      </div>
                    </div>

                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label><strong className='aln_cntr'>d</strong></label>
                      </div>
                    </div>

                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label><strong className='aln_cntr'>e </strong></label>
                      </div>
                    </div>

                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label><strong className='aln_cntr'>f</strong></label>
                      </div>
                    </div>

                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label><strong className='aln_cntr'>g = e-f</strong></label>
                      </div>
                    </div>

                    <div className='col-md-2'>
                      <div className='form-group'>
                        <label><strong className='aln_cntr'>h</strong></label>
                      </div>
                    </div>

                    <div className='col-md-1'>

                    </div>

                  </div>


                  {fields1.map((field, index) => (
                    <div className='container-fluid'>
                      <div className='row pt-0' eventKey="0" key={field.id}>

                        <div className='col-md-1'>
                          <div className='form-group'>{index + 1} &nbsp;</div>
                        </div>


                        <div className='col-md-2'>
                          <div className='form-group'>
                            <Select
                              key={field.id}
                              value={filteredBankOptions.find((option) => option.label === selectedBankOption[index])}
                              // onChange={(selected) => setSelectedBankOption(prevState => ({ ...prevState, [index]: selected.label }))}
                              onChange={(selected) => handleSchemeName(selected, index)}
                              options={filteredBankOptions}
                              onInputChange={handleBankSearch}
                              isSearchable
                            />


                            <input className='form-control' key={field.id} type='hidden'
                              {...register2(`alcoData[${index}].dtBankname`, {
                                required: 'Field is required'
                              })} value={selectedBankOption[index]} />
                            <span className='vldn'>{errors2.alcoData && errors2.alcoData[index]?.dtBankname && errors2.alcoData[index]?.dtBankname.message}</span>

                            <input key={field.id} type='hidden' {...register2(`alcoData[${index}].ifvId`)} />
                            <input key={field.id} type='hidden' {...register2(`alcoData[${index}].dtCode`)} />
                            <input key={field.id} type='hidden' {...register2(`alcoData[${index}].alCode`)} value={alCode} />
                            <input key={field.id} type='hidden' {...register2(`alcoData[${index}].dtAppl`)} value={alcoProposal.alAppNumber} />

                            <input key={field.id} type='hidden' {...register2(`alcoData[${index}].dtAmount`)} />
                            <input key={field.id} type='hidden' {...register2(`alcoData[${index}].dtScheme`)} />
                            <input key={field.id} type='hidden' {...register2(`alcoData[${index}].fundCode`)} />

                            <input key={field.id} type='hidden' {...register2(`alcoData[${index}].schemeCode`)} />
                            <input key={field.id} type='hidden' {...register2(`alcoData[${index}].prId`)} />
                          </div>
                        </div>


                        <div className='col-md-2'>
                          <div className='form-group'>
                            <input type='text' className='form-control' {...register2(`alcoData[${index}].dtSchemeAndAmount`)} readOnly />
                          </div>
                        </div>

                        <div className='col-md-1'>
                          <div className='form-group'>
                            <input className='form-control' key={field.id} type='number'
                              step='0.01'
                              {...register2(`alcoData[${index}].dtPeriod`)} readOnly />

                          </div>
                        </div>

                        <div className='col-md-1'>
                          <div className='form-group'>
                            <input className='form-control' key={field.id} type='number' step='0.01'
                              {...register2(`alcoData[${index}].dtRoi`, {
                                onChange: (e) => calculateSpreadMargin(`alcoData[${index}].dtRoi`, e.target.value, index)
                              })} readOnly />
                          </div>
                        </div>

                        <div className='col-md-1'>
                          <div className='form-group'>
                            <input className='form-control' key={field.id} type='number' step='0.01'
                              {...register2(`alcoData[${index}].dtCostOfFunds`,
                                {
                                  required: 'Field is required',
                                  validate: (value) => {
                                    if (value <= 0) return "Invalid value";
                                    //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
                                    if (!/^(100(\.0{1,2})?|\d{1,2}(\.\d{1,2})?)$/.test(value)) return "Enter up to 100 with up to 2 decimal places";
                                    return true;
                                  },
                                  onChange: (e) => calculateSpreadMargin(`alcoData[${index}].dtCostOfFunds`, e.target.value, index)
                                })} />
                            <span className='vldn'>{errors2.alcoData && errors2.alcoData[index]?.dtCostOfFunds && errors2.alcoData[index]?.dtCostOfFunds.message}</span>
                          </div>
                        </div>

                        <div className='col-md-1'>
                          <div className='form-group'>
                            <input className='form-control' key={field.id} type='number' step='0.01' readOnly
                              {...register2(`alcoData[${index}].dtSpeedmargin`)} />
                          </div>
                        </div>

                        <div className='col-md-2'>
                          <div className='form-group'>
                            {/* <input className='form-control' key={field.id} type='String'
                            {...register2(`alcoData[${index}].dtPrinicipalRep`)} /> */}
                            <select className="form-control"
                              {...register2(`alcoData[${index}].dtPrinicipalRep`, {
                                required: 'Field is required',
                              })}
                            >
                              <option value=""> Please select a value</option>
                              {PrincipalRepayment.map((item, i) => (
                                <option value={item}>{item}</option>
                              ))}
                            </select>
                            <span className='vldn'>{errors2.alcoData && errors2.alcoData[index]?.dtPrinicipalRep && errors2.alcoData[index]?.dtPrinicipalRep.message}</span>
                          </div>
                        </div>

                        <div className='col-md-1'>
                          <div className='form-group'>
                            {(editable || (isChecker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                              onClick={() => deleteAlcoData(index)}></i>}
                          </div>
                        </div>

                      </div>
                    </div>
                  ))}

                  <div className='row mt-3 mb-3'>
                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label className='ml-2'>&nbsp;</label>
                      </div>
                    </div>

                    <div className='col-md-2'>
                      <div className='form-group mrge'>
                        <label className='ml-3'><strong className='blds'>Total</strong></label>
                      </div>
                    </div>

                    <div className='col-md-2'>
                      <div className='form-group mrge'>
                        <input className='form-control' value={tot} readOnly />
                      </div>
                    </div>

                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label><strong>&nbsp;</strong></label>
                      </div>
                    </div>

                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label><strong>&nbsp;</strong></label>
                      </div>
                    </div>

                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label><strong>&nbsp;</strong></label>
                      </div>
                    </div>

                    <div className='col-md-2'>
                      <div className='form-group'>
                        <label><strong>&nbsp;</strong></label>
                      </div>
                    </div>

                    <div className='col-md-2'>
                      <div className='form-group'>
                        <label><strong>&nbsp;</strong></label>
                      </div>
                    </div>

                  </div>

                  <div className="button-container-end">
                    <button className='remove add' type="button" onClick={() => append1({})}>Add</button>
                  </div>

                  <div className="button-container-center">
                    {(editable || (isChecker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                  </div>
                </form>
              </Accordion.Body>
            </Accordion.Item>

            <Accordion.Item className='alc_row' eventKey='2'>
              <Accordion.Header>Sub-Committee of ALCO</Accordion.Header>
              <Accordion.Body className='ac_spc'>
                <div className='sb_cmt'>
                  <h5><strong>Benchmark Rates for Refinance Assistance for Banks/SFBs as Approved by ALCO / Board</strong></h5>
                  <span>Annexure</span>
                </div>
                <form key={3} onSubmit={handleSubmitOfBenchMarkRepository(onSubmitOfBenchMarkRepoBanks)}>
                  <div className='row'>
                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label className='ml-2 b_fnt'><b>A</b></label>
                      </div>
                    </div>
                    <div className='col-md-3'>
                      <div className='form-group'>
                        <label className='ml-1 b_fnt'><strong><b>Banks</b></strong></label>
                      </div>
                    </div>

                    <div className='col-md-8'>

                    </div>

                  </div>
                  <div className='row nrsn mb-2 pt-3'>
                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label className='ml-2'><strong>SL. No.</strong></label>
                      </div>
                    </div>

                    {/* <div className='col-md-3'>
                    <div className='form-group'>
                      <label className='ml-4'> Banks</label>
                    </div>
                  </div> */}

                    <div className='col-md-3'>
                      <div className='form-group'>
                        <label className='ml-1'><strong>Meeting No./Date </strong></label>
                      </div>
                    </div>

                    <div className='col-md-8'>
                      <div className='row'>
                        <div className='col-md-9'>
                          <div className='form-group'>
                            <label><strong>Decision</strong></label>
                          </div>
                        </div>

                        <div className='col-md-3'>
                          {/* <div className="button-container-end mt-0">
                            <button className='remove add' type="button" onClick={() => append2({})}>Add</button>
                          </div> */}
                        </div>
                      </div>
                    </div>

                  </div>


                  {fields2.map((field, index) => (
                    <div className='container-fluid'>
                      <div className='row otr pt-0 mb-2' eventKey="0" key={field.id}>

                        <div className='col-md-1'>
                          <div className='form-group'>{index + 1} &nbsp;</div>
                        </div>


                        {/* <div className='col-md-3'>
                        <div className='form-group'>
                          <input className='form-control' key={field.id} type='text' />
                        </div>
                      </div> */}


                        <div className='col-md-3'>
                          <div className='form-group'>
                            <input className='form-control' key={field.id} type='text'
                              {...register3(`benchMarkRepoBanks[${index}].bmBankmeetingdate`, {
                                required: 'Field is required'
                              })} onChange={(e) => Pattern.sanitizeInput(e)} />
                            <span className='vldn'>{errors3.benchMarkRepoBanks && errors3.benchMarkRepoBanks[index]?.bmBankmeetingdate && errors3.benchMarkRepoBanks[index]?.bmBankmeetingdate.message}</span>
                            <input key={field.id} type='hidden' {...register3(`benchMarkRepoBanks[${index}].bmCode`)} />
                            <input key={field.id} type='hidden' {...register3(`benchMarkRepoBanks[${index}].alCode`)} value={alCode} />
                            <input key={field.id} type='hidden' {...register3(`benchMarkRepoBanks[${index}].bmBanktype`)} value="Banks" />
                          </div>
                        </div>

                        <div className='col-md-7'>
                          <div className='form-group'>
                            <textarea className='form-control' key={field.id}
                              {...register3(`benchMarkRepoBanks[${index}].bmRemarks`, {
                                required: 'Field is required',
                                maxLength: {
                                  value: 4000,
                                  message: "The maximum length of the field is 4000"
                                },

                              })} onChange={(e) => Pattern.sanitizeInput(e)} />
                            <span className='vldn'>{errors3.benchMarkRepoBanks && errors3.benchMarkRepoBanks[index]?.bmRemarks && errors3.benchMarkRepoBanks[index]?.bmRemarks.message}</span>
                          </div>
                        </div>

                        <div className='col-md-1'>
                          <div className='form-group'>
                            {(editable || (isChecker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                              onClick={() => handleBenchMarkADelete(index)} >

                            </i>}
                          </div>
                        </div>

                      </div>
                    </div>
                  ))}
                  <div className="button-container-end">
                    <button type="button" className='addBtn' onClick={() => append2({})}>+</button>
                  </div>
                  <div className="button-container-center" style={{marginTop:'0px', marginBottom: '1rem'}}>
                    {(editable || (isChecker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                  </div>
                </form>
                <br />
                <form key={4} onSubmit={handleSubmitOfBenchMarkRepositorySfbs(onSubmitOfBenchMarkRepoSFBs)}>
                  <div className='row'>
                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label className='ml-2 b_fnt'><b>B</b></label>
                      </div>
                    </div>
                    <div className='col-md-3'>
                      <div className='form-group'>
                        <label className='ml-1 b_fnt'><strong><b>Small Finance Banks (SFB</b></strong><b>s)</b></label>
                      </div>
                    </div>

                    <div className='col-md-8'>

                    </div>

                  </div>
                  <div className='row nrsn pt-3 mb-2'>
                    <div className='col-md-1'>
                      <div className='form-group'>
                        <label className='ml-2'><strong>SL. No.</strong></label>
                      </div>
                    </div>

                    {/* <div className='col-md-3'>
                    <div className='form-group'>
                      <label className='ml-4'>Small Finance Banks (SFB<sub>s</sub>)</label>
                    </div>
                  </div> */}

                    <div className='col-md-3'>
                      <div className='form-group'>
                        <label className='ml-1'><strong>Meeting No./Date</strong></label>
                      </div>
                    </div>

                    <div className='col-md-8'>
                      <div className='row'>
                        <div className='col-md-9'>
                          <div className='form-group'>
                            <label><strong>Decision</strong></label>
                          </div>
                        </div>

                        <div className='col-md-3'>
                          {/* <div className="button-container-end mt-0">
                            <button className='remove add' type="button" onClick={() => append3({})}>Add</button>
                          </div> */}
                        </div>
                      </div>
                    </div>

                  </div>



                  {fields3.map((field, index) => (
                    <div className='container-fluid'>
                      <div className='row otr pt-0 mb-2' eventKey="0" key={field.id}>
                        <div className='col-md-1'>
                          <div className='form-group'>{index + 1} &nbsp;</div>
                        </div>


                        <div className='col-md-3'>
                          <div className='form-group'>
                            <input className='form-control' key={field.id} type='text'
                              {...register4(`benchMarkRepoSmallFinanceBanks[${index}].bmBankmeetingdate`, {
                                required: 'Field is required',

                              })} onChange={(e) => Pattern.sanitizeInput(e)} />
                            <span className='vldn'>{errors4.benchMarkRepoSmallFinanceBanks && errors4.benchMarkRepoSmallFinanceBanks[index]?.bmBankmeetingdate && errors4.benchMarkRepoSmallFinanceBanks[index]?.bmBankmeetingdate.message}</span>

                            <input key={field.id} type='hidden' {...register4(`benchMarkRepoSmallFinanceBanks[${index}].alCode`)} value={alCode} />
                            <input key={field.id} type='hidden' {...register4(`benchMarkRepoSmallFinanceBanks[${index}].bmCode`)} />
                            <input key={field.id} type='hidden' {...register4(`benchMarkRepoSmallFinanceBanks[${index}].bmBanktype`)} value="SFBs" />
                          </div>
                        </div>


                        {/* <div className='col-md-2'>
                          <div className='form-group'>
                            <input className='form-control' key={field.id} type='number' />
                          </div>
                        </div> */}

                        <div className='col-md-7'>
                          <div className='form-group'>
                            <textarea className='form-control' key={field.id}
                              {...register4(`benchMarkRepoSmallFinanceBanks[${index}].bmRemarks`, {
                                required: 'Field is required',
                                maxLength: {
                                  value: 4000,
                                  message: "The maximum length of the field is 4000"
                                },

                              })} onChange={(e) => Pattern.sanitizeInput(e)} />
                            <span className='vldn'>{errors4.benchMarkRepoSmallFinanceBanks && errors4.benchMarkRepoSmallFinanceBanks[index]?.bmRemarks && errors4.benchMarkRepoSmallFinanceBanks[index]?.bmRemarks.message}</span>
                          </div>
                        </div>

                        <div className='col-md-1'>
                          <div className='form-group'>
                            {(editable || (isChecker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                              onClick={() => handleBenchMarkBDelete(index)} >

                            </i>}
                          </div>
                        </div>

                      </div>
                    </div>
                  ))}
                  <div className="button-container-end">
                    <button type="button" className='addBtn' onClick={() => append3({})}>+</button>
                  </div>
                  <div className="button-container-center">
                    {(editable || (isChecker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                  </div>
                </form>

              </Accordion.Body>
            </Accordion.Item>




            <div className="button-container-center">
              {(editable && isMaker) && <button type='button' className='btn bg-success btnSave locks' onClick={() => updateDocument('LK')}>Lock Document <i className="fa fa-lock"></i></button>}
              {((locked && isChecker) || (isConfirmed && (isMakerConvenor || isHigherAuthority))) && <button type='button' className='btn bg-success btnSave' onClick={() => updateDocument('UL')}>Unlock Document <i className="fa fa-unlock"></i></button>}
              {(locked && isChecker) && <button type='button' className='btn bg-success btnSave' onClick={() => updateDocument('CN')}>Confirm Document <i className="fa fa-check-square-o"></i></button>}
              {(isConfirmed && (isMakerConvenor || isHigherAuthority)) && <button type='button' className='btn bg-success btnSave' onClick={() => updateDocument('AP')}>Approve Document <i className="fa fa-circle-check"></i></button>}
            </div>
          </>
          }
        </Accordion>

      </div>
      <Modal style={{ marginTop: "200px" }} show={showMsg} onHide={hideMsg}>

        <Modal.Body >
          <div className="conatiner text-center">
            <div className="row">
              <div className="col-sm-12">
              <h5 className= {message.includes('Error')? 'alertMsg':'loadMsg'}>{message}</h5>
                {/* <h5 className="loadMsg">{message}</h5> */}
              </div>
            </div>
          </div>
          
          <div className="row text-center">
            <div className="col-sm-12 text-center">
              <button type="button" className=" btn  btnRegister  themebutton" onClick={hideMsg}>OK</button>
            </div>
          </div>

        </Modal.Body>
      </Modal>
      <Modal style={{ marginTop: "200px" }} show={showLockUnlockMsg} onHide={hideLockUnlockMsg}>

        <Modal.Body >
          <div className="conatiner text-center">
            <div className="row">
              <div className="col-sm-12">
              <h5 className= {message.includes('Error')? 'alertMsg':'loadMsg'}>{message}</h5>
              </div>
            </div>
          </div>
         
          <div className="row text-center">
            <div className="col-sm-12 text-center">
              <button type="button" className=" btn  btnRegister  themebutton" onClick={hideLockUnlockMsg}>OK</button>
            </div>
          </div>

        </Modal.Body>
      </Modal>
      {loading && <Loading />}
    </Fragment >
  )
}
export default AlocDetails;