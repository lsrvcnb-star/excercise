import { useNavigate } from 'react-router-dom';
export default function NotFound() {
    const navigate = useNavigate();
    const styles = {
        container: {
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            minHeight: '100vh',
            padding: '20px',
            textAlign: 'center',
            backgroundColor: '#f8f9fa',
            fontFamily: 'system-ui, -apple-system, sans-serif'
        },
        errorCode: {
            fontSize: '120px',
            fontWeight: 'bold',
            color: '#dc3545',
            margin: '0',
            letterSpacing: '5px',
            textShadow: '2px 2px 4px rgba(0,0,0,0.1)'
        },
        heading: {
            color: '#343a40',
            fontSize: '28px',
            marginTop: '0',
            marginBottom: '16px',
            fontWeight: '600'
        },
        message: {
            color: '#6c757d',
            fontSize: '16px',
            maxWidth: '500px',
            lineHeight: '1.6',
            marginBottom: '32px'
        },
        buttonContainer: {
            display: 'flex',
            gap: '16px'
        },
        primaryButton: {
            padding: '12px 24px',
            backgroundColor: '#0066cc',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: '500',
            transition: 'all 0.2s ease',
            textDecoration: 'none'
        },
        secondaryButton: {
            padding: '12px 24px',
            backgroundColor: 'transparent',
            color: '#0066cc',
            border: '1px solid #0066cc',
            borderRadius: '6px',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: '500',
            transition: 'all 0.2s ease'
        }
    };
    const handleGoBack = () => {
        navigate(-1);
    };
    const handleGoHome = () => {
        navigate('/');
    };
    return (
        <div style={styles.container}>
            <h1 style={styles.errorCode}>404</h1>
            <h2 style={styles.heading}>Page Not Found</h2>
            <p style={styles.message}>
                Oops! The page you're looking for doesn't exist.
                It might have been moved or deleted, or perhaps you typed the URL incorrectly.
            </p>
            <div style={styles.buttonContainer}>
                <button
                    style={styles.primaryButton}
                    onClick={handleGoHome}
                    onMouseOver={(e) => e.target.style.backgroundColor = '#0052a3'}
                    onMouseOut={(e) => e.target.style.backgroundColor = '#0066cc'}
                >
                    Go to Home
                </button>
                <button
                    style={styles.secondaryButton}
                    onClick={handleGoBack}
                    onMouseOver={(e) => {
                        e.target.style.backgroundColor = '#f8f9fa';
                        e.target.style.borderColor = '#0052a3';
                        e.target.style.color = '#0052a3';
                    }}
                    onMouseOut={(e) => {
                        e.target.style.backgroundColor = 'transparent';
                        e.target.style.borderColor = '#0066cc';
                        e.target.style.color = '#0066cc';
                    }}
                >
                    Go Back
                </button>
            </div>
        </div>
    );
}