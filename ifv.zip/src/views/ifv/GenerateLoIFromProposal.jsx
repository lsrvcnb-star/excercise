import { Description, PictureAsPdf } from '@mui/icons-material';
import { Box, Button, Stack, Tab, Tabs } from '@mui/material';
import Loading from 'components/Loading';
import MessageModal from 'components/MessageModal';
import { format } from 'date-fns';
import { useErrorHandler } from 'hooks/useErrorHandler';
import useMessageModal from 'hooks/useMessageModal';
import { Fragment, useEffect, useState } from 'react';
import ReactDatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { Controller, useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
import MinutesService from 'services/MinutesService';
import CommonUtil from 'services/utils/CommonUtil';
import FileUtil from 'services/utils/FileUtil';
import Pattern from 'services/validators/Pattern';
const GenerateLoIFromProposal = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const ifvId = location.state?.ifvId;
    const propLoIidReceived = location.state?.id;
    const [value, setValue] = useState(0);
    const [loiList, setLoiList] = useState([]);
    const [selectedLoi, setSelectedLoi] = useState(null);
    const [checkerList, setCheckerList] = useState([]);
    const [selectedUser, setSelectedUser] = useState(null);
    const { control, register, handleSubmit, reset, getValues, setValue: setValues, formState: { errors } } = useForm({
        mode: "onBlur"
    });
    const {
        showMessage,
        hideMessage,
        isOpen,
        messageConfig,
        totalMessages,
        currentIndex,
        nextMessage,
        prevMessage,
        hasNext,
        hasPrev
    } = useMessageModal();
    const { handleApiError } = useErrorHandler(showMessage);
    const [loading, setLoading] = useState(false);
    useEffect(() => {
        if (ifvId || propLoIidReceived) {
            getUserList();
        }
    }, [ifvId]);
    const fetchLoIDetails = async (ifvId, userList) => {
        try {
            setLoading(true);
            let response;
            if (CommonUtil.isValidNumber(propLoIidReceived)) {
                response = await MinutesService.fetchLoIDetailsByPropId(propLoIidReceived);
            } else {
                response = await MinutesService.fetchLoIDetails(ifvId);
            }
            const loiData = Array.isArray(response.data) ? response.data : [];
            setLoiList(loiData);
            if (loiData.length > 0) {
                setSelectedLoi(loiData[0]);
                populateForm(loiData[0], userList);
            }
        } catch (error) {
            handleApiError(error, 'loading LoI details');
            setLoiList([]);
        } finally {
            setLoading(false);
        }
    };
    const handleTabChange = (event, newValue) => {
        setValue(newValue);
        const newLoi = loiList[newValue] || null;
        setSelectedLoi(newLoi);
        if (newLoi) {
            populateForm(newLoi, checkerList);
        }
    };
    const populateForm = (loiData, userList) => {
        if (CommonUtil.isEmpty(loiData.id)) {
            loiData = prepareDefaultLoiData(loiData);
        }
        reset({
            ...loiData,
            loiDate: loiData.loiDate ? new Date(loiData.loiDate) : null,
            ifvAppDated: loiData.ifvAppDated ? new Date(loiData.ifvAppDated) : null,
            documentDated: loiData.documentDated ? new Date(loiData.documentDated) : null,
            loiUser: selectedUser?.ofrCode || loiData.loiUser
        });
        // Restore selected user if exists
        if (loiData.loiUser) {
            const user = userList.find(u => u.ofrCode == loiData.loiUser);
            setSelectedUser(user || null);
        }
    };
    const prepareDefaultLoiData = (loiData) => {
        const originalDate = new Date(loiData.ifvAppDated);
        const formattedDate = format(originalDate, 'MMMM d, yyyy');
        const isRMSE = loiData.schemeName.includes('RMSE');
        const count2 = loiData.prIds.split(',').filter(Boolean).length;
        let annexures;
        if (count2 > 1) {
            annexures = Array.from({ length: count2 }, (_, i) => 'Annexure ' + (i + 1))
                .join(' & ');
        } else {
            annexures = 'Annexure';
        }
        return {
            ...loiData,
            headerNote: `Letter of Intent for refinance under ${loiData.schemeName} Scheme`,
            note1: `Please refer to your application dated ${formattedDate}, requesting for sanction of Refinance under ${loiData.schemeName} Scheme. We inform you that your request has been considered and Small Industries Development Bank of India (SIDBI) is agreeable, in principle, to grant to your Bank financial support to the extent of Rs. ${loiData.amount} crore (${loiData.amountInWords}) by way of refinance under ${loiData.schemeName} Scheme on the conditions as agreed under the General Agreement executed by you and more specifically on the terms and conditions specified herein in ${annexures} for the present proposal.`,
            note2: 'This Letter of Intent is being issued in duplicate. In case these terms and conditions are acceptable to your Bank, you may please return the duplicate copy hereof duly accepted by an authorized official on behalf of your bank. Please sign on each page of the duplicate LoI along with Round stamp and attached it to a non-judicial stamp paper of the requisite value for agreement with an endorsement thereon by the authorized official as follows:',
            note2Subnote1: `"The terms and conditions contained in the attached LoI bearing SIDBI: IFV: No. ${loiData.loiNo} dated ___________, are hereby accepted.`,
            note2Subnote2: 'I/We are authorized to accept the LoI as per the following document issued in my / our favour and which is valid as on date.',
            note3: `Please note that this communication should not be construed as giving rise to any binding obligation on the part of SIDBI, unless the loan agreement and other documents, if any, relating to the above facility are executed by your Bank in such form as may be required by SIDBI within ${isRMSE ? '7' : '3'} working days from the date of this Letter of Intent or such further time as may be allowed by SIDBI in its absolute discretion.`,
            nameOfDocuments: 'Power of Attorney / Authorization letter / Board resolution / any other document (please specify)',
            sectionMode: 'Singly / Jointly',
            kycDocuments: '•	Aadhar Card / Passport / Driving License / Voter ID Card / PAN Card.'
        };
    };
    const getUserList = async () => {
        try {
            setLoading(true);
            const response = await MinutesService.loadCheckers();
            setCheckerList(response.data);
            fetchLoIDetails(ifvId, response.data);

        } catch (error) {
            handleApiError(error, 'loading user list');
        } finally {
            setLoading(false);
        }
    };
    const saveLoiDetails = async (data) => {
        if (!selectedUser) {
            showMessage('Please select user', 'warning');
            return;
        }
        try {
            setLoading(true);
            const payload = {
                ...data,
                ifvId,
                loiUser: selectedUser?.ofrCode,
                loiDate: data.loiDate?.toISOString(),
                ifvAppDated: data.ifvAppDated?.toISOString(),
                documentDated: data.documentDated?.toISOString()
            };
            await MinutesService.saveLoiDetailsForProposals(payload);
            showMessage('LoI details have been successfully saved!', 'success');
            await fetchLoIDetails(ifvId, checkerList);
        } catch (error) {
            handleApiError(error, 'saving LoI details');
        } finally {
            setLoading(false);
        }
    };
    const generateLOI = async () => {
        if (!selectedLoi?.id) return;
        try {
            setLoading(true);
            const response = await MinutesService.generateLOIReportForAppraisal(selectedLoi.id);
            FileUtil.downloadFile(response.data.fileDataBytea, response.data.fileName, "application/pdf")
        } catch (error) {
            handleApiError(error, 'generating LoI');
        } finally {
            setLoading(false);
        }
    };
    const handleUserChange = (ofrCode) => {
        const user = checkerList.find(u => u.ofrCode == ofrCode);
        setSelectedUser(user);
    };
    const setSubNote1 = (e) => {
        const ifvNumber = getValues('loiNo');
        const originalDate = new Date(e.target.value);
        const formattedDate = format(originalDate, 'MMMM d, yyyy');
        setValues('note2Subnote1', `"The terms and conditions contained in the attached LoI bearing SIDBI: IFV: No. ${ifvNumber} dated ${formattedDate}, are hereby accepted.`);
    };

    const setSubNote1ForLoI = (e) => {
        const ifvNumber = e.target.value;
        let formattedDate = '';

        if (!CommonUtil.isEmpty(getValues('loiDate'))) {
            const originalDate = new Date(getValues('loiDate'));
            formattedDate = format(originalDate, 'MMMM d, yyyy');
        }
        setValues('note2Subnote1', `"The terms and conditions contained in the attached LoI bearing SIDBI: IFV: No. ${ifvNumber} dated ${formattedDate}, are hereby accepted.`);
    };

    const generateLoIReportWord = async () => {
        setLoading(true)
        try {
            const response = await MinutesService.generateLoIReportWord(selectedLoi.id);
            FileUtil.downloadWordFile(response);
            setLoading(false)
        } catch (error) {
            handleApiError(error, 'generating LoI');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Fragment>
            <div className={loading ? 'col-md-12 mint blur-background' : 'col-md-12 mint'}>
                <form onSubmit={handleSubmit(saveLoiDetails)}>
                    <div className="row mt-0">
                        <div className="col-md-12 p-0">
                            <div className="row no-prop alg_adst">
                                <div className="col-md-12">
                                    {selectedLoi?.id && (
                                        <Stack direction="row" spacing={2} justifyContent="flex-end">
                                            <Button
                                                variant="contained"
                                                color="primary"
                                                onClick={generateLOI}
                                                startIcon={<PictureAsPdf />}
                                                sx={{
                                                    textTransform: 'none',
                                                    borderRadius: 2,
                                                    boxShadow: 2,
                                                    '&:hover': {
                                                        boxShadow: 4,
                                                    },
                                                }}
                                            >
                                                Download as PDF
                                            </Button>
                                            <Button
                                                variant="contained"
                                                color="primary"
                                                onClick={generateLoIReportWord}
                                                startIcon={<Description />}
                                                sx={{
                                                    textTransform: 'none',
                                                    borderRadius: 2,
                                                    boxShadow: 2,
                                                    '&:hover': {
                                                        boxShadow: 4,
                                                    },
                                                }}
                                            >
                                                Download as Word
                                            </Button>
                                        </Stack>
                                    )}
                                </div>
                                <div className="col-md-12 pb-1 pt-3">
                                    <h5 className='HdngTitl mb-0'>LoI Details</h5>
                                    <Box sx={{ width: '100%', marginBottom: '2rem' }}>
                                        {Array.isArray(loiList) && loiList.length > 0 && (
                                            <Tabs
                                                value={value}
                                                onChange={handleTabChange}
                                                variant="scrollable"
                                                scrollButtons="auto"
                                                aria-label="loi tabs"
                                            >
                                                {loiList.map((loi, index) => (
                                                    <Tab
                                                        key={index}
                                                        label={`${loi.ifvName} / ${loi.schemeName}`}
                                                    />
                                                ))}
                                            </Tabs>
                                        )}
                                    </Box>
                                </div>
                                {selectedLoi && (
                                    <>
                                        <div className="col-md-6">
                                            <h2 className="heading">
                                                <strong>Scheme:</strong> {selectedLoi.schemeName}
                                            </h2>
                                        </div>
                                        <div className="col-md-6">
                                            <h2 className="heading">
                                                <strong>Amount:</strong> ₹{selectedLoi.amount} crore
                                            </h2>
                                        </div>
                                        <div className="col-md-6 mt-4">
                                            <div data-mdb-input-init className="form-outline">
                                                <label className="form-label">
                                                    <strong className='mndt'>LoI No <span className="color-red">*</span></strong>
                                                </label>
                                                <input
                                                    type="text"
                                                    className="form-control"
                                                    {...register('loiNo', {
                                                        required: "LoI No is required",
                                                    })}
                                                    onKeyUp={(e) => setSubNote1ForLoI(e)}
                                                    onChange={(e) => Pattern.sanitizeInput(e)}
                                                />
                                                {errors.loiNo && <span className='vldn'>{errors.loiNo.message}</span>}
                                            </div>
                                        </div>

                                        <div className="col-md-6 mt-4">
                                            <div data-mdb-input-init className="form-outline">
                                                <label className="form-label">
                                                    <strong className='mndt'>LoI Date <span className="color-red">*</span></strong>
                                                </label>
                                                <Controller
                                                    control={control}
                                                    name="loiDate"
                                                    rules={{
                                                        required: "Date is required",
                                                        validate: (value) => CommonUtil.validateDate(value),
                                                        onChange: (value) => setSubNote1(value)
                                                    }}
                                                    render={({ field }) => (
                                                        <ReactDatePicker
                                                            className="form-control"
                                                            onChange={field.onChange}
                                                            selected={field.value}
                                                            dateFormat="dd/MM/yyyy"
                                                            placeholderText="Select date"
                                                        />
                                                    )}
                                                />
                                                {errors.loiDate && <span className='vldn'>{errors.loiDate.message}</span>}
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                            <br />
                                            <div data-mdb-input-init className="form-outline">
                                                <label className="form-label" for="form3Example2"><strong>Address of Bank </strong></label>
                                                <textarea type="text" className="form-control" {...register('addressOfTheBank', {
                                                    required: "Field is required",
                                                })}
                                                    onChange={(e) => Pattern.sanitizeInput(e)}
                                                />
                                                <span className='vldn'>
                                                    {errors.addressOfTheBank && errors.addressOfTheBank.message}</span>
                                            </div>
                                        </div>


                                        <div className="col-md-12">
                                            <br />
                                            <div data-mdb-input-init className="form-outline">
                                                <input type="text" className="form-control" {...register('headerNote', {
                                                    required: "Field is required",
                                                })}
                                                    onChange={(e) => Pattern.sanitizeInput(e)}
                                                />
                                                <span className='vldn'>
                                                    {errors.headerNote && errors.headerNote.message}</span>
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                            <br />
                                            <div data-mdb-input-init className="form-outline">
                                                <label className="form-label" for="form3Example2"><strong>Note 1:</strong></label>
                                                <textarea type="text" className="form-control" {...register('note1', {
                                                    //  required: "Field is required",
                                                })} onChange={(e) => Pattern.sanitizeInput(e)} />
                                                <span className='vldn'>
                                                    {errors.note1 && errors.note1.message}</span>
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                            <br />
                                            <div data-mdb-input-init className="form-outline">
                                                <label className="form-label" for="form3Example2"><strong>Note 2:</strong></label>
                                                <textarea type="text" className="form-control" {...register('note2', {
                                                    //  required: "Field is required",
                                                })} onChange={(e) => Pattern.sanitizeInput(e)} />
                                                <span className='vldn'>
                                                    {errors.note2 && errors.note2.message}</span>
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                            <br />
                                            <div data-mdb-input-init className="form-outline">
                                                <span className="color-red"> Please keep this field data only if required. Otherwise, please remove the autofilled data.</span>
                                                <textarea type="text" className="form-control" {...register('note2Subnote1', {
                                                    // required: "Field is required",
                                                })} onChange={(e) => Pattern.sanitizeInput(e)} />
                                                <span className='vldn'>
                                                    {errors.note2Subnote1 && errors.note2Subnote1.message}</span>
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                            <br />
                                            <div data-mdb-input-init className="form-outline">
                                                <span className="color-red"> Please keep this field data only if required. Otherwise, please remove the autofilled data.</span>
                                                <textarea type="text" className="form-control" {...register('note2Subnote2', {
                                                    //  required: "Field is required",
                                                })} onChange={(e) => Pattern.sanitizeInput(e)} />
                                                <span className='vldn'>
                                                    {errors.note2Subnote2 && errors.note2Subnote2.message}</span>
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                            <br />
                                            <div data-mdb-input-init className="form-outline">
                                                <label className="form-label" for="form3Example2"><strong>Name of the document:</strong></label>
                                                <textarea type="text" className="form-control" {...register('nameOfDocuments', {
                                                    //  required: "Field is required",
                                                })} onChange={(e) => Pattern.sanitizeInput(e)} />
                                                <span className='vldn'>
                                                    {errors.nameOfDocuments && errors.nameOfDocuments.message}</span>
                                            </div>
                                        </div>
                                        <div className="col pt-4">
                                            <div data-mdb-input-init className="form-outline">
                                                <label className="form-label" for="form3Example2"><strong className='mndt'>Dated:</strong>
                                                </label>
                                                <Controller
                                                    control={control}
                                                    name='documentDated'
                                                    rules={{
                                                        validate: (value) => !CommonUtil.isEmpty(value) ? CommonUtil.validateDate(value) : true,
                                                    }}
                                                    render={({ field: { onChange, onBlur, value, ref } }) => (
                                                        <ReactDatePicker className="form-control"
                                                            onChange={onChange}
                                                            onBlur={onBlur}
                                                            selected={value}
                                                            dateFormat="dd/MM/yyyy"
                                                            placeholderText='Select date'
                                                        />
                                                    )}
                                                    {...register("documentDated")}
                                                /><span className='vldn'>
                                                    {errors.documentDated && errors.documentDated.message}</span>
                                            </div>
                                        </div>

                                        <div className="col pt-4">
                                            <div data-mdb-input-init className="form-outline">
                                                <label className="form-label" for="form3Example1"><strong className='mndt'>Section / Clause No. & Page Number:</strong>
                                                </label>
                                                <input type="text" className="form-control" {...register('sectionOrClauseNo', {
                                                    // required: "Field is required",
                                                })} onChange={(e) => Pattern.sanitizeInput(e)} />
                                                <span className='vldn'>
                                                    {errors.sectionOrClauseNo && errors.sectionOrClauseNo.message}</span>
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                            <br />
                                            <div data-mdb-input-init className="form-outline">
                                                <label className="form-label" for="form3Example2"><strong>Mode:</strong></label>
                                                <input type="text" className="form-control" {...register('sectionMode', {
                                                    //  required: "Field is required",
                                                })} onChange={(e) => Pattern.sanitizeInput(e)} />
                                                <span className='vldn'>
                                                    {errors.sectionMode && errors.sectionMode.message}</span>
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                            <br />
                                            <div data-mdb-input-init className="form-outline">
                                                <label className="form-label" for="form3Example2"><strong>The following KYC documents of authorized signatories are attached (Any one).</strong></label>
                                                <input type="text" className="form-control" {...register('kycDocuments', {
                                                    //  required: "Field is required",
                                                })} onChange={(e) => Pattern.sanitizeInput(e)} />
                                                <span className='vldn'>
                                                    {errors.kycDocuments && errors.kycDocuments.message}</span>
                                            </div>
                                        </div>

                                        <div className="col-md-12">
                                            <br />
                                            <div data-mdb-input-init className="form-outline">
                                                <label className="form-label" for="form3Example2"><strong>Note 3:</strong></label>
                                                <textarea type="text" className="form-control" {...register('note3', {
                                                    //  required: "Field is required",
                                                })} onChange={(e) => Pattern.sanitizeInput(e)} />
                                                <span className='vldn'>
                                                    {errors.note3 && errors.note3.message}</span>
                                            </div>
                                        </div>

                                        <div className="col-md-6">
                                            <br />
                                            <div data-mdb-input-init className="form-outline">
                                                <label className="form-label" htmlFor="form3Example2"><strong>User:<span className="color-red">*</span></strong></label>
                                                <select
                                                    className="form-select"
                                                    onChange={(e) => handleUserChange(e.target.value)}
                                                    value={selectedUser?.ofrCode || ''}
                                                >
                                                    <option value=''>Please select user</option>
                                                    {checkerList.map((item) => (
                                                        <option key={item.ofrCode} value={item.ofrCode}>
                                                            {item.ofrName}
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>
                                        </div>
                                    </>
                                )}
                            </div>
                        </div>

                        <div className="button-container-center">
                            <button type='button' className='btn btnPrev' onClick={() => navigate(-1)}>Go Back</button>
                            <button type='submit' className='btn btnSave'>
                                {selectedLoi?.id ? 'Update' : 'Save'} <i className="fa fa-circle-check"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div >

            {loading && <Loading />}
            <MessageModal
                open={isOpen}
                onClose={hideMessage}
                message={messageConfig.message}
                type={messageConfig.type}
                totalMessages={totalMessages}
                currentIndex={currentIndex}
                onNext={nextMessage}
                onPrev={prevMessage}
                hasNext={hasNext}
                hasPrev={hasPrev}
            />
        </Fragment >
    );
};

export default GenerateLoIFromProposal;