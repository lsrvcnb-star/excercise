import {
    Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TablePagination,
    TableRow
} from '@mui/material';
import Loading from 'components/Loading';
import { Fragment, useEffect, useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import ReactDatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { Controller, useForm } from "react-hook-form";
import Select from 'react-select';
import IfvAppraisalService from 'services/IfvAppraisalService';
import MasterService from 'services/MasterService';
import CommonUtil from 'services/utils/CommonUtil';

const FileButton = ({ fileName, onClick }) => {
    return (
        <button onClick={() => onClick(fileName)}>
            {fileName}
        </button>
    );
};


const PoaSignatureCard = () => {
    const { control: control1, register: register1, handleSubmit: handleSubmitOfPoa, setValue: setValue1, getValues: getValues1, reset: reset1, formState: { errors: errors1 } } = useForm({
        mode: "onBlur"
    });

    const [loading, setLoading] = useState(false)
    const [showMsg, setShowMsg] = useState(false)
    const [message, setMessage] = useState('')
    const [modalShow, setModalShow] = useState(false);
    const hideMsg = () => setShowMsg(false);

    const [data, setData] = useState([]);
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(5);

    useEffect(() => {
        getAllBankNames()
    }, []);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };
    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const getAllBankNames = () => {
        MasterService.getAllBcmCif().then(
            (response) => {
                setLoading(false)
                const formattedOptions = response.data.map((item) => ({
                    value: item.customerCode,
                    label: item.customerLongName,
                }))

                getAllPoaSignatureCards(formattedOptions)
            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();
                setLoading(false)
                setMessage('Error occured while loading applications: ' + resMessage)
                setShowMsg(true)
            }
        );
    }

    // const [createdBanks,setCreatedBanks] = useState([])

    const getAllPoaSignatureCards = (formattedOptions) => {
        setLoading(true)
        IfvAppraisalService.getAllPoaSignatureCards().then(
            (response) => {
                setData(response.data)

                let createdBanks = []

                response.data.forEach((item, index) => {
                    createdBanks.push(item.bankName)
                })

                const newFormattedOptions = formattedOptions.filter((item) => !createdBanks.includes(item.label))

                setOptions(newFormattedOptions)
                setFilteredOptions(newFormattedOptions)

                setLoading(false)
            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();
                setLoading(false)
                setMessage('Error occured while loading poa/signature details: ' + resMessage)
                setShowMsg(true)
            }
        );
    }

    const onSubmitOfPoa = (data, e) => {
        setLoading(true)
        const formData = new FormData();

        for (const key of Object.keys(selectedFiles)) {
            formData.append('files', selectedFiles[key]);

        }
        formData.append('data', JSON.stringify(data))

        if(!enable) {
            IfvAppraisalService.savePoaSignatureCards(formData).then(
                (response) => {
                    setMessage('Poa/Signature details have been successfully created!')
                    setShowMsg(true)
                    getAllPoaSignatureCards(options)
                    editDetails(response.data.cifNumber, response.data.bankName)
                    setLoading(false)
                },
                (error) => {
                    const resMessage =
                        (error.response &&
                            error.response.data &&
                            error.response.data.message) ||
                        error.message ||
                        error.toString();
                    setLoading(false)
                    setMessage('Error occured while creating poa/signature: ' + resMessage)
                    setShowMsg(true)
                }
            );
        } else {
            IfvAppraisalService.updatePoaSignatureCards(formData).then(
                (response) => {
                    setMessage('Poa/Signature details have been successfully updated!')
                    setShowMsg(true)
                    getAllPoaSignatureCards(options)
                    editDetails(response.data.cifNumber, response.data.bankName)
                    setLoading(false)
                },
                (error) => {
                    const resMessage =
                        (error.response &&
                            error.response.data &&
                            error.response.data.message) ||
                        error.message ||
                        error.toString();
                    setLoading(false)
                    setMessage('Error occured while updating poa/signature: ' + resMessage)
                    setShowMsg(true)
                }
            );
        }
    }

    const [selectedOption, setSelectedOption] = useState(null)
    const [filteredOptions, setFilteredOptions] = useState([])
    const [options, setOptions] = useState([])

    const handleSearch = (inputValue) => {
        if (inputValue === "") { setFilteredOptions(options); return; }
        const filteredOptions = options.filter((option) =>
            option.label.toLowerCase().includes(inputValue.toLowerCase())
        );

        setFilteredOptions(filteredOptions);
    };

    const [enable, setEnable] = useState(true)

    const clearAndOpenModal = (id) => {
        reset1()
        setSelectedOption(null)
        setExistingFiles([])

        if (id > 0) {
            setEnable(true)

        } else {
            setEnable(false)
        }

        setModalShow(true)
    }

    const [selectedFiles, setSelectedFiles] = useState([]);
    const handleFileChange = (e) => {
        setLoading(true)
        setSelectedFiles(e.target.files);
        setLoading(false)
    };
    const handleRemoveFile = (fileName) => {
        const updatedFiles = selectedFiles.filter(file => file.name !== fileName);
        setSelectedFiles(updatedFiles);
    };

    const [existingFiles, setExistingFiles] = useState([])

    const getPoaSignatureCardsOnCifNumber = (cifNumber) => {
        setLoading(true)
        IfvAppraisalService.getPoaSignatureCardsOnCifNumber(cifNumber).then(
            (response) => {
                response.data.forEach((item, index) => {
                    setValue1('id', item.id)
                    setValue1('startDate', new Date(item.startDate))
                    setValue1('endDate', new Date(item.endDate))
                    setExistingFiles(prevState => ({ ...prevState, [item.id]: item.fileName }))
                });

                setLoading(false)
            },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();
                setLoading(false)
                setMessage('Error occured while loading poa/signature details: ' + resMessage)
                setShowMsg(true)
            }
        );
    }

    const onchangeOfBankeName = (selected) => {
        setExistingFiles([])
        setSelectedOption(selected)
        setValue1('bankName', selected.label)
        setValue1('cifNumber', selected.value)
        setValue1('id', '')
        setValue1('startDate', '')
        setValue1('endDate', '')
        getPoaSignatureCardsOnCifNumber(selected.value)
    }

    const editDetails = (cifNumber, bankName) => {

        setExistingFiles([])
        const selOption = {
            label: bankName,
            value: cifNumber
        }
        setSelectedOption(selOption)
        setValue1('bankName', bankName)
        setValue1('cifNumber', cifNumber)
        setValue1('id', '')
        setValue1('startDate', '')
        setValue1('endDate', '')
        getPoaSignatureCardsOnCifNumber(cifNumber)
        setEnable(true)
        setModalShow(true)
    }

    const deleteFile = (id) => {
        IfvAppraisalService.deleteFile(id).then((response) => {
            getAllBankNames()
            setMessage('Poa/signature detail deleted successfully!')
            setShowMsg(true)
            setModalShow(false)
        },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                setMessage('Error occured while deleting poa/signature: ' + resMessage)
                setShowMsg(true)
            }
        )
    }

    const base64ToArrayBuffer = (base64) => {
        const binaryString = window.atob(base64);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return bytes;
    };

    const viewFile = (id) => {
        IfvAppraisalService.viewFile(id).then((response) => {

            const byteArray = base64ToArrayBuffer(response.data.file);

            const blob = new Blob([byteArray], { type: 'application/pdf' });
            const url = URL.createObjectURL(blob);

            const newWindow = window.open('', response.data.fileName, 'width=650,height=700');
            const iframe = document.createElement('iframe');
            iframe.src = url;
            iframe.title = response.data.fileName;
            iframe.style.width = '100%';
            iframe.style.height = '100%';
            newWindow.document.body.appendChild(iframe);

        },
            (error) => {
                const resMessage =
                    (error.response &&
                        error.response.data &&
                        error.response.data.message) ||
                    error.message ||
                    error.toString();

                setMessage('Error occured while deleting poa/signature: ' + resMessage)
                setShowMsg(true)
            }
        )
    }

    return (
        <Fragment>
            <div className={loading ? 'frgmnt blur-background' : 'frgmnt'}></div>
            <TableContainer component={Paper}>
                <Table>
                    <TableHead className='tbl_nrsn'>
                        <TableRow>
                            <TableCell><strong>Bank Name</strong></TableCell>
                            <TableCell><strong>CIF Number</strong></TableCell>
                            <TableCell><strong>Start Date</strong></TableCell>
                            <TableCell><strong>End Date</strong></TableCell>
                            <TableCell><strong>Existing files</strong></TableCell>
                            <TableCell>&nbsp;</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {(rowsPerPage > 0
                            ? data.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            : data
                        ).map((row) => (
                            <TableRow key={row.id}>
                                <TableCell>{row.bankName}</TableCell>
                                <TableCell>{row.cifNumber}</TableCell>
                                <TableCell>{CommonUtil.formatDate(row.startDate)}</TableCell>
                                <TableCell>{CommonUtil.formatDate(row.endDate)}</TableCell>
                                <TableCell>{row.fileNames.map((val, i) => (
                                    <p>{i + 1}: {val}</p>
                                ))}</TableCell>
                                <TableCell>
                                    <Button className='editBtn' onClick={() => editDetails(row.cifNumber, row.bankName)}><i className="fa fa-edit "></i> &nbsp; Edit</Button>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                component="div"
                count={data.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />

            <div className="button-container-center">
                <button type='button' onClick={() => clearAndOpenModal(0)} className='save btn btnSave crtnw'>Create New <i className="fa fa-pencil-square"></i></button>
            </div>


            <Modal show={modalShow}
                onHide={() => setModalShow(false)}
                className={loading ? 'blur-background' : ''}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Poa/Signature Cards
                    </Modal.Title>
                </Modal.Header>
                <form key={1} onSubmit={handleSubmitOfPoa(onSubmitOfPoa)}>
                    <Modal.Body>

                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <label> <strong>Bank Name</strong></label>

                                    <Select
                                        value={selectedOption}
                                        onChange={(selected) => onchangeOfBankeName(selected)}
                                        options={filteredOptions}
                                        onInputChange={handleSearch}
                                        isSearchable
                                        isDisabled={enable}
                                    />
                                    <input type='hidden' {...register1('bankName')} />
                                    <input type='hidden' {...register1('id')} />
                                </div>
                            </div>

                            <div className="col-md-6">
                                <div className="form-group">
                                    <label> <strong>Cif Number</strong></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        required readOnly
                                        value={selectedOption?.value}
                                        {...register1('cifNumber')}
                                    />
                                </div>
                            </div>

                        </div>

                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <label> <strong>Start Date</strong></label>
                                    <Controller
                                        control={control1}
                                        name='startDate'
                                        rules={{
                                            required: {
                                                value: true,
                                                message: "Date is required",
                                            },
                                        }}
                                        render={({ field: { onChange, onBlur, value, ref } }) => (
                                            <ReactDatePicker className="form-control"
                                                placeholderText='Select start date'
                                                onChange={onChange}
                                                onBlur={onBlur}
                                                selected={value}
                                                dateFormat="dd/MM/yyyy"
                                            />
                                        )}
                                        {...register1("startDate")}
                                    />
                                </div>
                            </div>


                            <div className="col-md-6">
                                <div className="form-group">
                                    <label> <strong>End Date</strong></label>
                                    <Controller
                                        control={control1}
                                        name='endDate'
                                        rules={{
                                            required: {
                                                value: true,
                                                message: "Date is required",
                                            },
                                        }}
                                        render={({ field: { onChange, onBlur, value, ref } }) => (
                                            <ReactDatePicker className="form-control"
                                                placeholderText='Select end date'
                                                onChange={onChange}
                                                onBlur={onBlur}
                                                selected={value}
                                                dateFormat="dd/MM/yyyy"
                                            />
                                        )}
                                        {...register1("endDate")}
                                    />
                                </div>
                            </div>

                        </div>

                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <label> <strong>Existing Documents</strong></label>


                                    <div style={{ display: 'flex', flexWrap: 'wrap' }}>
                                        {Object.keys(existingFiles).map(k => (
                                            <div key={k} style={{ flexBasis: '50%', padding: '10px', position: 'relative' }}>
                                                <div style={{ border: '1px solid black', padding: '10px', marginBottom: '10px', position: 'relative', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                                    <i className="fa fa-file-text" onClick={() => { viewFile(k) }} style={{ fontSize: '50px', marginBottom: '5px',cursor: 'pointer' }}></i>
                                                    <div>{existingFiles[k]}</div>
                                                    <button type='button'
                                                        style={{ marginTop: '10px', background: 'none', border: 'none', cursor: 'pointer' }}
                                                        onClick={() => deleteFile(k)}
                                                    >
                                                        <i className="fa fa-times" style={{ color: 'red' }}></i>
                                                    </button>
                                                </div>
                                            </div>

                                        ))}
                                    </div>

                                    {/* {Object.keys(existingFiles).map(key => (
                                        <div key={key}>
                                            <p> <i className="fa fa-file-text-o" aria-hidden="true"
                                               ></i>  {existingFiles[key]}</p>
                                            <i className="fa fa-trash" aria-hidden="true"
                                                onClick={() => deleteFile(key)}></i>
                                        </div>
                                    ))} */}
                                </div>
                            </div>

                            <div className="col-md-6">
                                <div className="form-group">
                                    <label> <strong>Upload New</strong></label>
                                    {/* <input type='file' onChange={(e) => handleFileChange(e)} /> */}
                                    <input type="file" accept=".pdf" name='file' onChange={handleFileChange} multiple />
                                </div>
                            </div>

                        </div>

                    </Modal.Body>
                    <Modal.Footer>
                        <div className="button-container-center">
                            <button type='submit' className='save btn btnSave'>{!enable ? 'Save' : 'Update'} <i className="fa fa-circle-check"></i></button>
                        </div>
                    </Modal.Footer>
                </form>
            </Modal>

            <Modal style={{ marginTop: "200px" }} show={showMsg} onHide={hideMsg}>

                <Modal.Body >
                    <div className="conatiner text-center">
                        <div className="row">
                            <div className="col-sm-12">
                            <h5 className= {message.includes('Error')? 'alertMsg':'loadMsg'}>{message}</h5>
                                {/* <h5 className="loadMsg">{message}</h5> */}
                            </div>
                        </div>
                    </div>
                  
                    <div className="row text-center">
                        <div className="col-sm-12 text-center">
                            <button type="button" className=" btn  btnRegister  themebutton" onClick={hideMsg}>OK</button>
                        </div>
                    </div>

                </Modal.Body>
            </Modal>
            {loading && <Loading />}

        </Fragment >
    )
}
export default PoaSignatureCard;