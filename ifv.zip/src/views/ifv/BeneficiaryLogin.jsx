import RefreshIcon from "@mui/icons-material/Refresh";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import backgroundImg from "assets/img/ifv-login-bck.png";

import {
  Alert,
  Box,
  Button,
  CircularProgress,
  IconButton,
  InputAdornment,
  Paper,
  Snackbar,
  Stack,
  TextField,
  Typography,
} from "@mui/material";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import IfvAppraisalService from "services/IfvAppraisalService";
import { generateCaptchaImage } from "services/utils/CaptchaUtils";
import CommonUtil from "services/utils/CommonUtil";

export default function BeneficiaryLogin() {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [captchaImage, setCaptchaImage] = useState("");
  const [encryptedCaptcha, setEncryptedCaptcha] = useState("");
  const [environment, setEnvironment] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [openError, setOpenError] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    mode: "onSubmit",
    defaultValues: {
      username: "",
      password: "",
      captcha: "",
    },
  });

  useEffect(() => {
    const env = process.env.REACT_APP_ENV;
    const envMessages = {
      dev: "This is Local Environment",
      prod: "Production Environment",
      uat: "UAT - Do not process live proposals",
    };
    setEnvironment(envMessages[env] || "");
    getCaptcha();
  }, []);

  const getCaptcha = async () => {
    try {
      const response = await IfvAppraisalService.getCaptcha();
      setEncryptedCaptcha(response.data.encryptedCaptcha);
      setCaptchaImage(generateCaptchaImage(response.data.captcha));
    } catch (error) {
      showError(error.response?.data?.message || "Failed to load CAPTCHA");
    }
  };

  /* ---------- SUBMIT ---------- */
  const onSubmit = async (data) => {
    try {
      setLoading(true);

      const encryptedUsername =
        await CommonUtil.encryptPassword(data.username);
      const encryptedPassword =
        await CommonUtil.encryptPassword(data.password);

      const requestBody = {
        userName: encryptedUsername,
        password: encryptedPassword,
        captcha: data.captcha,
        encryptedCaptcha: encryptedCaptcha,
      };

      const response =
        await IfvAppraisalService.beneficiaryLogin(requestBody);

      if (response?.data?.jwttoken) {
        sessionStorage.clear();
        sessionStorage.setItem("jwtToken", response.data.jwttoken);
        sessionStorage.setItem("user", JSON.stringify(response.data.data));
        navigate("/ifv/beneficiaryInfo");
      } else {
        showError(response.data?.message || "Login failed");
        getCaptcha();
      }
    } catch (error) {
      console.log(error);
      showError(
        error.response?.data?.message || "Something went wrong"
      );
      getCaptcha();
    } finally {
      setLoading(false);
    }
  };

  const showError = (msg) => {
    setErrorMsg(msg);
    setOpenError(true);
  };

  return (
    <Box
      sx={{
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        backgroundImage: `url(${backgroundImg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
      }}
    >
      <Paper
        elevation={10}
        sx={{
          p: 4,
          width: 400,
          borderRadius: 3,
          background: "rgba(255,255,255,0.85)",
          backdropFilter: "blur(8px)",
        }}
      >
        <Typography
          variant="h5"
          fontWeight="bold"
          textAlign="center"
          gutterBottom
        >
          Bank Login
        </Typography>

        <Typography
          variant="body2"
          textAlign="center"
          color="text.secondary"
          mb={3}
        >
          Secure access to IFV Portal
        </Typography>

        <form onSubmit={handleSubmit(onSubmit)}>
          <Stack spacing={2}>
            {/* Username */}
            <TextField
              label="User Name"
              fullWidth
              autoComplete="username"
              error={!!errors.username}
              helperText={errors.username?.message}
              {...register("username", {
                required: "User Name is required",
                minLength: {
                  value: 3,
                  message: "Minimum length is 3",
                },
              })}
            />

            {/* Password */}
            <TextField
              label="Password"
              type={showPassword ? "text" : "password"}
              fullWidth
              autoComplete="current-password"
              error={!!errors.password}
              helperText={errors.password?.message}
              {...register("password", {
                required: "Password is required",
                minLength: {
                  value: 5,
                  message: "Minimum length is 5",
                },
              })}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      onClick={() =>
                        setShowPassword(!showPassword)
                      }
                    >
                      {showPassword ? (
                        <VisibilityOff />
                      ) : (
                        <Visibility />
                      )}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />

            {/* CAPTCHA */}
            <Box>
              <Typography variant="body2" fontWeight={500} mb={1}>
                CAPTCHA
              </Typography>

              <Stack direction="row" spacing={1} alignItems="center" mb={1}>
                {captchaImage && (
                  <Box
                    component="img"
                    src={captchaImage}
                    sx={{
                      height: 40,
                      width: 120,
                      borderRadius: 1,
                      border: "1px solid #ddd",
                    }}
                  />
                )}

                <IconButton size="small" onClick={getCaptcha}>
                  <RefreshIcon />
                </IconButton>
              </Stack>

              <TextField
                placeholder="Enter CAPTCHA"
                fullWidth
                inputProps={{ maxLength: 4 }}
                error={!!errors.captcha}
                helperText={errors.captcha?.message}
                {...register("captcha", {
                  required: "CAPTCHA is required",
                })}
              />
            </Box>

            {/* Submit */}
            <Button
              type="submit"
              variant="contained"
              size="large"
              fullWidth
              disabled={loading}
              sx={{ height: 45 }}
            >
              {loading ? (
                <CircularProgress size={24} sx={{ color: "#fff" }} />
              ) : (
                "Sign In"
              )}
            </Button>

            {environment && (
              <Typography
                variant="caption"
                color="error"
                textAlign="center"
              >
                {environment}
              </Typography>
            )}
          </Stack>
        </form>
      </Paper>

      {/* Error Snackbar */}
      <Snackbar
        open={openError}
        autoHideDuration={4000}
        onClose={() => setOpenError(false)}
        anchorOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
      >
        <Alert
          severity="error"
          variant="filled"
          onClose={() => setOpenError(false)}
        >
          {errorMsg}
        </Alert>
      </Snackbar>
    </Box>
  );
}