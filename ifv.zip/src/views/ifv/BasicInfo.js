import { LinearProgress } from "@mui/material";
import Loading from "components/Loading";
import MessageModal from "components/MessageModal";
import ProposalHeader from "components/ProposalHeader";
import SectionNavigation from "components/SectionNavigation";
import { formatDate, useAggregateExposure } from "hooks/useAggregateExposure";
import { useErrorHandler } from "hooks/useErrorHandler";
import useMessageModal from "hooks/useMessageModal";
import { Fragment, useEffect, useState } from "react";
import ReactDatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Controller, useFieldArray, useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
import { getAggregateExposureData } from "services/aggregateExposureApi";
import { PrincipalRepayment } from "services/constants/PrincipalRepayment";
import IfvAppraisalService from "services/IfvAppraisalService";
import MasterService from "services/MasterService";
import UserService from "services/UserService";
import CommonUtil from "services/utils/CommonUtil";
import Pattern from "services/validators/Pattern";

const defaultAggregateExposure = [
  {
    slNo: 1,
    particulars:
      "Applicable category wise Exposure (as on date) - Eg. Exposure cap applicable for D-SIB category is 900% of SIDBI’s capital funds",
    amount: "",
  },
  {
    slNo: 2,
    particulars:
      "Aggregate Exposure to Category (as on date) - Eg. Aggregate exposure to D-SIB category is ₹ ___ Crore",
    amount: "",
  },
  {
    slNo: 3,
    particulars: "Proposed Sanction Amount",
    amount: "",
  },
  {
    slNo: 4,
    particulars: "Aggregate Category Exposure (with proposed sanction) (2 + 3)",
    amount: "",
  },
  {
    slNo: 5,
    particulars: "% Utilisation of Category Cap (Post-sanction) - SIDBI Solo",
    amount: "",
  },
];

const BasicInfo = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const fromAcceptedApplications = location.state?.fromAcceptedApplications ?? false;

  const selectedApp = location.state?.data ?? null;

  const [bankName, setBankName] = useState(fromAcceptedApplications ? location.state?.bankName ?? "" : selectedApp?.label ?? "");

  const [custId, setCustId] = useState(fromAcceptedApplications? location.state?.cifNumber ?? "" : selectedApp?.value ?? "");
 
  const [appRefNos, setAppRefNos] = useState(fromAcceptedApplications? location.state?.appRefNos ?? [] : []);

  const [appId, setAppId] = useState(location.state ? location.state.appId : 0);
  const {
    control,
    register,
    handleSubmit,
    watch,
    setValue,
    getValues,
    formState: { errors },
  } = useForm({
    mode: "onBlur",
  });

  const {
    fields: fields1,
    append: append1,
    remove: remove1,
  } = useFieldArray({
    control,
    name: "proposedSchemaDTOs",
  });

  const {
    fields: fields2,
    append: append2,
    remove: remove2,
  } = useFieldArray({
    control,
    name: "assistanceAppliedFor",
  });

  const {
    fields: fields3,
    append: append3,
    remove: remove3,
    error: errors3,
  } = useFieldArray({
    control,
    name: "aggregateExposure",
  });

  const [loading, setLoading] = useState(false);
  const {
    showMessage,
    hideMessage,
    isOpen,
    messageConfig,
    totalMessages,
    currentIndex,
    nextMessage,
    prevMessage,
    hasNext,
    hasPrev,
  } = useMessageModal();
  const { handleApiError } = useErrorHandler(showMessage);
  const [appStatus, setAppStatus] = useState("New");
  const [selectedFundCode, setSelectedFundCode] = useState([]);
  const [selectedFundCodeForAssist, setSelectedFundCodeForAssist] = useState(
    []
  );
  const [obj, setObj] = useState({});
  const [showSFB, setShowSFB] = useState(false);
  const onError = (errors, e) => console.log(errors, e);
  const [totalExposure, setTotalExposure] = useState(0);
  const [funds, setFunds] = useState([]);
  const [existingOs, setExistingOs] = useState();
  const [exposureLimit, setExposureLimit] = useState();
  const [locked, setLocked] = useState(false);
  const [isMaker, setMaker] = useState(false);
  const [fundCodeAndFundName, setFundCodeAndFundName] = useState([]);
  const [schemeNameAndSchemeCode, setSchemeNameAndSchemeCode] = useState([]);
  const [benchmarkList, setBenchmarkList] = useState([]);

  //Page Loding starts here
  // Fetch user roles
  const setupUserRoles = () => {
    const user = IfvAppraisalService.getCurrentUser();
    setMaker(UserService.isMaker(user));
  };

  // Fetch customer OS details
  const fetchCustOs = async () => {
    try {
      const response = await MasterService.getCustOs(custId);
      if (response.data.length <= 0) {
        showMessage("Empty data received for Existing O/S from MIS", "warning");
        return;
      }
      response.data.forEach((item) => {
        showMessage(`Existing O/S from MIS: ${item.custOs}`, "info");
        handleTotalExposure("ifvExistingOs", item.custOs);
        setExistingOs(item.custOs);
      });
    } catch (error) {
      handleApiError(error, "loading Existing O/S");
    }
  };

  // Fetch exposure limit
  const fetchExposureLimit = async () => {
    try {
      const response = await MasterService.getExposureLimit(custId);
      setExposureLimit(response.data);
      setValue("ifvExposureLimit", response.data);
      if (CommonUtil.isEmpty(response.data)) {
        showMessage("Exposure Limit from MIS is empty", "warning");
      } else {
        showMessage(`Exposure Limit from MIS: ${response.data}`, "info");
      }
    } catch (error) {
      handleApiError(error, "loading Exposure Limit");
    }
  };
  // Fetch TBL FWD details
  const fetchTblFwdDetail = async (showAssistance) => {
    try {
      if (!CommonUtil.isEmpty(appId)) {
        const response = await IfvAppraisalService.getTblFwdDetail(appId);
        const statusMap = {
          LK: { status: "Locked", locked: true },
          NW: { status: "New", locked: false },
          CN: { status: "Confirmed", locked: false },
          AP: { status: "Approved", locked: false },
        };
        const currentStatus = statusMap[response.data.appStatus] || {
          status: "New",
          locked: false,
        };
        setLocked(currentStatus.locked);
        setAppStatus(currentStatus.status);
      } else {
        setLocked(false);
        setAppStatus("New");
      }
      // if (showAssistance) {
      //   setNewAssistanceApp(true)
      //   append2({})
      // }
    } catch (error) {
      handleApiError(error, "loading TBL FWD details");
    }
  };

  // Fetch application details
  const fetchApplication = async (id) => {
    try {
      const response = await IfvAppraisalService.getIfvAppById(id);
      setApplication(response);
    } catch (error) {
      handleApiError(error, "loading IFV application");
    }
  };
  // Fetch application by CIF number
  const fetchApplicationByCifNo = async () => {
    try {

      const payload = {
        cifNumber:custId,
        appRefIds: fromAcceptedApplications? appRefNos: [],
      }

      const response = await IfvAppraisalService.loadProposalData(payload);
      if (!CommonUtil.isEmpty(response.data.cifNumber)) {
        setApplication(response);
      } else {
        append1({});
        append2({});
      }
    } catch (error) {
      handleApiError(error, "loading IFV application");
    }
  };
  // Fetch master data (funds and schemes)
  const fetchMasterData = async () => {
    try {
      const fundsResponse = await MasterService.getAllFundCode();
      setFunds(fundsResponse.data);
      const fundCodeMap = {};
      fundsResponse.data.forEach((item) => {
        fundCodeMap[item.fundCode] = item.fundDescription;
      });
      setFundCodeAndFundName(fundCodeMap);
      const schemesResponse = await MasterService.getAllSchemes();
      const schemeMap = {};
      schemesResponse.data.forEach((item) => {
        schemeMap[item.longName] = item.slchCode;
      });
      setSchemeNameAndSchemeCode(schemeMap);
    } catch (error) {
      handleApiError(error, "loading master data");
    }
  };

  const getBenchmarkDetails = async () => {
    try {
      const response = await MasterService.getBenchmarkDetails();
      setBenchmarkList(response.data);
    } catch (error) {
      handleApiError(error, "loading BenchMark details");
    }
  };

  // Main initialization effect
  useEffect(() => {
    const initializeData = async () => {
      setLoading(true);
      try {
        await getBenchmarkDetails();
        setupUserRoles();
        await fetchMasterData();
        if (!isNaN(appId) && appId > 0) {
          await fetchApplication(appId);
          //  await fetchTblFwdDetail();
        } else {
          await fetchApplicationByCifNo();
          await fetchCustOs();
          await fetchExposureLimit();
          setNewAssistanceApp(true);
        }
      } catch (error) {
        handleApiError(error, "initializing data");
      } finally {
        setLoading(false);
      }
    };
    initializeData();
  }, []);

  //Page Loding ends here..

  const [newAssistanceApp, setNewAssistanceApp] = useState(false);

  const setApplication = (response) => {
    const appData = response.data;
    setObj(appData);
    if (appData.sfb === "Y") {
      setShowSFB(true);
    } else {
      setShowSFB(false);
    }
    setCustId(appData.cifNumber);

    setBankName(appData.ifvName);
    setValue("ifvAssistance", appData.ifvAssistance);
    inputHandler(appData.ifvAssistance, "assApp");

    setValue("ifvBackground", appData.ifvBackground);
    if (!CommonUtil.isEmpty(appData.ifvBackground)) {
      inputHandler(appData.ifvBackground, "ifvBackground");
    }

    setValue("ifvAmount", appData.ifvAmount);
    setValue("ifvRoi", appData.ifvRoi);
    setValue("ifvTenure", appData.ifvTenure);
    setValue("ifvPrRepayment", appData.ifvPrRepayment);
    setValue("ifvSchemeName", appData.ifvSchemeName);

    let extOs = CommonUtil.isValidNumber(appData.ifvExistingOs)
      ? appData.ifvExistingOs
      : 0;
    let propExp = CommonUtil.isValidNumber(appData.ifvPropExposure)
      ? appData.ifvPropExposure
      : 0;
    let undSanc = CommonUtil.isValidNumber(appData.ifvUndisbursedSanction)
      ? appData.ifvUndisbursedSanction
      : 0;

    const tot = extOs + propExp + undSanc;
    setTotalExposure(CommonUtil.dynamicTotal(tot));
    setValue("ifvTotalExposure", CommonUtil.formatAmount(tot));

    if (appData.ifvExposureLimit != null) {
      setValue("ifvExposureLimit", appData.ifvExposureLimit);
    }
    if (appData.ifvExistingOs != null) {
      setValue("ifvExistingOs", appData.ifvExistingOs);
    }
    if (appData.ifvPropExposure != null) {
      setValue("ifvPropExposure", appData.ifvPropExposure);
    }

    if (appData.ifvUndisbursedSanction != null) {
      setValue("ifvUndisbursedSanction", appData.ifvUndisbursedSanction);
    }

    setValue("ifvRepaymentDate", new Date(appData.ifvRepaymentDate));
    setValue("ifvExternalRating", appData.ifvExternalRating);
    inputHandler(appData.ifvExternalRating, "extRating");
    setValue("ifvEws", appData.ifvEws);
    inputHandler(appData.ifvEws, "ews");
    setValue("ifvAdverseNews", appData.ifvAdverseNews);
    inputHandler(appData.ifvAdverseNews, "advNews");
    setValue("ifvMonetary", appData.ifvMonetary);
    inputHandler(appData.ifvMonetary, "monPen");

    if (appData.internalRating != null) {
      setValue("internalRating", appData.internalRating);
      inputHandler(appData.internalRating, "intRating");
    }

    if (appData.ifvRemarks != null) {
      setValue("ifvRemarks", appData.ifvRemarks);
      inputHandler(appData.ifvRemarks, "ifvRemarks");
    }

    if (appData.ifvExpRemarks != null) {
      setValue("ifvExpRemarks", appData.ifvExpRemarks);
      inputHandler(appData.ifvExpRemarks, "ifvExpRemarks");
    }

    if (appData.otherRemarks != null) {
      setValue("otherRemarks", appData.otherRemarks);
      inputHandler(appData.otherRemarks, "othRem");
    }

    let sum = 0;

    if (appData.proposedSchemaDTOs.length == 0) {
      append1({});
    }

    appData.proposedSchemaDTOs.forEach((item, index) => {
      remove1(index);
      append1({});
      validateFundCode(item.prFundcode, index);
      setSelectedScheme((prev) => ({ ...prev, [index]: item.prSchemeName }));
      setSelectedFundCode((prev) => ({ ...prev, [index]: item.prFundcode }));
      setValue(`proposedSchemaDTOs[${index}].prId`, item.prId);
      setValue(`proposedSchemaDTOs[${index}].ifvId`, item.ifvId);
      setValue(`proposedSchemaDTOs[${index}].prSchemeName`, item.prSchemeName);
      setValue(`proposedSchemaDTOs[${index}].prSchemecode`, item.prSchemecode);
      setValue(`proposedSchemaDTOs[${index}].prFundname`, item.prFundname);
      setValue(`proposedSchemaDTOs[${index}].prFundcode`, item.prFundcode);

      let objPrAmount;

      if (!CommonUtil.isEmpty(item.prAmount)) {
        objPrAmount = CommonUtil.formatAmount(item.prAmount);
        sum = parseFloat(sum) + parseFloat(objPrAmount);
        setAmountInRs((prev) => ({
          ...prev,
          [index]: CommonUtil.convertToIndianRupees(objPrAmount),
        }));
      } else {
        objPrAmount = item.prAmount;
      }
      setValue(`proposedSchemaDTOs[${index}].prAmount`, objPrAmount);

      let objPrRoI = "";

      if (!CommonUtil.isEmpty(item.prRoi)) {
        objPrRoI = parseFloat(item.prRoi).toFixed(2);
      }

      setValue(`proposedSchemaDTOs[${index}].prRoi`, objPrRoI);
      setValue(`proposedSchemaDTOs[${index}].interestType`, item.interestType);
      setValue(`proposedSchemaDTOs[${index}].prTenure`, item.prTenure);
      setValue(
        `proposedSchemaDTOs[${index}].prPrincipalRepayment`,
        item.prPrincipalRepayment
      );
      if (item.prMaturityDate != null) {
        setValue(
          `proposedSchemaDTOs[${index}].prMaturityDate`,
          new Date(item.prMaturityDate)
        );
        setAeDates((prevState) => ({
          ...prevState,
          [index]: new Date(item.prMaturityDate),
        }));
      }

      setValue(`proposedSchemaDTOs[${index}].benchMark`, item.benchMark);
      setValue(`proposedSchemaDTOs[${index}].spread`, item.spread);
      setValue(
        `proposedSchemaDTOs[${index}].interestReset`,
        item.interestReset
      );
      setValue(`proposedSchemaDTOs[${index}].roiNote`, item.roiNote);

      setValue(
        `proposedSchemaDTOs[${index}].incrementalCostBorrowing`,
        item.incrementalCostBorrowing
      );
      setValue(
        `proposedSchemaDTOs[${index}].dealwiseAverage`,
        item.dealwiseAverage
      );
      setValue(`proposedSchemaDTOs[${index}].tranche`, item.tranche);
      setValue(
        `proposedSchemaDTOs[${index}].incrementalCostBorrowingType`,
        item.incrementalCostBorrowingType
      );
      setValue(
        `proposedSchemaDTOs[${index}].prMoratoriumPeriod`,
        item.prMoratoriumPeriod
      );
      setValue(
        `proposedSchemaDTOs[${index}].icbFixedFloating`,
        item.icbFixedFloating
      );
      setValue(`proposedSchemaDTOs[${index}].icbBenchMark`, item.icbBenchMark);
      setValue(`proposedSchemaDTOs[${index}].icbSpread`, item.icbSpread);

      if (
        !CommonUtil.isEmpty(item.benchMark) &&
        item.benchMark.toLowerCase().includes("repo")
      ) {
        setRepoNote((prev) => ({ ...prev, [index]: true }));
      } else {
        setRepoNote((prev) => ({ ...prev, [index]: false }));
      }
    });
    setValue("ifvPropExposure", CommonUtil.dynamicTotal(sum));

    if (!CommonUtil.isEmpty(sum)) {
      setTotalAmount(CommonUtil.dynamicTotal(sum));
    }

    if (response.data.ifvBankType === "UCB") {
      setUcb(true);
      setRRB(false);
    } else if (response.data.ifvBankType === "RRB") {
      setUcb(false);
      setRRB(true);
    } else {
      setUcb(false);
      setRRB(false);
    }

    let showAssistance = false;

    if (!CommonUtil.isEmpty(appData.assistanceAppliedFor)) {
      setNewAssistanceApp(true);
      showAssistance = true;
      appData.assistanceAppliedFor.forEach((item, index) => {
        remove2(index);
        append2({});
        validateFundCodeForAssist(item.fundCode, index);
        setSelectedSchemeForAssist((prev) => ({
          ...prev,
          [index]: item.schemeName,
        }));
        setSelectedFundCodeForAssist((prev) => ({
          ...prev,
          [index]: item.fundCode,
        }));
        setValue(`assistanceAppliedFor[${index}].id`, item.id);
        setValue(`assistanceAppliedFor[${index}].ifvId`, item.ifvId);
        setValue(`assistanceAppliedFor[${index}].schemeName`, item.schemeName);
        setValue(`assistanceAppliedFor[${index}].schemeCode`, item.schemeCode);
        setValue(`assistanceAppliedFor[${index}].fundName`, item.fundName);
        setValue(`assistanceAppliedFor[${index}].fundCode`, item.fundCode);

        let objPrAmount;

        if (!CommonUtil.isEmpty(item.amount)) {
          objPrAmount = CommonUtil.formatAmount(item.amount);
        } else {
          objPrAmount = item.amount;
        }
        setValue(`assistanceAppliedFor[${index}].amount`, objPrAmount);

        if (!CommonUtil.isEmpty(item.videDate)) {
          setValue(
            `assistanceAppliedFor[${index}].videDate`,
            new Date(item.videDate)
          );
          setVideDates((prevState) => ({
            ...prevState,
            [index]: new Date(item.videDate),
          }));
        }
      });
    }
    fetchTblFwdDetail(showAssistance);

    if (!CommonUtil.isEmpty(appData.aggregateExposure)) {
      remove3();

      append3(
        appData.aggregateExposure.map((item) => ({
          id: item.id,
          ifvId: item.ifvId,
          slNo: item.slNo,
          particulars: item.particulars,
          amount: item.amount,
          groupName: item.groupName,
          capitalFunds: item.capitalFunds,
        }))
      );
    } else {
      remove3();
      append3(new Array(5).fill({}));
    }
  };

  const onSubmitOfApplication = (data, e) => {
    setLoading(true);
    if (CommonUtil.isEmpty(custId) || CommonUtil.isEmpty(bankName)) {
      setLoading(false);
      alert("Application data is incorrect!");
      return;
    }

    let isValid = true;

    data.proposedSchemaDTOs.forEach((item, i) => {
      if (!CommonUtil.isEmpty(aeDates[i])) {
        if (CommonUtil.validateDate(aeDates[i]) == true) {
          item.prMaturityDate = new Date(aeDates[i]);
        } else {
          isValid = false;
        }
      } else {
        item.prMaturityDate = "";
      }

      item.prFundname = fundCodeAndFundName[item.prFundcode];
      if (item.prSchemeName === "RMSE") {
        item.prSchemecode = "RE";
      } else {
        item.prSchemecode = schemeNameAndSchemeCode[item.prSchemeName];
      }
      if (item.interestType === "Fixed") {
        item.benchMark = "";
        item.spread = "";
      } else {
        item.prRoi = "";
      }
      if (item.icbFixedFloating === "Fixed") {
        item.icbBenchMark = "";
        item.icbSpread = "";
      } else {
        // item.incrementalCostBorrowing = '';
      }
    });

    if (!isValid) {
      setLoading(false);
      alert("Please select valid Maturity Date");
      return;
    }

    data.assistanceAppliedFor.forEach((item, i) => {
      if (CommonUtil.isEmpty(videDates[i])) {
        isValid = false;
        return;
      }

      if (CommonUtil.validateDate(videDates[i]) == true) {
        item.videDate = new Date(videDates[i]);
      } else {
        isValid = false;
        return;
      }

      item.fundName = fundCodeAndFundName[item.fundCode];
      if (item.schemeName === "RMSE") {
        item.schemeCode = "RM";
      } else {
        item.schemeCode = schemeNameAndSchemeCode[item.schemeName];
      }
    });

    if (!isValid) {
      setLoading(false);
      alert("Please select valid Vide Date");
      return;
    }

    const user = IfvAppraisalService.getCurrentUser();
    data.cifNumber = custId;
    data.ofrCode = user.ofrCode;
    let userName = user.ofrShortName;
    if (CommonUtil.isEmpty(userName)) {
      userName = user.ofrName;
    }

    data.ofrName = userName;

    if (showSFB) {
      data.sfb = "Y";
    } else {
      data.sfb = "N";
    }
    let totExp = getValues("ifvPropExposure");
    if (parseFloat(totalAmount) !== parseFloat(totExp)) {
      setLoading(false);
      showMessage(
        "The proposed exposure and total amount in the proposed sanction should be the same.",
        "warning"
      );
      return;
    }

    let existOs = CommonUtil.isEmpty(getValues("ifvExistingOs"))
      ? 0
      : parseFloat(getValues("ifvExistingOs"));
    let propExp = CommonUtil.isEmpty(getValues("ifvPropExposure"))
      ? 0
      : parseFloat(getValues("ifvPropExposure"));
    let undSanc = CommonUtil.isEmpty(getValues("ifvUndisbursedSanction"))
      ? 0
      : parseFloat(getValues("ifvUndisbursedSanction"));
    const sum = existOs + propExp + undSanc;
    data.ifvTotalExposure = CommonUtil.dynamicTotal(sum);

    if (!isNaN(appId) && appId > 0) {
      data.ifvId = appId;
      data.ifvName = bankName;

      IfvAppraisalService.updateIfvApp(data)
        .then((response) => {
          setLoading(false);
          setAppId(response.data.ifvId);
          fetchApplication(response.data.ifvId);
          showMessage(
            "Application data has been updated successfully!",
            "success"
          );
        })
        .catch((error) => {
          handleApiError(error, "updating the application");
          setLoading(false);
        });
    } else {

      data.bankAppRefNos = appRefNos;

      IfvAppraisalService.saveIfvApp(data)
        .then((response) => {
          setLoading(false);
          setAppId(response.data.ifvId);
          fetchApplication(response.data.ifvId);
          showMessage(
            "Application data has been saved successfully!",
            "success"
          );
        })
        .catch((error) => {
          handleApiError(error, "saving an application");
          setLoading(false);
        });
    }
  };

  const validateScheme = (scheme, index) => {
    setValue(`proposedSchemaDTOs[${index}].prSchemeName`, scheme);

    setShowSFB(false);
    if (bankName.toLowerCase().includes("small finance bank")) {
      // setShowSFB(true);
      // return;
    }

    if (scheme === "REFINANCE TO SFB") {
      setShowSFB(true);
      return;
    } else {
      fields1.map((item, i) => {
        const val = getValues(`proposedSchemaDTOs[${i}].prSchemeName`);
        if (val === "REFINANCE TO SFB") {
          setShowSFB(true);
          return;
        }
      });
    }
  };

  function goToNext() {
    if (CommonUtil.isEmpty(custId) || CommonUtil.isEmpty(bankName)) {
      alert("Application data is incorrect!");
      return;
    } else {
      if (showSFB) {
        navigate("/ifv/sectionOne", {
          state: {
            showSFB: showSFB,
            appId: appId,
          },
        });
      } else {
        navigate("/ifv/sectionTwo", {
          state: {
            showSFB: showSFB,
            appId: appId,
          },
        });
      }
    }
  }

  const handleTotalExposure = (field, value) => {
    setValue(field, value);

    let existOs = CommonUtil.isEmpty(watch("ifvExistingOs"))
      ? 0
      : parseFloat(watch("ifvExistingOs"));
    let propExp = CommonUtil.isEmpty(watch("ifvPropExposure"))
      ? 0
      : parseFloat(watch("ifvPropExposure"));
    let undSanc = CommonUtil.isEmpty(watch("ifvUndisbursedSanction"))
      ? 0
      : parseFloat(watch("ifvUndisbursedSanction"));
    const sum = existOs + propExp + undSanc;
    setTotalExposure(CommonUtil.dynamicTotal(sum));
  };

  const initialState = {
    assApp: "",
    extRating: "",
    ews: "",
    advNews: "",
    monPen: "",
    othRem: "",
    ifvRemarks: "",
    ifvExpRemarks: "",
    ifvBackground: "",
    intRating: "",
  };
  const [input, setInput] = useState(initialState);
  const inputHandler = (value, input) => {
    setInput((prevState) => ({ ...prevState, [input]: value }));
  };

  const handleSchemeDelete = (index) => {
    const id = getValues(`proposedSchemaDTOs[${index}].prId`);
    const cost = getValues(`proposedSchemaDTOs[${index}].prAmount`);
    if (CommonUtil.isValidNumber(id)) {
      setLoading(true);
      IfvAppraisalService.deleteScheme(id)
        .then((response) => {
          setLoading(false);
          setValue(
            "ifvPropExposure",
            CommonUtil.dynamicTotal(totalAmount - cost)
          );
          setTotalAmount(CommonUtil.dynamicTotal(totalAmount - cost));
          setTotalExposure(CommonUtil.dynamicTotal(totalExposure - cost));
          setSelectedFundCode((prev) => ({ ...prev, [index]: "" }));
          setSelectedScheme((prev) => ({ ...prev, [index]: "" }));
          setAeDates((prev) => ({ ...prev, [index]: "" }));
          setValue(`proposedSchemaDTOs[${index}]`, null);
          remove1(index);
          showMessage("Scheme has been deleted successfully!", "success");
        })
        .catch((error) => {
          setLoading(false);
          handleApiError(error, "deleting scheme");
        });
    } else {
      setValue("ifvPropExposure", CommonUtil.dynamicTotal(totalAmount - cost));
      setTotalAmount(CommonUtil.dynamicTotal(totalAmount - cost));

      setTotalExposure(CommonUtil.dynamicTotal(totalExposure - cost));

      setSelectedFundCode((prev) => ({ ...prev, [index]: "" }));
      setSelectedScheme((prev) => ({ ...prev, [index]: "" }));
      setAeDates((prev) => ({ ...prev, [index]: "" }));
      setValue(`proposedSchemaDTOs[${index}]`, null);
      remove1(index);
    }
  };

  const handleAssistanceDelete = (index) => {
    const id = getValues(`assistanceAppliedFor[${index}].id`);
    if (CommonUtil.isValidNumber(id)) {
      setLoading(true);
      IfvAppraisalService.deleteAssistanceApplied(id)
        .then((response) => {
          setLoading(false);
          setSelectedFundCodeForAssist((prev) => ({ ...prev, [index]: "" }));
          setSelectedSchemeForAssist((prev) => ({ ...prev, [index]: "" }));
          setVideDates((prev) => ({ ...prev, [index]: "" }));
          setValue(`assistanceAppliedFor[${index}]`, null);
          remove2(index);
          showMessage(
            "Assistance applied for details has been deleted successfully!",
            "success"
          );
        })
        .catch((error) => {
          setLoading(false);
          handleApiError(error, "deleting scheme");
        });
    } else {
      setSelectedFundCodeForAssist((prev) => ({ ...prev, [index]: "" }));
      setSelectedSchemeForAssist((prev) => ({ ...prev, [index]: "" }));
      setVideDates((prev) => ({ ...prev, [index]: "" }));
      setValue(`assistanceAppliedFor[${index}]`, null);
      remove2(index);
    }
  };

  const handleAggregateExposureDelete = (index) => {
    const id = getValues(`aggregateExposure[${index}].id`);
    if (CommonUtil.isValidNumber(id)) {
      setLoading(true);
      IfvAppraisalService.deleteAggregateExposure(id)
        .then((response) => {
          setLoading(false);
          setValue(`aggregateExposure[${index}]`, null);
          remove3(index);
          showMessage(
            "Aggregate Exposure Details has been deleted successfully!",
            "success"
          );
        })
        .catch((error) => {
          setLoading(false);
          handleApiError(error, "deleting aggregate exposure");
        });
    } else {
      setValue(`aggregateExposure[${index}]`, null);
      remove3(index);
    }
  };

  const [schemesOnFundCode, setSchemesOnFundCode] = useState([]);
  const [schemesOnFundCodeForAssist, setSchemesOnFundCodeForAssist] = useState(
    []
  );
  const [selectedScheme, setSelectedScheme] = useState([]);
  const [selectedSchemeForAssist, setSelectedSchemeForAssist] = useState([]);

  const [tranche, setTranche] = useState([]);

  const validateFundCode = (fundCode, index) => {
    setSelectedFundCode((prev) => ({ ...prev, [index]: fundCode }));

    if (fundCode === "") {
      setSchemesOnFundCode([]);
      return;
    }

    MasterService.getAllSchemesOnFundCode(fundCode)
      .then((response) => {
        if (response.data.length === 0) {
          //  showMessage('No schemes available for the selected fund', 'warning');
          const rmseSch = [
            { slchCode: "RM", shortName: "RMSE", longName: "RMSE" },
          ];
          setSchemesOnFundCode((prev) => ({ ...prev, [index]: rmseSch }));
        } else {
          if (fundCode === "01" || fundCode === "75" || fundCode === "59") {
            setSchemesOnFundCode((prev) => ({
              ...prev,
              [index]: response.data,
            }));
          } else {
            const rmseSch = [
              { slchCode: "RM", shortName: "RMSE", longName: "RMSE" },
            ];
            setSchemesOnFundCode((prev) => ({ ...prev, [index]: rmseSch }));
          }
        }
      })
      .catch((error) => {
        handleApiError(error, "loading schemes");
      });

    if (fundCode !== "01" && fundCode !== "59" && fundCode !== "75") {
      MasterService.getAllTrancheOnFundCode(fundCode)
        .then((response) => {
          setTranche((prev) => ({ ...prev, [index]: response.data }));
        })
        .catch((error) => {
          handleApiError(error, "loading tranche");
        });
    }
  };

  const validateFundCodeForAssist = (fundCode, index) => {
    setSelectedFundCodeForAssist((prev) => ({ ...prev, [index]: fundCode }));

    if (fundCode === "") {
      setSchemesOnFundCodeForAssist([]);
      return;
    }

    MasterService.getAllSchemesOnFundCode(fundCode)
      .then((response) => {
        if (response.data.length === 0) {
          //  showMessage('No schemes available for the selected fund', 'warning');
          const rmseSch = [
            { slchCode: "RM", shortName: "RMSE", longName: "RMSE" },
          ];
          setSchemesOnFundCodeForAssist((prev) => ({
            ...prev,
            [index]: rmseSch,
          }));
        } else {
          if (fundCode === "01" || fundCode === "75" || fundCode === "59") {
            setSchemesOnFundCodeForAssist((prev) => ({
              ...prev,
              [index]: response.data,
            }));
          } else {
            const rmseSch = [
              { slchCode: "RM", shortName: "RMSE", longName: "RMSE" },
            ];
            setSchemesOnFundCodeForAssist((prev) => ({
              ...prev,
              [index]: rmseSch,
            }));
          }
        }
      })
      .catch((error) => {
        handleApiError(error, "loading schemes");
      });
  };

  const [totalAmount, setTotalAmount] = useState(0);
  const [amountInRs, setAmountInRs] = useState([]);

  const calculateTotalAmount = (field, value, index) => {
    setValue(field, value, { shouldValidate: true });
    let sum = 0;
    fields1.map((item, ind) => {
      let val = getValues(`proposedSchemaDTOs[${ind}].prAmount`);
      if (CommonUtil.isValidNumber(val)) {
        sum = sum + parseFloat(val);
      }
    });

    setValue("ifvPropExposure", CommonUtil.dynamicTotal(sum));
    setTotalAmount(CommonUtil.dynamicTotal(sum));
    let existOs = CommonUtil.isEmpty(watch("ifvExistingOs"))
      ? 0
      : parseFloat(watch("ifvExistingOs"));
    let propExp = CommonUtil.isEmpty(watch("ifvPropExposure"))
      ? 0
      : parseFloat(watch("ifvPropExposure"));
    let undSanc = CommonUtil.isEmpty(watch("ifvUndisbursedSanction"))
      ? 0
      : parseFloat(watch("ifvUndisbursedSanction"));
    const totExposure = existOs + propExp + undSanc;
    setTotalExposure(CommonUtil.dynamicTotal(totExposure));

    if (!CommonUtil.isEmpty(value)) {
      setAmountInRs((prev) => ({
        ...prev,
        [index]: CommonUtil.convertToIndianRupees(value),
      }));
    }
  };

  const [aeDates, setAeDates] = useState([]);
  const [videDates, setVideDates] = useState([]);
  const [ucb, setUcb] = useState(true);
  const [rrb, setRRB] = useState(true);
  // const [enableDisableField, setEnableDisableField] = useState(false)
  // const setEnableDisableFieldChange = (val, index) => {
  //   if (val == 'Fixed') {
  //     setValue(`proposedSchemaDTOs[${index}].benchMark`, '')
  //     setValue(`proposedSchemaDTOs[${index}].spread`, '')
  //     // setEnableDisableField(true)
  //   } else {
  //     setValue(`proposedSchemaDTOs[${index}].prRoi`, '')
  //     // setEnableDisableField(false)
  //   }

  // }
  const fixDecimals = (e) => {
    if (!CommonUtil.isEmpty(e.target.value)) {
      const val = parseFloat(e.target.value).toFixed(2);
      e.target.value = val;
    }
  };

  const fixAmountDecimals = (e) => {
    if (
      !CommonUtil.isEmpty(e.target.value) &&
      CommonUtil.hasDecimals(e.target.value)
    ) {
      const val = CommonUtil.formatAmount(e.target.value);
      e.target.value = val;
    }
  };

  const [repoNote, setRepoNote] = useState([]);

  const handleRepoNote = (val, index) => {
    if (val.includes("REPO")) {
      setRepoNote((prev) => ({ ...prev, [index]: true }));
    } else {
      setRepoNote((prev) => ({ ...prev, [index]: false }));
    }
  };

  const validateAmount = (value) => {
    if (value === "" || value === null) return "This field is required";
    if (Number(value) < 0) return "Invalid value";
    if (!/^\d{1,8}(\.\d{1,2})?$/.test(value))
      return "Enter up to 8 digits with up to 2 decimals";
    return true;
  };

  const canDelete =
    appStatus === "" || appStatus === "New" || (locked && !isMaker);

  const proposedExposure = watch("ifvPropExposure");
  const asOnDate = watch("ifvRepaymentDate");
  const amount1 = watch("aggregateExposure[1].amount");
  const amount2 = watch("aggregateExposure[2].amount");
  const expLimit = watch("aggregateExposure[0].amount");
  const totAmount2And3 = watch("aggregateExposure[3].amount");
  const [groupName, setGroupName] = useState("");
  const [trigger, setTrigger] = useState(false);

  // Set proposed amount (row 2)
  useEffect(() => {
    const proposedVal = parseFloat(proposedExposure || 0);

    setValue("aggregateExposure[2].amount", proposedVal.toFixed(2), {
      shouldValidate: true,
      shouldDirty: true,
    });
  }, [proposedExposure, setValue]);

  const fetchAggregateExposureDetails = async () => {
    try {
      const formattedDate = formatDate(asOnDate);

      const exposureData = await getAggregateExposureData({
        cifNumber: custId,
        asOnDate: formattedDate,
      });

      if (exposureData && (CommonUtil.isEmpty(appId) || appId <= 0)) {
        remove3();

        append3([
          {},
          {},
          {
            amount: parseFloat(getValues("ifvPropExposure") || 0).toFixed(2),
          },
          {},
          {},
        ]);
      }

      // S.No
      for (let i = 0; i < 5; i++) {
        setValue(`aggregateExposure[${i}].slNo`, i + 1);
      }

      // Limit & capital
      setValue(
        "aggregateExposure[0].capitalFunds",
        exposureData.percCapitalFund ?? ""
      );
      setValue("aggregateExposure[0].amount", exposureData.exposureLimit ?? "");
      setValue("aggregateExposure[1].amount", exposureData.actualExposure ?? "");

      // Group
      const grp = exposureData.bankGroup || "";
      setGroupName(grp);

      // Particulars
      setValue(
        "aggregateExposure[0].particulars",
        `Applicable Exposure Cap to ${grp}`
      );
      setValue(
        "aggregateExposure[1].particulars",
        `Aggregate Exposure to ${grp}`
      );
      setValue("aggregateExposure[2].particulars", "Proposed Sanction Amount");
      setValue(
        "aggregateExposure[3].particulars",
        `Aggregate Exposure to ${grp} with proposed sanction (2+3)`
      );
      setValue(
        "aggregateExposure[4].particulars",
        `% Utilisation of ${grp} Cap - SIDBI Solo`
      );

      // Group names
      for (let i = 0; i < 5; i++) {
        setValue(`aggregateExposure[${i}].groupName`, grp);
      }
    } catch (err) {
      console.error("Error fetching group details:", err);
    }
  };

  useEffect(() => {
    if (!custId || !asOnDate) return;
    fetchAggregateExposureDetails();
  }, [custId, asOnDate]);

  console.log("selectedApp.value =", selectedApp?.value || custId);
  console.log("asOnDate =", asOnDate);

  const {
    loading: isLoading,
    status,
    data: exposureData,
    error,
  } = useAggregateExposure(custId, asOnDate, groupName, trigger);

  // Set actual exposure (row 1)
  useEffect(() => {
    if (!exposureData) return;

    const actual = parseFloat(exposureData || 0);

    setValue("aggregateExposure[1].amount", actual.toFixed(2));

    const proposedVal = parseFloat(getValues("ifvPropExposure") || 0);

    setValue("aggregateExposure[2].amount", proposedVal.toFixed(2));
  }, [exposureData]);

  // Row 3 = Actual + Proposed
  useEffect(() => {
    const actual = parseFloat(amount1 || 0);
    const proposed = parseFloat(amount2 || 0);

    const sum = actual + proposed;

    setValue("aggregateExposure[3].amount", sum.toFixed(2), {
      shouldValidate: true,
      shouldDirty: true,
    });
  }, [amount1, amount2]);

  // Util % = Actual / Limit * 100
  useEffect(() => {
    const actual = parseFloat(totAmount2And3 || 0);
    const limit = parseFloat(expLimit || 0);

    let percUtil = 0;

    if (limit > 0) {
      percUtil = (actual / limit) * 100;
    }

    setValue("aggregateExposure[4].amount", percUtil.toFixed(2));
  }, [totAmount2And3, expLimit]);

  return (
    <Fragment>
      <div className={loading ? "frgmnt blur-background" : "frgmnt"}>
        {appId > 0 && (
          <SectionNavigation
            activeView="Proposal Info"
            showSFB={showSFB}
            appId={appId}
          />
        )}
        <ProposalHeader
          bankName={bankName}
          appNumber={obj.appNumber}
          status={appStatus}
          appId={appId}
        />

        <form key={1} onSubmit={handleSubmit(onSubmitOfApplication, onError)}>
          <div className="container-fluid bsc_inf">
            <div className="row">
              {!newAssistanceApp && (
                <>
                  <div className="col-md-6">
                    <div className="form-group">
                      <label>
                        {" "}
                        <strong> Name of the Bank</strong>
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        autoComplete="off"
                        value={bankName}
                        readOnly
                        required
                        {...register("ifvName")}
                      />
                    </div>
                  </div>

                  <div className="col-md-6">
                    <div className="form-group n_m">
                      <label className="prog_lbl">
                        <strong>Assistance Applied for</strong>
                        <div className="prgs">
                          <span className="lft_crt">
                            {1000 - input["assApp"].length} Characters left
                          </span>
                          <LinearProgress
                            variant="determinate"
                            value={input["assApp"].length}
                          />
                        </div>
                      </label>

                      <textarea
                        className="form-control"
                        {...register("ifvAssistance", {
                          //required: "Assistance applied for is required",
                          maxLength: {
                            value: 1000,
                            message: "The maximum length of the field is 1000",
                          },
                          validate: (value) => {
                            if (Pattern.validateHtmlTags().test(value))
                              return "Invalid value";
                            return true;
                          },
                        })}
                        autoComplete="off"
                        maxLength="1000"
                        onChange={(e) => {
                          Pattern.sanitizeInput(e);
                          inputHandler(e.target.value, "assApp");
                        }}
                      />
                      <span className="vldn">
                        {errors.ifvAssistance && errors.ifvAssistance.message}
                      </span>
                    </div>
                  </div>
                </>
              )}
              {(ucb || rrb) && (
                <div className="col-md-12">
                  <div className="form-group n_m">
                    <label className="prog_lbl mb-0">
                      <strong>
                        Background (
                        <span className="clred_light">
                          * Applicable for UCB/RRB only
                        </span>
                        ):{" "}
                      </strong>
                      {/* <span className='ifany' style={{display:'block'}}>(Please use * between the words to make them bold.)</span> */}
                      <div className="prgs">
                        <span className="lft_crt">
                          {4000 - input["ifvBackground"].length} Characters left
                        </span>
                        <LinearProgress
                          variant="determinate"
                          value={input["ifvBackground"].length}
                        />
                      </div>
                    </label>
                    {appStatus === "New" && (
                      <span className="ifany pb-3" style={{ display: "block" }}>
                        (Please use * between the words to make them bold.)
                      </span>
                    )}

                    <textarea
                      className="form-control"
                      {...register("ifvBackground", {
                        maxLength: {
                          value: 4000,
                          message: "The maximum length of the field is 4000",
                        },
                      })}
                      autoComplete="off"
                      maxLength="4000"
                      onChange={(e) => {
                        Pattern.sanitizeInput(e);
                        inputHandler(e.target.value, "ifvBackground");
                      }}
                    />
                    <span className="vldn">
                      {errors.ifvBackground && errors.ifvBackground.message}
                    </span>
                  </div>
                </div>
              )}

              {newAssistanceApp && (
                <>
                  <div className="col-md-12">
                    <div className="otr_def">
                      <h5 className="HdngTitl">Assistance applied for</h5>
                      {fields2.map((field, index) => (
                        <div
                          className="container-fluid ps-0"
                          eventKey="0"
                          key={field.id}
                        >
                          <div className="row propSpc">
                            <div className="col-md-2">
                              <div className="form-group">
                                <label>
                                  <strong>
                                    Amount{" "}
                                    <span className="ifany">
                                      &nbsp;(₹ in crore){" "}
                                    </span>
                                    <span className="color-red"> *</span>
                                  </strong>{" "}
                                </label>
                                <input
                                  className="form-control"
                                  key={field.id}
                                  type="number"
                                  step="any"
                                  min="0"
                                  max="99999"
                                  onKeyDown={(e) =>
                                    CommonUtil.handleNumericInput(e)
                                  }
                                  {...register(
                                    `assistanceAppliedFor[${index}].amount`,
                                    {
                                      required: "Amount is required",
                                      validate: (value) => {
                                        if (value <= 0) return "Invalid value";
                                        if (
                                          !/^\d{1,8}(\.\d{1,7})?$/.test(value)
                                        )
                                          return "Enter up to 12 digits with up to 7 decimals";
                                        return true;
                                      },
                                    }
                                  )}
                                  onBlur={(e) => fixAmountDecimals(e)}
                                />
                                <span className="vldn">
                                  {errors.assistanceAppliedFor &&
                                    errors.assistanceAppliedFor[index]
                                      ?.amount &&
                                    errors.assistanceAppliedFor[index]?.amount
                                      .message}
                                </span>
                              </div>
                            </div>

                            <div className="col-md-3">
                              <div className="form-group">
                                <label>
                                  <strong>
                                    Fund<span className="color-red"> *</span>
                                  </strong>
                                </label>
                                <select
                                  className="form-select"
                                  key={field.id}
                                  {...register(
                                    `assistanceAppliedFor[${index}].fundCode`,
                                    {
                                      required: "Fund code is required",
                                      onChange: (e) =>
                                        validateFundCodeForAssist(
                                          e.target.value,
                                          index
                                        ),
                                    }
                                  )}
                                >
                                  <option value="">
                                    {" "}
                                    Please select a fund
                                  </option>
                                  {funds.map((item, i) => (
                                    <option
                                      selected={
                                        selectedFundCodeForAssist[index] ===
                                        item.fundCode
                                      }
                                      value={item.fundCode}
                                    >
                                      {item.fundDescription}
                                    </option>
                                  ))}
                                </select>
                                <span className="vldn">
                                  {errors.assistanceAppliedFor &&
                                    errors.assistanceAppliedFor[index]
                                      ?.fundCode &&
                                    errors.assistanceAppliedFor[index]?.fundCode
                                      .message}
                                </span>

                                <input
                                  type="hidden"
                                  {...register(
                                    `assistanceAppliedFor[${index}].fundName`
                                  )}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `assistanceAppliedFor[${index}].ifvId`
                                  )}
                                  value={appId}
                                />
                                <input
                                  type="hidden"
                                  {...register(
                                    `assistanceAppliedFor[${index}].id`
                                  )}
                                />
                              </div>
                            </div>

                            <div className="col-md-4">
                              <div className="form-group">
                                <label className="ml-2">
                                  <strong>
                                    Scheme<span className="color-red"> *</span>
                                  </strong>
                                </label>
                                <select
                                  className="form-select"
                                  key={field.id}
                                  {...register(
                                    `assistanceAppliedFor[${index}].schemeName`,
                                    {
                                      required: "Scheme is required",
                                      // onChange: (e) => validateScheme(e.target.value, index)
                                    }
                                  )}
                                >
                                  <option value="">
                                    {" "}
                                    Please select a scheme
                                  </option>
                                  {schemesOnFundCodeForAssist[index]?.map(
                                    (item, i) => (
                                      <option
                                        selected={
                                          selectedSchemeForAssist[index] ===
                                          item.longName
                                        }
                                        value={item.longName}
                                      >
                                        {item.longName}
                                      </option>
                                    )
                                  )}
                                </select>
                                <span className="vldn">
                                  {errors.assistanceAppliedFor &&
                                    errors.assistanceAppliedFor[index]
                                      ?.schemeName &&
                                    errors.assistanceAppliedFor[index]
                                      ?.schemeName.message}
                                </span>
                                <input
                                  type="hidden"
                                  {...register(
                                    `assistanceAppliedFor[${index}].schemeCode`
                                  )}
                                />
                              </div>
                            </div>

                            <div className="col-md-2">
                              <div className="form-group">
                                <label>
                                  <strong>
                                    Vide App Dated
                                    <span className="color-red"> *</span>
                                  </strong>{" "}
                                </label>
                                <div className="asis">
                                  <Controller
                                    {...register(
                                      `assistanceAppliedFor[${index}].videDate`
                                    )}
                                    control={control}
                                    render={({
                                      field: { onChange, onBlur, value, ref },
                                    }) => (
                                      <ReactDatePicker
                                        className="form-control"
                                        placeholderText="Select date"
                                        onChange={(date) =>
                                          setVideDates((prevState) => ({
                                            ...prevState,
                                            [index]: !CommonUtil.isEmpty(date)
                                              ? new Date(date)
                                              : "",
                                          }))
                                        }
                                        selected={
                                          videDates[index]
                                            ? new Date(videDates[index])
                                            : videDates[index]
                                        }
                                        onBlur={onBlur}
                                        dateFormat="dd/MM/yyyy"
                                      />
                                    )}
                                  />
                                  <span className="vldn">
                                    {errors.assistanceAppliedFor &&
                                      errors.assistanceAppliedFor[index]
                                        ?.videDate &&
                                      errors.assistanceAppliedFor[index]
                                        ?.videDate.message}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="col-md-1">
                              <div className="form-group">
                                {(appStatus === "" ||
                                  appStatus === "New" ||
                                  (locked && !isMaker)) && (
                                  <i
                                    key={field.id}
                                    className="fa fa-trash"
                                    aria-hidden="true"
                                    onClick={() =>
                                      handleAssistanceDelete(index)
                                    }
                                  ></i>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                      <div className="button-container-end">
                        <button
                          type="button"
                          className="addBtn"
                          onClick={() => {
                            append2({});
                          }}
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                </>
              )}

              <div className="col-md-12">
                <div className="otr_def">
                  <h5 className="HdngTitl">Amount Proposed for Sanction</h5>
                  {fields1.map((field, index) => {
                    const fndName = watch(
                      `proposedSchemaDTOs[${index}].prFundcode`
                    );
                    const selTranche = watch(
                      `proposedSchemaDTOs[${index}].tranche`
                    );
                    const intType = watch(
                      `proposedSchemaDTOs[${index}].interestType`
                    );
                    const isDisabled = intType === "Floating";
                    const icbType = watch(
                      `proposedSchemaDTOs[${index}].icbFixedFloating`
                    );
                    const isIcbDisabled = icbType === "Floating";
                    return (
                      <div
                        className="container-fluid ps-0"
                        eventKey="0"
                        key={field.id}
                      >
                        <div className="row propSpc">
                          <div className="col-md-3">
                            <div className="form-group">
                              <label>
                                <strong>
                                  Fund<span className="color-red"> *</span>
                                </strong>
                              </label>
                              <select
                                className="form-select"
                                key={field.id}
                                {...register(
                                  `proposedSchemaDTOs[${index}].prFundcode`,
                                  {
                                    required: "Fund code is required",
                                    onChange: (e) =>
                                      validateFundCode(e.target.value, index),
                                  }
                                )}
                              >
                                <option value=""> Please select a fund</option>
                                {funds.map((item, i) => (
                                  <option
                                    selected={
                                      selectedFundCode[index] === item.fundCode
                                    }
                                    value={item.fundCode}
                                  >
                                    {item.fundDescription}
                                  </option>
                                ))}
                              </select>
                              <span className="vldn">
                                {errors.proposedSchemaDTOs &&
                                  errors.proposedSchemaDTOs[index]
                                    ?.prFundcode &&
                                  errors.proposedSchemaDTOs[index]?.prFundcode
                                    .message}
                              </span>

                              <input
                                type="hidden"
                                {...register(
                                  `proposedSchemaDTOs[${index}].prFundname`
                                )}
                              />
                              <input
                                type="hidden"
                                {...register(
                                  `proposedSchemaDTOs[${index}].ifvId`
                                )}
                                value={appId}
                              />
                              <input
                                type="hidden"
                                {...register(
                                  `proposedSchemaDTOs[${index}].prId`
                                )}
                              />
                            </div>
                          </div>

                          <div className="col-md-4">
                            <div className="form-group">
                              <label className="ml-2">
                                <strong>
                                  Scheme<span className="color-red"> *</span>
                                </strong>
                              </label>
                              <select
                                className="form-select"
                                key={field.id}
                                {...register(
                                  `proposedSchemaDTOs[${index}].prSchemeName`,
                                  {
                                    required: "Scheme is required",
                                    onChange: (e) =>
                                      validateScheme(e.target.value, index),
                                  }
                                )}
                              >
                                <option value="">
                                  {" "}
                                  Please select a scheme
                                </option>
                                {schemesOnFundCode[index]?.map((item, i) => (
                                  <option
                                    selected={
                                      selectedScheme[index] === item.longName
                                    }
                                    value={item.longName}
                                  >
                                    {item.longName}
                                  </option>
                                ))}
                              </select>
                              <span className="vldn">
                                {errors.proposedSchemaDTOs &&
                                  errors.proposedSchemaDTOs[index]
                                    ?.prSchemeName &&
                                  errors.proposedSchemaDTOs[index]?.prSchemeName
                                    .message}
                              </span>
                              <input
                                type="hidden"
                                {...register(
                                  `proposedSchemaDTOs[${index}].prSchemecode`
                                )}
                              />
                            </div>
                          </div>

                          <div className="col-md-2">
                            <div className="form-group">
                              <label>
                                <strong>
                                  Amount{" "}
                                  <span className="ifany">
                                    &nbsp;(₹ in crore){" "}
                                  </span>
                                  <span className="color-red"> *</span>
                                </strong>{" "}
                              </label>
                              <input
                                className="form-control"
                                key={field.id}
                                type="number"
                                step="any"
                                min="0"
                                max="99999"
                                onKeyDown={(e) =>
                                  CommonUtil.handleNumericInput(e)
                                }
                                {...register(
                                  `proposedSchemaDTOs[${index}].prAmount`,
                                  {
                                    required: "Amount is required",
                                    validate: (value) => {
                                      if (value <= 0) return "Invalid value";
                                      if (!/^\d{1,8}(\.\d{1,7})?$/.test(value))
                                        return "Enter up to 12 digits with up to 7 decimals";
                                      return true;
                                    },
                                    onChange: (e) =>
                                      calculateTotalAmount(
                                        `proposedSchemaDTOs[${index}].prAmount`,
                                        e.target.value,
                                        index
                                      ),
                                  }
                                )}
                                onBlur={(e) => fixAmountDecimals(e)}
                              />
                              <span className="vldn">
                                {errors.proposedSchemaDTOs &&
                                  errors.proposedSchemaDTOs[index]?.prAmount &&
                                  errors.proposedSchemaDTOs[index]?.prAmount
                                    .message}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-3">
                            <div className="form-group">
                              <label>
                                <strong>
                                  Amount{" "}
                                  <span className="ifany">&nbsp;(₹) </span>
                                </strong>
                              </label>
                              <input
                                className="form-control"
                                key={field.id}
                                value={amountInRs[index]}
                                type="text"
                                readOnly
                              />
                            </div>
                          </div>

                          <div className="col-md-2">
                            <div className="form-group">
                              <label>
                                <strong>
                                  Interest Type
                                  <span className="color-red"> *</span>
                                </strong>{" "}
                              </label>
                              <select
                                className="form-select"
                                {...register(
                                  `proposedSchemaDTOs[${index}].interestType`,
                                  {
                                    required: "Field is required",
                                  }
                                )}
                                // onChange={(e) => setEnableDisableFieldChange(e.target.value, index)}
                              >
                                <option value="">Select a value</option>
                                <option value="Fixed">Fixed</option>
                                <option value="Floating">Floating</option>
                              </select>

                              <span className="vldn">
                                {errors.proposedSchemaDTOs &&
                                  errors.proposedSchemaDTOs[index]
                                    ?.interestType &&
                                  errors.proposedSchemaDTOs[index]?.interestType
                                    .message}
                              </span>
                            </div>
                          </div>

                          {!isDisabled && (
                            <div className="col-md-2">
                              <div className="form-group">
                                <label>
                                  <strong>
                                    RoI <span className="ifany">&nbsp;(%)</span>
                                    <span className="color-red"> *</span>
                                  </strong>{" "}
                                </label>
                                <input
                                  className="form-control"
                                  key={field.id}
                                  type="number"
                                  step="0.01"
                                  max="100"
                                  min="0"
                                  onKeyDown={(e) =>
                                    CommonUtil.handleNumericInput(e)
                                  }
                                  {...register(
                                    `proposedSchemaDTOs[${index}].prRoi`,
                                    {
                                      required: "Field is required",
                                      validate: (value) => {
                                        if (CommonUtil.isEmpty(value))
                                          return true;
                                        if (value <= 0) return "Invalid value";
                                        if (
                                          !/^(100(\.0{1,2})?|\d{1,2}(\.\d{1,2})?)$/.test(
                                            value
                                          )
                                        )
                                          return "Enter up to 100 with up to 2 decimal places";
                                        return true;
                                      },
                                    }
                                  )}
                                  onBlur={(e) => fixDecimals(e)}
                                />
                                <span className="vldn">
                                  {errors.proposedSchemaDTOs &&
                                    errors.proposedSchemaDTOs[index]?.prRoi &&
                                    errors.proposedSchemaDTOs[index]?.prRoi
                                      .message}
                                </span>
                              </div>
                            </div>
                          )}

                          {isDisabled && (
                            <>
                              {" "}
                              <div className="col-md-2">
                                <div className="form-group">
                                  <label>
                                    <strong>
                                      Bench Mark
                                      <span className="color-red"> *</span>
                                    </strong>{" "}
                                  </label>
                                  <select
                                    className="form-select"
                                    {...register(
                                      `proposedSchemaDTOs[${index}].benchMark`,
                                      {
                                        required: "Field is required",
                                        onChange: (e) =>
                                          handleRepoNote(e.target.value, index),
                                      }
                                    )}
                                  >
                                    <option value="">Select a value</option>
                                    {benchmarkList.map((item, ind) => (
                                      <option value={item}>{item}</option>
                                    ))}
                                  </select>

                                  <span className="vldn">
                                    {errors.proposedSchemaDTOs &&
                                      errors.proposedSchemaDTOs[index]
                                        ?.benchMark &&
                                      errors.proposedSchemaDTOs[index]
                                        ?.benchMark.message}
                                  </span>
                                </div>
                              </div>
                              <div className="col-md-2">
                                <div className="form-group">
                                  <label>
                                    <strong>
                                      Spread{" "}
                                      <span className="ifany">&nbsp;(bps)</span>
                                    </strong>{" "}
                                  </label>
                                  <input
                                    className="form-control"
                                    key={field.id}
                                    type="number"
                                    step="any"
                                    onKeyDown={(e) =>
                                      CommonUtil.handleNumericInput(e)
                                    }
                                    {...register(
                                      `proposedSchemaDTOs[${index}].spread`,
                                      {
                                        validate: (value) => {
                                          if (CommonUtil.isEmpty(value))
                                            return true;
                                          if (value <= 0)
                                            return "Invalid value";
                                          return true;
                                        },
                                      }
                                    )}
                                  />

                                  <span className="vldn">
                                    {errors.proposedSchemaDTOs &&
                                      errors.proposedSchemaDTOs[index]
                                        ?.spread &&
                                      errors.proposedSchemaDTOs[index]?.spread
                                        .message}
                                  </span>
                                </div>
                              </div>
                            </>
                          )}

                          <div className="col-md-2">
                            <div className="form-group">
                              <label>
                                <strong>Interest Reset</strong>{" "}
                              </label>
                              <select
                                className="form-select"
                                {...register(
                                  `proposedSchemaDTOs[${index}].interestReset`
                                )}
                              >
                                <option value="">Select a value</option>
                                <option value="Quarterly">Quarterly</option>
                                <option value="Half Yearly">Half Yearly</option>
                                <option value="Annual">Annual</option>
                                <option value="After 2 Years">After 2 Years</option>
                              </select>

                              <span className="vldn">
                                {errors.proposedSchemaDTOs &&
                                  errors.proposedSchemaDTOs[index]
                                    ?.interestReset &&
                                  errors.proposedSchemaDTOs[index]
                                    ?.interestReset.message}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-2">
                            <div className="form-group">
                              <label>
                                <strong>
                                  Tenure{" "}
                                  <span className="ifany">
                                    &nbsp;(In Months)
                                  </span>
                                  <span className="color-red"> *</span>
                                </strong>{" "}
                              </label>
                              <input
                                className="form-control"
                                key={field.id}
                                type="number"
                                onKeyDown={(e) =>
                                  CommonUtil.handleNumericInput(e)
                                }
                                {...register(
                                  `proposedSchemaDTOs[${index}].prTenure`,
                                  {
                                    required: "Field is required",
                                    pattern: {
                                      value: /^(?!0(?:\.0*|)$)\d*(?:\.\d+)?$/,
                                      message: "Invalid value",
                                    },
                                  }
                                )}
                              />
                              <span className="vldn">
                                {errors.proposedSchemaDTOs &&
                                  errors.proposedSchemaDTOs[index]?.prTenure &&
                                  errors.proposedSchemaDTOs[index]?.prTenure
                                    .message}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-2">
                            <div className="form-group">
                              <label>
                                <strong>
                                  Principal Repayment
                                  <span className="color-red"> *</span>
                                </strong>{" "}
                              </label>
                              <select
                                className="form-select"
                                {...register(
                                  `proposedSchemaDTOs[${index}].prPrincipalRepayment`,
                                  {
                                    required: "Principal Payment is required",
                                  }
                                )}
                              >
                                <option value=""> Please select a value</option>
                                {PrincipalRepayment.map((item, index) => (
                                  <option value={item}>{item}</option>
                                ))}
                              </select>
                              <span className="vldn">
                                {errors.proposedSchemaDTOs &&
                                  errors.proposedSchemaDTOs[index]
                                    ?.prPrincipalRepayment &&
                                  errors.proposedSchemaDTOs[index]
                                    ?.prPrincipalRepayment.message}
                              </span>
                            </div>
                          </div>
                          <div className="col-md-2">
                            <div className="form-group">
                              <label>
                                <strong>
                                  Maturity Date{" "}
                                  <span className="ifany">&nbsp;(if any)</span>
                                </strong>{" "}
                              </label>
                              <div className="asis">
                                <Controller
                                  {...register(
                                    `proposedSchemaDTOs[${index}].prMaturityDate`
                                  )}
                                  control={control}
                                  render={({
                                    field: { onChange, onBlur, value, ref },
                                  }) => (
                                    <ReactDatePicker
                                      className="form-control"
                                      placeholderText="Select date"
                                      onChange={(date) =>
                                        setAeDates((prevState) => ({
                                          ...prevState,
                                          [index]: !CommonUtil.isEmpty(date)
                                            ? new Date(date)
                                            : "",
                                        }))
                                      }
                                      selected={
                                        aeDates[index]
                                          ? new Date(aeDates[index])
                                          : aeDates[index]
                                      }
                                      onBlur={onBlur}
                                      dateFormat="dd/MM/yyyy"
                                    />
                                  )}
                                />
                                <span className="vldn">
                                  {errors.proposedSchemaDTOs &&
                                    errors.proposedSchemaDTOs[index]
                                      ?.prMaturityDate &&
                                    errors.proposedSchemaDTOs[index]
                                      ?.prMaturityDate.message}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* <div className='col-md-3'>
                            <div className='form-group'>
                              <label><strong>Moratorium period <span className='ifany'>&nbsp;(In Months)</span></strong> </label>
                              <input className='form-control'
                                key={field.id}
                                type='number'
                                onKeyDown={(e) => CommonUtil.handleNumericInput(e)}
                                {...register(`proposedSchemaDTOs[${index}].prMoratoriumPeriod`,
                                  {
                                    //required: "Field is required",
                                    pattern: {
                                      value: /^(?!0(?:\.0*|)$)\d*(?:\.\d+)?$/,
                                      message: "Invalid value"
                                    },
                                  })}
                              />
                              <span className='vldn'>{errors.proposedSchemaDTOs && errors.proposedSchemaDTOs[index]?.prMoratoriumPeriod && errors.proposedSchemaDTOs[index]?.prMoratoriumPeriod.message}</span>
                            </div>
                          </div> */}

                          {/* <div className='col-md-4'>
                            <div className='form-group'>
                              <label><strong>Incremental Cost of Borrowing (ICB) </strong> </label>
                              <select className="form-select"
                                {...register(`proposedSchemaDTOs[${index}].incrementalCostBorrowingType`, {
                                })}
                              >
                                <option value=""> Please select a value</option>
                                <option value="Cost of borrowing as per TRMV">Cost of borrowing as per TRMV</option>
                                <option value="AAA Bond yield">AAA Bond yield</option>
                              </select>
                              <span className='vldn'>{errors.proposedSchemaDTOs && errors.proposedSchemaDTOs[index]?.incrementalCostBorrowingType && errors.proposedSchemaDTOs[index]?.incrementalCostBorrowingType.message}</span>
                            </div>
                          </div> */}

                          {/* <div className='col-md-3'>
                            <div className='form-group'>
                              <label><strong>ICB Type</strong> </label>
                              <select className="form-select"
                                {...register(`proposedSchemaDTOs[${index}].icbFixedFloating`)}
                              >

                                <option value="">Select a value</option>
                                <option value="Fixed">Fixed</option>
                                <option value="Floating">Floating</option>
                              </select>
                              <span className='vldn'>{errors.proposedSchemaDTOs && errors.proposedSchemaDTOs[index]?.icbFixedFloating && errors.proposedSchemaDTOs[index]?.icbFixedFloating.message}</span>
                            </div>
                          </div> */}

                          {/* {isIcbDisabled && <>  <div className='col-md-2'>
                            <div className='form-group'>
                              <label><strong>Bench Mark (ICB)</strong> </label>
                              <select className="form-select"
                                {...register(`proposedSchemaDTOs[${index}].icbBenchMark`)}
                              >
                                <option value="">Select a value</option>
                                {benchmarkList.map((item, ind) => (
                                  <option value={item}>{item}</option>
                                ))}
                              </select>

                              <span className='vldn'>{errors.proposedSchemaDTOs && errors.proposedSchemaDTOs[index]?.icbBenchMark && errors.proposedSchemaDTOs[index]?.icbBenchMark.message}</span>
                            </div>
                          </div>

                            <div className='col-md-2'>
                              <div className='form-group'>
                                <label><strong>Spread (ICB)<span className='ifany'>&nbsp;(bps)</span></strong> </label>
                                <input className='form-control'
                                  key={field.id}
                                  type='number' step='any'
                                  onKeyDown={(e) => CommonUtil.handleNumericInput(e)}
                                  {...register(`proposedSchemaDTOs[${index}].icbSpread`, {
                                    validate: (value) => {
                                      if (CommonUtil.isEmpty(value)) return true;
                                      if (value <= 0) return "Invalid value";
                                      return true;
                                    },
                                  })}
                                />

                                <span className='vldn'>{errors.proposedSchemaDTOs && errors.proposedSchemaDTOs[index]?.icbSpread && errors.proposedSchemaDTOs[index]?.icbSpread.message}</span>
                              </div>
                            </div>
                          </>
                          } */}

                          <div className="col-md-3">
                            <div className="form-group">
                              <label>
                                <strong>Incremental Cost of Borrowing</strong>{" "}
                              </label>
                              <input
                                className="form-control"
                                key={field.id}
                                type="number"
                                step="any"
                                min="0"
                                max="99999"
                                onKeyDown={(e) =>
                                  CommonUtil.handleNumericInput(e)
                                }
                                {...register(
                                  `proposedSchemaDTOs[${index}].incrementalCostBorrowing`,
                                  {
                                    validate: (value) => {
                                      if (CommonUtil.isEmpty(value))
                                        return true;
                                      if (value <= 0) return "Invalid value";
                                      if (!/^\d{1,8}(\.\d{1,7})?$/.test(value))
                                        return "Enter up to 12 digits with up to 7 decimals";
                                      return true;
                                    },
                                  }
                                )}
                              />
                              <span className="vldn">
                                {errors.proposedSchemaDTOs &&
                                  errors.proposedSchemaDTOs[index]
                                    ?.incrementalCostBorrowing &&
                                  errors.proposedSchemaDTOs[index]
                                    ?.incrementalCostBorrowing.message}
                              </span>
                            </div>
                          </div>

                          <div className="col-md-2">
                            <div className="form-group">
                              <label>
                                <strong>Dealwise Average</strong>{" "}
                              </label>
                              <input
                                className="form-control"
                                key={field.id}
                                type="number"
                                step="any"
                                min="0"
                                max="99999"
                                onKeyDown={(e) =>
                                  CommonUtil.handleNumericInput(e)
                                }
                                {...register(
                                  `proposedSchemaDTOs[${index}].dealwiseAverage`,
                                  {
                                    validate: (value) => {
                                      if (CommonUtil.isEmpty(value))
                                        return true;
                                      if (value <= 0) return "Invalid value";
                                      if (!/^\d{1,8}(\.\d{1,7})?$/.test(value))
                                        return "Enter up to 12 digits with up to 7 decimals";
                                      return true;
                                    },
                                  }
                                )}
                              />
                              <span className="vldn">
                                {errors.proposedSchemaDTOs &&
                                  errors.proposedSchemaDTOs[index]
                                    ?.dealwiseAverage &&
                                  errors.proposedSchemaDTOs[index]
                                    ?.dealwiseAverage.message}
                              </span>
                            </div>
                          </div>
                          {fndName !== "01" &&
                            fndName !== "59" &&
                            fndName !== "75" && (
                              <div className="col-md-2">
                                <div className="form-group">
                                  <label>
                                    <strong>Tranche</strong>{" "}
                                  </label>
                                  {/* <input className='form-control'
                                  key={field.id}
                                  type='number' step='any' min='0' max='99999'
                                  {...register(`proposedSchemaDTOs[${index}].tranche`,
                                    {
                                      validate: (value) => {
                                        if (CommonUtil.isEmpty(value)) return true;
                                        if (value <= 0) return "Invalid value";
                                        if (!/^\d{1,8}(\.\d{1,7})?$/.test(value)) return "Enter up to 12 digits with up to 7 decimals";
                                        return true;
                                      },
                                    })}
                                /> */}

                                  <select
                                    className="form-select"
                                    key={field.id}
                                    {...register(
                                      `proposedSchemaDTOs[${index}].tranche`
                                    )}
                                  >
                                    <option value="">
                                      {" "}
                                      Please select tranche
                                    </option>
                                    {tranche[index]?.map((item, i) => (
                                      <option
                                        selected={selTranche == item}
                                        value={item}
                                      >
                                        {item}
                                      </option>
                                    ))}
                                  </select>

                                  <span className="vldn">
                                    {errors.proposedSchemaDTOs &&
                                      errors.proposedSchemaDTOs[index]
                                        ?.tranche &&
                                      errors.proposedSchemaDTOs[index]?.tranche
                                        .message}
                                  </span>
                                </div>
                              </div>
                            )}
                          <div className="col-md-1">
                            <div className="form-group">
                              {(appStatus === "" ||
                                appStatus === "New" ||
                                (locked && !isMaker)) && (
                                <i
                                  key={field.id}
                                  className="fa fa-trash"
                                  aria-hidden="true"
                                  onClick={() => handleSchemeDelete(index)}
                                ></i>
                              )}
                            </div>
                          </div>

                          {repoNote[index] === true && (
                            <div className="col-md-12">
                              <div className="form-group">
                                <label>
                                  <strong>Repo Note</strong>{" "}
                                </label>
                                <input
                                  className="form-control"
                                  key={field.id}
                                  type="text"
                                  {...register(
                                    `proposedSchemaDTOs[${index}].roiNote`,
                                    {
                                      maxLength: {
                                        value: 500,
                                        message:
                                          "The maximum length of the field is 500",
                                      },
                                    }
                                  )}
                                  autoComplete="off"
                                  maxLength="500"
                                  onChange={(e) => {
                                    Pattern.sanitizeInput(e);
                                  }}
                                />
                                <span className="vldn">
                                  {errors.proposedSchemaDTOs &&
                                    errors.proposedSchemaDTOs[index]?.roiNote &&
                                    errors.proposedSchemaDTOs[index]?.roiNote
                                      .message}
                                </span>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                  <div className="container-fluid ps-0 pt-2">
                    <div className="row">
                      <div className="col-md-3">
                        <div className="form-group">
                          <label>
                            <strong>
                              {" "}
                              Total Amount (₹ in crore)
                              <span className="color-red"> *</span>
                            </strong>
                          </label>
                          <input
                            className="form-control"
                            type="number"
                            value={totalAmount}
                            readOnly
                          />
                        </div>
                      </div>
                      <div className="col-md-1"></div>
                      <div className="col-md-2"></div>
                      <div className="col-md-1"></div>
                    </div>
                  </div>

                  <div className="button-container-end">
                    <button
                      type="button"
                      className="addBtn"
                      onClick={() => {
                        append1({});
                      }}
                    >
                      +
                    </button>
                  </div>

                  <div className="col-md-12 mt-2">
                    <div className="form-group">
                      <label className="prog_lbl">
                        <strong>Remarks:</strong>
                        <div className="prgs">
                          <span className="lft_crt">
                            {4000 - input["ifvRemarks"].length} Characters left
                          </span>
                          <LinearProgress
                            variant="determinate"
                            value={input["ifvRemarks"].length}
                          />
                        </div>
                      </label>
                      <textarea
                        className="form-control"
                        {...register("ifvRemarks", {
                          maxLength: {
                            value: 4000,
                            message: "The maximum length of the field is 4000",
                          },
                        })}
                        autoComplete="off"
                        maxLength="4000"
                        onChange={(e) => {
                          Pattern.sanitizeInput(e);
                          inputHandler(e.target.value, "ifvRemarks");
                        }}
                      />
                      <span className="vldn">
                        {errors.ifvRemarks && errors.ifvRemarks.message}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-md-12">
                <div className="otr_def">
                  <h5 className="HdngTitl">
                    Exposure Limit (As Advised by RiMV)
                  </h5>
                  <div className="sub_nrsn">
                    <h6>(A) Exposure Limit for Borrowing Bank</h6>
                    <span>
                      The Counterparty Exposure Limit for Business Operation
                      (BO) is Given Below: &nbsp; (<span>&#8377;</span> in
                      crore) &nbsp;
                    </span>{" "}
                    <span className="bo_txt"> BO</span>
                  </div>

                  <div className="row">
                    <div className="col-md-2">
                      <div className="form-group">
                        <label>
                          {" "}
                          <strong>
                            Exposure Limit<span className="color-red"> *</span>
                          </strong>
                        </label>
                        <input
                          className="form-control"
                          type="number"
                          step="any"
                          min="0"
                          autoComplete="off"
                          defaultValue={exposureLimit}
                          onKeyDown={(e) => CommonUtil.handleNumericInput(e)}
                          {...register("ifvExposureLimit", {
                            validate: (value) => {
                              if (CommonUtil.isEmpty(value))
                                return "Amount is required";
                              if (value <= 0) return "Invalid value";
                              return true;
                            },
                          })}
                          onChange={(e) =>
                            handleTotalExposure(
                              "ifvExposureLimit",
                              e.target.value
                            )
                          }
                        />
                        <span className="vldn">
                          {errors.ifvExposureLimit &&
                            errors.ifvExposureLimit.message}
                        </span>
                      </div>
                    </div>

                    <div className="col-md-2">
                      <div className="form-group">
                        <label>
                          {" "}
                          <strong>
                            Existing O/s<span className="color-red"> *</span>
                          </strong>
                        </label>
                        <input
                          className="form-control"
                          type="number"
                          step="any"
                          autoComplete="off"
                          defaultValue={existingOs}
                          onKeyDown={(e) => CommonUtil.handleNumericInput(e)}
                          {...register("ifvExistingOs", {
                            validate: (value) => {
                              if (value < 0) return "Invalid value";
                              return true;
                            },
                          })}
                          onChange={(e) =>
                            handleTotalExposure("ifvExistingOs", e.target.value)
                          }
                        />
                        <span className="vldn">
                          {errors.ifvExistingOs && errors.ifvExistingOs.message}
                        </span>
                      </div>
                    </div>

                    <div className="col-md-3">
                      <div className="form-group">
                        <label>
                          {" "}
                          <strong>Undisbursed Sanction</strong>
                        </label>
                        <input
                          className="form-control"
                          type="number"
                          step="any"
                          autoComplete="off"
                          {...register("ifvUndisbursedSanction")}
                          onChange={(e) =>
                            handleTotalExposure(
                              "ifvUndisbursedSanction",
                              e.target.value
                            )
                          }
                        />
                      </div>
                    </div>

                    <div className="col-md-2">
                      <div className="form-group">
                        <label>
                          <strong>
                            Proposed Exposure
                            <span className="color-red"> *</span>
                          </strong>
                        </label>
                        <input
                          className="form-control"
                          type="number"
                          step="any"
                          autoComplete="off"
                          defaultValue={totalAmount}
                          onKeyDown={(e) => CommonUtil.handleNumericInput(e)}
                          {...register("ifvPropExposure", {
                            required: "Field is required",
                            validate: (value) => {
                              if (CommonUtil.isEmpty(value))
                                return "Field is required";
                              if (value <= 0) return "Invalid value";
                              return true;
                            },
                          })}
                          onChange={(e) =>
                            handleTotalExposure(
                              "ifvPropExposure",
                              e.target.value
                            )
                          }
                        />
                        <span className="vldn">
                          {errors.ifvPropExposure &&
                            errors.ifvPropExposure.message}
                        </span>
                      </div>
                    </div>

                    <div className="col-md-2">
                      <div className="form-group">
                        <label>
                          <strong>
                            Total Exposure<span className="color-red"> *</span>
                          </strong>
                        </label>
                        <input
                          className="form-control"
                          type="number"
                          step="any"
                          autoComplete="off"
                          {...register("ifvTotalExposure")}
                          readOnly
                          value={totalExposure}
                        />
                        <span className="vldn">
                          {errors.ifvTotalExposure &&
                            errors.ifvTotalExposure.message}
                        </span>
                      </div>
                    </div>

                    <div className="col-md-4">
                      <div className="form-group">
                        <label>
                          <strong>
                            As Per MIS Alert (Inst. Wise Exposure) Report Dated
                            <span className="color-red"> *</span>
                          </strong>
                        </label>
                        <Controller
                          control={control}
                          name="ifvRepaymentDate"
                          rules={{
                            required: {
                              value: true,
                              message: "Date is required",
                            },
                            validate: (value) => CommonUtil.validateDate(value),
                          }}
                          render={({
                            field: { onChange, onBlur, value, ref },
                          }) => (
                            <ReactDatePicker
                              className="form-control"
                              placeholderText="Select date"
                              onChange={onChange}
                              onBlur={onBlur}
                              selected={value}
                              dateFormat="dd/MM/yyyy"
                              maxDate={new Date()}
                            />
                          )}
                          {...register("ifvRepaymentDate")}
                        />
                        <span className="vldn">
                          {errors.ifvRepaymentDate &&
                            errors.ifvRepaymentDate.message}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="col-md-12 mt-2">
                    <div className="form-group">
                      <label className="prog_lbl">
                        <strong>Exposure Remarks:</strong>
                        <div className="prgs">
                          <span className="lft_crt">
                            {4000 - input["ifvExpRemarks"].length} Characters
                            left
                          </span>
                          <LinearProgress
                            variant="determinate"
                            value={input["ifvExpRemarks"].length}
                          />
                        </div>
                      </label>
                      <textarea
                        className="form-control"
                        {...register("ifvExpRemarks", {
                          maxLength: {
                            value: 4000,
                            message: "The maximum length of the field is 4000",
                          },
                        })}
                        autoComplete="off"
                        maxLength="4000"
                        onChange={(e) => {
                          Pattern.sanitizeInput(e);
                          inputHandler(e.target.value, "ifvExpRemarks");
                        }}
                      />
                      <span className="vldn">
                        {errors.ifvExpRemarks && errors.ifvExpRemarks.message}
                      </span>
                    </div>
                  </div>

                  {/* Aggregate Exposure Status */}
                  <div className="sub_nrsn">
                    <div style={{ display: "inline", lineHeight: "1.8" }}>
                      <span>
                        (B) Aggregate Exposure cap for the{" "}
                        {groupName ? groupName : "Banks"} :
                      </span>

                      <input
                        className="form-control d-inline"
                        type="text"
                        style={{
                          width: "80px",
                          display: "inline-block",
                          margin: "0 10px",
                          verticalAlign: "middle",
                        }}
                        inputMode="decimal"
                        readOnly={!CommonUtil.isEmpty(groupName)}
                        {...register("aggregateExposure[0].capitalFunds", {
                          required: "Value is required",
                          validate: (value) => {
                            if (!value) return "Value is required";

                            const regex = /^\d{1,12}(\.\d{1,8})?$/;
                            if (parseFloat(value) < 0) {
                              return "Value cannot be negative";
                            }
                            if (!regex.test(value)) {
                              return "Max 12 digits allowed with up to 8 decimal places";
                            }
                            return true;
                          },
                        })}
                      />

                      <span>% of the capital funds of SIDBI</span>
                    </div>

                    {errors?.aggregateExposure?.[0]?.capitalFunds && (
                      <span className="text-danger">
                        {errors.aggregateExposure[0].capitalFunds.message}
                      </span>
                    )}
                  </div>

                  {/* Table Header */}
                  <div className="row">
                    <div className="col-md-1">
                      <strong style={{ paddingLeft: "10px" }}>S.No.</strong>
                    </div>
                    <div className="col-md-8">
                      <strong style={{ paddingLeft: "10px" }}>
                        Particulars
                      </strong>
                    </div>
                    <div className="col-md-3" style={{ paddingLeft: "6px" }}>
                      <strong>Amount (₹ in crore)</strong>
                    </div>
                    {/* <div className="col-md-1"></div> */}
                  </div>

                  {/* Dynamic Rows */}
                  {fields3.map((field, index) => (
                    <div className="container-fluid" key={field.id}>
                      <div className="row pt-2 pb-1">
                        {/* S.No */}
                        <div className="col-md-1">
                          <input
                            className="form-control"
                            type="text"
                            readOnly
                            inputMode="numeric"
                            {...register(`aggregateExposure[${index}].slNo`)}
                          />
                          {errors?.aggregateExposure?.[index]?.slNo && (
                            <span className="text-danger">
                              {errors.aggregateExposure[index].slNo.message}
                            </span>
                          )}
                        </div>

                        {/* Particulars */}
                        <div className="col-md-8">
                          <textarea
                            className="form-control"
                            maxLength={200}
                            {...register(
                              `aggregateExposure[${index}].particulars`,
                              {
                                required: "Field is required",
                                onChange: (e) => Pattern.sanitizeInput(e),
                                validate: (value) => {
                                  if (Pattern.validateHtmlTags().test(value))
                                    return "Invalid value";
                                  return true;
                                },
                              }
                            )}
                          />
                          {errors?.aggregateExposure?.[index]?.particulars && (
                            <span className="text-danger">
                              {
                                errors.aggregateExposure[index].particulars
                                  .message
                              }
                            </span>
                          )}

                          {/* Hidden Fields */}
                          <input
                            type="hidden"
                            {...register(`aggregateExposure[${index}].ifvId`)}
                            value={appId}
                          />
                          <input
                            type="hidden"
                            {...register(`aggregateExposure[${index}].id`)}
                          />
                          <input
                            type="hidden"
                            {...register(
                              `aggregateExposure[${index}].groupName`
                            )}
                            value={groupName}
                          />
                        </div>

                        {/* Amount */}
                        <div className="col-md-3">
                          <input
                            className="form-control text-end"
                            type="text"
                            inputMode="decimal"
                            autoComplete="off"
                            readOnly={!CommonUtil.isEmpty(groupName)}
                            onKeyDown={(e) => CommonUtil.handleNumericInput(e)}
                            {...register(`aggregateExposure[${index}].amount`, {
                              validate: (value) => {
                                if (!value) return "Value cannot be empty";
                                if (parseFloat(value) < 0) {
                                  return "Value cannot be negative";
                                }
                                const regex = /^\d{1,12}(\.\d{1,8})?$/;

                                if (!regex.test(value)) {
                                  return "Max 12 digits allowed with up to 8 decimal places";
                                }

                                return true;
                              },
                            })}
                          />

                          {index === 1 && (
                            <>
                               {!isLoading && (
                                <a
                                  href="#"
                                  onClick={(e) => {
                                    e.preventDefault();
                                    if (!groupName) {
                                      alert(
                                        "Group details not loaded yet. Please wait."
                                      );
                                      return;
                                    }
                                    setTrigger((prev) => !prev);
                                  }}
                                >
                                  Load Aggregate Exposure
                                </a>
                              )}

                              {isLoading && (
                                <div className="alert alert-info mt-2">
                                  <div className="d-flex align-items-center">
                                    <div
                                      className="spinner-border spinner-border-sm me-2"
                                      role="status"
                                    />
                                    <span>
                                      Fetching Aggregate Exposure data...
                                    </span>
                                  </div>
                                </div>
                              )}

                              {status === "PENDING" && !isLoading && (
                                <div className="alert alert-warning mt-2">
                                  Aggregate Exposure request submitted. Waiting
                                  for processing...
                                </div>
                              )}

                              {status === "PROCESSING" && (
                                <div className="alert alert-primary mt-2">
                                  Please wait for 3..4 minutes
                                </div>
                              )}

                              {status === "READY" && exposureData && (
                                <div className="alert alert-success mt-2">
                                  Aggregate Exposure data loaded successfully.
                                </div>
                              )}

                              {error && (
                                <div className="alert alert-danger mt-2">
                                  {error}
                                </div>
                              )}
                            </>
                          )}

                          {errors?.aggregateExposure?.[index]?.amount && (
                            <span className="text-danger">
                              {errors.aggregateExposure[index].amount.message}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="row" style={{ marginTop: "1rem" }}>
              <div className="col-md-12">
                <div className="otr_def">
                  <h5 className="HdngTitl">
                    Rating (External). EWS/Adverse News, if any/Regularity
                    Restrictions, if any (Last 6 Months)
                  </h5>
                  <div className="row">
                    <div className="col-md-6">
                      <div className="form-group">
                        <label className="prog_lbl">
                          <strong>i. External Rating:</strong>
                          <div className="prgs">
                            <span className="lft_crt">
                              {4000 - input["extRating"].length} Characters left
                            </span>
                            <LinearProgress
                              variant="determinate"
                              value={input["extRating"].length}
                            />
                          </div>
                        </label>

                        <textarea
                          className="form-control"
                          id="ifvExternalRating"
                          {...register("ifvExternalRating", {
                            maxLength: {
                              value: 4000,
                              message:
                                "The maximum length of the field is 4000",
                            },
                            validate: (value) => {
                              if (Pattern.validateHtmlTags().test(value))
                                return "Invalid value";
                              return true;
                            },
                          })}
                          maxLength="4000"
                          onChange={(e) => {
                            Pattern.sanitizeInput(e);
                            inputHandler(e.target.value, "extRating");
                          }}
                        />
                        <span className="vldn">
                          {" "}
                          {errors.ifvExternalRating &&
                            errors.ifvExternalRating.message}
                        </span>
                      </div>
                    </div>

                    <div className="col-md-6">
                      <div className="form-group">
                        <label className="prog_lbl">
                          <strong>ii. Internal Rating:</strong>
                          <div className="prgs">
                            <span className="lft_crt">
                              {4000 - input["intRating"].length} Characters left
                            </span>
                            <LinearProgress
                              variant="determinate"
                              value={input["intRating"].length}
                            />
                          </div>
                        </label>

                        <textarea
                          className="form-control"
                          id="internalRating"
                          {...register("internalRating", {
                            maxLength: {
                              value: 4000,
                              message:
                                "The maximum length of the field is 4000",
                            },
                            validate: (value) => {
                              if (Pattern.validateHtmlTags().test(value))
                                return "Invalid value";
                              return true;
                            },
                          })}
                          maxLength="4000"
                          onChange={(e) => {
                            Pattern.sanitizeInput(e);
                            inputHandler(e.target.value, "intRating");
                          }}
                        />
                        <span className="vldn">
                          {" "}
                          {errors.internalRating &&
                            errors.internalRating.message}
                        </span>
                      </div>
                    </div>

                    <div className="col-md-6">
                      <div className="form-group">
                        <label className="prog_lbl">
                          <strong>iii. EWS</strong>
                          <div className="prgs">
                            <span className="lft_crt">
                              {4000 - input["ews"].length} Characters left
                            </span>
                            <LinearProgress
                              variant="determinate"
                              value={input["ews"].length}
                            />
                          </div>
                        </label>

                        <textarea
                          className="form-control"
                          id="ifvEws"
                          {...register("ifvEws", {
                            maxLength: {
                              value: 4000,
                              message:
                                "The maximum length of the field is 4000",
                            },
                            validate: (value) => {
                              if (Pattern.validateHtmlTags().test(value))
                                return "Invalid value";
                              return true;
                            },
                          })}
                          maxLength="4000"
                          onChange={(e) => {
                            Pattern.sanitizeInput(e);
                            inputHandler(e.target.value, "ews");
                          }}
                        />
                        <span className="vldn">
                          {errors.ifvEws && errors.ifvEws.message}
                        </span>
                      </div>
                    </div>

                    <div className="col-md-6">
                      <div className="form-group">
                        <label className="prog_lbl">
                          <strong>iv. Adverse News About Bank:</strong>
                          <div className="prgs">
                            <span className="lft_crt">
                              {4000 - input["advNews"].length} Characters left
                            </span>
                            <LinearProgress
                              variant="determinate"
                              value={input["advNews"].length}
                            />
                          </div>
                        </label>
                        <textarea
                          className="form-control"
                          id="ifvAdverseNews"
                          {...register("ifvAdverseNews", {
                            maxLength: {
                              value: 4000,
                              message:
                                "The maximum length of the field is 4000",
                            },
                            validate: (value) => {
                              if (Pattern.validateHtmlTags().test(value))
                                return "Invalid value";
                              return true;
                            },
                          })}
                          maxLength="4000"
                          onChange={(e) => {
                            Pattern.sanitizeInput(e);
                            inputHandler(e.target.value, "advNews");
                          }}
                        />
                        <span className="vldn">
                          {" "}
                          {errors.ifvAdverseNews &&
                            errors.ifvAdverseNews.message}
                        </span>
                      </div>
                    </div>
                    <div className="col-md-6">
                      <div className="form-group">
                        <label className="prog_lbl">
                          <strong>
                            v. Monetary Penalty/Regularity Restrictions
                          </strong>
                          <div className="prgs">
                            <span className="lft_crt">
                              {4000 - input["monPen"].length} Characters left
                            </span>
                            <LinearProgress
                              variant="determinate"
                              value={input["monPen"].length}
                            />
                          </div>
                        </label>
                        <textarea
                          className="form-control"
                          id="ifvMonetary"
                          {...register("ifvMonetary", {
                            maxLength: {
                              value: 4000,
                              message:
                                "The maximum length of the field is 4000",
                            },
                            validate: (value) => {
                              if (Pattern.validateHtmlTags().test(value))
                                return "Invalid value";
                              return true;
                            },
                          })}
                          maxLength="4000"
                          onChange={(e) => {
                            Pattern.sanitizeInput(e);
                            inputHandler(e.target.value, "monPen");
                          }}
                        />
                        <span className="vldn">
                          {" "}
                          {errors.ifvMonetary && errors.ifvMonetary.message}
                        </span>
                      </div>
                    </div>

                    {showSFB && (
                      <div className="col-md-6">
                        <div className="form-group">
                          <label className="prog_lbl">
                            <strong>Other Remarks</strong>
                            <div className="prgs">
                              <span className="lft_crt">
                                {4000 - input["othRem"].length} Characters left
                              </span>
                              <LinearProgress
                                variant="determinate"
                                value={input["othRem"].length}
                              />
                            </div>
                          </label>

                          <textarea
                            className="form-control"
                            id="otherRemarks"
                            {...register("otherRemarks", {
                              maxLength: {
                                value: 4000,
                                message:
                                  "The maximum length of the field is 4000",
                              },
                              validate: (value) => {
                                if (Pattern.validateHtmlTags().test(value))
                                  return "Invalid value";
                                return true;
                              },
                            })}
                            maxLength="4000"
                            onChange={(e) => {
                              Pattern.sanitizeInput(e);
                              inputHandler(e.target.value, "othRem");
                            }}
                          />
                          <span className="vldn">
                            {" "}
                            {errors.otherRemarks && errors.otherRemarks.message}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-12">
                <div className="button-container-center">
                  {(appStatus === "" ||
                    appStatus === "New" ||
                    (locked && !isMaker)) && (
                    <button type="submit" className="btn btnSave">
                      {appId > 0 ? "Update" : "Save"}
                    </button>
                  )}
                  {appId > 0 && (
                    <button
                      type="button"
                      className="btn btnNext"
                      onClick={goToNext}
                    >
                      Next <i className="fa fa-arrow-right"></i>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
      {loading && <Loading />}
      <MessageModal
        open={isOpen}
        onClose={hideMessage}
        message={messageConfig.message}
        type={messageConfig.type}
        totalMessages={totalMessages}
        currentIndex={currentIndex}
        onNext={nextMessage}
        onPrev={prevMessage}
        hasNext={hasNext}
        hasPrev={hasPrev}
      />
    </Fragment>
  );
};
export default BasicInfo;
