import Loading from "components/Loading";
import { useEffect, useState } from "react";
import { Card, Col, Container, Row } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import IfvAppraisalService from "services/IfvAppraisalService";
import MinutesService from "services/MinutesService";
import UserService from "services/UserService";
const Minutes = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [existingMeetingDetailsCount, setExistingMeetingDetailsCount] =
    useState("");
  const [approvedAppCount, setApprovedAppCount] = useState("");
  const [isMaker, setMaker] = useState(false);
  const [isChecker, setChecker] = useState(false);
  const [isAdminChecker, setAdminChecker] = useState(false);
  const [isMakerConvenor, setMakerConvenor] = useState(false);
  useEffect(() => {
    const user = IfvAppraisalService.getCurrentUser();
    setMaker(UserService.isMaker(user));
    setChecker(UserService.isChecker(user));
    setAdminChecker(UserService.isAdminChecker(user));
    setMakerConvenor(UserService.isMakerConvenor(user));
    getAllMeetingDetails(user);
  }, []);
  const handleNewOrExistingMeeting = (mtCode) => {
    navigate("/ifv/meeting-details", {
      state: { mtCode },
    });
  };
  const getAllMeetingDetails = (user) => {
    setLoading(true);
    MinutesService.getLoiAndMinsCount(user.ofrType, user.ofrCode)
      .then((response) => {
        Object.entries(response.data).forEach(([key, value]) => {
          if (key === "LOI") {
            setApprovedAppCount(value);
          } else {
            setExistingMeetingDetailsCount(value);
          }
        });
      })
      .catch((error) => {
        const resMessage =
          (error.response &&
            error.response.data &&
            error.response.data.message) ||
          error.message ||
          error.toString();
        console.error("Error:", resMessage);
        alert("Error occurred while loading existing meeting details");
      })
      .finally(() => setLoading(false));
  };
  const navigateToMinutesSummary = (mode) => {
    navigate("/ifv/minutesSummary", {
      state: { mode },
    });
  };
  const navigateToLoiSummary = () => {
    navigate("/ifv/viewSignedLoiSummary");
  };

  return (
    <div className={loading ? "blur-background" : ""}>
      <Container fluid>
        <Row>
          <div className="col-md-12 p-0">
            <div className="ds_wrap">
              <h5>Minutes</h5>
              <div className="row mb-4 m-2">
                {(isMaker || isChecker || isAdminChecker) && (
                  <Col lg="3" sm="6">
                    <Card className="card-stats">
                      <Card.Body>
                        <Row>
                          <Col xs="5">
                            <div className="icon-big text-center icon-warning">
                              <i className="fa fa-calendar-plus text-success"></i>
                            </div>
                          </Col>
                          <Col xs="7">
                            <div className="numbers">
                              <p className="card-category">New Agenda</p>
                            </div>
                          </Col>
                        </Row>
                      </Card.Body>
                      <Card.Footer>
                        <hr />
                        <div className="stats">
                          <a
                            onClick={() => handleNewOrExistingMeeting(0)}
                            className="hvr-icon-wobble-horizontal"
                          >
                            &nbsp;Create New{" "}
                            <i className="fa fa-arrow-right hvr-icon"></i>
                          </a>
                        </div>
                      </Card.Footer>
                    </Card>
                  </Col>
                )}
                <Col lg="3" sm="6">
                  <Card className="card-stats">
                    <Card.Body>
                      <Row>
                        <Col xs="5">
                          <div className="icon-big text-center icon-warning">
                            <i className="fa fa-calendar-days text-info"></i>
                          </div>
                        </Col>
                        <Col xs="7">
                          <div className="numbers">
                            <p className="card-category">Existing Minutes</p>
                            <Card.Title as="h4">
                              {existingMeetingDetailsCount}
                            </Card.Title>
                          </div>
                        </Col>
                      </Row>
                    </Card.Body>
                    <Card.Footer>
                      <hr />
                      <div className="stats">
                        <a
                          href="#"
                          onClick={(e) => {
                            e.preventDefault();
                            navigateToMinutesSummary("Min");
                          }}
                          className="hvr-icon-wobble-horizontal"
                        >
                          &nbsp;Know More{" "}
                          <i className="fa fa-arrow-right hvr-icon"></i>
                        </a>
                      </div>
                    </Card.Footer>
                  </Card>
                </Col>
                <Col lg="3" sm="6">
                  <Card className="card-stats">
                    <Card.Body>
                      <Row>
                        <Col xs="5">
                          <div className="icon-big text-center icon-warning">
                            <i className="fa fa-handshake text-success"></i>
                          </div>
                        </Col>
                        <Col xs="7">
                          <div className="numbers">
                            <p className="card-category">Approved Minutes</p>
                            <Card.Title as="h4">{approvedAppCount}</Card.Title>
                          </div>
                        </Col>
                      </Row>
                    </Card.Body>
                    <Card.Footer>
                      <hr />
                      <div className="stats">
                        <a
                          href="#"
                          onClick={(e) => {
                            e.preventDefault();
                            navigateToMinutesSummary("AP");
                          }}
                          className="hvr-icon-wobble-horizontal"
                        >
                          &nbsp;Know More{" "}
                          <i className="fa fa-arrow-right hvr-icon"></i>
                        </a>
                      </div>
                    </Card.Footer>
                  </Card>
                </Col>
              </div>
            </div>
          </div>
        </Row>

        <Row>
          <div className="col-md-12 p-0">
            <div className="ds_wrap">
              <h5>LoI</h5>
              <div className="row mb-4 m-2">
                <Col lg="3" sm="6">
                  <Card className="card-stats">
                    <Card.Body>
                      <Row>
                        <Col xs="5">
                          <div className="icon-big text-center icon-warning">
                            <i className="fa fa-file-signature text-primary"></i>
                          </div>
                        </Col>
                        <Col xs="7">
                          <div className="numbers">
                            <p className="card-category">Generate LoI</p>
                            <Card.Title as="h4"></Card.Title>
                          </div>
                        </Col>
                      </Row>
                    </Card.Body>
                    <Card.Footer>
                      <hr />
                      <div className="stats">
                        <a
                          href="#"
                          onClick={(e) => {
                            e.preventDefault();
                            navigateToMinutesSummary("LOI");
                          }}
                          className="hvr-icon-wobble-horizontal"
                        >
                          &nbsp;Know More{" "}
                          <i className="fa fa-arrow-right hvr-icon"></i>
                        </a>
                      </div>
                    </Card.Footer>
                  </Card>
                </Col>

                <Col lg="3" sm="6">
                  <Card className="card-stats">
                    <Card.Body>
                      <Row>
                        <Col xs="5">
                          <div className="icon-big text-center icon-warning">
                            <i className="fa fa-handshake text-success"></i>
                          </div>
                        </Col>
                        <Col xs="7">
                          <div className="numbers">
                            <p className="card-category">Submitted LoI</p>
                            <Card.Title as="h4"></Card.Title>
                          </div>
                        </Col>
                      </Row>
                    </Card.Body>
                    <Card.Footer>
                      <hr />
                      <div className="stats">
                        <a
                          href="#"
                          onClick={(e) => {
                            e.preventDefault();
                            navigateToLoiSummary();
                          }}
                          className="hvr-icon-wobble-horizontal"
                        >
                          &nbsp;Know More{" "}
                          <i className="fa fa-arrow-right hvr-icon"></i>
                        </a>
                      </div>
                    </Card.Footer>
                  </Card>
                </Col>
              </div>
            </div>
          </div>
        </Row>
        {loading && <Loading />}
      </Container>
    </div>
  );
};
export default Minutes;
