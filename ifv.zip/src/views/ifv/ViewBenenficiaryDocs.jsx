import {
    Clear as ClearIcon,
    Download as DownloadIcon,
    KeyboardArrowDown as ExpandIcon,
    KeyboardArrowUp as CollapseIcon
} from "@mui/icons-material";
import {
    Alert,
    Box,
    Chip,
    IconButton,
    Paper,
    Tooltip,
    Typography
} from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFnsV3";
import {
    keepPreviousData,
    QueryClient,
    QueryClientProvider,
    useQuery
} from "@tanstack/react-query";
import { format, isValid } from "date-fns";
import {
    MaterialReactTable,
    useMaterialReactTable
} from "material-react-table";
import { useMemo, useState } from "react";
import BeneficiaryApiService from "services/BeneficiaryApiService";

// ══════════════════════════════════════════════════════════════════
// QueryClient
// ══════════════════════════════════════════════════════════════════
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5,
      cacheTime: 1000 * 60 * 10,
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

// ══════════════════════════════════════════════════════════════════
// DATE RANGE FILTER COMPONENT
// Calendar-only, no manual typing allowed
// ══════════════════════════════════════════════════════════════════
function DateRangeFilter({ column }) {
  const filterValue = column.getFilterValue() ?? [null, null];
  const [from, to] = filterValue;

  const handleFromChange = (newVal) => {
    column.setFilterValue([newVal ? newVal.toISOString() : null, to]);
  };

  const handleToChange = (newVal) => {
    column.setFilterValue([from, newVal ? newVal.toISOString() : null]);
  };

  const handleClear = () => {
    column.setFilterValue([null, null]);
  };

  const hasValue = from || to;

  const fromDate = from && isValid(new Date(from)) ? new Date(from) : null;
  const toDate = to && isValid(new Date(to)) ? new Date(to) : null;

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          gap: 0.8,
          pt: 0.5,
          minWidth: 180,
        }}
      >
        <DatePicker
          label="From"
          value={fromDate}
          onChange={handleFromChange}
          maxDate={toDate ?? undefined}
          slotProps={{
            textField: {
              size: "small",
              variant: "outlined",
              fullWidth: true,
              inputProps: {
                readOnly: true,
                style: { cursor: "pointer", fontSize: 12 },
              },
              sx: {
                "& .MuiInputBase-root": {
                  fontSize: 12,
                  backgroundColor: "#fff",
                },
                "& .MuiInputLabel-root": { fontSize: 12 },
              },
            },
            field: { readOnly: true },
          }}
        />
        <DatePicker
          label="To"
          value={toDate}
          onChange={handleToChange}
          minDate={fromDate ?? undefined}
          slotProps={{
            textField: {
              size: "small",
              variant: "outlined",
              fullWidth: true,
              inputProps: {
                readOnly: true,
                style: { cursor: "pointer", fontSize: 12 },
              },
              sx: {
                "& .MuiInputBase-root": {
                  fontSize: 12,
                  backgroundColor: "#fff",
                },
                "& .MuiInputLabel-root": { fontSize: 12 },
              },
            },
            field: { readOnly: true },
          }}
        />
        {hasValue && (
          <Box sx={{ display: "flex", justifyContent: "flex-end" }}>
            <Tooltip title="Clear date filter">
              <IconButton size="small" onClick={handleClear} sx={{ p: 0.3 }}>
                <ClearIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Box>
        )}
      </Box>
    </LocalizationProvider>
  );
}

// ══════════════════════════════════════════════════════════════════
// SUB-TABLE COMPONENT
// ══════════════════════════════════════════════════════════════════
function DocumentsSubTable({ cifNumber, bankName }) {
  const [columnFilters, setColumnFilters] = useState([]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [sorting, setSorting] = useState([
    { id: "uploadDateTime", desc: true },
  ]);
  const [pagination, setPagination] = useState({
    pageIndex: 0,
    pageSize: 5,
  });
  const [downloading, setDownloading] = useState(null);

  // Build filters map — date range gets special serialization
  const filters = useMemo(() => {
    const filterMap = {};
    const textKeys = ["bnRefNo", "fileName", "uploadBy", "remarks"];

    columnFilters.forEach(({ id, value }) => {
      if (textKeys.includes(id) && value) {
        filterMap[id] = value;
      }
      if (id === "uploadDateTime" && Array.isArray(value)) {
        const [from, to] = value;
        // :white_check_mark: date-fns format instead of dayjs
        if (from && isValid(new Date(from)))
          filterMap["uploadDateFrom"] = format(new Date(from), "yyyy-MM-dd");
        if (to && isValid(new Date(to)))
          filterMap["uploadDateTo"] = format(new Date(to), "yyyy-MM-dd");
      }
    });

    return Object.keys(filterMap).length > 0 ? filterMap : undefined;
  }, [columnFilters]);

  const sortingParam =
    sorting.length > 0
      ? `${sorting[0].id}:${sorting[0].desc ? "desc" : "asc"}`
      : undefined;

  const { data, isError, isFetching, isLoading, error } = useQuery({
    queryKey: [
      "beneficiary-docs",
      cifNumber,
      pagination.pageIndex,
      pagination.pageSize,
      filters,
      sortingParam,
      globalFilter,
    ],
    queryFn: () =>
      BeneficiaryApiService.fetchBeneficiaryDocsByCif({
        cifNumber,
        page: pagination.pageIndex,
        size: pagination.pageSize,
        filters,
        sorting: sortingParam,
        globalFilter: globalFilter || undefined,
      }),
    enabled: !!cifNumber,
    placeholderData: keepPreviousData,
  });

  const handleDownload = async (row) => {
    setDownloading(row.original.id);
    try {
      await BeneficiaryApiService.downloadAppDocument(
        row.original.filePath,
        row.original.fileName
      );
    } catch (err) {
      console.error("Download failed:", err);
      alert("Failed to download file. Please try again.");
    } finally {
      setDownloading(null);
    }
  };

  const columns = useMemo(
    () => [
      {
        header: "Sl No",
        size: 60,
        enableSorting: false,
        enableColumnFilter: false,
        Cell: ({ row, table }) => {
          const { pageIndex, pageSize } = table.getState().pagination;
          return pageIndex * pageSize + row.index + 1;
        },
      },
      {
        accessorKey: "bnRefNo",
        header: "BN Ref No",
        size: 140,
        enableColumnFilter: true,
      },
      {
        accessorKey: "fileName",
        header: "File Name",
        size: 200,
        enableColumnFilter: true,
        Cell: ({ cell }) => (
          <Tooltip title={cell.getValue() || ""}>
            <Typography variant="body2" noWrap sx={{ cursor: "pointer" }}>
              {cell.getValue() || "-"}
            </Typography>
          </Tooltip>
        ),
      },
      {
        accessorKey: "uploadDateTime",
        header: "Upload Date & Time",
        size: 180,
        enableColumnFilter: true,
        // :white_check_mark: Custom filter component — calendar only, no manual input
        Filter: ({ column }) => <DateRangeFilter column={column} />,
        // Disable the built-in filter mode toggling (no text/range mode switch needed)
        enableFilterMatchHighlighting: false,
        Cell: ({ cell }) => {
          const value = cell.getValue();
          if (!value) return "-";
          try {
            return new Date(value).toLocaleString("en-IN", {
              year: "numeric",
              month: "short",
              day: "2-digit",
              hour: "2-digit",
              minute: "2-digit",
            });
          } catch {
            return value;
          }
        },
      },
      {
        accessorKey: "uploadBy",
        header: "Uploaded By",
        size: 150,
        enableColumnFilter: true,
      },
      {
        accessorKey: "remarks",
        header: "Remarks",
        size: 200,
        enableColumnFilter: true,
        Cell: ({ cell }) => (
          <Tooltip title={cell.getValue() || ""}>
            <Typography variant="body2" noWrap>
              {cell.getValue() || "-"}
            </Typography>
          </Tooltip>
        ),
      },
    ],
    []
  );

  const table = useMaterialReactTable({
    columns,
    data: data?.content ?? [],
    rowCount: data?.totalElements ?? 0,
    manualPagination: true,
    manualSorting: true,
    manualFiltering: true,
    enableRowActions: true,
    positionActionsColumn: "last",
    displayColumnDefOptions: {
      "mrt-row-actions": {
        header: "Actions",
        size: 80,
        muiTableHeadCellProps: { sx: { minWidth: 80 } },
        muiTableBodyCellProps: { sx: { minWidth: 80 } },
      },
    },
    renderRowActions: ({ row }) => (
      <Box sx={{ display: "flex", gap: 0.5, justifyContent: "center" }}>
        <Tooltip title="Download Document">
          <span>
            <IconButton
              size="small"
              onClick={() => handleDownload(row)}
              color="primary"
              disabled={downloading === row.original.id}
            >
              <DownloadIcon fontSize="small" />
            </IconButton>
          </span>
        </Tooltip>
      </Box>
    ),
    state: {
      columnFilters,
      globalFilter,
      isLoading,
      pagination,
      showAlertBanner: isError,
      showProgressBars: isFetching || downloading !== null,
      sorting,
    },
    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
    onPaginationChange: setPagination,
    onSortingChange: setSorting,
    muiTablePaperProps: {
      elevation: 0,
      sx: {
        backgroundColor: "#F8F9FA",
        border: "1px solid #E0E0E0",
        overflowX: "auto",
        width: "100%",
      },
    },
    muiTableContainerProps: {
      sx: { overflowX: "auto", maxWidth: "100%" },
    },
    muiTableProps: {
      sx: { tableLayout: "auto", minWidth: 900 },
    },
    muiTableHeadCellProps: {
      sx: {
        backgroundColor: "#E3F2FD",
        fontWeight: "bold",
        whiteSpace: "nowrap",
      },
    },
    muiTableBodyCellProps: {
      sx: { whiteSpace: "nowrap" },
    },
  });

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Paper
        elevation={0}
        sx={{
          p: 2,
          backgroundColor: "#fff",
          border: "1px solid #C4DCED",
          overflow: "hidden",
          width: "100%",
        }}
      >
        <Box
          sx={{
            mb: 2,
            display: "flex",
            alignItems: "center",
            gap: 2,
            flexWrap: "wrap",
          }}
        >
          <Chip
            label={`Documents for: ${bankName}`}
            color="primary"
            variant="outlined"
            size="small"
          />
          <Chip
            label={`CIF: ${cifNumber}`}
            color="secondary"
            variant="outlined"
            size="small"
          />
          {data?.totalElements > 0 && (
            <Chip
              label={`Total: ${data.totalElements} documents`}
              size="small"
            />
          )}
        </Box>

        {isError && (
          <Alert severity="error" sx={{ mb: 2 }}>
            Failed to load documents: {error?.message || "Unknown error"}
          </Alert>
        )}

        <Box sx={{ overflowX: "auto", width: "100%" }}>
          <MaterialReactTable table={table} />
        </Box>
      </Paper>
    </LocalizationProvider>
  );
}

// ══════════════════════════════════════════════════════════════════
// MAIN TABLE — unchanged from previous version
// ══════════════════════════════════════════════════════════════════
function BeneficiaryTable() {
  const [columnFilters, setColumnFilters] = useState([]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [sorting, setSorting] = useState([]);
  const [pagination, setPagination] = useState({ pageIndex: 0, pageSize: 10 });

  const cifNumber =
    columnFilters.find((f) => f.id === "cifNumber")?.value ?? "";
  const bankName = columnFilters.find((f) => f.id === "bankName")?.value ?? "";

  const sortingParam =
    sorting.length > 0
      ? `${sorting[0].id}:${sorting[0].desc ? "desc" : "asc"}`
      : undefined;

  const { data, isError, isFetching, isLoading, error } = useQuery({
    queryKey: [
      "beneficiaries",
      pagination.pageIndex,
      pagination.pageSize,
      cifNumber,
      bankName,
      sortingParam,
      globalFilter,
    ],
    queryFn: () =>
      BeneficiaryApiService.fetchBeneficiaryDataForIfv({
        page: pagination.pageIndex,
        size: pagination.pageSize,
        cifNumber: cifNumber || undefined,
        bankName: bankName || undefined,
        sorting: sortingParam,
        globalFilter: globalFilter || undefined,
      }),
    placeholderData: keepPreviousData,
  });

  const columns = useMemo(
    () => [
      {
        header: "Sl No",
        size: 70,
        enableSorting: false,
        enableColumnFilter: false,
        Cell: ({ row, table }) => {
          const { pageIndex, pageSize } = table.getState().pagination;
          return pageIndex * pageSize + row.index + 1;
        },
      },
      {
        accessorKey: "cifNumber",
        header: "CIF Number",
        size: 150,
        enableColumnFilter: true,
      },
      {
        accessorKey: "bankName",
        header: "Bank Name",
        size: 250,
        enableColumnFilter: true,
        Cell: ({ cell }) => (
          <Tooltip title={cell.getValue() || ""}>
            <Typography variant="body2" noWrap>
              {cell.getValue() || "-"}
            </Typography>
          </Tooltip>
        ),
      },
    ],
    []
  );

  const table = useMaterialReactTable({
    columns,
    data: data?.content ?? [],
    rowCount: data?.totalElements ?? 0,
    manualPagination: true,
    manualSorting: true,
    manualFiltering: true,
    enableExpanding: true,
    enableExpandAll: false,
    muiExpandButtonProps: ({ row }) => ({
      children: row.getIsExpanded() ? <CollapseIcon /> : <ExpandIcon />,
    }),
    renderDetailPanel: ({ row }) => (
      <Box sx={{ backgroundColor: "#fff", width: "100%", overflow: "hidden" }}>
        {row.getIsExpanded() && (
          <DocumentsSubTable
            cifNumber={row.original.cifNumber}
            bankName={row.original.bankName}
          />
        )}
      </Box>
    ),
    muiDetailPanelProps: { sx: { padding: "8px 16px" } },
    state: {
      columnFilters,
      globalFilter,
      isLoading,
      pagination,
      showAlertBanner: isError,
      showProgressBars: isFetching,
      sorting,
    },
    onColumnFiltersChange: setColumnFilters,
    onGlobalFilterChange: setGlobalFilter,
    onPaginationChange: setPagination,
    onSortingChange: setSorting,
  });

  return (
    <Box>
      {isError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          Failed to load beneficiary data: {error?.message || "Unknown error"}
        </Alert>
      )}
      <MaterialReactTable table={table} />
    </Box>
  );
}

export default function ViewBeneficiarySummary() {
  return (
    <QueryClientProvider client={queryClient}>
      <BeneficiaryTable />
    </QueryClientProvider>
  );
}
