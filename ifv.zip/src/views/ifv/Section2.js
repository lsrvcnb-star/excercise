import { LinearProgress } from '@mui/material';
import cnfrm from 'assets/img/alert.gif';
import Loading from 'components/Loading';
import MessageModal from 'components/MessageModal';
import ProposalHeader from 'components/ProposalHeader';
import SectionNavigation from 'components/SectionNavigation';
import { useErrorHandler } from 'hooks/useErrorHandler';
import useMessageModal from 'hooks/useMessageModal';
import { Fragment, useEffect, useState } from 'react';
import Accordion from 'react-bootstrap/Accordion';
import { confirmAlert } from 'react-confirm-alert';
import 'react-confirm-alert/src/react-confirm-alert.css';
import ReactDatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { Controller, useFieldArray, useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
import IfvAppraisalService from 'services/IfvAppraisalService';
import UserService from 'services/UserService';
import { Highlights } from 'services/constants/Highlights';
import CommonUtil from 'services/utils/CommonUtil';
import Pattern from 'services/validators/Pattern';

const SectionTwo = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const showSFB = location.state ? location.state.showSFB : null;
    const appId = location.state ? location.state.appId : 0;
    const [loading, setLoading] = useState(true)
    const {
        showMessage,
        hideMessage,
        isOpen,
        messageConfig,
        totalMessages,
        currentIndex,
        nextMessage,
        prevMessage,
        hasNext,
        hasPrev
    } = useMessageModal();
    const { handleApiError } = useErrorHandler(showMessage);

    const { control, register, handleSubmit, formState: { errors } } = useForm({
        mode: "onBlur"
    });

    const { control: control7, register: register7, handleSubmit: handleSubmitOfFinancialHighlights, setValue: setValue7, getValues: getValues7, formState: { errors: errors7 }, } = useForm({
        mode: "onBlur",
        defaultValues: {
            financialHighlights: [{ fhParticular: "Share Capital" }, { fhParticular: "Reserves" }, { fhParticular: "Net worth" },
            { fhParticular: "Deposits" }, { fhParticular: "Borrowings" }, { fhParticular: "Advances" }, { fhParticular: "Interest Income" },
            { fhParticular: "Other Income" }, { fhParticular: "Operating Profit" }, { fhParticular: "Net profit/loss" },
            { fhParticular: "GNPA (%)" }, { fhParticular: "Net NPA (%)" }, { fhParticular: "CRAR (%)" },
            { fhParticular: "CET1 (%)" }, { fhParticular: "CCB (%)" }, { fhParticular: "NIM (%)" }, { fhParticular: "PCR (%)" }]
        },
    });

    const { control: control8, register: register8, handleSubmit: handleSubmitOfEligibility, setValue, formState: { errors: errors8 }, } = useForm({
        mode: "onBlur",
        defaultValues: {
            ucbEligibility: [{ particulars: "CRAR", bfsNorm: "Minimum 12%", relaxationCap: "No relaxation." },
            { particulars: "Networth", bfsNorm: "> or = Rs.100 crore", relaxationCap: "No relaxation." },
            { particulars: "Gross NPA", bfsNorm: "<7%", relaxationCap: "No relaxation." },
            { particulars: "Net NPA", bfsNorm: "<3%", relaxationCap: "No relaxation." },
            { particulars: "Profitability", bfsNorm: "Net profit in 3 out of the last 4 FYs. In case of net loss in any of the years, there should be operating profit in that year.", relaxationCap: "No relaxation." },
            { particulars: "Status", bfsNorm: "Scheduled", relaxationCap: "No relaxation." },
            { particulars: "Category", bfsNorm: "Tier - 3 and Tier - 4", relaxationCap: "No relaxation." }
            ]
        },
    });

    const { control: control9, register: register9, handleSubmit: handleSubmitOfUcbCriteria, setValue: setValue9, formState: { errors: errors9 }, } = useForm({
        mode: "onBlur",
        defaultValues: {
            ucbCriteria: [{ criteriaParameters: "The CRAR shall be at least 1 percentage point above the minimum CRAR applicable to an UCB as on the reference date", complied: 'Y' },
            { criteriaParameters: "Net NPA of not more than 3%;", complied: 'Y' },
            { criteriaParameters: "Net profit for at least three out of the preceding four years subject to it not having incurred a net loss in the immediate preceding year", complied: 'Y' },
            { criteriaParameters: "No default in the maintenance of CRR / SLR during the preceding financial year;", complied: 'Y' },
            { criteriaParameters: "Sound internal control system with at least two professional directors on the Board", complied: 'Y' },
            { criteriaParameters: "Core Banking Solution (CBS) fully implemented", complied: 'Y' },
            { criteriaParameters: "No monetary penalty should have been imposed on the bank on account of violation of RBI directives / guidelines during the last two financial years", complied: 'Y' }]
        },
    });


    const { fields: fields6, append: append6, remove: remove6 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "financialHighlights", // unique name for your Field Array
    });

    const { fields: fields7, append: append7, remove: remove7 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "collectionEfficiency", // unique name for your Field Array
    });

    const { fields: fields8, append: append8, remove: remove8 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "restructuredAssets", // unique name for your Field Array
    });

    const { fields: fields9, append: append9, remove: remove9 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "statusData", // unique name for your Field Array
    });

    const { fields: fields10, append: append10, remove: remove10 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "ucbFinc", // unique name for your Field Array
    });

    const { fields: fields11, append: append11, remove: remove11 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "ucbEligibility", // unique name for your Field Array,
    });

    const { fields: fields12, append: append12, remove: remove12 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "ucbCriteria", // unique name for your Field Array,
    });

    const [ecId, setEcId] = useState(0)
    const [fhId, setFhId] = useState(0)
    const [locked, setLocked] = useState(false)
    const [ifvApp, setIfvApp] = useState({})
    const [isMaker, setMaker] = useState(false)
    const [generalAndRsfb, setGeneralAndRsfb] = useState(false)
    const [fabiaMsmeRampe, setFabiaMsmeRampe] = useState(false)

    const [mserScheme, setMserScheme] = useState(false)
    const [rmseScheme, setRmseScheme] = useState(false)

    const [ucb, setUcb] = useState(false)
    const [rrb, setRRB] = useState(false)

    const initialState = {
        fhFinperformance: '',
        fhAssestProfile: '',
        fhLiabilities: '',
        fhProfitabilities: '',
        fhEqulity: '',
        fhHighlights: '',
        fhDisclosure: '',
        fhCollection: '',
        fhStatutory: '',
        fhStatus: '',
        ecRemarks: '',
        ecRmseRemarks: '',
        ecRmseAssistance: '',
        ecRbiCompliance: '',
        ecSdbiFixed: '',
        ecRmseRegular: '',
        ecRemarks1: '',
        ecRmseIcdd: '',
        ecFabiaRemarks: '',
        ecFabiaStatus: '',
        financialPerformance2: '',
        rbiGuidelines: ''
    }
    const [input, setInput] = useState(initialState);
    const inputHandler = (value, input) => {
        setInput(prevState => ({ ...prevState, [input]: value }));
    }

    const [editable, setEditable] = useState(false)
    const [rmseSchemesList, setRmseSchemesList] = useState([])

    useEffect(() => {
        if (showSFB === null) {
            alert('Invalid scheme')
            navigate(-1);
        }

        if (showSFB) {
            for (let i = 0; i < 5; i++) {
                append7({})
            }
        }

        for (let i = 0; i < 2; i++) {
            append8({})
        }

        for (let i = 0; i < 3; i++) {
            append9({})
        }

        const user = IfvAppraisalService.getCurrentUser();

        setMaker(UserService.isMaker(user))

        IfvAppraisalService.getIfvAppById(appId).then(
            (response) => {
                setIfvApp(response.data)
                if (response.data.ifvBankType === 'UCB') {
                    setUcb(true)

                    getUcbFincByIfvId()
                    getUcbEligibilityByIfvId(true, false)
                    getUcbCriteriaByIfvId(response.data.ifvName)
                    getFinancialHighlightsByIfvId(false)
                } else if (response.data.ifvBankType === 'RRB') {
                    setRRB(true)
                    getUcbEligibilityByIfvId(false, true)
                    getUcbCriteriaByIfvId(response.data.ifvName)
                    setRmseSchemesList(prev => ({ ...prev, 0: 'RMSE- (Regular)' }))
                    setRmseSchemesList(prev => ({ ...prev, 1: 'RMSE- (ICDD)' }))
                    getFinancialHighlightsByIfvId(true)
                } else {
                    setUcb(false)
                    setRRB(false)
                    getFinancialHighlightsByIfvId(false)
                }
            },
            (error) => {
                handleApiError(error, 'loading App Data')
            }
        )

        IfvAppraisalService.getAllSchemesOnIfvId(appId).then(
            (response) => {
                let ind = 0;
                const distinctData = response.data.filter(
                    (item, index, self) =>
                        index === self.findIndex((t) => t.prFundname === item.prFundname)
                );

                const updatedRmseSchemesList = { ...rmseSchemesList };

                distinctData.forEach((item, index) => {

                    if (item.prFundcode === '01' && item.prSchemeName.includes('SFB') && showSFB) {
                        setGeneralAndRsfb(true)
                    }
                    if (item.prFundname.toLowerCase().includes('rmse')) {
                        setRmseScheme(true)
                        if (!item.prFundname.includes('ICDD')) {
                            //setRmseSchemesList(prev => ({ ...prev, [ind]: item.prFundname }));
                            updatedRmseSchemesList[ind] = item.prFundname;
                            ++ind;
                        }
                    }
                    if (!item.prFundname.toLowerCase().includes('rmse') && item.prSchemeName === 'MSERS') {
                        setMserScheme(true)
                    }
                });
                //setRmseSchemesList(prev => ({ ...prev, [ind]: 'RMSE- (ICDD)' }))
                updatedRmseSchemesList[ind] = 'RMSE- (ICDD)';
                setRmseSchemesList(updatedRmseSchemesList);
                setLastInd(ind)
                getEligibilityByIfvId(ind);

            },
            (error) => {
                handleApiError(error, 'loading scheme data')
            }
        )

        for (let i = 0; i < 17; i++) {
            append6({})
        }

        getTblFwdDetail()
    }, []);

    const [appStatus, setAppStatus] = useState('')

    const getTblFwdDetail = () => {
        IfvAppraisalService.getTblFwdDetail(appId)
            .then((response) => {
                const status = response.data.appStatus
                switch (status) {
                    case 'LK':
                        setLocked(true)
                        setEditable(false)
                        setAppStatus('Locked')
                        break
                    case 'NW':
                        setLocked(false)
                        setEditable(true)
                        setAppStatus('New')
                        break
                    case 'CN':
                        setLocked(false)
                        setEditable(false)
                        setAppStatus('Confirmed')
                        break
                    case 'AP':
                        setLocked(false)
                        setEditable(false)
                        setAppStatus('Approved')
                        break
                }
            })
            .catch(error => {
                handleApiError(error, 'loading TBL data')
            })
    }

    const [ecPsbsSelected, setEcPsbsSelected] = useState(false)
    const [sectForChecked, setSectForChecked] = useState(false)
    const handleEcPsbsCheckBox = () => {
        setEcPsbsSelected((prevChecked) => !prevChecked)
    }

    const handleSectForCheckBox = () => {
        setSectForChecked((prevChecked) => !prevChecked)
    }

    const [lastInd, setLastInd] = useState(0)

    const getEligibilityByIfvId = (ind) => {
        IfvAppraisalService.getEligibilityByIfvId(appId).then(response => {
            const appData = response.data
            setValue('ecId', appData.ecId)
            setEcId(appData.ecId)
            setValue('ifvId', appData.ifvId)

            let ecRemarksNote;

            if (appData.ecId > 0) {
                ecRemarksNote = appData.ecRemarks;
            } else {
                if (showSFB) {
                    ecRemarksNote = 'Any relaxation to be approved by IFCC - DMD';
                } else {
                    ecRemarksNote = 'Any relaxation to be approved by IFCC - DMD';
                }
            }

            let ecRemarksNote1;

            if (appData.ecId > 0) {
                ecRemarksNote1 = appData.ecRemarks1;
            } else {
                if (showSFB) {
                    ecRemarksNote1 = 'No relaxation';
                } else {
                    ecRemarksNote1 = 'Any relaxation to be approved by IFCC - DMD';
                }
            }

            setValue('ecRemarks', ecRemarksNote)
            setValue('ecBfsnorms', appData.ecBfsnorms)
            setValue('ecRemarks1', ecRemarksNote1)
            setValue('ecBfsnorms1', appData.ecBfsnorms1)

            if (appData.ecId > 0) {
                setValue('ecBfnormseligibility', appData.ecBfnormseligibility)
                setValue('rmse1Data', appData.rmse1Data)
                setValue('rmse2Data', appData.rmse2Data)
                setValue('rmse3Data', appData.rmse3Data)
                setValue('rmse4Data', appData.rmse4Data)
                setValue('rmse5Data', appData.rmse5Data)
            } else {
                if (showSFB) {
                    setValue('ecBfnormseligibility', 'Net NPA less than 6%.')
                } else {
                    setValue('ecBfnormseligibility', 'Net NPA less than 6%.')
                }

                setValue('rmse1Data', 'Eligibility as per RBI letter dated _________, for having achived PSL target for lending  to Micro enterprise in FY _____.')

                if (ind === 0) {
                    setValue('rmse1Data', 'Availability of assets in the 196 identified credit deficient districts.')
                } else if (ind === 1) {
                    setValue('rmse2Data', 'Availability of assets in the 196 identified credit deficient districts.')
                } else if (ind === 2) {
                    setValue('rmse3Data', 'Availability of assets in the 196 identified credit deficient districts.')
                } else if (ind === 3) {
                    setValue('rmse4Data', 'Availability of assets in the 196 identified credit deficient districts.')
                } else if (ind === 4) {
                    setValue('rmse5Data', 'Availability of assets in the 196 identified credit deficient districts.')
                }
            }

            setValue('ecPsbs', appData.ecPsbs)

            setEcPsbsSelected((appData.ecPsbs != null && appData.ecPsbs === 'true') ? true : false)
            setSectForChecked((appData.ecSectForEignBank != null && appData.ecSectForEignBank === 'true') ? true : false)
            setValue('ecSectForEignBank', appData.ecSectForEignBank)
            if (appData.ecNnpaDate != null) {
                setValue('ecNnpaDate', new Date(appData.ecNnpaDate))
            }
            setValue('ecNnpaPercent', appData.ecNnpaPercent)
            setValue('ecNnoaRemarks', appData.ecNnoaRemarks)
            setValue('ecNnpaStatus', appData.ecNnpaStatus)
            setValue('ecRmseAssistance', appData.ecRmseAssistance)
            setValue('ecRmseStatus', appData.ecRmseStatus)
            setValue('ecAssstance', appData.ecAssstance)
            setValue('ecAssstanceStatus', appData.ecAssstanceStatus)
            setValue('ecRbiCompliance', appData.ecRbiCompliance)
            setValue('ecRbiStatus', appData.ecRbiStatus)
            if (appData.ecGsecDate != null) {
                setValue('ecGsecDate', new Date(appData.ecGsecDate))
            }
            setValue('ecGsecPercent', appData.ecGsecPercent)
            setValue('ecSdbiFixed', appData.ecSdbiFixed)
            setValue('ecSidbiRemarks', appData.ecSidbiRemarks)
            setValue('ecSidbiStatus', appData.ecSidbiStatus)
            if (appData.ecRmseDate != null) {
                setValue('ecRmseDate', new Date(appData.ecRmseDate))
            }
            //setValue('ecRmsEmiCrofy', appData.ecRmsEmiCrofy)
            setValue('ecRmseRemarks', appData.ecRmseRemarks)
            setValue('ecRmseStatus1', appData.ecRmseStatus1)
            setValue('ecIcddRemarks', appData.ecIcddRemarks)
            setValue('ecIcddStatus', appData.ecIcddStatus)
            setValue('ecFabiaRemarks', appData.ecFabiaRemarks)
            setValue('ecFabiaStatus', appData.ecFabiaStatus)

            if (appData.ecId != null && appData.ecId > 0) {
                setValue('ecFabiaStatus', appData.ecFabiaStatus)
                setValue('bankParameter', appData.bankParameter)
            } else {
                setValue('ecFabiaStatus', 'The sanctioning committee is authorized to relax the eligibility criteria for all categories of banks as mentioned above on case-to-case basis by looking at the overall picture of the concerned bank, the reasons behind weak numbers, if any, and the overall comfort available in extending support on merits based on the banks inherent strength, parentage, external rating and market intelligence.')
                setValue('bankParameter', 'The bank is meeting all the scheme parameters.')
            }

            setValue('rmse3Remarks', appData.rmse3Remarks)
            setValue('rmse4Remarks', appData.rmse4Remarks)
            setValue('rmse5Remarks', appData.rmse5Remarks)
            setValue('rmse3Status', appData.rmse3Status)
            setValue('rmse4Status', appData.rmse4Status)
            setValue('rmse5Status', appData.rmse5Status)
        },
            (error) => {
                handleApiError(error, 'loading Details of Eligibility')
            }
        )
    }

    const getUcbFincByIfvId = () => {
        for (let i = 0; i < 4; i++) {
            append10({})
        }
        IfvAppraisalService.getUcbFincByIfvId(appId).then(response => {
            const appData = response.data
            appData.forEach((item, index) => {
                setValue7(`ucbFinc[${index}].ifvId`, item.ifvId)
                setValue7(`ucbFinc[${index}].id`, item.id)

                if (!CommonUtil.isEmpty(item.date1)) {
                    setValue7(`ucbFinc[0].date1`, new Date(item.date1))
                }
                if (!CommonUtil.isEmpty(item.date2)) {
                    setValue7(`ucbFinc[0].date2`, new Date(item.date2))
                }
                if (!CommonUtil.isEmpty(item.note)) {
                    setValue7(`ucbFinc[0].note`, item.note)
                }
                setValue7(`ucbFinc[${index}].particulars`, item.particulars)
                setValue7(`ucbFinc[${index}].amount1`, item.amount1)
                setValue7(`ucbFinc[${index}].amount2`, item.amount2)

            })
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading UCB Finc')
            }
        )
    }

    const [RiMCStip1, setRiMCStip1] = useState('')
    const [comp1, setComp1] = useState('')
    const [RiMCStip2, setRiMCStip2] = useState('')
    const [comp2, setComp2] = useState('')
    const [ucbId1, setUcbId1] = useState(0)
    const [ucbId2, setUcbId2] = useState(0)

    const getUcbEligibilityByIfvId = (ucb, rrb) => {

        IfvAppraisalService.getUcbEligibilityByIfvId(appId).then(response => {
            const appData = response.data

            if (appData.length > 0) {

                const ucbElig = appData?.filter(item => item.eligibilityType === 'BFS')
                const rimcElig = appData?.filter(item => item.eligibilityType === 'RIMC')

                ucbElig.forEach((item, index) => {
                    remove11(index)
                    append11({})
                    setValue(`ucbEligibility[${index}].ifvId`, item.ifvId)
                    setValue(`ucbEligibility[${index}].id`, item.id)

                    if (!CommonUtil.isEmpty(item.complianceStatusYear)) {
                        setValue(`ucbEligibility[0].complianceStatusYear`, item.complianceStatusYear)
                    }

                    setValue(`ucbEligibility[${index}].particulars`, item.particulars)
                    setValue(`ucbEligibility[${index}].bfsNorm`, item.bfsNorm)
                    setValue(`ucbEligibility[${index}].complianceStatus`, item.complianceStatus)
                    setValue(`ucbEligibility[${index}].relaxationCap`, item.relaxationCap)
                })
                if (rimcElig.length > 0) {
                    rimcElig.forEach((item, index) => {
                        if (index === 0) {
                            setRiMCStip1(item.particulars)
                            setUcbId1(item.id)
                        }
                        if (index === 1) {
                            setUcbId2(item.id)
                            setRiMCStip2(item.particulars)
                        }

                        if (index === 0) {
                            setComp1(item.complianceStatus)

                        }
                        if (index === 1) {
                            setComp2(item.complianceStatus)
                        }

                    })
                }
            } else {
                if (rrb) {
                    for (let i = 0; i < 5; i++) {
                        append11({})
                        setValue(`ucbEligibility[0].bfsNorm`, '9% (minimum)')
                        setValue(`ucbEligibility[1].bfsNorm`, 'Rs. 100 crore (minimum)')
                        setValue(`ucbEligibility[2].particulars`, 'Net NPA')
                        setValue(`ucbEligibility[2].bfsNorm`, 'Less than 6%')
                        setValue(`ucbEligibility[3].particulars`, 'Profitability')
                        setValue(`ucbEligibility[3].bfsNorm`, 'Earning net profit in the two years immediately preceding financial years.')
                        setValue(`ucbEligibility[4].particulars`, 'Status')
                        setValue(`ucbEligibility[4].bfsNorm`, 'Scheduled')
                        setValue(`ucbEligibility[${i}].relaxationCap`, `Relaxation to be approved by the sanctioning committee for any parameters subject to RRB providing 'Comfort Letter' from Sponsor Bank.\n\nThe Comfort Letter would require the Sponsor Bank to confirm that it shall fully undertake on behalf of the RRB, any liability that may arise in respect of refinance extended by SIDBI, in case of RRB unable to meet the applicable norms as per SIDBI's existing criteria.`)
                    }
                }
                if (ucb) {
                    for (let i = 0; i < 7; i++) {
                        append11({})
                    }
                }
                //   setComp1(`${IFVName} is one of the top UCBs in the country, having rating Acuite A-/Stable. It has satisfactory financials and profit-making track record. Existing customer with excellent repayment track record.`)
                setRiMCStip1('SIDBI Board in its 213th meeting held on February 02, 2022 approved the proposal for extending refinance to UCBs and RRBs. Further Board advised that the Bank may initially maintain selectivity in taking exposures only on the well performing UCBs/RRBs in view of higher risks vis-a-vis scheduled commercial banks, including SFBs which are at present being covered under refinance operation.')
                if (ucb) {
                    setRiMCStip2('SIDBI Board in its 214th meeting held on May 17, 2022 while approving the policy framework for institutional finance vertical for FY 2023, felt that in view of the relatively higher risk profile of UCBs, to the extent feasible, suitable risk premium could be built into the pricing of loan to such entities which are below a threshold rating.')
                    //   setComp2('The proposed assistance being under RMSE-XIII scheme, the pricing is same as applicable for SCBs/SFBs.')
                }
            }

        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading UCB Eligibility')
            }
        )
    }

    const getFinancialHighlightsByIfvId = (rrb) => {
        setLoading(true)

        IfvAppraisalService.getCollEfficiency(appId).then(response => {
            const appData = response.data
            appData.forEach((item, index) => {
                setValue7(`collectionEfficiency[${index}].ifvId`, item.ifvId)
                setValue7(`collectionEfficiency[${index}].id`, item.id)
                setValue7(`collectionEfficiency[${index}].particulars`, item.particulars)
                setValue7(`collectionEfficiency[${index}].collectionEfficiency`, item.collectionEfficiency)
            })
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading Collection Efficiency')
            }
        )

        IfvAppraisalService.getRestructuredAssets(appId).then(response => {
            const appData = response.data
            appData.forEach((item, index) => {
                setValue7(`restructuredAssets[${index}].ifvId`, item.ifvId)
                setValue7(`restructuredAssets[${index}].id`, item.id)
                setValue7(`restructuredAssets[${index}].rsDate`, item.rsDate != null ? new Date(item.rsDate) : '')
                setValue7(`restructuredAssets[${index}].noOfAccounts`, item.noOfAccounts)
                setValue7(`restructuredAssets[${index}].rsAmount`, item.rsAmount)
            })
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading Restructured assets')
            }
        )

        IfvAppraisalService.getStatusOfListing(appId).then(response => {
            const appData = response.data
            appData.forEach((item, index) => {
                setValue7(`statusData[${index}].ifvId`, item.ifvId)
                setValue7(`statusData[${index}].id`, item.id)
                setValue7(`statusData[${index}].column1`, item.column1)
                setValue7(`statusData[${index}].column2`, item.column2)
                setValue7(`statusData[${index}].column3`, item.column3)
            })
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading Status of Listing')
            }
        )


        IfvAppraisalService.getFinancialHighlightsByIfvId(appId).then(response => {
            const appData = response.data
            if (CommonUtil.isEmpty(appData) || appData.length <= 0 || CommonUtil.isEmpty(appData[0].fhId)) {
                if (rrb) {

                    const rrbGuidelines = '1. DOR.ACC.REC.No.45/21.04.018/2021-22 dated August 30, 2021, updated as on April 01, 2024, on Disclosure in the “Notes to Accounts” to the Financial Statements - Divergence in the asset classification & provisioning is not applicable on the RRBs.\n2.NABARD conducts the statutory inspections of State Cooperative Banks, District Central Cooperative Banks and Regional Rural Banks under the Banking Regulation Act, 1949/(AACS) but the regulatory powers continue to be vested with the Reserve Bank of India.';
                    setValue7(`financialHighlights[0].rbiGuidelines`, rrbGuidelines)
                    inputHandler(rrbGuidelines, 'rbiGuidelines')

                    const rrbDisclosure = 'As per Annual Report 2024,’ The NABARD Inspection for the Financial Position as on 31.03.2023 was conducted by NABARD from 29.05.2023 to 15.06.2023. All observations/deficiencies have been dealt with and reply submitted to NABARD.’';
                    setValue7(`financialHighlights[0].fhDisclosure`, rrbDisclosure)
                    inputHandler(rrbDisclosure, 'fhDisclosure')
                } else {
                    const otherDisclosure = 'As per RBI circular No. DBR.BP.BC.No.32/21.04.018/2018-19 dated April 01, 2019, banks must give Disclosure in the “Notes to Accounts” to the Financial Statements - Divergence in the asset classification & provisioning if either or both of the following conditions are satisfied:\n1. The additional provisioning for NPAs assessed by RBI exceeds 10 per cent of the reported profit before provisions and contingencies for the reference period, and\n2. The additional Gross NPAs identified by RBI exceed 15 per cent of the published incremental Gross NPAs for the reference period.';
                    setValue7(`financialHighlights[0].rbiGuidelines`, otherDisclosure)
                    inputHandler(otherDisclosure, 'rbiGuidelines')
                }
            }
            appData.forEach((item, index) => {
                setFhId(item.fhId)
                setValue7(`financialHighlights[${index}].ifvId`, item.ifvId)
                setValue7(`financialHighlights[${index}].fhId`, item.fhId)

                if (!CommonUtil.isEmpty(item.fhFyMarch31)) {
                    setValue7(`financialHighlights[${index}].fhFyMarch31`, item.fhFyMarch31)
                }
                if (!CommonUtil.isEmpty(item.fhFyResults)) {
                    setValue7(`financialHighlights[${index}].fhFyResults`, item.fhFyResults)
                }
                if (!CommonUtil.isEmpty(item.currentYearValue)) {
                    setValue7(`financialHighlights[${index}].currentYearValue`, item.currentYearValue)
                }
                if (!CommonUtil.isEmpty(item.previousYearValue)) {
                    setValue7(`financialHighlights[${index}].previousYearValue`, item.previousYearValue)
                }

                if (!CommonUtil.isEmpty(item.months)) {
                    setValue7(`financialHighlights[${index}].months`, item.months)
                }
                if (!CommonUtil.isEmpty(item.fyEndedAudit)) {
                    setValue7(`financialHighlights[${index}].fyEndedAudit`, item.fyEndedAudit)
                }
                if (!CommonUtil.isEmpty(item.fyResultAudit)) {
                    setValue7(`financialHighlights[${index}].fyResultAudit`, item.fyResultAudit)
                }

                setValue7(`financialHighlights[${index}].fhFy3`, item.fhFy3)
                setValue7(`financialHighlights[${index}].fhParticular`, item.fhParticular)
                setValue7(`financialHighlights[${index}].fhFy1`, item.fhFy1)
                setValue7(`financialHighlights[${index}].fhFy2`, item.fhFy2)
                setValue7(`financialHighlights[${index}].fhYoy`, item.fhYoy)
                setValue7(`financialHighlights[${index}].fhFy3`, item.fhFy3)
                if (!CommonUtil.isEmpty(item.fhFinperformance)) {
                    setValue7(`financialHighlights[${index}].fhFinperformance`, item.fhFinperformance)
                    inputHandler(item.fhFinperformance, 'fhFinperformance')
                    setValue7(`financialHighlights[${index}].fhLcrDate`, new Date(item.fhLcrDate))
                    setValue7(`financialHighlights[${index}].fhLcrValue`, item.fhLcrValue)
                }
                if (!CommonUtil.isEmpty(item.financialPerformance2)) {
                    setValue7(`financialHighlights[${index}].financialPerformance2`, item.financialPerformance2)
                    inputHandler(item.financialPerformance2, 'financialPerformance2')
                }
                if (!CommonUtil.isEmpty(item.fhAssestProfile)) {
                    setValue7(`financialHighlights[${index}].fhAssestProfile`, item.fhAssestProfile)
                    inputHandler(item.fhAssestProfile, 'fhAssestProfile')
                }
                if (!CommonUtil.isEmpty(item.fhLiabilities)) {
                    setValue7(`financialHighlights[${index}].fhLiabilities`, item.fhLiabilities)
                    inputHandler(item.fhLiabilities, 'fhLiabilities')
                }
                if (!CommonUtil.isEmpty(item.fhProfitabilities)) {
                    setValue7(`financialHighlights[${index}].fhProfitabilities`, item.fhProfitabilities)
                    inputHandler(item.fhProfitabilities, 'fhProfitabilities')
                }
                if (!CommonUtil.isEmpty(item.fhEqulity)) {
                    setValue7(`financialHighlights[${index}].fhEqulity`, item.fhEqulity)
                    inputHandler(item.fhEqulity, 'fhEqulity')
                }
                if (!CommonUtil.isEmpty(item.fhHighlights)) {
                    setValue7(`financialHighlights[${index}].fhHighlights`, item.fhHighlights)
                    inputHandler(item.fhHighlights, 'fhHighlights')
                }
                if (!CommonUtil.isEmpty(item.fhDisclosure)) {
                    setValue7(`financialHighlights[${index}].fhDisclosure`, item.fhDisclosure)
                    inputHandler(item.fhDisclosure, 'fhDisclosure')
                }
                if (!CommonUtil.isEmpty(item.fhCollection)) {
                    setValue7(`financialHighlights[${index}].fhCollection`, item.fhCollection)
                    inputHandler(item.fhCollection, 'fhCollection')
                }
                if (!CommonUtil.isEmpty(item.fhEfficiency)) {
                    setValue7(`financialHighlights[${index}].fhEfficiency`, item.fhEfficiency)
                    inputHandler(item.fhEfficiency, 'fhEfficiency')
                }

                if (!CommonUtil.isEmpty(item.fhStatutory)) {
                    setValue7(`financialHighlights[${index}].fhEfficiencyDate`, new Date(item.fhEfficiencyDate))
                    setValue7(`financialHighlights[${index}].fhStatutory`, item.fhStatutory)
                    inputHandler(item.fhStatutory, 'fhStatutory')

                    if (!CommonUtil.isEmpty(item.fhStatus)) {
                        setValue7(`financialHighlights[${index}].fhStatus`, item.fhStatus)
                        inputHandler(item.fhStatus, 'fhStatus')
                    }
                }

                if (!CommonUtil.isEmpty(item.financialPerformanceYear1)) {
                    setValue7(`financialHighlights[${index}].financialPerformanceYear1`, item.financialPerformanceYear1)
                }

                if (!CommonUtil.isEmpty(item.financialPerformanceYear2)) {
                    setValue7(`financialHighlights[${index}].financialPerformanceYear2`, item.financialPerformanceYear2)
                }

                if (!CommonUtil.isEmpty(item.highlightsValue)) {
                    setValue7(`financialHighlights[${index}].highlightsValue`, item.highlightsValue)
                }

                if (!CommonUtil.isEmpty(item.highlightsDate)) {
                    setValue7(`financialHighlights[${index}].highlightsDate`, new Date(item.highlightsDate))
                }

                if (!CommonUtil.isEmpty(item.rbiGuidelines)) {
                    setValue7(`financialHighlights[${index}].rbiGuidelines`, item.rbiGuidelines)
                    inputHandler(item.rbiGuidelines, 'rbiGuidelines')
                }

                if (!CommonUtil.isEmpty(item.restructuredAsset)) {
                    setValue7(`financialHighlights[${index}].restructuredAsset`, item.restructuredAsset)
                }

                if (!CommonUtil.isEmpty(item.restructuredAssetFlag)) {
                    setValue7(`financialHighlights[${index}].restructuredAssetFlag`, item.restructuredAssetFlag)
                }
            });
            setLoading(false)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading Details of Financial Highlights')
            }
        )
    }

    const onSubmitOfEligibility = (data, e) => {
        setLoading(true)

        if (ucb || rrb) {
            let ucbElig = data['ucbEligibility']

            if (rrb) {
                ucbElig = ucbElig.slice(0, 5);
            }

            let obj = {
                id: ucbId1 > 0 ? ucbId1 : null,
                ifvId: appId,
                particulars: RiMCStip1,
                complianceStatus: comp1,
                eligibilityType: 'RIMC'
            }

            ucbElig.push(obj)

            if (!rrb) {
                let obj2 = {
                    id: ucbId2 > 0 ? ucbId2 : null,
                    ifvId: appId,
                    particulars: RiMCStip2,
                    complianceStatus: comp2,
                    eligibilityType: 'RIMC'
                }
                ucbElig.push(obj2)
            }

            IfvAppraisalService.saveUcbEligibility(ucbElig).then((response) => {
                getUcbEligibilityByIfvId(ucb, rrb)
            },
                (error) => {
                    handleApiError(error, 'saving UCB/RRB Eligibility')
                })
        }
        delete data.ucbEligibility
        data.ifvId = appId
        if (ecId > 0) {
            IfvAppraisalService.updateEligibility(data).then((response) => {
                setLoading(false)
                showMessage('Eligibility Details have been Successfully Updated!', 'success')
                getEligibilityByIfvId(lastInd)
            },
                (error) => {
                    setLoading(false)
                    handleApiError(error, 'updating Eligibility')
                })
        } else {
            IfvAppraisalService.saveEligibility(data).then((response) => {
                setLoading(false)
                showMessage('Eligibility Details have been Successfully Saved!', 'success')
                getEligibilityByIfvId(lastInd)
            },
                (error) => {
                    setLoading(false)
                    handleApiError(error, 'saving Eligibility')
                })
        }
    }

    const onSubmitOfFinancialHighlights = (data) => {
        const firstObj = data['financialHighlights'][0]
        let emptyList = []
        if (isValEmpty(firstObj.financialPerformanceYear1)) {
            emptyList.push('Financial Performance Year 1')
        }
        if (isValEmpty(firstObj.fhFinperformance)) {
            emptyList.push('Financial Performance')
        }
        if (isValEmpty(firstObj.fhAssestProfile)) {
            emptyList.push('Asset Profile')
        }
        if (isValEmpty(firstObj.fhLiabilities)) {
            emptyList.push('Liabilities Profile')
        }
        if (isValEmpty(firstObj.fhProfitabilities)) {
            emptyList.push('Profitability')
        }
        if (isValEmpty(firstObj.fhEqulity)) {
            emptyList.push('Equity')
        }
        if (isValEmpty(firstObj.fhDisclosure)) {
            emptyList.push('Disclosure on Divergence [1]')
        }
        if (isValEmpty(firstObj.financialPerformance2)) {
            emptyList.push('Financial Performance 2')
        }
        if (isValEmpty(firstObj.fhCollection)) {
            emptyList.push('Collection')
        }
        if (isValEmpty(firstObj.fhStatutory)) {
            emptyList.push('Any adverse remarks by Statuary Auditors/Nominee Director od SIDBI')
        }
        if (isValEmpty(firstObj.fhStatus)) {
            emptyList.push('Status of Listing of SFB/Hold Co. If listed, share price')
        }
        if (isValEmpty(firstObj.fhHighlights)) {
            emptyList.push('Highlights')
        }
        if (isValEmpty(firstObj.financialPerformanceYear2)) {
            emptyList.push('Financial Performance Year 2')
        }
        if (isValEmpty(firstObj.highlightsValue)) {
            emptyList.push('Highlights value')
        }
        if (isValEmpty(firstObj.rbiGuidelines)) {
            emptyList.push('Note')
        }

        const formatMessage = () => {
            return emptyList.map((item, index) => (
                <div key={index}>{index + 1}: {item}</div>
            ));
        };

        let msg = '';
        if (emptyList.length > 0) {
            msg = 'The fields mentioned below are not filled out with data. Are you sure you want to save?'
        } else {
            msg = 'Are you sure you want to save?'
        }

        confirmAlert({
            title: 'Confirm to Save',
            message: <div>
                <p> <img src={cnfrm} alt="My Image" /></p>
                <span>{msg}</span>
                {formatMessage()}
            </div>,

            buttons: [
                {
                    label: 'Yes',
                    onClick: () => {
                        confirmDialog(data)
                    }
                },
                {
                    label: 'No',
                    onClick: () => {
                        console.log('Canceled save');
                    }
                }
            ]
        });
    }

    const confirmDialog = (data) => {
        setLoading(true)

        const collData = data['collectionEfficiency']?.filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.particulars));

        if (!CommonUtil.isEmpty(collData)) {
            IfvAppraisalService.saveCollEfficiency(collData).then((response) => {

            },
                (error) => {
                    setLoading(false)
                    handleApiError(error, 'saving Collection  Efficiency')
                })
        }

        const rsData = data['restructuredAssets']?.filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.rsDate));

        if (!CommonUtil.isEmpty(rsData)) {
            IfvAppraisalService.saveRestructuredAssets(rsData).then((response) => {

            },
                (error) => {
                    setLoading(false)
                    handleApiError(error, 'saving Restructured assets')
                })
        }

        const statusOfListingData = data['statusData']?.filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.column1));

        if (!CommonUtil.isEmpty(statusOfListingData)) {
            IfvAppraisalService.saveStatusOfListing(statusOfListingData).then((response) => {
            },
                (error) => {
                    setLoading(false)
                    handleApiError(error, 'saving Status of Listing')
                })
        }
        if (ucb || rrb) {
            const ucbFincData = data['ucbFinc']?.filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.particulars))
            if (!CommonUtil.isEmpty(ucbFincData)) {
                IfvAppraisalService.saveUcbFinc(ucbFincData).then((response) => {
                },
                    (error) => {
                        setLoading(false)
                        handleApiError(error, 'saving UCB/RRB Financial Performance')
                    })
            }
        }

        const finData = data['financialHighlights']?.filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.fhParticular));

        IfvAppraisalService.saveFinancialHlts(finData).then((response) => {
            setLoading(false)
            showMessage(`Financial Highlights details have been successfully ${fhId > 0 ? 'updated!' : 'saved!'}`, 'success')
            getFinancialHighlightsByIfvId(rrb)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving Financial Performance')
            })

    }

    const isValEmpty = (val) => {
        return val !== null && val !== undefined && val === '';
    }

    function goToNext() {
        navigate('/ifv/sectionThree', {
            state: {
                showSFB: showSFB,
                appId: appId
            }
        });
    }

    function goToPrev() {
        if (!showSFB) {
            navigate('/ifv/basic', {
                state: {
                    showSFB: showSFB,
                    appId: appId
                }
            });
        } else {
            navigate('/ifv/sectionOne', {
                state: {
                    showSFB: showSFB,
                    appId: appId
                }
            });
        }
    }

    const calculateYoy = (field, value, index) => {
        setValue7(field, value, { shouldValidate: true })
        let yoy = 0;

        const yoy1 = getValues7(`financialHighlights[${index}].fhFy1`)
        const yoy2 = getValues7(`financialHighlights[${index}].fhFy2`)

        if (CommonUtil.isValidNumber(yoy1) && CommonUtil.isValidNumber(yoy2)) {
            yoy = ((parseFloat(yoy2) - parseFloat(yoy1)) / parseFloat(yoy1)) * 100;
        }
        yoy = Math.round(yoy * 100) / 100
        setValue7(`financialHighlights[${index}].fhYoy`, yoy, { shouldValidate: true })
    }

    const onSubmitOfUcbCriteria = (data, e) => {
        let finalData = data['ucbCriteria']?.filter(item => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.criteriaParameters))
        if (CommonUtil.isEmpty(finalData)) {
            return
        }
        if (rrb) {
            finalData = finalData.slice(0, 1);
            finalData.forEach(item => {
                item.criteriaParameters = '';
                item.complied = '';
                item.ifvId = appId;
            })
        }
        setLoading(true)
        IfvAppraisalService.saveUcbCriteria(finalData).then((response) => {
            setLoading(false)
            showMessage('UCB Criteria have been Successfully Saved!', 'success')
            getUcbCriteriaByIfvId(ifvApp.ifvName)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving UCB Criteria')
            })
    }

    const getUcbCriteriaByIfvId = (IFVName) => {

        IfvAppraisalService.getUcbCriteriaByIfvId(appId).then(response => {
            const appData = response.data

            if (appData.length <= 0) {
                for (let i = 0; i < 7; i++) {
                    append12({})
                }
                setValue9(`ucbCriteria[0].justification`, 'The proposal is meeting all eligibility criteria/ scheme norms and does not involve any relaxation.')
                setValue9(`ucbCriteria[0].note`, 'Compliance on RBI circular dated December 01, 2022 on “Review of norms for classification of Urban Co-operative Banks (UCBs) as Financially Sound and Well Managed (FSWM)”\nRBI classifies the UCBs as FSWM based on certain laid down criteria on fulfilment / compliance of laid down criterion. UCBs which meet the revised FSWM criteria can open new branches up to 10% of the number of branches as at the end of the previous FY under automatic route.\n…………RBI self classification…………….During discussion they have indicated that they will approach RBI, along with compliance of all requisite conditions in due course. However, this will have no impact on it’s existing operations. As per extant guidelines / Board approval compliance to FSWM is not mandatory for providing refinance to UCBs.\nOn the basis of the annual report for FY’23 and the information submitted by the bank, the compliance of __ to the revised norms are furnished as under:')
                setValue9(`ucbCriteria[0].complianceDate`, 'as on March 31, 2023')
            } else {
                appData.forEach((item, index) => {
                    remove12(index)
                    append12({})

                    setValue9(`ucbCriteria[${index}].ifvId`, item.ifvId)
                    setValue9(`ucbCriteria[${index}].id`, item.id)

                    if (!CommonUtil.isEmpty(item.justification)) {
                        setValue9(`ucbCriteria[0].justification`, item.justification)
                    }
                    if (!CommonUtil.isEmpty(item.note)) {
                        setValue9(`ucbCriteria[0].note`, item.note)
                    }
                    if (!CommonUtil.isEmpty(item.complianceDate)) {
                        setValue9(`ucbCriteria[0].complianceDate`, item.complianceDate)
                    }

                    setValue9(`ucbCriteria[${index}].criteriaParameters`, item.criteriaParameters)
                    setValue9(`ucbCriteria[${index}].complied`, item.complied)
                    setValue9(`ucbCriteria[${index}].compliance`, item.compliance)
                })
            }
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading UCB Criteria')
            }
        )
    }

    return (
        <Fragment>
            <div className={loading ? 'frgmnt blur-background' : 'frgmnt'}>
                {appId > 0 && <SectionNavigation activeView={'Section Two'} showSFB={showSFB} appId={appId} />}

                <ProposalHeader
                    bankName={ifvApp.ifvName}
                    appNumber={ifvApp.appNumber}
                    status={appStatus}
                    appId={appId}
                />

                <Accordion flush>

                    <form key={6} onSubmit={handleSubmitOfFinancialHighlights(onSubmitOfFinancialHighlights)}>
                        <Accordion.Item>
                            <Accordion.Header><strong>Financial Highlights (Standalone Financials) : (In <span>&#8377;</span> crore)</strong></Accordion.Header>
                            <Accordion.Body>
                                {/* <div {...getRootProps()} style={{ border: '1px solid black', padding: '20px', textAlign: 'center', cursor: 'pointer' }}>
                                    <input {...getInputProps()} />
                                    <p>Drag and drop Excel file here, or click to select file</p>
                                </div>
                                <br /> */}
                                <div className='row row_align'>
                                    <div className='col-md-2'>
                                        <div className='form-group'>
                                            <label><strong>Particulars</strong></label>
                                        </div>
                                    </div>

                                    <div className='col-md-3'>
                                        <div className='branch_on'>
                                            <label><strong>FY Ended March 31 <select className="form-select"
                                                {...register7('financialHighlights[0].fyEndedAudit')}
                                            >
                                                <option value="Audited">Audited</option>
                                                <option value="Unaudited">Unaudited</option>
                                            </select></strong></label>
                                            {/* <div className='brn_wrp'>
                                                <input className='form-control'
                                                    type='number'
                                                    autoComplete='off'
                                                    {...register7('financialHighlights[0].fhFyMarch31', {
                                                        // required: "Field is required",
                                                        maxLength: {
                                                            value: 4,
                                                            message: "The length of the field is 4"
                                                        },
                                                        minLength: {
                                                            value: 4,
                                                            message: "The length of the field is 4"
                                                        },
                                                    })}
                                                />

                                            </div> */}
                                            {/* <label> (AUDITED)</label> */}
                                            <span className='color-red'>
                                                {errors7.financialHighlights && errors7.financialHighlights[0] && errors7.financialHighlights[0].fhFyMarch31 && errors7.financialHighlights[0].fhFyMarch31.message}</span>
                                        </div>
                                        <div className='branch_on no-algn'>
                                            <div className='brn_wrp'>
                                                <input className='form-control'
                                                    type='number'
                                                    {...register7(`financialHighlights[0].currentYearValue`, {
                                                        required: "Field is required",
                                                        maxLength: {
                                                            value: 4,
                                                            message: "The length of the field is 4"
                                                        },
                                                        minLength: {
                                                            value: 4,
                                                            message: "The length of the field is 4"
                                                        },
                                                        validate: (value) => {
                                                            if (value < 2000 || value > 2100) return "Invalid value";
                                                            return true;
                                                        },
                                                    })}
                                                />
                                                <span className='color-red' style={{ display: 'block' }}>
                                                    {errors7.financialHighlights && errors7.financialHighlights[0] && errors7.financialHighlights[0].currentYearValue && errors7.financialHighlights[0].currentYearValue.message}</span>
                                            </div>
                                            <div className='brn_wrp'>
                                                <input className='form-control'
                                                    type='number'
                                                    {...register7(`financialHighlights[0].previousYearValue`, {
                                                        required: "Field is required",
                                                        maxLength: {
                                                            value: 4,
                                                            message: "The length of the field is 4"
                                                        },
                                                        minLength: {
                                                            value: 4,
                                                            message: "The length of the field is 4"
                                                        },
                                                        validate: (value) => {
                                                            if (value < 2000 || value > 2100) return "Invalid value";
                                                            return true;
                                                        },
                                                    })}
                                                />
                                                <span className='color-red'>
                                                    {errors7.financialHighlights && errors7.financialHighlights[0] && errors7.financialHighlights[0].previousYearValue && errors7.financialHighlights[0].previousYearValue.message}</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div className='col-md-2'>
                                        <div className='form-group'>
                                            <label><strong>YOY (%)</strong> </label>
                                        </div>
                                    </div>
                                    <div className='col-md-5'>
                                        <div className='branch_on no-algn'>
                                            <div className='brn_wrp' style={{ marginTop: '-3px' }}>
                                                <label><strong>*Result
                                                </strong></label>
                                                <select className="form-select"
                                                    {...register7('financialHighlights[0].fyResultAudit')}
                                                >
                                                    <option value="Unaudited">Unaudited</option>
                                                    <option value="Audited">Audited</option>
                                                </select>
                                                <div className='brn_wrp mt-2' style={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                                                    <label style={{ marginRight: '5px' }}><strong>FY</strong> </label>
                                                    <input className='form-control'
                                                        type='number'
                                                        autoComplete='off'
                                                        {...register7('financialHighlights[0].fhFyResults', {
                                                            maxLength: {
                                                                value: 4,
                                                                message: "The length of the field is 4"
                                                            },
                                                            minLength: {
                                                                value: 4,
                                                                message: "The length of the field is 4"
                                                            },
                                                            validate: (value) => {
                                                                if (CommonUtil.isEmpty(value)) return true;
                                                                if (value < 2000 || value > 2100) return "Invalid value";
                                                                return true;
                                                            },
                                                        })}
                                                    />
                                                </div>
                                                <span className='color-red'>
                                                    {errors7.financialHighlights && errors7.financialHighlights[0] && errors7.financialHighlights[0].fhFyResults && errors7.financialHighlights[0].fhFyResults.message}</span>
                                            </div>


                                            <div className='brn_wrp'>
                                                <label><strong>Months</strong></label>
                                                {/* <input className='form-control'
                                                    type='number'
                                                    autoComplete='off'
                                                    {...register7('financialHighlights[0].months')}
                                                /> */}
                                                <select className="form-select"
                                                    {...register7('financialHighlights[0].months')}
                                                >
                                                    <option value="">Select Month</option>
                                                    {/* {Months.map((item, index) => (
                                                        <option value={item}>{item}</option>
                                                    ))} */}
                                                    <option value="3 Months">3 Months</option>
                                                    <option value="Half Year">Half Year</option>
                                                    <option value="9 Months">9 Months</option>
                                                </select>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                {fields6.map((field, index) => (
                                    <div className='container-fluid p-0'>
                                        <div className='row' eventKey="0" key={field.id}>
                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <input className='form-control' key={field.id}
                                                        type='text'
                                                        readOnly
                                                        {...register7(`financialHighlights[${index}].fhParticular`)}

                                                    />
                                                    <input type='hidden' {...register7(`financialHighlights[${index}].fhId`)} />
                                                    <input type='hidden' {...register7(`financialHighlights[${index}].ifvId`)} value={appId} />
                                                </div>
                                            </div>


                                            <div className='col-md-3'>
                                                <div className='row'>
                                                    <div className='col-md-6'>
                                                        <div className='form-group'>
                                                            <input className='form-control' key={field.id} // important to include key with field's id
                                                                type='number'
                                                                autoComplete='off'
                                                                step='any'
                                                                {...register7(`financialHighlights[${index}].fhFy1`,
                                                                    {
                                                                        validate: (value) => {
                                                                            if (CommonUtil.isEmpty(value)) return true;
                                                                            //   if (value < 0) return "Invalid value";
                                                                            if (!/^-?\d{1,12}(?:\.\d{1,2})?$/.test(value)) return "Enter up to 12 digits with up to 2 decimals";
                                                                            return true;
                                                                        },
                                                                        onChange: (e) => calculateYoy(`financialHighlights[${index}].fhFy1`, e.target.value, index)
                                                                    }
                                                                )}
                                                            />
                                                            <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[index]?.fhFy1 && errors7.financialHighlights[index]?.fhFy1.message}</span>
                                                        </div>
                                                    </div>

                                                    <div className='col-md-6'>
                                                        <div className='form-group'>
                                                            <input className='form-control' key={field.id} // important to include key with field's id
                                                                type='number'
                                                                autoComplete='off'
                                                                step='any'
                                                                {...register7(`financialHighlights[${index}].fhFy2`,
                                                                    {
                                                                        validate: (value) => {
                                                                            if (CommonUtil.isEmpty(value)) return true;
                                                                            //  if (value < 0) return "Invalid value";
                                                                            //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
                                                                            if (!/^-?\d{1,12}(?:\.\d{1,2})?$/.test(value)) return "Enter up to 12 digits with up to 2 decimals";
                                                                            return true;
                                                                        },
                                                                        onChange: (e) => calculateYoy(`financialHighlights[${index}].fhFy2`, e.target.value, index)
                                                                    }
                                                                )}
                                                            />
                                                            <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[index]?.fhFy2 && errors7.financialHighlights[index]?.fhFy2.message}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className='col-md-2'>
                                                <div className='form-group'>
                                                    <input className='form-control' key={field.id} // important to include key with field's id
                                                        type='number'
                                                        autoComplete='off'
                                                        step='any'
                                                        readOnly
                                                        {...register7(`financialHighlights[${index}].fhYoy`)}
                                                    />
                                                </div>
                                            </div>

                                            <div className='col-md-5'>
                                                <div className='form-group'>
                                                    <input className='form-control' key={field.id} // important to include key with field's id
                                                        type='number'
                                                        autoComplete='off'
                                                        step='any'
                                                        {...register7(`financialHighlights[${index}].fhFy3`, {
                                                            validate: (value) => {
                                                                if (CommonUtil.isEmpty(value)) return true;
                                                                // if (value < 0) return "Invalid value";
                                                                //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
                                                                if (!/^-?\d{1,12}(?:\.\d{1,2})?$/.test(value)) return "Enter up to 12 digits with up to 2 decimals";
                                                                return true;
                                                            },
                                                        })}
                                                    />
                                                    <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[index]?.fhFy3 && errors7.financialHighlights[index]?.fhFy3.message}</span>
                                                </div>
                                            </div>



                                        </div>



                                    </div>
                                ))}

                                <div className='container-fluid'>
                                    <div className='row'>
                                        <div className='col-md-12'>
                                            <div className='form-group'>

                                                <label className='prog_lbl'>
                                                    <strong style={{ display: 'flex', width: '45%', alignItems: 'center' }}>Financial Performance : (<input className='form-control' type='text' {...register7('financialHighlights[0].financialPerformanceYear1')} style={{ width: '200px', marginLeft: '5px' }} /> &nbsp;) </strong>
                                                    <div className='prgs'>
                                                        <span className='lft_crt'>{4000 - input['fhFinperformance'].length} Characters left</span>
                                                        <LinearProgress
                                                            variant="determinate"
                                                            value={input['fhFinperformance'].length}
                                                        />
                                                    </div>
                                                </label>
                                                <textarea className='form-control'
                                                    {...register7('financialHighlights[0].fhFinperformance', {
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                    })}
                                                    autoComplete="off"
                                                    maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "fhFinperformance") }}
                                                />
                                                <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[0]?.fhFinperformance && errors7.financialHighlights[0]?.fhFinperformance.message}</span>
                                            </div>

                                        </div>

                                        {/* <div className='col-md-12 mt-cstm'>
                                            <div className="branch_on"><label>LCR as on</label>
                                                <div className="brn_wrp">
                                                    <Controller control={control7}
                                                        name='fhLcrDate'
                                                        render={({ field: { onChange, onBlur, value, ref } }) => (
                                                            <ReactDatePicker className="form-control"
                                                                onChange={onChange}
                                                                onBlur={onBlur}
                                                                selected={value}
                                                                dateFormat="dd/MM/yyyy"
                                                            />
                                                        )}

                                                        {...register7('financialHighlights[0].fhLcrDate')}
                                                    />
                                                </div>
                                                <label> was</label>
                                                <div className="brn_wrp">
                                                    <input className='form-control' type='number'
                                                        step='any' autoComplete="off"
                                                        {...register7('financialHighlights[0].fhLcrValue')}

                                                    />
                                                </div>
                                                <label>%</label>
                                            </div>
                                        </div> */}
                                    </div>

                                    <div className='row'>
                                        <div className='col-md-12 mt-2'>
                                            <div className='form-group'>
                                                <label className='prog_lbl'>
                                                    <strong>Assets Profile:</strong>
                                                    <div className='prgs'>
                                                        <span className='lft_crt'>{4000 - input['fhAssestProfile'].length} Characters left</span>
                                                        <LinearProgress
                                                            variant="determinate"
                                                            value={input['fhAssestProfile'].length}
                                                        />
                                                    </div>
                                                </label>
                                                <textarea className='form-control'
                                                    {...register7('financialHighlights[0].fhAssestProfile', {
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                    })}
                                                    autoComplete="off" maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "fhAssestProfile") }}
                                                />
                                                <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[0]?.fhAssestProfile && errors7.financialHighlights[0]?.fhAssestProfile.message}</span>
                                            </div>
                                        </div>

                                        <div className='col-md-12 mt-2'>
                                            <div className='form-group'>
                                                <label className='prog_lbl'>
                                                    <strong>Liabilities Profile:</strong>
                                                    <div className='prgs'>
                                                        <span className='lft_crt'>{4000 - input['fhLiabilities'].length} Characters left</span>
                                                        <LinearProgress
                                                            variant="determinate"
                                                            value={input['fhLiabilities'].length}
                                                        />
                                                    </div>
                                                </label>
                                                <textarea className='form-control'
                                                    {...register7('financialHighlights[0].fhLiabilities', {
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                    })}
                                                    autoComplete="off" maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "fhLiabilities") }}
                                                />
                                                <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[0]?.fhLiabilities && errors7.financialHighlights[0]?.fhLiabilities.message}</span>
                                            </div>
                                        </div>

                                        <div className='col-md-12 mt-2'>
                                            <div className='form-group'>
                                                <label className='prog_lbl'>
                                                    <strong>Profitability:</strong>
                                                    <div className='prgs'>
                                                        <span className='lft_crt'>{4000 - input['fhProfitabilities'].length} Characters left</span>
                                                        <LinearProgress
                                                            variant="determinate"
                                                            value={input['fhProfitabilities'].length}
                                                        />
                                                    </div>
                                                </label>
                                                <textarea className='form-control'
                                                    {...register7('financialHighlights[0].fhProfitabilities', {
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                    })}
                                                    autoComplete="off" maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "fhProfitabilities") }}
                                                />
                                                <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[0]?.fhProfitabilities && errors7.financialHighlights[0]?.fhProfitabilities.message}</span>
                                            </div>
                                        </div>


                                        <div className='col-md-12 mt-2'>
                                            <div className='form-group'>
                                                <label className='prog_lbl'>
                                                    <strong>Equity:</strong>
                                                    <div className='prgs'>
                                                        <span className='lft_crt'>{4000 - input['fhEqulity'].length} Characters left</span>
                                                        <LinearProgress
                                                            variant="determinate"
                                                            value={input['fhEqulity'].length}
                                                        />
                                                    </div>
                                                </label>
                                                <textarea className='form-control'
                                                    {...register7('financialHighlights[0].fhEqulity', {
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                    })}
                                                    autoComplete="off" maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "fhEqulity") }}
                                                />
                                                <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[0]?.fhEqulity && errors7.financialHighlights[0]?.fhEqulity.message}</span>
                                            </div>
                                        </div>

                                        {!showSFB && <div className='col-md-12'>
                                            <div className='form-group'>
                                                <label className='prog_lbl hlt'>
                                                    <strong>Highlights: </strong>
                                                    <select className="form-control"
                                                        {...register7('financialHighlights[0].highlightsValue', {
                                                            // required: 'Field is required'
                                                        })}
                                                    >
                                                        <option value=""> Please select a value</option>
                                                        {Highlights.map((item, index) => (
                                                            <option value={item}>{item}</option>
                                                        ))}
                                                    </select>
                                                    <span className='vldn' style={{ marginRight: '10px' }}>{errors7.financialHighlights && errors7.financialHighlights[0]?.highlightsValue && errors7.financialHighlights[0]?.highlightsValue.message}</span>

                                                    <strong> as on</strong> <Controller
                                                        control={control7}
                                                        name='financialHighlights[0].highlightsDate'
                                                        rules={{
                                                            // required: {
                                                            //     value: true,
                                                            //     message: "Date is required",
                                                            // },
                                                            validate: (value) => !CommonUtil.isEmpty(value) ? CommonUtil.validateDate(value) : true
                                                        }}
                                                        render={({ field: { onChange, onBlur, value, ref } }) => (
                                                            <ReactDatePicker className="form-control"
                                                                onChange={onChange}
                                                                onBlur={onBlur}
                                                                selected={value}
                                                                dateFormat="dd/MM/yyyy"
                                                            />
                                                        )}
                                                        {...register7("financialHighlights[0].highlightsDate")}
                                                    />
                                                    <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[0]?.highlightsDate && errors7.financialHighlights[0]?.highlightsDate.message}</span>
                                                    <div className='prgs'>
                                                        <span className='lft_crt'>{4000 - input['fhHighlights'].length} Characters left</span>
                                                        <LinearProgress
                                                            variant="determinate"
                                                            value={input['fhHighlights'].length}
                                                        />
                                                    </div>
                                                </label>
                                                <textarea className='form-control'
                                                    {...register7('financialHighlights[0].fhHighlights', {
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                    })}
                                                    autoComplete="off" maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "fhHighlights") }}
                                                />
                                                <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[0]?.fhAssestProfile && errors7.financialHighlights[0]?.fhHighlights.message}</span>
                                            </div>
                                        </div>}

                                        {showSFB && <div className='col-md-12'>
                                            <div className='form-group'>

                                                <label className='prog_lbl'>
                                                    <strong style={{ display: 'flex', width: '45%' }}>Financial Performance (<input className='form-control' type='text' {...register7('financialHighlights[0].financialPerformanceYear2')} style={{ width: '200px', marginLeft: '10px' }} />): </strong>
                                                    <div className='prgs'>
                                                        <span className='lft_crt'>{4000 - input['financialPerformance2'].length} Characters left</span>
                                                        <LinearProgress
                                                            variant="determinate"
                                                            value={input['financialPerformance2'].length}
                                                        />
                                                    </div>
                                                </label>
                                                <textarea className='form-control'
                                                    {...register7('financialHighlights[0].financialPerformance2', {
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                    })}
                                                    autoComplete="off"
                                                    maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "financialPerformance2") }}
                                                />
                                                <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[0]?.financialPerformance2 && errors7.financialHighlights[0]?.financialPerformance2.message}</span>
                                            </div>

                                        </div>
                                        }

                                        {ucb && <><div className='row'>
                                            <div className='col-md-1'>
                                                <div className='form-group'>
                                                    <label><strong>Sl No</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-5'>
                                                <div className='form-group'>
                                                    <label><strong>Particulars</strong></label>
                                                </div>
                                            </div>
                                            <div className='col-md-3'>
                                                <div className='form-group'>
                                                    <label><strong>As on<Controller
                                                        {...register7(`ucbFinc[0].date1`)}
                                                        control={control7}
                                                        rules={{

                                                            validate: (value) => !CommonUtil.isEmpty(value) ? CommonUtil.validateDate(value) : true
                                                        }}
                                                        render={({ field: { onChange, onBlur, value, ref } }) => (
                                                            <ReactDatePicker className="form-control"
                                                                placeholderText="Select date"
                                                                onChange={onChange}
                                                                onBlur={onBlur}
                                                                selected={value}
                                                                dateFormat="dd/MM/yyyy"
                                                            />

                                                        )}

                                                    /></strong></label>
                                                </div>
                                            </div>
                                            <div className='col-md-3'>
                                                <div className='form-group'>
                                                    <label><strong>As on<Controller
                                                        {...register7(`ucbFinc[0].date2`)}
                                                        control={control7}
                                                        rules={{

                                                            validate: (value) => !CommonUtil.isEmpty(value) ? CommonUtil.validateDate(value) : true
                                                        }}
                                                        render={({ field: { onChange, onBlur, value, ref } }) => (
                                                            <ReactDatePicker className="form-control"
                                                                placeholderText="Select date"
                                                                onChange={onChange}
                                                                onBlur={onBlur}
                                                                selected={value}
                                                                dateFormat="dd/MM/yyyy"
                                                            />

                                                        )}

                                                    /></strong></label>
                                                </div>
                                            </div>
                                        </div>

                                            {fields10.map((field2, i) => (
                                                <div className='container-fluid'>
                                                    <div className='row' key={field2.id}>

                                                        <div className='col-md-1'>
                                                            <div className='form-group'>
                                                                {i + 1}
                                                            </div>
                                                        </div>
                                                        <div className='col-md-5'>
                                                            <div className='form-group'>
                                                                <input className='form-control'
                                                                    key={field2.id} // important to include key with field's id
                                                                    type='text'
                                                                    {...register7(`ucbFinc[${i}].particulars`, {
                                                                        validate: (value) => {
                                                                            if (CommonUtil.isEmpty(value)) return true;
                                                                            return true;
                                                                        },
                                                                    })

                                                                    }
                                                                    onchange={(e) => Pattern.sanitizeInput(e)}
                                                                />


                                                                <span className='vldn'>{errors7.ucbFinc && errors7.ucbFinc[i]?.particulars && errors7.ucbFinc[i]?.particulars.message}</span>
                                                                <input key={field2.id} type='hidden' {...register7(`ucbFinc[${i}].id`)} />
                                                                <input key={field2.id} type='hidden' {...register7(`ucbFinc[${i}].ifvId`)} value={appId} />
                                                            </div>
                                                        </div>


                                                        <div className='col-md-3'>
                                                            <div className='form-group'>
                                                                <input className='form-control'
                                                                    key={field2.id} // important to include key with field's id
                                                                    type='number' min='0' step='any'
                                                                    {...register7(`ucbFinc[${i}].amount1`, {
                                                                        validate: (value) => {
                                                                            if (CommonUtil.isEmpty(value)) return true;
                                                                            if (value <= 0) return "Invalid value";
                                                                            return true;
                                                                        },
                                                                    })}
                                                                />
                                                                <span className='vldn'>{errors7.ucbFinc && errors7.ucbFinc[i]?.amount1 && errors7.ucbFinc[i]?.amount1.message}</span>
                                                            </div>
                                                        </div>
                                                        <div className='col-md-3'>
                                                            <div className='form-group'>
                                                                <input className='form-control'
                                                                    key={field2.id} // important to include key with field's id
                                                                    type='number' min='0' step='any'
                                                                    {...register7(`ucbFinc[${i}].amount2`, {
                                                                        validate: (value) => {
                                                                            if (CommonUtil.isEmpty(value)) return true;
                                                                            if (value <= 0) return "Invalid value";
                                                                            return true;
                                                                        },
                                                                    })}
                                                                />
                                                                <span className='vldn'>{errors7.ucbFinc && errors7.ucbFinc[i]?.amount2 && errors7.ucbFinc[i]?.amount2.message}</span>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            ))}

                                            <div className='form-group'>

                                                <textarea className='form-control'
                                                    {...register7('ucbFinc[0].note', {

                                                        maxLength: {
                                                            value: 250,
                                                            message: "The maximum length of the field is 250"
                                                        },
                                                    })}
                                                    autoComplete="off" maxLength="250"
                                                    onChange={(e) => Pattern.sanitizeInput(e)}
                                                />
                                                <span className='vldn'>{errors7.ucbFinc && errors7.ucbFinc[0]?.note && errors7.ucbFinc[0]?.note.message}</span>
                                            </div>

                                        </>

                                        }

                                        <div className='col-md-12'>
                                            <div className='form-group'>
                                                <label className='prog_lbl'>
                                                    <strong>Disclosure on Divergence<sup>1</sup>:</strong>

                                                    {ucb && <div style={{ display: 'flex', alignItems: 'center' }}>
                                                        <label style={{ display: 'flex', alignItems: 'center', marginRight: '15px' }}>
                                                            <input
                                                                type="radio"
                                                                value="Yes"
                                                                {...register7('financialHighlights[0].restructuredAssetFlag')}
                                                                style={{ marginRight: '5px' }}
                                                            />
                                                            Yes
                                                        </label>
                                                        <label style={{ display: 'flex', alignItems: 'center' }}>
                                                            <input
                                                                type="radio"
                                                                value="No"
                                                                {...register7('financialHighlights[0].restructuredAssetFlag')}
                                                                style={{ marginRight: '5px' }}
                                                            />
                                                            No
                                                        </label>
                                                    </div>}

                                                    <div className='prgs'>
                                                        <span className='lft_crt'>{4000 - input['fhDisclosure'].length} Characters left</span>
                                                        <LinearProgress
                                                            variant="determinate"
                                                            value={input['fhDisclosure'].length}
                                                        />
                                                    </div>
                                                </label>
                                                <textarea className='form-control'
                                                    {...register7('financialHighlights[0].fhDisclosure', {
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                    })}
                                                    autoComplete="off" maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "fhDisclosure") }}
                                                />
                                                <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[0]?.fhDisclosure && errors7.financialHighlights[0]?.fhDisclosure.message}</span>
                                            </div>
                                        </div>

                                        {(showSFB && !rrb) && <>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label className='prog_lbl'>
                                                        <input className='form-control'
                                                            {...register7('financialHighlights[0].restructuredAsset')}
                                                            autoComplete="off" maxLength="4000" defaultValue='Restructured Assets of the Bank'
                                                            onChange={(e) => Pattern.sanitizeInput(e)} />
                                                    </label>

                                                </div>
                                            </div>


                                            <div className='row'>
                                                <div className='col-md-4'>
                                                    <div className='form-group'>
                                                        <label><strong>Date</strong></label>
                                                    </div>
                                                </div>

                                                <div className='col-md-4'>
                                                    <div className='form-group'>
                                                        <label><strong>No of A/cs</strong></label>
                                                    </div>
                                                </div>
                                                <div className='col-md-4'>
                                                    <div className='form-group'>
                                                        <label><strong>Amount</strong></label>
                                                    </div>
                                                </div>
                                            </div>

                                            {fields8.map((field2, i) => (
                                                <div className='container-fluid'>
                                                    <div className='row' key={field2.id}>
                                                        <div className='col-md-4'>
                                                            <div className='form-group'>
                                                                <Controller
                                                                    {...register7(`restructuredAssets[${i}].rsDate`)}
                                                                    control={control7}
                                                                    rules={{

                                                                        validate: (value) => !CommonUtil.isEmpty(value) ? CommonUtil.validateDate(value) : true
                                                                    }}
                                                                    render={({ field: { onChange, onBlur, value, ref } }) => (
                                                                        <ReactDatePicker className="form-control"
                                                                            placeholderText="Select date"
                                                                            onChange={onChange}
                                                                            onBlur={onBlur}
                                                                            selected={value}
                                                                            dateFormat="dd/MM/yyyy"
                                                                        />

                                                                    )}

                                                                />
                                                                <span className='vldn'>{errors7.restructuredAssets && errors7.restructuredAssets[i]?.rsDate && errors7.restructuredAssets[i]?.rsDate.message}</span>
                                                                <input key={field2.id} type='hidden' {...register7(`restructuredAssets[${i}].id`)} />
                                                                <input key={field2.id} type='hidden' {...register7(`restructuredAssets[${i}].ifvId`)} value={appId} />
                                                            </div>
                                                        </div>


                                                        <div className='col-md-4'>
                                                            <div className='form-group'>
                                                                <input className='form-control'
                                                                    key={field2.id} // important to include key with field's id
                                                                    type='number' min='0'
                                                                    {...register7(`restructuredAssets[${i}].noOfAccounts`, {
                                                                        validate: (value) => {
                                                                            if (CommonUtil.isEmpty(value)) return true;
                                                                            if (value <= 0) return "Invalid value";
                                                                            return true;
                                                                        },
                                                                    })}
                                                                />
                                                                <span className='vldn'>{errors7.restructuredAssets && errors7.restructuredAssets[i]?.noOfAccounts && errors7.restructuredAssets[i]?.noOfAccounts.message}</span>
                                                            </div>
                                                        </div>
                                                        <div className='col-md-4'>
                                                            <div className='form-group'>
                                                                <input className='form-control'
                                                                    key={field2.id} // important to include key with field's id
                                                                    type='number' step='0.01'
                                                                    {...register7(`restructuredAssets[${i}].rsAmount`, {

                                                                        validate: (value) => {
                                                                            if (CommonUtil.isEmpty(value)) return true;
                                                                            if (value <= 0) return "Invalid value";
                                                                            if (!/^\d{1,8}(\.\d{1,2})?$/.test(value)) return "Enter up to 8 digits with up to 2 decimals";
                                                                            return true;
                                                                        },
                                                                        // onChange: (e) => calculateTotalAmount(`proposedSchemaDTOs[${index}].prAmount`, e.target.value)
                                                                    })}
                                                                />
                                                                <span className='vldn'>{errors7.restructuredAssets && errors7.restructuredAssets[i]?.prAmount && errors7.restructuredAssets[i]?.prAmount.message}</span>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            ))}</>}

                                        {((generalAndRsfb || showSFB) && !rrb) && <>

                                            <div className='row'>
                                                <div className='col-md-6'>
                                                    <div className='form-group'>
                                                        <label><strong>Particulars</strong></label>
                                                    </div>
                                                </div>

                                                <div className='col-md-6'>
                                                    <div className='form-group'>
                                                        <label><strong>Collection Efficiency (%)</strong></label>
                                                    </div>
                                                </div>
                                            </div>

                                            {fields7.map((field1, i) => (
                                                <div className='container-fluid'>
                                                    <div className='row' key={field1.id}>
                                                        <div className='col-md-6'>
                                                            <div className='form-group'>
                                                                <input className='form-control'
                                                                    key={field1.id} // important to include key with field's id
                                                                    type='text'
                                                                    {...register7(`collectionEfficiency[${i}].particulars`)}
                                                                />

                                                                <input key={field1.id} type='hidden' {...register7(`collectionEfficiency[${i}].id`)} />
                                                                <input key={field1.id} type='hidden' {...register7(`collectionEfficiency[${i}].ifvId`)} value={appId} />
                                                            </div>
                                                        </div>


                                                        <div className='col-md-6'>
                                                            <div className='form-group'>
                                                                <input className='form-control'
                                                                    key={field1.id} // important to include key with field's id
                                                                    type='number' step='0.01'
                                                                    {...register7(`collectionEfficiency[${i}].collectionEfficiency`, {
                                                                        validate: (value) => {
                                                                            if (value === '') return true;
                                                                            if (value <= 0) return "Invalid value";
                                                                            if (!/^(100(\.0{1,2})?|\d{1,2}(\.\d{1,2})?)$/.test(value)) return "Enter up to 100 with up to 2 decimal places";
                                                                            return true;
                                                                        },
                                                                    })}
                                                                />
                                                                <span className='vldn'>{errors7.collectionEfficiency && errors7.collectionEfficiency[i]?.collectionEfficiency && errors7.collectionEfficiency[i]?.collectionEfficiency.message}</span>
                                                            </div>
                                                        </div>


                                                    </div>
                                                </div>
                                            ))}


                                            {/* <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label className='prog_lbl'>
                                                        <strong>Collection Efficiency:</strong>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['fhCollection'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['fhCollection'].length}
                                                            />
                                                        </div>
                                                    </label>
                                                    <textarea className='form-control'
                                                        {...register7('financialHighlights[0].fhCollection')}
                                                        autoComplete="off" maxLength="4000"
                                                        onChange={(e) => inputHandler(e.target.value, "fhCollection")}
                                                    />
                                                </div>
                                            </div> */}
                                            {/* <div className='col-md-6 mt-cstm'>
                                                <div className="branch_on"><label>Collection efficiency was</label>
                                                    <div className="brn_wrp">
                                                        <input className='form-control' type='number'
                                                            step='any'
                                                            {...register7('financialHighlights[0].fhEfficiency')}
                                                        />
                                                    </div>
                                                    <label> % as on</label>
                                                    <div className="brn_wrp">
                                                        <Controller
                                                            control={control7}
                                                            name='fhEfficiencyDate'
                                                            render={({ field: { onChange, onBlur, value, ref } }) => (
                                                                <ReactDatePicker className="form-control"
                                                                    onChange={onChange}
                                                                    onBlur={onBlur}
                                                                    selected={value}
                                                                    dateFormat="dd/MM/yyyy"
                                                                />
                                                            )}
                                                            {...register7('financialHighlights[0].fhEfficiencyDate')}
                                                        />
                                                    </div>

                                                </div>
                                            </div> */}
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label className='prog_lbl'>
                                                        <strong>Any adverse remarks by Statuary Auditors/Nominee Director od SIDBI.</strong>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['fhStatutory'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['fhStatutory'].length}
                                                            />

                                                        </div>
                                                    </label>

                                                    <textarea className='form-control'
                                                        {...register7('financialHighlights[0].fhStatutory', {
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                return true;
                                                            },
                                                            maxLength: {
                                                                value: 4000,
                                                                message: "The maximum length of the field is 4000"
                                                            },
                                                        })}
                                                        autoComplete="off" maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "fhStatutory") }}
                                                    />
                                                    <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[0]?.fhStatutory && errors7.financialHighlights[0]?.fhStatutory.message}</span>
                                                </div>
                                            </div>

                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label className='prog_lbl'>
                                                        <strong>{rrb ? 'NPA management:' : 'Status of Listing of SFB/Hold Co. If listed, share price'}</strong>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['fhStatus'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['fhStatus'].length}
                                                            />
                                                        </div>
                                                    </label>

                                                    <textarea className='form-control'
                                                        {...register7('financialHighlights[0].fhStatus', {
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                return true;
                                                            },
                                                            maxLength: {
                                                                value: 4000,
                                                                message: "The maximum length of the field is 4000"
                                                            },
                                                        })}
                                                        autoComplete="off" maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "fhStatus") }}
                                                    />
                                                    <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[0]?.fhStatus && errors7.financialHighlights[0]?.fhStatus.message}</span>
                                                </div>
                                            </div>


                                            <div className='row'>
                                                <div className='col-md-4'>
                                                    <div className='form-group'>

                                                    </div>
                                                </div>

                                                <div className='col-md-4'>
                                                    <div className='form-group'>
                                                        <label><strong>NSE</strong></label>
                                                    </div>
                                                </div>
                                                <div className='col-md-4'>
                                                    <div className='form-group'>
                                                        <label><strong>BSE</strong></label>
                                                    </div>
                                                </div>
                                            </div>

                                            {fields9.map((field2, i) => (
                                                <div className='container-fluid'>
                                                    <div className='row' key={field2.id}>
                                                        <div className='col-md-4'>
                                                            <div className='form-group'>
                                                                <input className='form-control'
                                                                    key={field2.id} // important to include key with field's id
                                                                    type='text'
                                                                    {...register7(`statusData[${i}].column1`)}
                                                                    autoComplete="off" maxLength="150"
                                                                    onChange={(e) => Pattern.sanitizeInput(e)}
                                                                />

                                                                <span className='vldn'>{errors7.statusData && errors7.statusData[i]?.column1 && errors7.statusData[i]?.column1.message}</span>
                                                                <input key={field2.id} type='hidden' {...register7(`statusData[${i}].id`)} />
                                                                <input key={field2.id} type='hidden' {...register7(`statusData[${i}].ifvId`)} value={appId} />
                                                            </div>
                                                        </div>


                                                        <div className='col-md-4'>
                                                            <div className='form-group'>
                                                                <input className='form-control'
                                                                    key={field2.id} // important to include key with field's id
                                                                    type='number' step='0.01'
                                                                    {...register7(`statusData[${i}].column2`, {
                                                                        validate: (value) => {
                                                                            if (CommonUtil.isEmpty(value)) return true;
                                                                            if (value <= 0) return "Invalid value";
                                                                            if (!/^\d{1,8}(\.\d{1,2})?$/.test(value)) return "Enter up to 8 digits with up to 2 decimals";
                                                                            return true;
                                                                        },
                                                                    })}
                                                                />
                                                                <span className='vldn'>{errors7.statusData && errors7.statusData[i]?.column2 && errors7.statusData[i]?.column2.message}</span>
                                                            </div>
                                                        </div>
                                                        <div className='col-md-4'>
                                                            <div className='form-group'>
                                                                <input className='form-control'
                                                                    key={field2.id} // important to include key with field's id
                                                                    type='number' step='0.01'
                                                                    {...register7(`statusData[${i}].column3`, {

                                                                        validate: (value) => {
                                                                            if (CommonUtil.isEmpty(value)) return true;
                                                                            if (value <= 0) return "Invalid value";
                                                                            if (!/^\d{1,8}(\.\d{1,2})?$/.test(value)) return "Enter up to 8 digits with up to 2 decimals";
                                                                            return true;
                                                                        },
                                                                        // onChange: (e) => calculateTotalAmount(`proposedSchemaDTOs[${index}].prAmount`, e.target.value)
                                                                    })}
                                                                />
                                                                <span className='vldn'>{errors7.statusData && errors7.statusData[i]?.column3 && errors7.statusData[i]?.column3.message}</span>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            ))}


                                        </>}

                                        <div className='col-md-12'>
                                            <div className='form-group'>
                                                <label className='prog_lbl'>
                                                    <strong><sup>1</sup>Note: </strong>
                                                    <div className='prgs'>
                                                        <span className='lft_crt'>{4000 - input['rbiGuidelines'].length} Characters left</span>
                                                        <LinearProgress
                                                            variant="determinate"
                                                            value={input['rbiGuidelines'].length}
                                                        />
                                                    </div>
                                                </label>

                                                <textarea className='form-control'
                                                    {...register7('financialHighlights[0].rbiGuidelines', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                    })}
                                                    autoComplete="off" maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "rbiGuidelines") }}
                                                />
                                                <span className='vldn'>{errors7.financialHighlights && errors7.financialHighlights[0]?.rbiGuidelines && errors7.financialHighlights[0]?.rbiGuidelines.message}</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && <button type='submit' className='save'>{fhId > 0 ? 'Update' : 'Save'} <i className="fa fa-circle-check"></i></button>}
                                    </div>
                                </div>
                            </Accordion.Body>
                        </Accordion.Item>
                    </form>

                    <form key={7} onSubmit={handleSubmitOfEligibility(onSubmitOfEligibility)}>
                        <Accordion.Item eventKey="1">
                            <Accordion.Header>{ucb ? 'The Board approved eligibility criteria for assistance to UCBs and its compliance:' : 'The Eligibility Criteria for Assistance and its Compliances:'}</Accordion.Header>


                            <Accordion.Body>
                                {(ucb || rrb) && <>
                                    <div className='container-fluid'>
                                        <div className='row row_align'>
                                            <div className='col-md-1'>
                                                <label><strong> Sl No</strong></label>
                                            </div>
                                            <div className='col-md-3'>
                                                <label><strong>Parameters</strong></label>
                                            </div>
                                            <div className='col-md-3'>
                                                <label><strong>Bfs Norm</strong></label>
                                            </div>

                                            <div className='col-md-2'>
                                                <label><strong>Relaxation Cap</strong></label>
                                            </div>

                                            <div className='col-md-3'>
                                                <label><strong> Compliance Status(<input className='form-control' type='text' {...register8(`ucbEligibility[0].complianceStatusYear`, {
                                                    onChange: (e) => { Pattern.sanitizeInput(e) },
                                                })} />)</strong></label>
                                            </div>


                                        </div>

                                        {fields11.map((field, index) => (
                                            <div className='container-fluid'>
                                                <input type='hidden' key={field.id} {...register8(`ucbEligibility[${index}].ifvId`)} value={appId} />
                                                <input type='hidden' key={field.id} {...register8(`ucbEligibility[${index}].id`)} />
                                                <input type='hidden' key={field.id} {...register8(`ucbEligibility[${index}].eligibilityType`)} value="BFS" />

                                                <div className='row pt-0' key={field.id}>
                                                    <div className='col-md-1'>
                                                        <div className='form-group'>
                                                            {index + 1}
                                                        </div>
                                                    </div>
                                                    <div className='col-md-3'>
                                                        <div className='form-group'>
                                                            <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='text'
                                                                {...register8(`ucbEligibility[${index}].particulars`, {
                                                                    required: "Field is required",
                                                                    onChange: (e) => { Pattern.sanitizeInput(e) },
                                                                    validate: (value) => {
                                                                        if (/\d/.test(value)) return 'Field should not contain any numbers';
                                                                        return true;
                                                                    },

                                                                })}
                                                            />
                                                            <span className='vldn'>{errors8.ucbEligibility && errors8.ucbEligibility[index]?.particulars && errors8.ucbEligibility[index]?.particulars.message}</span>
                                                        </div>
                                                    </div>

                                                    <div className='col-md-3'>
                                                        <div className='form-group'>
                                                            <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='text'
                                                                {...register8(`ucbEligibility[${index}].bfsNorm`, {
                                                                    //  required: "Field is required",
                                                                    onChange: (e) => { Pattern.sanitizeInput(e) },
                                                                })}
                                                            />
                                                            <span className='vldn'>{errors8.ucbEligibility && errors8.ucbEligibility[index]?.bfsNorm && errors8.ucbEligibility[index]?.bfsNorm.message}</span>
                                                        </div>
                                                    </div>

                                                    <div className='col-md-2'>
                                                        <div className='form-group'>
                                                            <textarea className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                {...register8(`ucbEligibility[${index}].relaxationCap`, {
                                                                    //   required: "Field is required",
                                                                    onChange: (e) => { Pattern.sanitizeInput(e) },
                                                                })}
                                                            />
                                                        </div>
                                                    </div>

                                                    <div className='col-md-3'>
                                                        <div className='form-group'>
                                                            <textarea className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                {...register8(`ucbEligibility[${index}].complianceStatus`, {
                                                                    //  required: "Field is required",
                                                                    onChange: (e) => { Pattern.sanitizeInput(e) },
                                                                })}
                                                            />
                                                        </div>
                                                    </div>

                                                </div>


                                            </div>
                                        ))}
                                        <br />
                                        <div className='row'>
                                            <div className='col-md-12'>
                                                <h5> <strong>Board/RiMC approval and its compliance:</strong></h5>
                                            </div>
                                        </div>

                                        <div className='container-fluid'>
                                            <div className='row row_align'>
                                                <div className='col-md-1'>
                                                    <label><strong>Sl No</strong></label>
                                                </div>

                                                <div className='col-md-6'>
                                                    <label><strong>Board / RiMC stipulation</strong></label>
                                                </div>

                                                <div className='col-md-5'>
                                                    <label><strong>Compliance</strong></label>
                                                </div>


                                            </div>

                                            <div className='row'>
                                                <div className='col-md-1'>
                                                    <div className='form-group'>
                                                        i.
                                                    </div>
                                                </div>

                                                <div className='col-md-6'>
                                                    <div className='form-group'>
                                                        <textarea className='form-control'
                                                            defaultValue={RiMCStip1}
                                                            autoComplete='off'
                                                            onChange={(e) => setRiMCStip1(e.target.value)}
                                                        />

                                                    </div>
                                                </div>

                                                <div className='col-md-5'>
                                                    <div className='form-group'>
                                                        <textarea className='form-control'
                                                            defaultValue={comp1}
                                                            autoComplete='off'
                                                            onChange={(e) => setComp1(e.target.value)}
                                                        />
                                                    </div>
                                                </div>
                                            </div>

                                            {ucb && <div className='row'>
                                                <div className='col-md-1'>
                                                    <div className='form-group'>
                                                        ii.
                                                    </div>
                                                </div>

                                                <div className='col-md-6'>
                                                    <div className='form-group'>
                                                        <textarea className='form-control'
                                                            defaultValue={RiMCStip2}
                                                            autoComplete='off'
                                                            onChange={(e) => setRiMCStip2(e.target.value)}
                                                        />

                                                    </div>
                                                </div>

                                                <div className='col-md-5'>
                                                    <div className='form-group'>
                                                        <textarea className='form-control'
                                                            defaultValue={comp2}
                                                            autoComplete='off'
                                                            onChange={(e) => setComp2(e.target.value)}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                            }

                                            <div className='row'>
                                                <div className='col-md-12'>
                                                    {/* <div className='form-group'>
                                                The bank is meeting all the scheme parameters.
                                            </div> */}
                                                </div>


                                            </div>

                                        </div>

                                    </div>

                                </>

                                }



                                {showSFB && !ucb && !rrb && <div className='container-fluid'>
                                    <div className='row row_align'>
                                        <div className='col-md-6'>
                                            <div className='form-group'>
                                                <label><strong> BFS Norm for Eligibility</strong></label>
                                            </div>
                                        </div>

                                        <div className='col-md-3'>
                                            <label><strong>Extent of Relaxation</strong></label>
                                        </div>

                                        <div className='col-md-3'>
                                            <label><strong> Compliance/Remarks</strong></label>
                                        </div>


                                    </div>

                                    <div className='row'>
                                        <div className='col-md-6'>
                                            {/* <div className='form-group'>
                                                Net NPA not to exceed 7%
                                            </div> */}
                                            <div className='form-group'>
                                                <input className='form-control'
                                                    type='text'
                                                    {...register8('ecBfnormseligibility')}
                                                    autoComplete='off'
                                                />
                                            </div>
                                        </div>

                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <input className='form-control'
                                                    type='text'
                                                    {...register8('ecRemarks')}
                                                    // value='No relaxation'
                                                    autoComplete='off'
                                                />
                                                <input type='hidden' {...register8('ecId')} />
                                                <input type='hidden' {...register8('ifvId')} value={appId} />
                                            </div>
                                        </div>

                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <textarea className='form-control'
                                                    {...register8('ecBfsnorms')}
                                                    autoComplete='off'
                                                />
                                            </div>
                                        </div>
                                    </div>



                                    <div className='row'>
                                        <div className='col-md-6'>
                                            <div className='form-group'>
                                                The sanctioning authority to consider assistance to individual SFB upto the exposure limit on a case-to-case basis, subject to SIDBI's exposure being capped at 30% of the loans and advances portfolio of the SFB concerned as on March 31, of the previous year. (Board of Directors in its meeting no. 215 held on August 05, 2022)
                                            </div>
                                        </div>

                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <input className='form-control'
                                                    type='text'
                                                    {...register8('ecRemarks1')}
                                                    //value='No relaxation'
                                                    autoComplete='off'
                                                />
                                            </div>
                                        </div>

                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <textarea className='form-control'
                                                    {...register8('ecBfsnorms1')}
                                                    autoComplete='off'
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <div className='row'>
                                        <div className='col-md-12'>
                                            {/* <div className='form-group'>
                                                The bank is meeting all the scheme parameters.
                                            </div> */}
                                        </div>


                                    </div>

                                </div>}


                                {!showSFB && <div className='container-fluid'>
                                    <div className='row row_align'>
                                        <div className='col-md-12'></div>
                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <label>BFS NORM For Eligibility</label>
                                            </div>
                                        </div>

                                        <div className='col-md-3'>
                                            <label><strong>Extent of Relaxation</strong></label>
                                        </div>

                                        <div className='col-md-6'>
                                            <label><strong>Compliance/Remarks</strong></label>
                                        </div>
                                    </div>

                                    <div className='row'>
                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <input className='form-control'
                                                    type='text'
                                                    {...register8('ecBfnormseligibility')}
                                                />
                                                <input type='hidden' {...register8('ecId')} />
                                                <input type='hidden' {...register8('ifvId')} value={appId} />
                                            </div>
                                        </div>

                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <div className='checks_lbl'>
                                                    <div className='checks_wrp'><label><strong>For PSBs </strong></label><input type='checkbox'  {...register8('ecPsbs')}
                                                        onChange={() => handleEcPsbsCheckBox()} checked={ecPsbsSelected} /></div>
                                                    {/* <p>Full relaxation for PSBs by the sanctioning Committee.</p> */}
                                                    <input className='form-control'
                                                        type='text'
                                                        {...register8('ecRemarks')}
                                                        autoComplete='off'
                                                    />
                                                </div>

                                                <div className='checks_lbl'>
                                                    <div className='checks_wrp'><label><strong>For Pvt. Sector and Foreign Banks</strong></label><input type='checkbox'
                                                        {...register8('ecSectForEignBank')} onChange={() => handleSectForCheckBox()} checked={sectForChecked} /></div>
                                                    {/* <p>Relaxation to be permitted up to 12.5%</p> */}
                                                    <input className='form-control'
                                                        type='text'
                                                        {...register8('ecRemarks1')}
                                                        autoComplete='off'
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                        <div className='col-md-6'>
                                            <div className='form-group'>
                                                <div className="branch_on"><label>NNPA as on</label>
                                                    <div className="brn_wrp">
                                                        <Controller
                                                            control={control8}
                                                            name='ecNnpaDate'
                                                            render={({ field: { onChange, onBlur, value, ref } }) => (
                                                                <ReactDatePicker className="form-control"
                                                                    onChange={onChange}
                                                                    onBlur={onBlur}
                                                                    selected={value}
                                                                    dateFormat="dd/MM/yyyy"
                                                                />
                                                            )}
                                                            {...register8('ecNnpaDate')}
                                                        />
                                                    </div>
                                                    <label> was</label>
                                                    <div className="brn_wrp">
                                                        <input className='form-control'
                                                            type='number'
                                                            step='any'
                                                            {...register8('ecNnpaPercent')}
                                                        />
                                                    </div>
                                                    <label>%</label>
                                                </div>
                                            </div>
                                            <div className='form-group'>
                                                <textarea className='form-control mb-1'
                                                    {...register8("ecNnoaRemarks")}
                                                    autoComplete="off"
                                                />
                                                <select className='form-control' {...register8("ecNnpaStatus")}>
                                                    <option value="">Please select one</option>
                                                    <option value="Complied with">Complied with </option>
                                                    <option value="Non Complied with">Non Complied with </option>
                                                </select>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                                }
                                <br />
                                {(rmseScheme) && <div className='container-fluid'>
                                    <div className='row'>
                                        <div className='col-md-12'>
                                            <h5> <strong>RMSE-(Regular/ICDD) Specific Criteria and Compliance</strong></h5>
                                        </div>
                                    </div>

                                    <div className='row'>
                                        <div className='col-md-12'><h6><strong>i. Board approved Criteria and Compliance</strong></h6></div>
                                        <div className='col-md-9'>
                                            <div className='form-group'>
                                                <p className='mb-0'><strong>Assistance Against Existing Assets:</strong></p>
                                                Refinance will be on reimbursement basis against existing assets. Amount equivalent to outstanding portfolio of loans and advances (ie. terms loans and working capital advances) for eligible activities, in which disbursements have been made to existing/new MSEs up to 12 months before date of application for refinance by PLIs.
                                            </div>
                                        </div>

                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <textarea className='form-control mb-1'
                                                    {...register8("ecRmseAssistance")}
                                                    autoComplete="off"
                                                />
                                                <select className='form-control' {...register8("ecRmseStatus")}>
                                                    <option value="">Please select one</option>
                                                    <option value="Complied with">Complied with </option>
                                                    <option value="Non Complied with">Non Complied with </option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                    <div className='row'>
                                        <div className='col-md-9'>
                                            <div className='form-group'>
                                                <p className='mb-0'><strong>Assistance for Creation of Incremental Assets:</strong></p>
                                                Commitment for concessional funds under the facility will be given to PLIs against their application indicating the anticipated utilisation. Such commitment would be generally valid for 3 to 6 months.
                                            </div>
                                        </div>

                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <textarea className='form-control mb-1'
                                                    {...register8("ecAssstance")}
                                                    autoComplete="off"
                                                />
                                                <select className='form-control' {...register8("ecAssstanceStatus")}>
                                                    <option value="">Please select one</option>
                                                    <option value="Complied with">Complied with </option>
                                                    <option value="Non Complied with">Non Complied with </option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                    <div className='row'>
                                        <div className='col-md-12'><h6><strong>i. RBI Criteria and compliance</strong></h6></div>
                                        <div className='col-md-9'>
                                            <div className='form-group'>
                                                Lending rate to ultimate borrowers by eligible institutions should be up to 350 bps/ 450 bps over the External Benchmark "10-year G-Sec yield" under Regular / ICDD scheme respectively.
                                                <p className='mt-3'><strong>Note:</strong><br />The yield as on the last day of the quarter may be used to consider the eligibility of bank loans for refinance for the ensuing quarter.</p>
                                                <div className="branch_on"><label>10 Year G-Sec yield as on</label>
                                                    <div className="brn_wrp">
                                                        <Controller
                                                            control={control8}
                                                            name='ecGsecDate'
                                                            render={({ field: { onChange, onBlur, value, ref } }) => (
                                                                <ReactDatePicker className="form-control"
                                                                    onChange={onChange}
                                                                    onBlur={onBlur}
                                                                    selected={value}
                                                                    dateFormat="dd/MM/yyyy"
                                                                />
                                                            )}
                                                            {...register8("ecGsecDate")}
                                                        />
                                                    </div>
                                                    <label>was</label>
                                                    <div className="brn_wrp">
                                                        <input className='form-control'
                                                            type='number'
                                                            step='any'
                                                            autoComplete='off'
                                                            {...register8('ecGsecPercent')}

                                                        />
                                                    </div>
                                                    <label>%</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <textarea className='form-control mb-1'
                                                    {...register8("ecRbiCompliance")}
                                                    autoComplete="off"
                                                />
                                                <select className='form-control' {...register8("ecRbiStatus")}>
                                                    <option value="">Please select one</option>
                                                    <option value="Complied with">Complied with </option>
                                                    <option value="Non Complied with">Non Complied with </option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>




                                    <div className='row'>
                                        <div className='col-md-9'>
                                            <div className='form-group'>
                                                <div className="branch_on"><label>SIDBI's spread is fixed at </label>
                                                    <div className="brn_wrp">
                                                        <input className='form-control'
                                                            type='number'
                                                            autoComplete='off'
                                                            step='any'
                                                            {...register8('ecSdbiFixed')}
                                                        />
                                                    </div>
                                                    <label>bps over and above the cost of borrowing under MSE Refinance Fund.</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <textarea className='form-control mb-1'
                                                    {...register8("ecSidbiRemarks")}
                                                    autoComplete="off"
                                                />
                                                <select className='form-control' {...register8("ecSidbiStatus")}>
                                                    <option value="">Please select one</option>
                                                    <option value="Complied with">Complied with </option>
                                                    <option value="Non Complied with">Non Complied with </option>
                                                </select>

                                            </div>
                                        </div>
                                    </div>

                                    {!CommonUtil.isEmpty(rmseSchemesList[0]) &&
                                        <div className='row'>

                                            <div className='col-md-9'>
                                                <div className='form-group'>
                                                    <p><strong>{rmseSchemesList[0]}</strong></p>
                                                    <textarea className='form-control'
                                                        {...register8("rmse1Data")}
                                                        autoComplete="off" maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e) }}
                                                    />
                                                </div>
                                            </div>

                                            <div className='col-md-3'>
                                                <div className='form-group'>
                                                    <textarea className='form-control mb-1'
                                                        {...register8("ecRmseRemarks")}
                                                        autoComplete="off" maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e) }}
                                                    />
                                                    <select className='form-control' {...register8("ecRmseStatus1")}>
                                                        <option value="">Please select one</option>
                                                        <option value="Complied with">Complied with </option>
                                                        <option value="Non Complied with">Non Complied with </option>
                                                    </select>

                                                </div>
                                            </div>
                                        </div>
                                    }

                                    {!CommonUtil.isEmpty(rmseSchemesList[1]) &&
                                        <div className='row'>
                                            <div className='col-md-9'>
                                                <div className='form-group'>
                                                    <p><strong>{rrb ? 'RMSE- (ICDD)' : rmseSchemesList[1]}</strong><br /></p>
                                                    <textarea className='form-control'
                                                        {...register8("rmse2Data")}
                                                        autoComplete="off" maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e) }}
                                                    />
                                                </div>
                                            </div>

                                            <div className='col-md-3'>
                                                <div className='form-group'>
                                                    <textarea className='form-control mb-1'
                                                        {...register8("ecIcddRemarks")}
                                                        autoComplete="off"
                                                    />
                                                    <select className='form-control' {...register8("ecIcddStatus")}>
                                                        <option value="">Please select one</option>
                                                        <option value="Complied with">Complied with </option>
                                                        <option value="Non Complied with">Non Complied with </option>
                                                    </select>

                                                </div>
                                            </div>
                                        </div>
                                    }

                                    {!CommonUtil.isEmpty(rmseSchemesList[2]) &&
                                        <div className='row'>
                                            <div className='col-md-9'>
                                                <div className='form-group'>
                                                    <p><strong>{rmseSchemesList[2]}</strong><br /></p>
                                                    <textarea className='form-control'
                                                        {...register8("rmse3Data")}
                                                        autoComplete="off" maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e) }}
                                                    />
                                                </div>
                                            </div>

                                            <div className='col-md-3'>
                                                <div className='form-group'>
                                                    <textarea className='form-control mb-1'
                                                        {...register8("rmse3Remarks")}
                                                        autoComplete="off"
                                                    />
                                                    <select className='form-control' {...register8("rmse3Status")}>
                                                        <option value="">Please select one</option>
                                                        <option value="Complied with">Complied with </option>
                                                        <option value="Non Complied with">Non Complied with </option>
                                                    </select>

                                                </div>
                                            </div>
                                        </div>
                                    }

                                    {!CommonUtil.isEmpty(rmseSchemesList[3]) &&
                                        <div className='row'>
                                            <div className='col-md-9'>
                                                <div className='form-group'>
                                                    <p><strong>{rmseSchemesList[3]}</strong><br /></p>
                                                    <textarea className='form-control'
                                                        {...register8("rmse4Data")}
                                                        autoComplete="off" maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e) }}
                                                    />
                                                </div>
                                            </div>

                                            <div className='col-md-3'>
                                                <div className='form-group'>
                                                    <textarea className='form-control mb-1'
                                                        {...register8("rmse4Remarks")}
                                                        autoComplete="off"
                                                    />
                                                    <select className='form-control' {...register8("rmse4Status")}>
                                                        <option value="">Please select one</option>
                                                        <option value="Complied with">Complied with </option>
                                                        <option value="Non Complied with">Non Complied with </option>
                                                    </select>

                                                </div>
                                            </div>
                                        </div>
                                    }

                                    {!CommonUtil.isEmpty(rmseSchemesList[4]) &&
                                        <div className='row'>
                                            <div className='col-md-9'>
                                                <div className='form-group'>
                                                    <p><strong>{rmseSchemesList[4]}</strong><br /></p>
                                                    <textarea className='form-control'
                                                        {...register8("rmse5Data")}
                                                        autoComplete="off" maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e) }}
                                                    />
                                                </div>
                                            </div>

                                            <div className='col-md-3'>
                                                <div className='form-group'>
                                                    <textarea className='form-control mb-1'
                                                        {...register8("rmse5Remarks")}
                                                        autoComplete="off"
                                                    />
                                                    <select className='form-control' {...register8("rmse5Status")}>
                                                        <option value="">Please select one</option>
                                                        <option value="Complied with">Complied with </option>
                                                        <option value="Non Complied with">Non Complied with </option>
                                                    </select>

                                                </div>
                                            </div>
                                        </div>
                                    }


                                </div>
                                }

                                <div className='container-fluid'>
                                    {fabiaMsmeRampe && <>  <div className='row'>
                                        <div className='col-md-12'>
                                            <h5> <strong>FABIA-MSME/RAMPE scheme specific criteria and compliance</strong></h5>
                                        </div>
                                    </div>

                                        <div className='row'>
                                            <div className='col-md-12'><h6><strong>i. Board approved criteria and compliance</strong></h6></div>
                                            <div className='col-md-9'>
                                                <div className='form-group'>
                                                    <p className='mb-0'><strong>a Assistance for creation of Incremental assets:</strong></p>
                                                    Sanction/Disbursement under the Facility will be given to PLIs against their application indicating the anticipated utilization and creation of incremental MSME assets. Such commitment would be generally valid for 3 to 6 months within which PLIs have to create the MSME assets and submit the certificate along-with underlying assets / end borrower's list in our prescribed format.
                                                </div>
                                            </div>

                                            <div className='col-md-3'>
                                                <div className='form-group'>

                                                    <textarea className='form-control'
                                                        {...register8("ecFabiaRemarks")}
                                                        autoComplete="off"
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </>
                                    }
                                    <div className='row'>
                                        <div className='col-md-12'>
                                            <div className='form-group'>
                                                <textarea className='form-control'
                                                    {...register8("ecFabiaStatus")}
                                                    autoComplete="off"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div className='row'>
                                        <div className='col-md-12'>
                                            <div className='form-group'>
                                                <input className='form-control'
                                                    {...register8("bankParameter")}
                                                    autoComplete="off"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="button-container-center">
                                    {(editable || (!isMaker && locked)) && <button type='submit' className='btn bg-success btnSave'>{ecId > 0 ? 'Update' : 'Save'}</button>}
                                </div>

                            </Accordion.Body>
                        </Accordion.Item>
                    </form>


                    {(ucb || rrb) &&
                        <Accordion.Item eventKey="3">
                            <Accordion.Header>Justification/ rationale for the proposed relaxation</Accordion.Header>
                            <Accordion.Body>
                                <form key={9} onSubmit={handleSubmitOfUcbCriteria(onSubmitOfUcbCriteria)}>
                                    <div className='row'>
                                        <div className='col-md-12'>
                                            <div className='form-group'>
                                                <textarea  {...register9('ucbCriteria[0].justification')}
                                                    autoComplete='off' />
                                            </div>
                                        </div>
                                    </div>
                                    {ucb && <>
                                        <div className='row'>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <textarea {...register9('ucbCriteria[0].note')}
                                                        autoComplete='off' />
                                                </div>
                                            </div>
                                        </div>


                                        <div className='container-fluid'>
                                            <div className='row'>
                                                <div className='col-md-1'>
                                                    <label><strong> Sl No</strong></label>
                                                </div>
                                                <div className='col-md-4'>
                                                    <label><strong>Criteria parameters for qualifying as FSWM</strong></label>
                                                </div>
                                                <div className='col-md-2'>
                                                    <label><strong>Complied (Y/N)</strong></label>
                                                </div>

                                                <div className='col-md-5'>
                                                    <label><strong>Compliance <input className='form-control' type='text'
                                                        {...register9(`ucbCriteria[0].complianceDate`, {
                                                            onChange: (e) => { Pattern.sanitizeInput(e) },
                                                        })} /></strong></label>
                                                </div>

                                            </div>

                                            {fields12.map((field, index) => (
                                                <div className='container-fluid'>
                                                    <input type='hidden' key={field.id} {...register9(`ucbCriteria[${index}].ifvId`)} value={appId} />
                                                    <input type='hidden' key={field.id} {...register9(`ucbCriteria[${index}].id`)} />

                                                    <div className='row pt-0' key={field.id}>
                                                        <div className='col-md-1'>
                                                            <div className='form-group'>
                                                                {index + 1}
                                                            </div>
                                                        </div>
                                                        <div className='col-md-5'>
                                                            <div className='form-group'>
                                                                <textarea className='form-control'
                                                                    key={field.id} // important to include key with field's id
                                                                    {...register9(`ucbCriteria[${index}].criteriaParameters`, {
                                                                        required: "Field is required",
                                                                        onChange: (e) => { Pattern.sanitizeInput(e) },
                                                                    })}
                                                                />
                                                                <span className='vldn'>{errors8.ucbCriteria && errors8.ucbCriteria[index]?.criteriaParameters && errors8.ucbCriteria[index]?.criteriaParameters.message}</span>
                                                            </div>
                                                        </div>

                                                        <div className='col-md-1'>
                                                            <div className='form-group'>
                                                                {/* <input className='form-control'
                                                                key={field.id} // important to include key with field's id
                                                                type='text'
                                                                {...register9(`ucbCriteria[${index}].complied`, {
                                                                    required: "Field is required",
                                                                    onChange: (e) => { Pattern.sanitizeInput(e) },
                                                                })}
                                                            /> */}

                                                                <select className='form-control' {...register9(`ucbCriteria[${index}].complied`)}>
                                                                    <option value="">Please select one</option>
                                                                    <option value="Y">Y</option>
                                                                    <option value="N">N</option>
                                                                </select>


                                                                <span className='vldn'>{errors9.ucbCriteria && errors9.ucbCriteria[index]?.complied && errors9.ucbCriteria[index]?.complied.message}</span>
                                                            </div>
                                                        </div>

                                                        <div className='col-md-5'>
                                                            <div className='form-group'>
                                                                <textarea className='form-control'
                                                                    key={field.id} // important to include key with field's id
                                                                    {...register9(`ucbCriteria[${index}].compliance`, {
                                                                        //  required: "Field is required",
                                                                        onChange: (e) => { Pattern.sanitizeInput(e) },
                                                                    })}
                                                                />
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            ))}


                                        </div>
                                    </>
                                    }
                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && <button type='submit' className='save'>Save<i className="fa fa-circle-check"></i></button>}
                                    </div>
                                </form>
                            </Accordion.Body>

                        </Accordion.Item>
                    }

                </Accordion>
                <div className="button-container-center">
                    {appId > 0 && <button type='button' className='btn btnPrev' onClick={goToPrev}><i className="fa fa-arrow-left"></i> Prev</button>}
                    {appId > 0 && <button type='button' className='btn btnNext' onClick={goToNext}>Next <i className="fa fa-arrow-right"></i></button>}
                </div>
            </div>
            {loading && <Loading />}
            <MessageModal
                open={isOpen}
                onClose={hideMessage}
                message={messageConfig.message}
                type={messageConfig.type}
                totalMessages={totalMessages}
                currentIndex={currentIndex}
                onNext={nextMessage}
                onPrev={prevMessage}
                hasNext={hasNext}
                hasPrev={hasPrev}
            />
        </Fragment >
    )
}
export default SectionTwo;
