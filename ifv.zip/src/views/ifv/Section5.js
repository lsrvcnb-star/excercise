import DeleteIcon from '@mui/icons-material/Delete';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import RefreshIcon from '@mui/icons-material/Refresh';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import { Box, Button, CircularProgress, IconButton, LinearProgress, Tab, Tabs, TextField, Typography } from '@mui/material';
import cnfrm from 'assets/img/alert.gif';
import axios from 'axios';
import Loading from 'components/Loading';
import MessageModal from 'components/MessageModal';
import ProposalHeader from 'components/ProposalHeader';
import SectionNavigation from 'components/SectionNavigation';
import { format } from 'date-fns';
import { useErrorHandler } from 'hooks/useErrorHandler';
import useMessageModal from 'hooks/useMessageModal';
import { Fragment, useEffect, useState } from 'react';
import {
    Modal
} from "react-bootstrap";
import Accordion from 'react-bootstrap/Accordion';
import { confirmAlert } from 'react-confirm-alert';
import ReactDatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { Controller, useFieldArray, useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
import Select from 'react-select';
import IfvAppraisalService from 'services/IfvAppraisalService';
import MasterService from 'services/MasterService';
import MinutesService from 'services/MinutesService';
import UserService from 'services/UserService';
import PrincipalRepaymentData from 'services/constants/PrincipalRepaymentData';
import { RatingType } from 'services/constants/RatingType';
import CommonUtil from 'services/utils/CommonUtil';
import FileUtil from 'services/utils/FileUtil';
import { getJwtToken } from 'services/utils/JwtUtil';
import Pattern from 'services/validators/Pattern';
import RimvDocsDialog from 'views/RimvDocsDialog';
import RRBGeographicalAreaTabs from './RRBGeographicalAreaTabs';

const API_BASE_URL = process.env.REACT_APP_API_ENDPOINT;

const TermsAndConditions = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const showSFB = location.state ? location.state.showSFB : null;
    const appId = location.state ? location.state.appId : 0;
    const [ifvApp, setIfvApp] = useState({});
    const [openRimvDialog, setOpenRimvDialog] = useState(false);
    const {
        showMessage,
        hideMessage,
        isOpen,
        messageConfig,
        totalMessages,
        currentIndex,
        nextMessage,
        prevMessage,
        hasNext,
        hasPrev
    } = useMessageModal();
    const { handleApiError } = useErrorHandler(showMessage);

    const { control, } = useForm({
        mode: "onBlur"
    });

    const { control: control16, register: register16, handleSubmit: handleSubmitOfTermsAndConditionData, setValue: setValue16, getValues: getValues16, formState: { errors: errors16 }, } = useForm({
        mode: "onBlur"
    });

    const { control: control17, register: register17, handleSubmit: handleSubmitOfIntitutional, setValue: setValue17, getValues: getValues17, formState: { errors: errors17 }, } = useForm({
        mode: "onBlur"
    });

    const { control: control18, register: register18, handleSubmit: handleSubmitOfRatingRepo, setValue: setValue18, getValues: getValues18, formState: { errors: errors18 }, } = useForm({
        mode: "onBlur"
    });

    const { control: control19, register: register19, handleSubmit: handleSubmitOfBoardOfDirectors, setValue: setValue19, getValues: getValues19, formState: { errors: errors19 }, } = useForm({
        mode: "onBlur"
    });

    const { control: control4, register: register4, handleSubmit: handleSubmitOfGeographicalArea, setValue: setValue4, getValues: getValues4, watch: watch4, formState: { errors: errors4 }, } = useForm({
        mode: "onBlur"
    });

    const { control: control5, register: register5, handleSubmit: handleSubmitOfUcbAnnexure4, setValue: setValue5, getValues: getValues5, formState: { errors: errors5 }, } = useForm({
        mode: "onBlur"
    });

    const { control: discControl, register: discRegister, handleSubmit: handleSubmitOfDisclosure, setValue: setValueOfDisc, getValues: getValuesOfDisc, formState: { errors: errorOfDisc }, } = useForm({
        mode: "onBlur"
    });

    const { fields: discFields, append: discAppend, remove: discRemove } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "disclosure", // unique name for your Field Array
    });

    const { fields: fields17, append: append17, remove: remove17 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "institution", // unique name for your Field Array
    });

    const { fields: fields18, append: append18, remove: remove18 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "ratingRepo", // unique name for your Field Array
    });

    const { fields: fields19, append: append19, remove: remove19 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "boardOfDirectors", // unique name for your Field Array
    });

    const { fields: fields3, append: append3, remove: remove3 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "geographicalArea", // unique name for your Field Array
    });

    const { fields: fields5, append: append5, remove: remove5 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "ucbAnnexure4", // unique name for your Field Array
    });

    const { fields: fields6, append: append6, remove: remove6 } = useFieldArray({
        control, // control props comes from useForm (optional: if you are using FormContext)
        name: "ucbAnnexure5", // unique name for your Field Array
    });

    const [inDate, setInDate] = useState('')
    const [locked, setLocked] = useState(false)
    const [totRep, setTotRep] = useState(0)
    const [isMaker, setMaker] = useState(false)
    const [isChecker, setChecker] = useState(false)
    const [isMakerConvenor, setMakerConvenor] = useState(false)
    const [isCheckerConvenor, setCheckerConvenor] = useState(false)
    const [isHigherAuthority, setHigherAuthority] = useState(false)
    const [isPrivatePublicOrForeignBank, setIsPrivatePublicOrForeignBank] = useState(false)
    const [isAdminChecker, setAdminChecker] = useState(false)
    const [editable, setEditable] = useState(false)
    const [isConfirmed, setConfirmed] = useState(false)
    const [isApproved, setApproved] = useState(false)
    const [appStatus, setAppStatus] = useState('')
    const [ucb, setUcb] = useState(false)
    const [rrb, setRRB] = useState(false)
    const getTblFwdDetail = () => {

        IfvAppraisalService.getTblFwdDetail(appId).then(
            (response) => {
                const status = response.data.appStatus
                if (status === 'LK') {
                    setLocked(true)
                    setEditable(false)
                    setAppStatus('Locked')
                }
                if (status === 'NW') {
                    setLocked(false)
                    setEditable(true)
                    setAppStatus('New')
                }
                if (status === 'CN') {
                    setLocked(false)
                    setEditable(false)
                    setAppStatus('Confirmed')
                    setConfirmed(true)
                }
                if (status === 'AP') {
                    setLocked(false)
                    setEditable(false)
                    setAppStatus('Approved')
                    setApproved(true)
                }
            },
            (error) => {
                handleApiError(error, 'loading TBL FWD Details');
            }
        )
    }

    const [options, setOptions] = useState([])
    const [selectedOption, setSelectedOption] = useState([])
    const handleChange = (val) => {
        setSelectedOption(val);
    };

    const getAllOnMstParticulars = () => {

        IfvAppraisalService.getAllOnMstParticulars("Other Conditions").then(
            (response) => {

                const filteredData = response.data.filter((item) => item.mstFlg === 'Y')

                const formattedOptions = filteredData.map((item) => ({
                    value: parseInt(item.mstCode),
                    label: item.mstRemarks,
                }))
                setOptions(formattedOptions)
                getProposedSchemesData(formattedOptions)
            },
            (error) => {
                handleApiError(error, 'loading Other Conditions');
            }
        )
    }

    const getinstitutional = () => {
        IfvAppraisalService.getinstitutional(appId).then(response => {
            const appData = response.data
            if (appData.length > 0) {
                for (let i = 0; i < appData.length; i++) {
                    remove17(i)
                    append17({})
                }
            }
            else {
                append17({})
                setValue17(`institution[0].inDate`, '')
                setInDate('')
            }
            let tot = 0;
            appData.forEach((item, index) => {
                setValue17(`institution[${index}].inId`, item.inId)
                setValue17(`institution[${index}].ifvId`, item.ifvId)
                setValue17(`institution[${index}].inParticular`, item.inParticular)
                setValue17(`institution[${index}].inAmount`, item.inAmount)
                if (!CommonUtil.isEmpty(item.inDate)) {
                    setValue17(`institution[${index}].inDate`, item.inDate)
                    setInDate(new Date(item.inDate))
                }

                tot = tot + parseFloat(item.inAmount)
            });
            setTotRep(CommonUtil.roundToTwoDecimals(tot))
        },
            (error) => {
                handleApiError(error, 'loading details of Institutional');
            }
        )
    }

    const [loading, setLoading] = useState(false)

    const onSubmitOfInstitutional = (data, e) => {
        setLoading(true)

        if (CommonUtil.isEmpty(inDate)) {
            setLoading(false)
            showMessage('Please Enter Valid Date', 'warning')
            return
        }

        let finalData = data['institution']?.filter(item => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.inParticular))
        const res = CommonUtil.validateDate(inDate)
        if (res === true) {
        } else {
            setLoading(false)
            showMessage('Please Enter Valid Date', 'warning')
            return
        }
        finalData.forEach((item, index) => {
            item.inDate = inDate
        })

        IfvAppraisalService.saveInstitutional(finalData).then((response) => {
            setLoading(false)
            showMessage('Institutional details have been successfully saved!', 'success')
            getinstitutional()
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving Institutional');
            })
    }

    const getRatingRepo = () => {
        IfvAppraisalService.getRatingRepo(appId).then(response => {
            const appData = response.data
            if (appData.length > 0) {
                for (let i = 0; i < appData.length; i++) {
                    remove18(i)
                    append18({})
                }
            }
            else {
                append18({})
            }
            appData.forEach((item, index) => {
                setValue18(`ratingRepo[${index}].rtCode`, item.rtCode)
                setValue18(`ratingRepo[${index}].ifvId`, item.ifvId)
                setValue18(`ratingRepo[${index}].rtType`, item.rtType)
                setValue18(`ratingRepo[${index}].rtParticulars1`, item.rtParticulars1)
                setValue18(`ratingRepo[${index}].rtRemarks`, item.rtRemarks)
                setValue18(`ratingRepo[${index}].rtOrder`, item.rtOrder)
            });
        },
            (error) => {
                handleApiError(error, 'loading Details of Rating');
            }
        )
    }

    const onSubmitOfRatingRepo = (data, e) => {
        setLoading(true)
        const finalData = data['ratingRepo']?.filter((item => item != null))
        IfvAppraisalService.saveRatingRepo(finalData).then((response) => {
            setLoading(false)
            showMessage('Rating details have been successfully saved!', 'success')
            getRatingRepo()
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving Details of Rating');
            })
    }

    const getBoardOfDirectors = () => {
        IfvAppraisalService.getBoardOfDirectors(appId).then(response => {
            const appData = response.data
            if (appData.length > 0) {
                for (let i = 0; i < appData.length; i++) {
                    remove19(i)
                    append19({})
                }
            }
            else {
                append19({})
            }
            appData.forEach((item, index) => {
                setValue19(`boardOfDirectors[${index}].prCode`, item.prCode)
                setValue19(`boardOfDirectors[${index}].ifvId`, item.ifvId)
                setValue19(`boardOfDirectors[${index}].prFirstName`, item.prFirstName)
                setValue19(`boardOfDirectors[${index}].prDesignation`, item.prDesignation)
                setValue19(`boardOfDirectors[${index}].prBriefProfile`, item.prBriefProfile)
            });
        },
            (error) => {
                handleApiError(error, 'loading Details of Board of Directors');
            }
        )
    }

    const onSubmitOfBoardOfDirectors = (data, e) => {
        setLoading(true)
        IfvAppraisalService.saveBoardOfDirectors(data['boardOfDirectors']).then((response) => {
            setLoading(false)
            showMessage('Board of Directors details have been successfully saved!', 'success')
            getBoardOfDirectors()
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving Board of Directors');
            })
    }

    const getUcbAnnexure4 = (annexureNo) => {
        IfvAppraisalService.getUcbAnnexure4(appId, annexureNo).then((response) => {
            setLoading(false)
            const appData = response.data
            if (appData.length > 0) {
                appData.forEach((item, index) => {
                    remove5(index)
                    append5({})
                    setValue5(`ucbAnnexure4[${index}].id`, item.id)
                    setValue5(`ucbAnnexure4[${index}].ifvId`, item.ifvId)
                    setValue5(`ucbAnnexure4[${index}].particulars`, item.particulars)
                    setValue5(`ucbAnnexure4[${index}].remarks`, item.remarks)
                    setValue5(`ucbAnnexure4[${index}].annexureNo`, item.annexureNo)
                    if (!CommonUtil.isEmpty(item.note)) {
                        setValue5(`ucbAnnexure4[0].note`, item.note)
                    }
                })
            } else {
                append5({})
            }

        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading UCB Annexure IV');
            })
    }

    const getUcbAnnexure5 = (annexureNo) => {
        IfvAppraisalService.getUcbAnnexure4(appId, annexureNo).then((response) => {
            setLoading(false)
            const appData = response.data
            if (appData.length > 0) {
                appData.forEach((item, index) => {
                    remove6(index)
                    append6({})
                    setValue5(`ucbAnnexure5[${index}].id`, item.id)
                    setValue5(`ucbAnnexure5[${index}].ifvId`, item.ifvId)
                    setValue5(`ucbAnnexure5[${index}].particulars`, item.particulars)
                    setValue5(`ucbAnnexure5[${index}].remarks`, item.remarks)
                    setValue5(`ucbAnnexure5[${index}].annexureNo`, item.annexureNo)
                    if (!CommonUtil.isEmpty(item.note)) {
                        setValue5(`ucbAnnexure5[0].note`, item.note)
                    }
                })
            } else {
                append6({})
            }

        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading UCB Annexure V');
            })
    }

    const onSubmitOfUcbAnnexure4 = (data, e) => {

        const finalData = data['ucbAnnexure4']?.filter(item => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.note))
        if (CommonUtil.isEmpty(finalData)) {
            return
        }
        setLoading(true)
        IfvAppraisalService.saveUcbAnnexure4(finalData).then((response) => {
            setLoading(false)
            showMessage('Annexure IV details have been successfully saved!', 'success')
            getUcbAnnexure4(4)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving UCB Annexure IV');
            })
    }

    const onSubmitOfUcbAnnexure5 = (data, e) => {

        const finalData = data['ucbAnnexure5']?.filter(item => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.note))
        if (CommonUtil.isEmpty(finalData)) {
            return
        }
        setLoading(true)
        IfvAppraisalService.saveUcbAnnexure4(finalData).then((response) => {
            setLoading(false)
            showMessage('Annexure V details have been successfully saved!', 'success')
            getUcbAnnexure5(5)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving UCB Annexure V');
            })
    }

    const [proposedSchemes, setProposedSchemes] = useState([])

    useEffect(() => {
        const user = IfvAppraisalService.getCurrentUser();

        setMaker(UserService.isMaker(user))
        setChecker(UserService.isChecker(user))
        setMakerConvenor(UserService.isMakerConvenor(user))
        setHigherAuthority(UserService.isHigherAuthority(user))
        setCheckerConvenor(UserService.isCheckerConvenor(user))
        setAdminChecker(UserService.isAdminChecker(user))
        getAllOnMstParticulars()
        IfvAppraisalService.getIfvAppById(appId).then(
            (response) => {
                setIfvApp(response.data)
                if (response.data.ifvBankType === 'UCB') {
                    setUcb(true)
                    getUcbAnnexure4(4)
                    getUcbAnnexure5(5)
                    findByFileIfvIdAndFileModule(true)
                } else if (response.data.ifvBankType === 'RRB') {
                    setRRB(true)
                    getUcbAnnexure4(4)
                    getUcbAnnexure5(5)
                    findByFileIfvIdAndFileModule(true)
                } else {
                    setUcb(false)
                    findByFileIfvIdAndFileModule(false)
                }

                getAllOnIfvIdOnST(response.data.ifvBankType === 'RRB');

                MasterService.getBankType(response.data.cifNumber).then(
                    (resp) => {
                        const res = resp.data.trim()
                        if (res === 'PUBLIC SECTOR BANK' || res === 'PRIVATE SECTOR BANK' || res === 'FOREIGN BANKS') {
                            setIsPrivatePublicOrForeignBank(true)
                        }
                    },
                    (error) => {
                        handleApiError(error, 'loading Bank Type');
                    }
                )
            },
            (error) => {
                handleApiError(error, 'loading App Data');
            }
        )
        getinstitutional()
        getTblFwdDetail()
        getRatingRepo()
        getBoardOfDirectors()
        getDisclosureStatus()
        //fetchDocuments()
    }, []);

    const [showDisc, setShowDisc] = useState(false)

    const getDisclosureStatus = () => {
        IfvAppraisalService.getDisclosureStatus(appId).then(
            (response) => {

                if (response.data == 'Yes') {
                    getDisclosure()
                    setShowDisc(true)
                } else {
                    setShowDisc(false)
                }

            },
            (error) => {
                handleApiError(error, 'loading disclosure data');
            }
        )
    }

    function getProposedSchemesData(options) {
        IfvAppraisalService.getAllSchemesOnIfvId(appId).then(
            (response) => {

                setProposedSchemes(response.data)

                if (response.data.length > 0) {
                    const obj = response.data[0]
                    setSelectedButton([])
                    setSelectedButton(prev => ({ ...prev, 0: 'true' }))
                    getSanctionTermsOnPrIdAndIfvId(options, obj)
                }

            },
            (error) => {
                handleApiError(error, 'loading schemes data');
            }
        )
    }

    const documentLock = () => {
        if (CommonUtil.isEmpty(appChecker)) {
            showMessage('Please select checker to proceed further', 'warning')
            return
        }

        setLoading(true)
        const user = IfvAppraisalService.getCurrentUser()
        let userName = user.ofrShortName
        if (CommonUtil.isEmpty(userName)) {
            userName = user.ofrName
        }

        const data = {
            ifvId: appId,
            ofrCode: user.ofrCode,
            ofrName: userName,
            checkerId: parseInt(appChecker),
            ifvBackground: forwardComment
        }

        IfvAppraisalService.lockDocument(data).then((response) => {
            setLoading(false)
            getTblFwdDetail()
            showMessage('Application has been sent!', 'success')
            setTimeout(() => {
                navigate('/ifv/dashboard');
            }, 2000);
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'sending the application');
            }
        )
    }

    const unlockDocument = () => {
        if (CommonUtil.isEmpty(appChecker)) {
            showMessage('Please select checker to proceed further', 'warning')
            return
        }

        setLoading(true)
        const user = IfvAppraisalService.getCurrentUser()
        let userName = user.ofrShortName
        if (CommonUtil.isEmpty(userName)) {
            userName = user.ofrName
        }
        const data = {
            ifvId: appId,
            ofrCode: user.ofrCode,
            ofrName: userName,
            checkerId: parseInt(appChecker),
            ifvBackground: forwardComment
        }

        IfvAppraisalService.unlockDocument(data)
            .then((response) => {
                setLoading(false);
                getTblFwdDetail();
                showMessage('Application has been sent back!', 'success');
                setTimeout(() => {
                    navigate('/ifv/dashboard');
                }, 2000);
            })
            .catch((error) => {
                setLoading(false);
                handleApiError(error, 'sending back the application');
            });
    }

    const revertBackDocument = () => {
        if (window.confirm('Are you sure you want to unlock the document?')) {
            setLoading(true)
            const user = IfvAppraisalService.getCurrentUser()
            let userName = user.ofrShortName
            if (CommonUtil.isEmpty(userName)) {
                userName = user.ofrName
            }
            const data = {
                ifvId: appId,
                ofrCode: user.ofrCode,
                ofrName: userName,
            }

            IfvAppraisalService.revertApprovedDocument(data).then((response) => {
                setLoading(false)
                getTblFwdDetail()
                showMessage('Application has been unlocked!', 'success')
                setTimeout(() => {
                    navigate('/ifv/dashboard');
                }, 2000);
            },
                (error) => {
                    setLoading(false)
                    handleApiError(error, 'unlocking the application');
                }
            )
        }
    }

    const approveDocument = () => {
        setLoading(true)
        const user = IfvAppraisalService.getCurrentUser()
        let userName = user.ofrShortName
        if (CommonUtil.isEmpty(userName)) {
            userName = user.ofrName
        }
        const data = {
            ifvId: appId,
            ofrCode: user.ofrCode,
            ofrName: userName,
            ifvBackground: forwardComment
        }

        IfvAppraisalService.approveDocument(data).then((response) => {
            setLoading(false)
            getTblFwdDetail()
            showMessage('Application has been approved!', 'success')
            setTimeout(() => {
                navigate('/ifv/dashboard');
            }, 2000);
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'approving the application');
            }
        )
    }

    const calculateGeoTotal = (field, value) => {
        setValue17(field, value, { shouldValidate: true })
        let sum = 0;
        fields17.map((item, index) => {
            let val = getValues17(`institution[${index}].inAmount`)
            if (CommonUtil.isValidNumber(val)) {
                sum = sum + parseFloat(val)
            }

        })
        setTotRep(CommonUtil.roundToTwoDecimals(sum))
    }

    const calculateDiscTotal = (field, value) => {
        setValueOfDisc(field, value, { shouldValidate: true })
        let sum = 0;
        discFields.map((item, index) => {
            let val = getValuesOfDisc(`disclosure[${index}].amount`)
            if (CommonUtil.isValidNumber(val)) {
                sum = sum + parseFloat(val)
            }

        })
        setTotDisc(CommonUtil.roundToTwoDecimals(sum))
    }

    const [numberToWords, setNumberToWords] = useState('')

    const convertNumberToWords = (value) => {
        setNumberToWords(CommonUtil.numberToWords(parseFloat(value)))
    }

    const deleteRatingDetails = (index) => {
        setLoading(true)
        const id = getValues18(`ratingRepo[${index}].rtCode`)
        if (CommonUtil.isValidNumber(id)) {
            IfvAppraisalService.deleteRatingDetails(id).then((response) => {
                setLoading(false)
                setValue18(`ratingRepo[${index}]`, undefined)
                remove18(index)
                showMessage('Rating detail deleted successfully!', 'success')

            },
                (error) => {
                    setLoading(false)
                    handleApiError(error, 'deleting the Rating');
                }
            )
        } else {
            setLoading(false)
            setValue18(`ratingRepo[${index}]`, undefined)
            remove18(index)
        }
    }

    const deleteProfileBOD = (index) => {
        setLoading(true)
        const id = getValues19(`boardOfDirectors[${index}].prCode`)
        if (CommonUtil.isValidNumber(id)) {
            IfvAppraisalService.deleteProfileBOD(id).then((response) => {
                setLoading(false)
                setValue19(`boardOfDirectors[${index}]`, undefined)
                remove19(index)
                showMessage('Profile detail deleted successfully!', 'success')

            },
                (error) => {
                    setLoading(false)
                    handleApiError(error, 'deleting the Profile');
                }
            )
        } else {
            setLoading(false)
            setValue19(`boardOfDirectors[${index}]`, undefined)
            remove19(index)
        }
    }

    const deleteInstitutional = (index) => {
        setLoading(true)
        const id = getValues17(`institution[${index}].inId`)
        const cost = getValues17(`institution[${index}].inAmount`)
        if (CommonUtil.isValidNumber(id)) {
            IfvAppraisalService.deleteInstitutional(id).then((response) => {
                setLoading(false)
                setValue17(`institution[${index}].inId`, undefined)
                setValue17(`institution[${index}]`, undefined)
                setTotRep(CommonUtil.roundToTwoDecimals(totRep - cost))
                remove17(index)
                getinstitutional()
                showMessage('Institutional detail deleted successfully!', 'success')

            },
                (error) => {
                    setLoading(false)
                    handleApiError(error, 'deleting the Institutional');
                }
            )
        } else {
            setLoading(false)
            setTotRep(CommonUtil.roundToTwoDecimals(totRep - cost))
            setValue17(`institution[${index}]`, undefined)
            remove17(index)
        }
    }

    const deleteDisc = (index) => {
        setLoading(true)
        const id = getValuesOfDisc(`disclosure[${index}].id`)
        const cost = getValuesOfDisc(`disclosure[${index}].amount`)
        if (CommonUtil.isValidNumber(id)) {
            IfvAppraisalService.deleteDisc(id).then((response) => {
                setLoading(false)
                setValueOfDisc(`disclosure[${index}].id`, undefined)
                setValueOfDisc(`disclosure[${index}]`, undefined)
                setTotDisc(CommonUtil.roundToTwoDecimals(totDisc - cost))
                discRemove(index)
                getDisclosure()
                showMessage('Disclosure detail deleted successfully!', 'success')

            },
                (error) => {
                    setLoading(false)
                    handleApiError(error, 'deleting the disclosure');
                }
            )
        } else {
            setLoading(false)
            setTotDisc(CommonUtil.roundToTwoDecimals(totDisc - cost))
            setValueOfDisc(`disclosure[${index}]`, undefined)
            discRemove(index)
        }
    }


    const loadTermsAndConditionsOfSanction = (item, i) => {
        setSelectedButton([])
        setSelectedButton(prev => ({ ...prev, [i]: 'true' }))
        getSanctionTermsOnPrIdAndIfvId(options, item)
    }

    const [selectedButton, setSelectedButton] = useState([])
    const [saveOrUpdate, setSaveOrUpdate] = useState(false)
    const [ThreeMTBillBenchmark, setThreeMTBillBenchmark] = useState(false)
    const [benchMarkSpread, setBenchMarkSpread] = useState('')

    const [repoRate, setRepoRate] = useState(false)
    const [enableInterestReset, setEnableInterestReset] = useState(false)

    const getSanctionTermsOnPrIdAndIfvId = (formattedOptions, obj) => {

        setLoading(true)
        IfvAppraisalService.getSanctionTermsOnPrIdAndIfvId(appId, obj.prId).then(response => {
            const appData = response.data

            if (CommonUtil.isEmpty(appData.id)) {
                setSaveOrUpdate(false)
                setValue16('id', appData.id)
                setValue16('ifvId', appId)
                setValue16('prId', obj.prId)
                setValue16('schemeName', obj.prSchemeName)

                let sch = obj.prSchemeName
                if (obj.prFundname.toLowerCase().includes('rmse')) {
                    sch = 'RMSE'
                }
                setValue16('schemeNameAdv', sch)
                setValue16('fundName', obj.prFundname)

                setValue16('amount', CommonUtil.formatAmount(obj.prAmount))
                setValue16('amountInWords', '')
                let objPrRoI = '';

                if (!CommonUtil.isEmpty(obj.prRoi)) {
                    objPrRoI = parseFloat(obj.prRoi).toFixed(2)
                }
                setValue16('tsRAteInterest', objPrRoI)
                setNumberToWords(capitalizeFirstLetter(CommonUtil.numberToWords(objPrRoI)))
                setValue16('tsTenurePeriod', obj.prTenure)
                let words = CommonUtil.numberToWordsInCrores(obj.prAmount)
                // let capitalizedSentence = capitalizeFirstLetter(words);
                setValue16('amountInWords', words)
                setValue16('tsRoiRepayment', 'The unpaid interest shall also bear interest on monthly rest at the agreed rate till its repayments.\nPenal charges @ 2% per annum along with applicable taxes, over and above the applicable lending rate will be levied for defaults in payment of installments of principal, interest and other monies as per General Agreement for Refinance. The same shall be computed on the basis of 365 days a year and the actual number of days elapsed.')

                let principalRepaymentdata = PrincipalRepaymentData[obj.prPrincipalRepayment];

                if (obj.prPrincipalRepayment == 'Bullet') {

                    const originalDate = new Date(obj.prMaturityDate)
                    // const formattedDate = moment(originalDate, 'DD/MM/YYYY').format('MMMM D, YYYY');
                    const formattedDate = format(originalDate, 'MMMM d, yyyy');

                    principalRepaymentdata = 'The principal would be repayable in single bullet installment at the end of ' + formattedDate + ' months starting from the date of first disbursement.';
                }

                setValue16('tsPrincipalRepayment', principalRepaymentdata)

                setValue16('tsIntrestPayment', 'Interest shall be paid on monthly basis on the 10th day of each month starting from 10th day of the subsequent month from the date of first disbursement.')
                setValue16('tsTenureWd', 'However, if the due date of repayment falls on Saturday/Sunday/ Holidays under N.I. Act, the due date of payment would be the preceding working day.')
                setValue16('tsExtent', 'Amount equivalent to the outstanding portfolio of loans and advances (i.e., term loans and working capital advances) for eligible activities, against which no financial assistance / refinance has been sought/ availed from any other Banks/ Financial Institutions.')
                setValue16('tsEligibleMse', 'Refinance shall be provided for the following eligible loans extended by the bank:\n a)	Loans relating to micro finance activities and or financing micro enterprises under non-farm income generating activities eligible for coverage under SIDBI’s extant guidelines.\n b)	Loans to units in the Micro & Small Enterprises Sector as defined under MSMED Act 2006 for productive purposes.')
                setValue16('tsEligibleActivities', appData.tsEligibleActivities)
                setValue16('tsEventDflt', '(i)	The bank shall submit list of end borrowers in the prescribed format at the time of disbursement or within extended period as may be allowed by SIDBI. In case, the bank fails to furnish the list of end-borrowers as per sanction terms, penal charges @0.5% p.a., along with applicable taxes, on the disbursed amount will be charged with prospective effect till date of receipt of data. \n(ii)	Further, if the data is not furnished within 3 months from the date of disbursement, SIDBI shall have the right to recall the loan and the bank would be required to prepay the entire loan outstanding.')
                setValue16('tsSecurity', 'The bank shall hold in trust for SIDBI, all the securities including movable and immovable assets, book debts, receivables, actionable claims, guarantees, assignments, bills of exchange and proceeds thereof as also other securities as may be directly or indirectly obtained or to be obtained by the bank from its borrowers to secure the financial assistance made available to the borrowers for which the loan has been sanctioned by SIDBI to the bank\nThe bank, whenever called upon, shall also furnish to SIDBI all such information and copies of all security documents obtained by it as security for the loan sanctioned to its borrowers covered under the said scheme subject to all applicable laws.')
                setValue16('tsDocumentstion', 'I.	Acceptance of LoI by authorized official of the Bank on a non-judicial stamp paper of requisite value with certified copy of Power of Attorney / applicable Board Resolution/Authorization letter.\nII.	KYC documents of the authorized officials executing the requisite documents on behalf of the Bank shall be submitted, along with the Board Resolution/DOP/Authorization letter.')

                if (sch == 'RMSE') {
                    setValue16('tsTimeFrame', 'LoI to be accepted within 7 working days from the date of issue of LoI.  Disbursement to be availed within 10 working days from the date of issue of LoI.')
                } else {
                    setValue16('tsTimeFrame', 'LoI to be accepted within 3 working days from the date of issue of LoI.  Disbursement to be availed within 5 working days from the date of issue of LoI.')
                }

                setValue16('tsDrawaloan', 'SIDBI reserves the right to disburse the amount in lump sum or in one or more tranches, at mutually agreed rates of interest depending upon the market conditions.')
                setValue16('tsOtherCond', appData.tsOtherCond)
                setValue16('tsOutstandingAmount', appData.tsOutstandingAmount)
                setValue16('tsTermsection', appData.tsTermsection)
                setValue16('tsExtraConditions', appData.tsExtraConditions)
                setValue16('tsTenureApprox', '')

                setValue16('interestType', obj.interestType)
                setValue16('benchMark', obj.benchMark)
                setValue16('spread', obj.spread)
                setValue16('interestReset', obj.interestReset)

                setRepoRate(false)


                if (!CommonUtil.isEmpty(obj.benchMark) && obj.benchMark.toLowerCase().includes('bill')) {
                    setThreeMTBillBenchmark(true)
                    setRepoRate(false)
                    setBenchMarkSpread(obj.benchMark + ' + ' + obj.spread + ' bps.')
                    setValue16('benchMarkNote', 'The benchmark i.e., 3M T-Bill rate as per the T-Bill curve published by FBIL website for the working day immediately preceding the date of disbursement / reset date.')
                    setValue16('interestResetNote', 'The interest rate (only benchmark) is subject to reset every 3 months from the date of disbursement, while spread will remain unchanged.')
                } else if (!CommonUtil.isEmpty(obj.benchMark) && obj.benchMark.toLowerCase().includes('repo')) {
                    setThreeMTBillBenchmark(false)
                    setRepoRate(true)
                    setBenchMarkSpread('RBI Repo rate' + ' + ' + obj.spread + ' bps.')
                    setValue16('tsRoiRepayment', 'The unpaid interest shall also bear interest on monthly rest at the agreed rate till its repayments. Penal Interest @ 2% per annum, over and above the applicable lending rate will be levied for defaults in payment of installments of principal, interest and other monies as per the General Agreement for Refinance. The same shall be computed on the basis of 365 days a year and the actual number of days elapsed.');
                    setValue16('benchMarkNote', '');
                    setValue16('interestResetNote', ' Interest will be payable at the rate of ' + obj.prRoi + '% p.a. fixed for the first year with interest rate reset applicable after 1 year from the date of first disbursement when SIDBI would have the option to revise the rate of interest.\nIn case, the revised rate of interest is not acceptable to the Borrower, it shall have the option to prepay outstanding loan without any prepayment premium within 5 days from the date of notice by SIDBI for revision in the applicable interest rate. The reset rate would be applicable from the reset date till the date of prepayment by the Borrower.')
                } else {
                    setThreeMTBillBenchmark(false)
                    setRepoRate(false)
                    setBenchMarkSpread('')
                    setValue16('benchMarkNote', '')
                    setValue16('interestResetNote', '')
                }

                if (!CommonUtil.isEmpty(obj.interestReset)) {
                    setEnableInterestReset(true)
                } else {
                    setEnableInterestReset(false)
                }

            } else {
                setSaveOrUpdate(true)
                setValue16('id', appData.id)
                setValue16('ifvId', appData.ifvId)
                setValue16('prId', appData.prId)
                setValue16('schemeName', appData.schemeName)
                let sch = appData.schemeName

                if (appData.fundName.toLowerCase().includes('rmse')) {
                    sch = 'RMSE'
                }
                setValue16('schemeNameAdv', sch)
                setValue16('fundName', appData.fundName)

                setValue16('amount', CommonUtil.formatAmount(appData.amount))

                let words = CommonUtil.numberToWordsInCrores(appData.amount)
                // let capitalizedSentence = capitalizeFirstLetter(words);

                setValue16('amountInWords', words)

                let objPrRoI = '';

                if (!CommonUtil.isEmpty(appData.tsRAteInterest)) {
                    objPrRoI = parseFloat(appData.tsRAteInterest).toFixed(2)
                }

                setValue16('tsRAteInterest', objPrRoI)
                setNumberToWords(capitalizeFirstLetter(CommonUtil.numberToWords(objPrRoI)))
                setValue16('tsRoiRepayment', appData.tsRoiRepayment)
                setValue16('tsTenurePeriod', appData.tsTenurePeriod)

                setValue16('tsPrincipalRepayment', appData.tsPrincipalRepayment)

                setValue16('tsIntrestPayment', appData.tsIntrestPayment)
                setValue16('tsTenureWd', appData.tsTenureWd)
                setValue16('tsExtent', appData.tsExtent)
                setValue16('tsEligibleMse', appData.tsEligibleMse)
                setValue16('tsEligibleActivities', appData.tsEligibleActivities)
                setValue16('tsEventDflt', appData.tsEventDflt)
                setValue16('tsSecurity', appData.tsSecurity)
                setValue16('tsDocumentstion', appData.tsDocumentstion)
                setValue16('tsTimeFrame', appData.tsTimeFrame)
                setValue16('tsDrawaloan', appData.tsDrawaloan)
                setValue16('tsOtherCond', appData.tsOtherCond)

                if (appData.tsOtherCond != null) {
                    const arrayOne = appData.tsOtherCond.split(',')
                    let otherConditions = []

                    arrayOne.map((item, index) => {
                        const it = formattedOptions.find(obj => obj['value'] === parseInt(item));
                        if (it !== undefined) {
                            otherConditions.push(it)
                        }
                    })
                    setSelectedOption(otherConditions)
                }

                setValue16('tsOutstandingAmount', appData.tsOutstandingAmount)
                setValue16('tsTermsection', appData.tsTermsection)
                setValue16('tsExtraConditions', appData.tsExtraConditions)
                setValue16('tsTenureApprox', appData.tsTenureApprox)

                setValue16('interestType', appData.interestType)
                setValue16('benchMark', appData.benchMark)
                setValue16('spread', appData.spread)
                setValue16('interestReset', appData.interestReset)

                setRepoRate(false)
                setThreeMTBillBenchmark(false)

                if (!CommonUtil.isEmpty(appData.benchMark) && appData.benchMark.toLowerCase().includes('bill')) {
                    setThreeMTBillBenchmark(true)
                    setBenchMarkSpread(appData.benchMark + ' + ' + appData.spread + ' bps.')
                } else if (!CommonUtil.isEmpty(appData.benchMark) && appData.benchMark.toLowerCase().includes('repo')) {
                    setRepoRate(true)
                    setBenchMarkSpread('RBI Repo rate' + ' + ' + appData.spread + ' bps.')
                } else {
                    setBenchMarkSpread('')
                }

                setValue16('benchMarkNote', appData.benchMarkNote)
                setValue16('interestResetNote', appData.interestResetNote)

                if (!CommonUtil.isEmpty(appData.interestReset)) {
                    setEnableInterestReset(true)
                } else {
                    setEnableInterestReset(false)
                }
            }
            inputHandler(getValues16('tsRoiRepayment'), 'roiPayment')
            inputHandler(CommonUtil.isEmpty(getValues16('tsPrincipalRepayment')) ? '' : getValues16('tsPrincipalRepayment'), 'princRep')
            inputHandler(getValues16('tsIntrestPayment'), 'intPay')
            inputHandler(getValues16('tsTenureWd'), 'note')
            inputHandler(getValues16('tsExtent'), 'extOfRefinance')
            inputHandler(getValues16('tsEligibleMse'), 'eligEndBorrow')
            inputHandler(getValues16('tsEventDflt'), 'eventOfDefault')
            inputHandler(getValues16('tsSecurity'), 'security')
            inputHandler(getValues16('tsDocumentstion'), 'docs')
            inputHandler(getValues16('tsTimeFrame'), 'timeFrame')
            inputHandler(getValues16('tsDrawaloan'), 'drawalOfLoan')
            setLoading(false)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading Details of Appendix');
            }
        )
    }

    function capitalizeFirstLetter(sentence) {
        return sentence.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    }

    const onSubmitOfSanctionTermsAndConditions = (data, e) => {
        setLoading(true)
        let mstCodes = ""
        if (selectedOption.length > 0) {
            selectedOption.map((item, index) => {
                mstCodes = mstCodes.concat(item['value'] + ',')
            })
        }

        data.ifvId = appId
        data.tsOtherCond = mstCodes
        delete data.schemeNameAdv

        IfvAppraisalService.saveSanctionTerms(data).then((response) => {
            setLoading(false)
            showMessage('Appendix details have been successfully saved!', 'success')
            const obj = {
                prId: response.data.prId,
                prFundname: response.data.fundName,
                prSchemeName: response.data.schemeName,
                prAmount: response.data.amount,
                prRoi: response.data.tsRAteInterest,
                prTenure: response.data.tsTenurePeriod,
                prPrincipalRepayment: '',
                prMaturityDate: '',
            }
            getSanctionTermsOnPrIdAndIfvId(options, obj)

        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving Appendix');
            })
    }

    const initialState = {
        roiPayment: '',
        princRep: '',
        intPay: '',
        note: '',
        extOfRefinance: '',
        eligEndBorrow: '',
        eventOfDefault: '',
        security: '',
        docs: '',
        timeFrame: '',
        drawalOfLoan: '',
    }
    const [input, setInput] = useState(initialState);
    const inputHandler = (value, input) => {
        setInput(prevState => ({ ...prevState, [input]: value }));
    };

    const [auditComment, setAuditComment] = useState('')
    const [forwardComment, setForwardComment] = useState('')
    const [openAuditComment, setOpenAuditComment] = useState(false)
    const handleAuditCommentClose = () => {
        setOpenAuditComment(false)
    }

    const openCommentModel = () => {
        getCommonData()
    }

    const saveOrUpdateAuditComment = () => {
        if (CommonUtil.isEmpty(auditComment)) {
            showMessage('Please add comment', 'warning');
            return;
        }
        IfvAppraisalService.saveOrUpdateAuditComment(appId, auditComment).then(response => {
            setAuditComment(response.data.auditComments)
            showMessage('Audit Comment added successfully!', 'success')
        },
            (error) => {
                handleApiError(error, 'saving audit comments');
            }
        )
    }

    const getCommonData = () => {
        IfvAppraisalService.getCommonData(appId).then(response => {
            setAuditComment(response.data.auditComments)
            setOpenAuditComment(true)
        },
            (error) => {
                handleApiError(error, 'oading audit comments');
            }
        )
    }

    const [fileName, setFileName] = useState('')

    const handleFileUpload = (e) => {
        setLoading(true);
        if (!e.target.files || !e.target.files[0]) {
            setLoading(false);
            showMessage("No file selected", 'warning');
            return;
        }
        let file = e.target.files[0];
        let file_name = file.name;
        let fileExtension = file_name.substring(file_name.lastIndexOf(".") + 1).toLowerCase();
        let errorMsg = "";

        if (file.size === 0) {
            errorMsg = "Cannot upload empty file (0MB)";
        }
        else if (fileExtension !== 'pdf') {
            errorMsg = "File should be of PDF format";
        }
        else if (file.size / 1024 / 1024 > 12) {
            errorMsg = "File size should be less than 12MB";
        }

        if (errorMsg !== "") {
            setLoading(false);
            showMessage(errorMsg, 'warning');
            e.target.value = null;
            return;
        }

        let annexureType = 'Annexure-II';
        if (ucb) {
            annexureType = 'UCB-Annexure-VIII';
        }

        file_name = file_name.split('.').slice(0, -1).join('.');
        const formData = new FormData()
        formData.append('fileData', file)
        formData.append('fileIfvId', ifvApp.ifvId)
        formData.append('fileModule', annexureType)

        MinutesService.uploadAgendaFile(formData).then((response) => {
            setFileName(response.data.fileName)
            setReUpload(false)
            setFileId(response.data.fileCode)
            setLoading(false)
            showMessage('File uploaded successfully!', 'success')

        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'uploading file');
            }
        )

    }

    const [reUpload, setReUpload] = useState(false)
    const setReUploadFlag = () => {
        setReUpload(true)
    }

    const deleteAnnexureIIFile = () => {
        setLoading(true)
        IfvAppraisalService.deleteAnnexureIIFile(fileId).then((response) => {

            setFileName('')
            setReUpload(false)
            setFileId(0)

            setLoading(false)
            showMessage('File deleted successfully!', 'success')

        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'deleting file');
            }
        )
    }

    const displayFileDetail = (module) => {
        setLoading(true)
        IfvAppraisalService.findByFileIfvIdAndFileModule(appId, module).then(response => {
            setLoading(false)
            if (response.data && response.data.fileDataBytea != null) {
                FileUtil.viewFile(response.data.fileDataBytea, response.data.fileName, response.data.fileContentType)
            } else {
                showMessage('Invalid file', 'error')
            }

        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading file');
            }
        )
    }

    const [fileId, setFileId] = useState(0)

    const findByFileIfvIdAndFileModule = (isUcb) => {
        let module = 'Annexure-II'
        if (isUcb) {
            module = 'UCB-Annexure-VIII'
        }

        IfvAppraisalService.findByFileIfvIdAndFileModule(appId, module).then(response => {
            const appData = response.data
            if (appData != null && appData.fileName != null) {
                setFileName(appData.fileName)
                setFileId(appData.fileCode)
            }
        },
            (error) => {
                handleApiError(error, 'loading file data');
            }
        )
    }

    const [showHideProceed, setShowHideProceed] = useState(false)
    const hideProceed = () => setShowHideProceed(false)
    const [showHideApprove, setShowHideApprove] = useState(false)
    const hideApprove = () => setShowHideApprove(false)
    const [checkerList, setCheckerList] = useState([])
    const [appChecker, setAppChecker] = useState('')
    const [filteredStatesOptions, setFilteredStatesOptions] = useState([])
    const [statesOptions, setStatesOptions] = useState([])
    const [selectedStateOption, setSelectedStateOption] = useState([]);
    const [filteredStatesOptionsForRRB, setFilteredStatesOptionsForRRB] = useState([])
    const [statesOptionsForRRB, setStatesOptionsForRRB] = useState([])
    const [sendBack, setSendBack] = useState(false)
    const getCheckerListForSendBack = () => {
        const user = IfvAppraisalService.getCurrentUser();
        setSendBack(true)
        setLoading(true)
        IfvAppraisalService.getCheckerListForSendBack(appId, user.ofrCode).then(response => {
            setLoading(false)
            setCheckerList(response.data)
            setShowHideProceed(true)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading checker list');
            }
        )
    }

    const checkSendToRimv = () => {
        if (isMaker && !locked && !isForwarded) {
            setOpenRimvDialog(true);
        } else {
            validateDataForForwarding();
        }
    }

    const validateDataForForwarding = () => {
        IfvAppraisalService.getDetailsOfEmptyData(appId).then(response => {

            let msg = '';
            if (!CommonUtil.isEmpty(response.data)) {
                msg = 'The fields mentioned below are not filled out with data. Are you sure you want to forward?'
            } else {
                msg = 'Are you sure you want to forward?'
            }

            confirmAlert({
                title: 'Confirm to Forward',
                message: <div>
                    <p> <img src={cnfrm} alt="My Image" /></p>
                    <span>{msg}</span>
                    {response.data}
                </div>,

                buttons: [
                    {
                        label: 'Yes',
                        onClick: () => {
                            lockDocument()
                        }
                    },
                    {
                        label: 'No',
                        onClick: () => {
                            console.log('Canceled forward');
                        }
                    }
                ]
            });

        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading cvalidating data');
            }
        )
    }

    const lockDocument = () => {
        const user = IfvAppraisalService.getCurrentUser();
        setSendBack(false)
        setLoading(true)
        IfvAppraisalService.getCheckerListForForwarding(appId, user.ofrCode).then(response => {
            setLoading(false)
            setCheckerList(response.data)
            setShowHideProceed(true)
        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'loading checker list');
            }
        )
    }

    const initialStateGeo = {
        ifvId: appId,
        sfbAoNetwork: '',
        sfbAoBranches: '',
        sfbAoDate: '',
        sfbAoMajorityBranches: ''
    }

    const [common, setCommon] = useState(initialStateGeo)
    const [geoTotal, setGeoTotal] = useState(0)

    const [preparationFunction, setPreparationFunction] = useState(null);
    const handleDataPrepare = (prepareFunction) => {
        console.log('Preparation Function Received:', prepareFunction);
        setPreparationFunction(() => prepareFunction);
    };

    const [fetchTrigger, setFetchTrigger] = useState(0);

    const onSubmitOfGeographicalArea = (data, e) => {
        e.preventDefault();

        common.ifvId = appId

        const res = CommonUtil.validateDate(common.sfbAoDate)
        if (res === true) {
        } else {
            setLoading(false)
            showMessage('Please enter valid AO Branches On date', 'warning')
            return
        }

        let geoData;

        if (rrb) {
            if (!preparationFunction) {
                showMessage('Data preparation function is not initialized', 'error');
                return;
            }

            const preparedData = preparationFunction();
            if (preparedData) {
                geoData = preparedData.filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.agBranch))
            }
        } else {
            geoData = data['geographicalArea'].filter((item) => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.agBranch))

            geoData.map((item, index) => {
                item['agState'] = selectedStateOption[index]
            })

            const isFieldEmpty = geoData.some(obj => {
                return CommonUtil.isEmpty(obj['agState']);
            });

            if (isFieldEmpty) {
                setLoading(false)
                showMessage('Please select State/UT', 'warning')

                return
            }
        }

        const finalData = {
            listAreasGeographicalDTO: geoData,
            sfbCommondtDTO: common
        }

        setLoading(true)
        IfvAppraisalService.saveAreaOfOperationGeographical(finalData).then((response) => {
            getAllOnIfvIdOnST(rrb)
            if (rrb) {
                setFetchTrigger(prev => prev + 1);
            }
            setLoading(false)
            showMessage('Area of Operation-Geographical details have been successfully saved!', 'success')

        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving Area of Operation-Geographical');
            })
    }

    const getAllOnIfvIdOnST = (isRRB) => {
        IfvAppraisalService.getAllOnIfvIdOnST(appId).then(response => {
            const appData = response.data.listAreasGeographicalDTO

            const commonDTO = response.data.sfbCommondtDTO
            if (commonDTO != null) {
                setCommon({
                    ifvId: commonDTO.ifvId,
                    sfbAoNetwork: commonDTO.sfbAoNetwork,
                    sfbAoBranches: commonDTO.sfbAoBranches,
                    sfbAoDate: commonDTO.sfbAoDate != null ? new Date(commonDTO.sfbAoDate) : '',
                    sfbAoMajorityBranches: commonDTO.sfbAoMajorityBranches != null ? commonDTO.sfbAoMajorityBranches : ''
                })

                const selected = {
                    label: commonDTO.sfbAoMajorityBranches,
                    value: commonDTO.sfbAoMajorityBranches
                }

                setSelectedMajBankOption(selected)
            }

            if (!CommonUtil.isEmpty(appData) && appData.length > 0) {
                for (let i = 0; i < appData.length; i++) {
                    remove3(i)
                    append3({})
                }

                if (rrb) {

                } else {
                    let sum = 0

                    appData.forEach((item, index) => {
                        setValue4(`geographicalArea[${index}].agId`, item.agId)
                        setValue4(`geographicalArea[${index}].ifvId`, item.ifvId)
                        setValue4(`geographicalArea[${index}].agState`, item.agState)
                        setValue4(`geographicalArea[${index}].agBranch`, item.agBranch)
                        setValue4(`geographicalArea[${index}].agType`, item.agType)
                        setSelectedStateOption(prevState => ({ ...prevState, [index]: item.agState }))
                        sum = sum + item.agBranch
                    });
                    setGeoTotal(sum);
                }
            }
            else {
                for (let i = 0; i < 2; i++) {
                    append3({})
                }
            }

            MasterService.getStatesOrUT().then(
                (res) => {
                    const formattedOptions = res.data.map((item) => ({
                        value: item.locaDistCd,
                        label: item.locaDistName,
                    }));

                    if (isRRB) {

                        if (!CommonUtil.isEmpty(commonDTO) && !CommonUtil.isEmpty(commonDTO.sfbAoMajorityBranches) && appData.length > 0) {
                            res.data.map((item) => {
                                if (commonDTO.sfbAoMajorityBranches === item.locaDistName) {
                                    getAllDistByStateCd(item.locaDistCd);
                                }
                            });
                        }

                        setStatesOptionsForRRB(formattedOptions)
                        setFilteredStatesOptionsForRRB(formattedOptions)
                    } else {
                        setStatesOptions(formattedOptions)
                        setFilteredStatesOptions(formattedOptions)
                    }

                },
                (err) => {
                    handleApiError(err, 'loading States');
                }
            )

        }, (error) => {
            handleApiError(error, 'loading Area of Operation-Geographical');
        })
    }

    const handleStateSearch = (inputValue) => {
        if (inputValue === "") { setFilteredStatesOptions(statesOptions); return; }
        const filteredOptions = statesOptions.filter((option) =>
            option.label.toLowerCase().includes(inputValue.toLowerCase())
        );
        setFilteredStatesOptions(filteredOptions);
    }

    const handleStateSearchForRRB = (inputValue) => {
        if (inputValue === "") { setFilteredStatesOptionsForRRB(statesOptionsForRRB); return; }
        const filteredOptions = statesOptionsForRRB.filter((option) =>
            option.label.toLowerCase().includes(inputValue.toLowerCase())
        );
        setFilteredStatesOptionsForRRB(filteredOptions);
    }

    const deleteAeStates = (index) => {
        setLoading(true)
        const id = getValues4(`geographicalArea[${index}].agId`)
        const noOfBranches = getValues4(`geographicalArea[${index}].agBranch`)
        if (CommonUtil.isValidNumber(id)) {
            IfvAppraisalService.deleteAeStates(id).then((response) => {
                setValue4(`geographicalArea[${index}]`, undefined)
                remove3(index)
                delete selectedStateOption[index]
                setGeoTotal(geoTotal - noOfBranches)
                getAllOnIfvIdOnST(rrb)
                setLoading(false)
                showMessage('Area of Operation-Geographical detail deleted successfully!', 'success')

            },
                (error) => {
                    setLoading(false)
                    handleApiError(error, 'deleting Area of Operation-Geographical');
                }
            )
        } else {
            setValue4(`geographicalArea[${index}]`, undefined)
            remove3(index)
            delete selectedStateOption[index]
            setGeoTotal(geoTotal - noOfBranches)
            setLoading(false)
        }
    }

    const [selectedMajBankOption, setSelectedMajBankOption] = useState(null)

    const setMaxBranchState = (selected) => {
        setSelectedMajBankOption(selected)
        setCommon(prevState => ({ ...prevState, 'sfbAoMajorityBranches': selected.label }))
        if (rrb) {
            getAllDistByStateCd(selected.value);
        }
    }

    const getAllDistByStateCd = (stateCd) => {
        MasterService.getDistrictsByState(stateCd).then(
            (response) => {
                const formattedOptions = response.data.map((item) => ({
                    value: item.locaDistCd,
                    label: item.locaDistName,
                }))
                setStatesOptions(formattedOptions)
                setFilteredStatesOptions(formattedOptions)
            },
            (error) => {
                handleApiError(error, 'loading Districts');
            }
        )
    }

    const proceed = () => {
        if (sendBack) {
            unlockDocument()
        } else {
            documentLock()
        }
    }

    const [totDisc, setTotDisc] = useState(0)

    const getDisclosure = () => {
        IfvAppraisalService.getDisclosure(appId).then(response => {
            const appData = response.data
            if (appData.length > 0) {
                for (let i = 0; i < appData.length; i++) {
                    discRemove(i)
                    discAppend({})
                }
            }
            else {
                discAppend({})
            }
            let tot = 0;
            appData.forEach((item, index) => {
                setValueOfDisc(`disclosure[${index}].id`, item.id)
                setValueOfDisc(`disclosure[${index}].ifvId`, item.ifvId)
                setValueOfDisc(`disclosure[${index}].particulars`, item.particulars)
                setValueOfDisc(`disclosure[${index}].amount`, item.amount)

                tot = tot + parseFloat(item.amount)
            });
            setTotDisc(CommonUtil.roundToTwoDecimals(tot))
        },
            (error) => {
                handleApiError(error, 'loading Details of Disclosure');
            }
        )
    }

    const onSubmitOfDisclosure = (data, e) => {
        setLoading(true)

        let finalData = data['disclosure']?.filter(item => !CommonUtil.isEmpty(item) && !CommonUtil.isEmpty(item.particulars))
        IfvAppraisalService.saveDisclosure(finalData).then((response) => {
            setLoading(false)
            showMessage('Disclosure details have been successfully saved!', 'success')
            getDisclosure()

        },
            (error) => {
                setLoading(false)
                handleApiError(error, 'saving Disclosure');
            })
    }

    const [selectedTab, setSelectedTab] = useState(0);
    const handleTabChange = (event, newValue) => {
        setSelectedTab(newValue);
        loadTermsAndConditionsOfSanction(proposedSchemes[newValue], newValue);
    };

    const [isForwarded, setForwarding] = useState(false);
    const [isRimvRejected, setRimvRejected] = useState(false);
    const [isRimvApproved, setRimvApproved] = useState(false);
    const fetchDocuments = async () => {
        const token = getJwtToken();
        try {
            const response = await axios.get(`${API_BASE_URL}rimv/getAllDocsOnIfvId/${appId}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                }
            });
            if (response.data?.[0]?.fwdStatus === 'P') {
                setForwarding(true);
            }
            if (response.data?.[0]?.fwdStatus === 'R') {
                setRimvRejected(true);
            }
            if (response.data?.[0]?.fwdStatus === 'A') {
                setRimvApproved(true);
            }
        } catch (err) {
            console.error('Error fetching documents:', err);
        } finally {
            setLoading(false);
        }
    };

    const setRimvOnClose = () => {
        setOpenRimvDialog(false);
        fetchDocuments();
    }

    return (
        <Fragment>
            <div className={loading ? 'frgmnt blur-background' : 'frgmnt'}>
                <SectionNavigation activeView={'Section Five'} showSFB={showSFB} appId={appId} />
                <ProposalHeader
                    bankName={ifvApp.ifvName}
                    appNumber={ifvApp.appNumber}
                    status={appStatus}
                    appId={appId}
                />

                <Accordion flush>

                    <Accordion.Item>
                        <Accordion.Header>Appendix</Accordion.Header>
                        <Accordion.Body>
                            <h5 className='HdngTitl' style={{ marginTop: '0.8rem', marginBottom: '1.5rem' }}>Terms and Conditions of Sanction</h5>
                            <div className='pergs'>
                                <Tabs
                                    value={selectedTab}
                                    onChange={handleTabChange}
                                    variant="scrollable"
                                    scrollButtons="auto"
                                    aria-label="proposed schemes tabs"
                                    sx={{ marginBottom: '20px' }}
                                >
                                    {proposedSchemes.map((item, i) => (
                                        <Tab
                                            key={i}
                                            label={`${item.prFundname} / ${item.prFundname.toLowerCase().includes('rmse') ? 'RMSE' : item.prSchemeName}`}
                                        />
                                    ))}
                                </Tabs>

                                <form key={14} onSubmit={handleSubmitOfTermsAndConditionData(onSubmitOfSanctionTermsAndConditions)}>
                                    <input type='hidden'
                                        {...register16('id')}
                                    />
                                    <input type='hidden'
                                        {...register16('ifvId')} value={appId}
                                    />
                                    <input type='hidden'
                                        {...register16('prId')}
                                    />
                                    <input type='hidden'
                                        {...register16('interestType')}
                                    />
                                    <input type='hidden'
                                        {...register16('interestReset')}
                                    />
                                    <input type='hidden'
                                        {...register16('benchMark')}
                                    />
                                    <input type='hidden'
                                        {...register16('spread')}
                                    />
                                    <div className='container-fluid p-0'>
                                        <div className='row'>
                                            <div className='col-md-6'>
                                                <div className='form-group'>
                                                    <label><strong>Fund</strong></label>
                                                    <input type='text' className='form-control' {...register16('fundName')} readOnly />
                                                </div>
                                            </div>
                                            <div className='col-md-6'>
                                                <div className='form-group'>
                                                    <label><strong>Scheme</strong></label>
                                                    <input type='text' className='form-control' {...register16('schemeNameAdv')} readOnly />
                                                    <input type='hidden' className='form-control' {...register16('schemeName')} readOnly />
                                                </div>
                                            </div>

                                            <div className='col-md-3'>
                                                <div className='form-group'>
                                                    <label><strong>Amount (₹ in crore)</strong></label>
                                                    <div className='brn_wrp'>
                                                        <input type='number' step='any' className='form-control' {...register16('amount')} readOnly />
                                                    </div>
                                                </div>
                                            </div>

                                            <div className='col-md-9'>
                                                <div className='form-group'>
                                                    <label><strong>Amount In Words</strong></label>
                                                    <input type='text' className='form-control'  {...register16('amountInWords', {
                                                        required: 'Field is required'
                                                    })} readOnly />
                                                    <span className="vldn"> {errors16.amountInWords && errors16.amountInWords.message}</span>
                                                </div>
                                            </div>
                                            <div className='col-md-12 mt-3'>
                                                <div className='form-group'>
                                                    <label><strong>Rate of Interest</strong></label>
                                                    <div className='branch_on'>
                                                        <label>Interest will be charged @</label>
                                                        {benchMarkSpread ? <> <div className='brn_wrp'>
                                                            <label>{benchMarkSpread}</label>
                                                        </div> </> : <>    <div className='brn_wrp'>
                                                            <input className='form-control'
                                                                type='number' readOnly
                                                                step='0.01'
                                                                {...register16('tsRAteInterest',
                                                                    {
                                                                        onChange: (e) => convertNumberToWords(e.target.value)
                                                                    })
                                                                }
                                                            //onBlur={(e) => fixDecimals(e)}
                                                            />
                                                        </div>
                                                            <label> % p.a. </label>
                                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                            <label>{numberToWords} percent per annum</label>
                                                        </>}

                                                    </div>

                                                    {ThreeMTBillBenchmark && <>
                                                        <div className='col-md-12'>
                                                            <label><strong>Interest Reset:</strong></label>
                                                            <div className='form-group'>
                                                                <textarea className='form-control' {...register16('interestResetNote', {
                                                                    maxLength: {
                                                                        value: 4000,
                                                                        message: "The maximum length of the field is 4000"
                                                                    },
                                                                })} maxLength="4000"
                                                                    onChange={(e) => { Pattern.sanitizeInput(e) }} />
                                                                <span className="vldn"> {errors16.interestResetNote && errors16.interestResetNote.message}</span>
                                                            </div>
                                                        </div>


                                                        <div className='col-md-12'>
                                                            <label><strong>Benchmark:</strong></label>
                                                            <div className='form-group'>
                                                                <textarea className='form-control' {...register16('benchMarkNote', {
                                                                    maxLength: {
                                                                        value: 4000,
                                                                        message: "The maximum length of the field is 4000"
                                                                    },
                                                                })} maxLength="4000"
                                                                    onChange={(e) => { Pattern.sanitizeInput(e) }} />
                                                                <span className="vldn"> {errors16.benchMarkNote && errors16.benchMarkNote.message}</span>
                                                            </div>
                                                        </div>
                                                    </>}

                                                    <div className='col-md-12'>
                                                        <label className="prog_lbl" style={{ justifyContent: 'right', marginBottom: '6px' }}>
                                                            <div className='prgs'>
                                                                <span className='lft_crt'>{4000 - input['roiPayment'].length} Characters left</span>
                                                                <LinearProgress
                                                                    variant="determinate"
                                                                    value={input['roiPayment'].length}
                                                                />
                                                            </div>
                                                        </label>
                                                        <div className='form-group'>
                                                            {/* <label>The unpaid interest shall also bear interest on monthly rest at the agreed rate till its repayments.</label> */}
                                                            <textarea className='form-control' {...register16('tsRoiRepayment', {
                                                                maxLength: {
                                                                    value: 4000,
                                                                    message: "The maximum length of the field is 4000"
                                                                },
                                                                validate: (value) => {
                                                                    if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                    return true;
                                                                },
                                                            })} maxLength="4000"
                                                                onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "roiPayment") }} />
                                                            <span className="vldn"> {errors16.tsRoiRepayment && errors16.tsRoiRepayment.message}</span>
                                                        </div>
                                                    </div>

                                                    {repoRate && <>
                                                        <div className='col-md-12'>
                                                            <label><strong>Reset of interest rate:</strong></label>
                                                            <div className='form-group'>
                                                                <textarea className='form-control' {...register16('interestResetNote', {
                                                                    maxLength: {
                                                                        value: 4000,
                                                                        message: "The maximum length of the field is 4000"
                                                                    },
                                                                })} maxLength="4000"
                                                                    onChange={(e) => { Pattern.sanitizeInput(e) }} />
                                                                <span className="vldn"> {errors16.interestResetNote && errors16.interestResetNote.message}</span>
                                                            </div>
                                                        </div>
                                                    </>}


                                                    {/* Add Interest reset */}
                                                    {!ThreeMTBillBenchmark && !repoRate && enableInterestReset &&
                                                        <div className='col-md-12'>
                                                            <label><strong>Interest Reset:</strong></label>
                                                            <div className='form-group'>
                                                                <textarea className='form-control' {...register16('interestResetNote', {
                                                                    maxLength: {
                                                                        value: 4000,
                                                                        message: "The maximum length of the field is 4000"
                                                                    },
                                                                })} maxLength="4000"
                                                                    onChange={(e) => { Pattern.sanitizeInput(e) }} />
                                                                <span className="vldn"> {errors16.interestResetNote && errors16.interestResetNote.message}</span>
                                                            </div>
                                                        </div>
                                                    }


                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div className='form-group msersWrap'>
                                        <div className='row'>
                                            <div className='branch_on'>
                                                <label>Tenure: </label>
                                                <div className='brn_wrp'>
                                                    <input className='form-control'
                                                        type='number' step='0.01' readOnly
                                                        {...register16('tsTenurePeriod',
                                                            {
                                                                required: "Field is required",
                                                                pattern: {
                                                                    value: /^(?!0(?:\.0*|)$)\d*(?:\.\d+)?$/,
                                                                    message: "Invalid value"
                                                                },
                                                            })}
                                                    />
                                                    <span className="vldn"> {errors16.tsTenurePeriod && errors16.tsTenurePeriod.message}</span>
                                                </div>
                                                <label> months </label>
                                                <input className='form-control'
                                                    type='text' defaultValue='(Approx.)' {...register16('tsTenureApprox')}
                                                    autoComplete="off"
                                                    onChange={(e) => Pattern.sanitizeInput(e)}
                                                />
                                                <span className="vldn"> {errors16.tsTenureApprox && errors16.tsTenureApprox.message}</span>
                                            </div>
                                        </div>
                                        <div className='container-fluid pt-0'>
                                            <div className='row'>
                                                <div className='col-md-6 ps-0'>
                                                    <label className='prog_lbl'>
                                                        <strong>Principal Repayment</strong>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['princRep'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['princRep'].length}
                                                            />
                                                        </div>
                                                    </label>
                                                    <div className='form-group'>
                                                        {/* The principal would be repayable in quarterly instaliments starting from the date of first disbursement commencing from 10th of the month concerned. The repayment schedule shall be drawn accordingly based on the date on which first disbursement is affected */}
                                                        <textarea className='form-control mt-2'  {...register16('tsPrincipalRepayment', {
                                                            maxLength: {
                                                                value: 4000,
                                                                message: "The maximum length of the field is 4000"
                                                            },
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                return true;
                                                            },
                                                        })} maxLength="4000"
                                                            onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "princRep") }} />
                                                        <span className="vldn"> {errors16.tsPrincipalRepayment && errors16.tsPrincipalRepayment.message}</span>
                                                    </div>
                                                </div>

                                                <div className='col-md-6 pe-0'>
                                                    <label className='prog_lbl'>
                                                        <strong>Interest Payment</strong>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['intPay'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['intPay'].length}
                                                            />
                                                        </div>
                                                    </label>
                                                    <div className='form-group'>
                                                        {/* Interest shall be paid on monthly basis on the 10th day of each month starting from 10th day of the subsequent month from the date of first disbursement. */}
                                                        <textarea className='form-control mt-2'  {...register16('tsIntrestPayment', {
                                                            maxLength: {
                                                                value: 4000,
                                                                message: "The maximum length of the field is 4000"
                                                            },
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                return true;
                                                            },
                                                        })} maxLength="4000"
                                                            onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "intPay") }} />
                                                        <span className="vldn"> {errors16.tsIntrestPayment && errors16.tsIntrestPayment.message}</span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className='row mt-2'>
                                                <div className='col-md-12 p-0'>
                                                    <label className="prog_lbl" style={{ justifyContent: 'right', marginBottom: '6px' }}>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['note'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['note'].length}
                                                            />
                                                        </div>
                                                    </label>
                                                    <div className='form-group'>
                                                        {/* However, if the due date of repayment falls on Saturday/Sunday/ Holidays under N.1. Act, the due date of payment would be the preceding working day. */}
                                                        <textarea className='form-control mt-2'  {...register16('tsTenureWd', {
                                                            maxLength: {
                                                                value: 4000,
                                                                message: "The maximum length of the field is 4000"
                                                            },
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                return true;
                                                            },
                                                        })} maxLength="4000"
                                                            onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "note") }} />
                                                        <span className="vldn"> {errors16.tsTenureWd && errors16.tsTenureWd.message}</span>
                                                    </div>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                    <div className='container-fluid mt-4 p-0'>
                                        <div className='row'>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label className='prog_lbl'><strong>Extent of Refinance</strong>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['extOfRefinance'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['extOfRefinance'].length}
                                                            />
                                                        </div>
                                                    </label>

                                                    <textarea className='form-control' {...register16('tsExtent', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                    })} maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "extOfRefinance") }} />
                                                    <span className="vldn"> {errors16.tsExtent && errors16.tsExtent.message}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='row mt-3'>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label className='prog_lbl'><strong>Eligible end borrowers/underlying assets</strong>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['eligEndBorrow'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['eligEndBorrow'].length}
                                                            />
                                                        </div>
                                                    </label>

                                                    <textarea className='form-control' {...register16('tsEligibleMse', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                    })} maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "eligEndBorrow") }} />
                                                    <span className="vldn"> {errors16.tsEligibleMse && errors16.tsEligibleMse.message}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='row  mt-3'>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label><strong>Eligible Activities</strong></label>
                                                    As Defined in Sction 2(h) of SIDBI Act.
                                                </div>
                                            </div>
                                        </div>
                                        <div className='row'>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label className='prog_lbl'><strong>Event of Default</strong>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['eventOfDefault'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['eventOfDefault'].length}
                                                            />
                                                        </div>
                                                    </label>

                                                    <textarea className='form-control' {...register16('tsEventDflt', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                    })} maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "eventOfDefault") }} />
                                                    <span className="vldn"> {errors16.tsEventDflt && errors16.tsEventDflt.message}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='row mt-3'>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label className='prog_lbl'><strong>Security</strong>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['security'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['security'].length}
                                                            />
                                                        </div>
                                                    </label>
                                                    <textarea className='form-control' {...register16('tsSecurity', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                    })} maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "security") }} />
                                                    <span className="vldn"> {errors16.tsSecurity && errors16.tsSecurity.message}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='row mt-3'>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label className='prog_lbl'><strong>Documentation</strong>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['docs'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['docs'].length}
                                                            />
                                                        </div>
                                                    </label>
                                                    <textarea className='form-control' {...register16('tsDocumentstion', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                    })} maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "docs") }} />
                                                    <span className="vldn"> {errors16.tsDocumentstion && errors16.tsDocumentstion.message}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='row mt-3'>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label className='prog_lbl'><strong>Time Frame for Aceptance of LoI/Disbursement</strong>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['timeFrame'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['timeFrame'].length}
                                                            />
                                                        </div>
                                                    </label>
                                                    <textarea className='form-control' {...register16('tsTimeFrame', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                    })} maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "timeFrame") }} />
                                                    <span className="vldn"> {errors16.tsTimeFrame && errors16.tsTimeFrame.message}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='row mt-3'>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label className='prog_lbl'><strong>Drawal of Loan</strong>
                                                        <div className='prgs'>
                                                            <span className='lft_crt'>{4000 - input['drawalOfLoan'].length} Characters left</span>
                                                            <LinearProgress
                                                                variant="determinate"
                                                                value={input['drawalOfLoan'].length}
                                                            />
                                                        </div>
                                                    </label>
                                                    {/* SIDBI reserves the right to disburse the amount in lump sum or in one or more tranches, at mutually agreed rates of interest depending upon the market conditions. */}
                                                    <textarea className='form-control' {...register16('tsDrawaloan', {
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },
                                                        validate: (value) => {
                                                            if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                            return true;
                                                        },
                                                    })} maxLength="4000"
                                                        onChange={(e) => { Pattern.sanitizeInput(e); inputHandler(e.target.value, "drawalOfLoan") }} />
                                                    <span className="vldn"> {errors16.tsDrawaloan && errors16.tsDrawaloan.message}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className='row mt-3'>
                                            <div className='col-md-12'>
                                                <div className='form-group'>
                                                    <label><strong>Other Conditions</strong></label>
                                                    {/* <textarea className='form-control' {...register16('tsOtherCond')} /> */}

                                                    <Select
                                                        isMulti
                                                        value={selectedOption}
                                                        onChange={handleChange}
                                                        options={options}
                                                    // {...register16('tsOtherCond')}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                        {/* <div className='row'>
                                        <div className='col-md-12'>
                                            <div className='form-group'>
                                                <label className='prog_lbl'><strong>Add more Conditions (if any)</strong></label>
                                                <textarea className='form-control' {...register16('tsExtraConditions')} />
                                            </div>
                                        </div>
                                    </div> */}
                                    </div>

                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && !saveOrUpdate && <p className='color-red'>Please save the autofilled data before proceeding.</p>}
                                    </div>
                                    <div className="button-container-center mb-4">
                                        {(editable || (!isMaker && locked)) && <button type='submit' className='save'>{!saveOrUpdate ? 'Save' : 'Update'} <i className="fa fa-circle-check"></i></button>}
                                    </div>
                                </form>
                            </div>
                        </Accordion.Body>
                    </Accordion.Item>

                    <Accordion.Item eventKey="1">
                        <Accordion.Header>Annexure-I</Accordion.Header>
                        <Accordion.Body>
                            <h5 className='HdngTitl' style={{ marginTop: '0.8rem', marginBottom: '1.5rem' }}>Rating Details - {ifvApp.ifvName}</h5>
                            <div className='container-fluid p-0'>
                                <form key={16} onSubmit={handleSubmitOfRatingRepo(onSubmitOfRatingRepo)}>
                                    <div className='row'>
                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <label className='ml-6'><strong>Rating Type</strong></label>
                                            </div>
                                        </div>

                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <label className='ml-6'><strong>Particulars</strong></label>
                                            </div>
                                        </div>
                                        <div className='col-md-5'>
                                            <div className='form-group'>
                                                <label className='ml-6'><strong>Remarks</strong></label>
                                            </div>
                                        </div>
                                        <div className='col-md-1'>
                                            <div className='form-group'>
                                            </div>
                                        </div>
                                    </div>

                                    {fields18.map((field, index) => (
                                        <div className='row p-0' key={field.id}>
                                            <div className='col-md-3'>
                                                <div className='form-group'>
                                                    <select className="form-select"
                                                        key={field.id}
                                                        {...register18(`ratingRepo[${index}].rtType`, {
                                                            required: "Field is required",
                                                        })}
                                                    >
                                                        <option value="">Select Rating Type</option>
                                                        {RatingType.map((item, index) => (
                                                            <option value={item}>{item}</option>
                                                        ))}
                                                    </select>
                                                    <span className='vldn'>{errors18.ratingRepo && errors18.ratingRepo[index]?.rtType && errors18.ratingRepo[index]?.rtType.message}</span>
                                                    <input type='hidden' {...register18(`ratingRepo[${index}].rtCode`)} />
                                                    <input type='hidden' {...register18(`ratingRepo[${index}].ifvId`)} value={appId} />
                                                </div>
                                            </div>

                                            <div className='col-md-3'>
                                                <div className='form-group'>
                                                    <textarea className='form-control'
                                                        key={field.id}
                                                        type='text'
                                                        {...register18(`ratingRepo[${index}].rtParticulars1`, {
                                                            required: "Field is required",
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                return true;
                                                            },
                                                        })}
                                                    />
                                                    <span className='vldn'>{errors18.ratingRepo && errors18.ratingRepo[index]?.rtParticulars1 && errors18.ratingRepo[index]?.rtParticulars1.message}</span>
                                                </div>
                                            </div>

                                            <div className='col-md-5'>
                                                <div className='form-group'>
                                                    <textarea className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='text'
                                                        {...register18(`ratingRepo[${index}].rtRemarks`, {
                                                            onChange: (e) => { Pattern.sanitizeInput(e) },
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                return true;
                                                            },
                                                        })}
                                                    />
                                                </div>
                                            </div>

                                            <div className='col-md-1'>
                                                <div className='form-group'>
                                                    {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                                        onClick={() => deleteRatingDetails(index)}></i>}
                                                </div>
                                            </div>

                                        </div>
                                    ))}

                                    <div className="button-container-end">
                                        <button type="button" className='remove' onClick={() => append18({})}>+</button>
                                    </div>
                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                                    </div>
                                </form>
                            </div>


                        </Accordion.Body>
                    </Accordion.Item>

                    {!isPrivatePublicOrForeignBank && !rrb && <Accordion.Item eventKey="2">
                        <Accordion.Header>Annexure-II</Accordion.Header>
                        <Accordion.Body>
                            <h4 className='ps-0'>Profile of the Board of Directors</h4>

                            <div className='container-fluid p-0'>
                                <form key={17} onSubmit={handleSubmitOfBoardOfDirectors(onSubmitOfBoardOfDirectors)}>
                                    <div className='row'>
                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <label className='ml-6'><strong>First Name</strong></label>
                                            </div>
                                        </div>

                                        <div className='col-md-4'>
                                            <div className='form-group'>
                                                <label className='ml-6'><strong>Designation</strong></label>
                                            </div>
                                        </div>
                                        <div className='col-md-4'>
                                            <div className='form-group'>
                                                <label className='ml-6'><strong>Brief Profile</strong></label>
                                            </div>
                                        </div>
                                        <div className='col-md-1'>
                                            <div className='form-group'>
                                            </div>
                                        </div>
                                    </div>

                                    {fields19.map((field, index) => (
                                        <div className='row p-0' key={field.id}>
                                            <div className='col-md-3'>
                                                <div className='form-group'>
                                                    <input className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='text'
                                                        {...register19(`boardOfDirectors[${index}].prFirstName`, {
                                                            required: "Field is required",
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                if (/\d/.test(value)) return 'Field should not contain any numbers';
                                                                return true;
                                                            },
                                                        })}
                                                    />
                                                    <span className='vldn'>{errors19.boardOfDirectors && errors19.boardOfDirectors[index]?.prFirstName && errors19.boardOfDirectors[index]?.prFirstName.message}</span>
                                                    <input type='hidden' {...register19(`boardOfDirectors[${index}].prCode`)} />
                                                    <input type='hidden' {...register19(`boardOfDirectors[${index}].ifvId`)} value={appId} />
                                                </div>
                                            </div>

                                            <div className='col-md-4'>
                                                <div className='form-group'>
                                                    <input className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='text'
                                                        {...register19(`boardOfDirectors[${index}].prDesignation`)}
                                                    />
                                                    {/* <select className="form-select"
                                                        key={field.id}
                                                        {...register19(`boardOfDirectors[${index}].prDesignation`, {
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                return true;
                                                            },
                                                        })}
                                                    >
                                                        <option value="">Select Designation</option>
                                                        {Designation.map((item, index) => (
                                                            <option value={item}>{item}</option>
                                                        ))}
                                                    </select> */}
                                                </div>
                                            </div>

                                            <div className='col-md-4'>
                                                <div className='form-group'>
                                                    <textarea key={field.id} className='form-control'
                                                        {...register19(`boardOfDirectors[${index}].prBriefProfile`, {
                                                            onChange: (e) => { Pattern.sanitizeInput(e) },
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                return true;
                                                            },
                                                        })} />
                                                </div>
                                            </div>
                                            <div className='col-md-1'>
                                                <div className='form-group'>
                                                    {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                                        onClick={() => deleteProfileBOD(index)}></i>}
                                                </div>
                                            </div>

                                        </div>
                                    ))}

                                    <div className="button-container-end">
                                        <button type="button" className='remove' onClick={() => append19({})}>+</button>
                                    </div>
                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                                    </div>
                                </form>
                            </div>


                        </Accordion.Body>
                    </Accordion.Item>}

                    {isPrivatePublicOrForeignBank && <Accordion.Item eventKey="4">
                        <Accordion.Header>Annexure-II</Accordion.Header>
                        <Accordion.Body>
                            <>
                                <Typography variant="h6" sx={{ mt: 1, mb: 2, fontWeight: 'normal', textTransform: 'none' }}>
                                    Disclosure of Divergences
                                </Typography>
                                <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
                                    {(editable || (!isMaker && locked)) && (
                                        <Box>
                                            {(CommonUtil.isEmpty(fileName) || reUpload) ? (
                                                <Box>
                                                    <input
                                                        type="file"
                                                        accept=".pdf"
                                                        id="file-upload"
                                                        style={{ display: 'none' }}
                                                        onChange={handleFileUpload}
                                                    />
                                                    <label htmlFor="file-upload">
                                                        <Button
                                                            variant="contained"
                                                            component="span"
                                                            color="primary"
                                                            startIcon={<UploadFileIcon />}
                                                            disabled={loading}
                                                        >
                                                            {loading ? (
                                                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                                                    <CircularProgress size={20} sx={{ mr: 1, color: 'white' }} />
                                                                    Uploading...
                                                                </Box>
                                                            ) : (
                                                                'Upload PDF'
                                                            )}
                                                        </Button>
                                                    </label>
                                                    <Typography variant="caption" sx={{ display: 'block', mt: 0.5, color: 'text.secondary' }}>
                                                        PDF only, maximum size 12MB
                                                    </Typography>
                                                </Box>
                                            ) : (
                                                <Button
                                                    variant="contained"
                                                    color="success"
                                                    startIcon={<RefreshIcon />}
                                                    onClick={() => setReUploadFlag()}
                                                >
                                                    Re-upload
                                                </Button>
                                            )}
                                        </Box>
                                    )}
                                    {!CommonUtil.isEmpty(fileName) && (
                                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                            <InsertDriveFileIcon color="primary" sx={{ mr: 1 }} />
                                            <TextField
                                                variant="standard"
                                                value={fileName}
                                                InputProps={{
                                                    readOnly: true,
                                                    disableUnderline: true,
                                                    style: { cursor: 'pointer', color: '#1976d2' }
                                                }}
                                                onClick={() => displayFileDetail('Annexure-II')}
                                                sx={{
                                                    '& .MuiInputBase-input': {
                                                        textDecoration: 'underline',
                                                        '&:hover': { color: '#0d47a1' }
                                                    }
                                                }}
                                            />
                                        </Box>
                                    )}
                                    {!CommonUtil.isEmpty(fileName) && (editable || (!isMaker && locked)) && (
                                        <IconButton
                                            color="error"
                                            onClick={() => deleteAnnexureIIFile()}
                                            sx={{ ml: 1 }}
                                        >
                                            <DeleteIcon />
                                        </IconButton>
                                    )}
                                </Box>

                            </>

                        </Accordion.Body>
                    </Accordion.Item>}

                    {ucb && <Accordion.Item eventKey="8">
                        <Accordion.Header>Annexure-III</Accordion.Header>
                        <Accordion.Body>
                            <h4 className='ps-0'>Lending Mechanism</h4>

                            <div className='container-fluid p-0'>
                                <form key={20} onSubmit={handleSubmitOfUcbAnnexure4(onSubmitOfUcbAnnexure4)}>
                                    <input type='hidden' {...register5(`ucbAnnexure4[0].id`)} />
                                    <input type='hidden' {...register5(`ucbAnnexure4[0].ifvId`)} value={appId} />
                                    <input type='hidden' {...register5(`ucbAnnexure4[0].annexureNo`)} value='4' />
                                    <input type='hidden' {...register5(`ucbAnnexure4[0].particulars`)} value='Nil' />

                                    <div className='row mt-3'>
                                        <div className='col-md-12'>
                                            <div className='form-group'>

                                                <textarea className="form-control"
                                                    {...register5('ucbAnnexure4[0].note', {
                                                        required: "Field is required",
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },

                                                    })}
                                                    maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e) }}
                                                />
                                                <span className='vldn'>{errors5.ucbAnnexure4 && errors5.ucbAnnexure4[0]?.note && errors5.ucbAnnexure4[0]?.note.message}</span>

                                            </div>
                                        </div>
                                    </div><br />

                                    {/* <div className='row'>
                                        <div className='col-md-5'>
                                            <div className='form-group'>
                                                <label className='ml-6'><strong>Particulars</strong></label>
                                            </div>
                                        </div>
                                        <div className='col-md-6'>
                                            <div className='form-group'>
                                                <label className='ml-6'><strong>Remarks</strong></label>
                                            </div>
                                        </div>
                                        <div className='col-md-1'>
                                            <div className='form-group'>
                                            </div>
                                        </div>
                                    </div>

                                    {fields5.map((field, index) => (
                                        <div className='row p-0' key={field.id}>
                                            <div className='col-md-5'>
                                                <div className='form-group'>
                                                    <input className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='text'
                                                        {...register5(`ucbAnnexure4[${index}].particulars`, {
                                                            required: "Field is required",
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                if (/\d/.test(value)) return 'Field should not contain any numbers';
                                                                return true;
                                                            },
                                                        })}
                                                    />
                                                    <span className='vldn'>{errors5.ucbAnnexure4 && errors5.ucbAnnexure4[index]?.particulars && errors5.ucbAnnexure4[index]?.particulars.message}</span>
                                                    <input type='hidden' {...register5(`ucbAnnexure4[${index}].id`)} />
                                                    <input type='hidden' {...register5(`ucbAnnexure4[${index}].ifvId`)} value={appId} />
                                                    <input type='hidden' {...register5(`ucbAnnexure4[${index}].annexureNo`)} value='4' />
                                                </div>
                                            </div>

                                            <div className='col-md-6'>
                                                <div className='form-group'>
                                                    <textarea key={field.id} className='form-control'
                                                        {...register5(`ucbAnnexure4[${index}].remarks`, {
                                                            onChange: (e) => { Pattern.sanitizeInput(e) },
                                                        })} />
                                                </div>
                                            </div>
                                            <div className='col-md-1'>
                                                <div className='form-group'>
                                                    {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                                        onClick={() => deleteUcbAnnexure4(index)}></i>}
                                                </div>
                                            </div>

                                        </div>
                                    ))}

                                    <div className="button-container-end">
                                        <button type="button" className='remove' onClick={() => append5({})}>+</button>
                                    </div> */}
                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                                    </div>
                                </form>
                            </div>


                        </Accordion.Body>
                    </Accordion.Item>
                    }

                    {ucb && <Accordion.Item eventKey="9">
                        <Accordion.Header>Annexure-IV</Accordion.Header>
                        <Accordion.Body>
                            <h4 className='ps-0'>Risk Control Mechanism</h4>

                            <div className='container-fluid p-0'>
                                <form key={27} onSubmit={handleSubmitOfUcbAnnexure4(onSubmitOfUcbAnnexure5)}>
                                    <input type='hidden' {...register5(`ucbAnnexure5[0].id`)} />
                                    <input type='hidden' {...register5(`ucbAnnexure5[0].ifvId`)} value={appId} />
                                    <input type='hidden' {...register5(`ucbAnnexure5[0].annexureNo`)} value='5' />
                                    <input type='hidden' {...register5(`ucbAnnexure5[0].particulars`)} value='Nil' />
                                    <div className='row mt-3'>
                                        <div className='col-md-12'>
                                            <div className='form-group'>

                                                <textarea className="form-control"
                                                    {...register5('ucbAnnexure5[0].note', {
                                                        required: "Field is required",
                                                        maxLength: {
                                                            value: 4000,
                                                            message: "The maximum length of the field is 4000"
                                                        },

                                                    })}
                                                    maxLength="4000"
                                                    onChange={(e) => { Pattern.sanitizeInput(e) }}
                                                />
                                                <span className='vldn'>{errors5.ucbAnnexure5 && errors5.ucbAnnexure5[0]?.note && errors5.ucbAnnexure5[0]?.note.message}</span>

                                            </div>
                                        </div>
                                    </div><br />

                                    {/* <div className='row'>
                                        <div className='col-md-5'>
                                            <div className='form-group'>
                                                <label className='ml-6'><strong>Particulars</strong></label>
                                            </div>
                                        </div>
                                        <div className='col-md-6'>
                                            <div className='form-group'>
                                                <label className='ml-6'><strong>Remarks</strong></label>
                                            </div>
                                        </div>
                                        <div className='col-md-1'>
                                            <div className='form-group'>
                                            </div>
                                        </div>
                                    </div>

                                    {fields6.map((field, index) => (
                                        <div className='row p-0' key={field.id}>
                                            <div className='col-md-5'>
                                                <div className='form-group'>
                                                    <input className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='text'
                                                        {...register5(`ucbAnnexure5[${index}].particulars`, {
                                                            required: "Field is required",
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                if (/\d/.test(value)) return 'Field should not contain any numbers';
                                                                return true;
                                                            },
                                                        })}
                                                    />
                                                    <span className='vldn'>{errors5.ucbAnnexure5 && errors5.ucbAnnexure5[index]?.particulars && errors5.ucbAnnexure5[index]?.particulars.message}</span>
                                                    <input type='hidden' {...register5(`ucbAnnexure5[${index}].id`)} />
                                                    <input type='hidden' {...register5(`ucbAnnexure5[${index}].ifvId`)} value={appId} />
                                                    <input type='hidden' {...register5(`ucbAnnexure5[${index}].annexureNo`)} value='5' />
                                                </div>
                                            </div>

                                            <div className='col-md-6'>
                                                <div className='form-group'>
                                                    <textarea key={field.id} className='form-control'
                                                        {...register5(`ucbAnnexure5[${index}].remarks`, {
                                                            onChange: (e) => { Pattern.sanitizeInput(e) },
                                                        })} />
                                                </div>
                                            </div>
                                            <div className='col-md-1'>
                                                <div className='form-group'>
                                                    {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                                        onClick={() => deleteUcbAnnexure5(index)}></i>}
                                                </div>
                                            </div>

                                        </div>
                                    ))}

                                    <div className="button-container-end">
                                        <button type="button" className='remove' onClick={() => append6({})}>+</button>
                                    </div> */}
                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                                    </div>
                                </form>
                            </div>


                        </Accordion.Body>
                    </Accordion.Item>
                    }

                    {showSFB && <Accordion.Item eventKey="3">
                        <Accordion.Header>{rrb ? 'Annexure-II' : (ucb ? 'Annexure-V' : 'Annexure-III')}</Accordion.Header>
                        <Accordion.Body>
                            <h4>Area of Operation-Geographical</h4>

                            <form key={4} onSubmit={handleSubmitOfGeographicalArea(onSubmitOfGeographicalArea)}>
                                <div className='row'>
                                    <div className='col-md-12'>
                                        <div className='branch_on'>
                                            <label>Branch Network as on </label>
                                            <div className='brn_wrp'>
                                                <Controller
                                                    control={control4}
                                                    name='sfbAoDate'
                                                    render={({ field: { onChange, onBlur, value, ref } }) => (
                                                        <ReactDatePicker className="form-control"
                                                            placeholderText="Select date"
                                                            selected={common.sfbAoDate}
                                                            onChange={(date) => setCommon(prevState => ({ ...prevState, 'sfbAoDate': new Date(date) }))}
                                                            onBlur={onBlur}
                                                            dateFormat="dd/MM/yyyy"
                                                        />
                                                    )}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className='row'>
                                    <div className='col-md-6'>
                                        <div className='form-group'>
                                            <label className='ml-4'><strong>{rrb ? 'District' : 'STATE/UT'}</strong></label>
                                        </div>
                                    </div>

                                    <div className='col-md-5'>
                                        <div className='form-group'>
                                            <label className='ml-2'><strong>NO. OF BRANCHES</strong></label>
                                        </div>
                                    </div>
                                    <div className='col-md-1'>

                                    </div>
                                </div>

                                {rrb ? <RRBGeographicalAreaTabs
                                    control4={control4}
                                    register4={register4}
                                    errors4={errors4}
                                    getValues={getValues4}
                                    setValue={setValue4}
                                    appId={appId}
                                    editable={true}
                                    isMaker={true}
                                    locked={false}
                                    showMessage={showMessage}
                                    filteredStatesOptionsForRRB={statesOptionsForRRB}
                                    handleStateSearchForRRB={handleStateSearchForRRB}
                                    onDataPrepare={handleDataPrepare}
                                    forceFetch={fetchTrigger}
                                /> :

                                    fields3.map((field, index) => (
                                        <div className='container-fluid p-0'>
                                            <div className='row pt-0' key={field.id}>
                                                <div className='col-md-6'>
                                                    <div className='form-group'>
                                                        {!rrb ? <><Select
                                                            key={field.id}
                                                            value={filteredStatesOptions.find((option) => option.label === selectedStateOption[index])}
                                                            onChange={(selected) => setSelectedStateOption(prevState => ({ ...prevState, [index]: selected.label }))}
                                                            options={filteredStatesOptions}
                                                            onInputChange={handleStateSearch}
                                                            isSearchable
                                                        />
                                                            <input key={field.id} type='hidden' {...register4(`geographicalArea[${index}].agState`)} value={selectedStateOption[index]} /></> :
                                                            <input key={field.id} type='text' className='form-control' {...register4(`geographicalArea[${index}].agState`)} />
                                                        }

                                                        <input key={field.id} type='hidden' {...register4(`geographicalArea[${index}].ifvId`)} value={appId} />
                                                        <input key={field.id} type='hidden' {...register4(`geographicalArea[${index}].agId`)} />
                                                        <input key={field.id} type='hidden' {...register4(`geographicalArea[${index}].agType`)} value='ST' />
                                                    </div>
                                                </div>
                                                <div className='col-md-5'>
                                                    <div className='form-group'>
                                                        <input className='form-control'
                                                            key={field.id}
                                                            type='number'
                                                            {...register4(`geographicalArea[${index}].agBranch`,
                                                                {
                                                                    required: "Field is required",
                                                                    validate: (value) => {
                                                                        if (value < 0) return "Invalid value";
                                                                        return true;
                                                                    },
                                                                    onChange: (e) => calculateGeoTotal(`geographicalArea[${index}].agBranch`, e.target.value)
                                                                })}
                                                        />
                                                        <span className='vldn'>{errors4.geographicalArea && errors4.geographicalArea[index]?.agBranch && errors4.geographicalArea[index]?.agBranch.message}</span>
                                                    </div>
                                                </div>
                                                <div className='col-md-1'>
                                                    <div className='form-group'>
                                                        {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                                            onClick={() => deleteAeStates(index)}></i>}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                }


                                {!rrb && <>
                                    <div className='container-fluid p-0'>
                                        <div className='row'>
                                            <div className='col-md-6'>
                                                <div className='form-group'>
                                                    <label><strong> Grand Total</strong></label>

                                                </div>
                                            </div>
                                            <div className='col-md-5'>
                                                <div className='form-group'>
                                                    <input className='form-control' type='number' value={geoTotal}
                                                        readOnly />
                                                </div>
                                            </div>
                                        </div>
                                        <div className='col-md-1'>

                                        </div>
                                    </div><br />
                                </>
                                }
                                {!rrb &&
                                    <div className='row'>

                                        <div className='col-md-3'>
                                            <div className='form-group'>
                                                <label><strong>  Majority of the branches are in</strong></label>
                                                <Select
                                                    value={selectedMajBankOption}
                                                    onChange={(selected) => setMaxBranchState(selected)}
                                                    options={filteredStatesOptions}
                                                    onInputChange={handleStateSearch}
                                                    isSearchable
                                                />

                                                <input type='hidden' name='sfbAoMajorityBranches' value={selectedMajBankOption?.label} />
                                            </div>
                                        </div>
                                    </div>
                                }
                                <div className='col-md-12'>
                                    {!rrb && <div className="button-container-end">
                                        <button className='remove' type="button" onClick={() => append3({})}>+</button>
                                    </div>
                                    }
                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                                    </div>
                                </div>
                            </form>


                        </Accordion.Body>
                    </Accordion.Item>}

                    {!isPrivatePublicOrForeignBank && !rrb && <Accordion.Item eventKey="5">
                        <Accordion.Header>{ucb ? 'Annexure-VI' : 'Annexure-IV'}</Accordion.Header>
                        <Accordion.Body>
                            <h4 className='ps-0'>Institutional Borrowings</h4>

                            <div className='container-fluid p-0'>
                                <form key={15} onSubmit={handleSubmitOfIntitutional(onSubmitOfInstitutional)}>
                                    <div className='row'>
                                        <div className='col-md-6'>
                                            <div className='form-group'>
                                                <label className='ml-6'><strong>Name of the Lender</strong></label>
                                            </div>
                                        </div>

                                        <div className='col-md-5'>
                                            <div className='form-group'>
                                                <label className='ml-2'><strong>Outstanding Amount (in <span>&#8377;</span> crore) as on</strong>
                                                    <Controller
                                                        control={control}
                                                        name='inDate'
                                                        {...register17(`institution[0].inDate`)}
                                                        render={({ field: { onChange, onBlur, value, ref } }) => (
                                                            <ReactDatePicker className="form-control"
                                                                placeholderText="Select date"
                                                                //  onChange={onChange}
                                                                selected={inDate ? inDate : ''}
                                                                onChange={(date) => setInDate(date)}
                                                                onBlur={onBlur}
                                                                dateFormat="dd/MM/yyyy"
                                                            //    selected={value}
                                                            />
                                                        )}
                                                    //  onChange={(event) => setPercSharePortfolio(event.target.value)}
                                                    />

                                                </label>
                                            </div>
                                        </div>
                                        <div className='col-md-1'>
                                            <div className='form-group'>
                                            </div>
                                        </div>
                                    </div>

                                    {fields17.map((field, index) => (
                                        <div className='row p-0' key={field.id}>
                                            <div className='col-md-6'>
                                                <div className='form-group'>
                                                    <input className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='text'
                                                        {...register17(`institution[${index}].inParticular`, {
                                                            required: "Field is required",
                                                            validate: (value) => {
                                                                if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                return true;
                                                            },
                                                        })}
                                                    />
                                                    <span className='vldn'>{errors17.institution && errors17.institution[index]?.inParticular && errors17.institution[index]?.inParticular.message}</span>
                                                    {/* <select className="form-control"
                                                        key={field.id}
                                                        {...register17(`institution[${index}].inParticular`)}
                                                    >
                                                        <option value="">Select Name of the Lender</option>
                                                        {Particular.map((item, index) => (
                                                            <option value={item}>{item}</option>
                                                        ))}
                                                    </select> */}
                                                    <input type='hidden' {...register17(`institution[${index}].inId`)} />
                                                    <input type='hidden' {...register17(`institution[${index}].ifvId`)} value={appId} />
                                                </div>
                                            </div>

                                            <div className='col-md-5'>
                                                <div className='form-group'>
                                                    <input className='form-control'
                                                        key={field.id} // important to include key with field's id
                                                        type='number'
                                                        step='0.01'
                                                        {...register17(`institution[${index}].inAmount`,
                                                            {
                                                                required: "Amount is required",
                                                                validate: (value) => {
                                                                    if (value < 0) return "Invalid value";
                                                                    //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
                                                                    if (!/^\d{1,8}(\.\d{1,2})?$/.test(value)) return "Enter up to 8 digits with up to 2 decimals";
                                                                    return true;
                                                                },
                                                                onChange: (e) => calculateGeoTotal(`institution[${index}].inAmount`, e.target.value)
                                                            })
                                                        }
                                                    />
                                                    <span className='vldn'>{errors17.institution && errors17.institution[index]?.inAmount && errors17.institution[index]?.inAmount.message}</span>
                                                </div>
                                            </div>
                                            <div className='col-md-1'>
                                                <div className='form-group'>
                                                    {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                                        onClick={() => deleteInstitutional(index)}></i>}
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                    <div className='container-fluid p-0'>
                                        <div className='row'>
                                            <div className='col-md-6'>
                                                <div className='form-group'>
                                                    <strong>Total</strong>
                                                </div>
                                            </div>

                                            <div className='col-md-5'>
                                                <div className='form-group'>
                                                    <input className='form-control' type='number' step='any' readOnly value={totRep} />
                                                </div>
                                            </div>
                                            <div className='col-md-1'>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="button-container-end">
                                        <button type="button" className='remove' onClick={() => append17({})}>+</button>
                                    </div>
                                    <div className="button-container-center">
                                        {(editable || (!isMaker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                                    </div>
                                </form>
                            </div>


                        </Accordion.Body>
                    </Accordion.Item>}

                    {showSFB && !ucb && <Accordion.Item eventKey="6">
                        <Accordion.Header>{rrb ? 'Annexure-III' : 'Annexure-V'} </Accordion.Header>
                        <Accordion.Body>
                            <>
                                <Typography variant="h6" sx={{ mt: 1, mb: 2, fontWeight: 'normal', textTransform: 'none' }}>
                                    Disclosure of Divergences
                                </Typography>
                                <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
                                    {(editable || (!isMaker && locked)) && (
                                        <Box>
                                            {(CommonUtil.isEmpty(fileName) || reUpload) ? (
                                                <Box>
                                                    <input
                                                        type="file"
                                                        accept=".pdf"
                                                        id="file-upload"
                                                        style={{ display: 'none' }}
                                                        onChange={handleFileUpload}
                                                    />
                                                    <label htmlFor="file-upload">
                                                        <Button
                                                            variant="contained"
                                                            component="span"
                                                            color="primary"
                                                            startIcon={<UploadFileIcon />}
                                                            disabled={loading}
                                                        >
                                                            {loading ? (
                                                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                                                    <CircularProgress size={20} sx={{ mr: 1, color: 'white' }} />
                                                                    Uploading...
                                                                </Box>
                                                            ) : (
                                                                'Upload PDF'
                                                            )}
                                                        </Button>
                                                    </label>
                                                    <Typography variant="caption" sx={{ display: 'block', mt: 0.5, color: 'text.secondary' }}>
                                                        PDF only, maximum size 12MB
                                                    </Typography>
                                                </Box>
                                            ) : (
                                                <Button
                                                    variant="contained"
                                                    color="success"
                                                    startIcon={<RefreshIcon />}
                                                    onClick={() => setReUploadFlag()}
                                                >
                                                    Re-upload
                                                </Button>
                                            )}
                                        </Box>
                                    )}
                                    {!CommonUtil.isEmpty(fileName) && (
                                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                            <InsertDriveFileIcon color="primary" sx={{ mr: 1 }} />
                                            <TextField
                                                variant="standard"
                                                value={fileName}
                                                InputProps={{
                                                    readOnly: true,
                                                    disableUnderline: true,
                                                    style: { cursor: 'pointer', color: '#1976d2' }
                                                }}
                                                onClick={() => displayFileDetail('Annexure-II')}
                                                sx={{
                                                    '& .MuiInputBase-input': {
                                                        textDecoration: 'underline',
                                                        '&:hover': { color: '#0d47a1' }
                                                    }
                                                }}
                                            />
                                        </Box>
                                    )}
                                    {!CommonUtil.isEmpty(fileName) && (editable || (!isMaker && locked)) && (
                                        <IconButton
                                            color="error"
                                            onClick={() => deleteAnnexureIIFile()}
                                            sx={{ ml: 1 }}
                                        >
                                            <DeleteIcon />
                                        </IconButton>
                                    )}
                                </Box>

                            </>

                        </Accordion.Body>
                    </Accordion.Item>}

                    {ucb && showDisc &&

                        <Accordion.Item eventKey="7">
                            <Accordion.Header>Annexure-VII</Accordion.Header>
                            <Accordion.Body>
                                {/* <h5 className='HdngTitl' style={{ marginTop: '0.8rem', marginBottom: '1.5rem' }}>Copy of RBI Annexure to be uploaded.</h5>
                                <div>
                                    <tr> {(editable || (!isMaker && locked)) && <td>  {(CommonUtil.isEmpty(fileName) || reUpload) ? <input type="file" name='file'
                                        accept=".pdf" placeholder="Upload document"
                                        onChange={(e) => handleUCBFileUpload(e)}
                                    />
                                        : <>
                                            <i className="fa fa-refresh" aria-hidden="true" onClick={() => setReUploadFlag()} style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                padding: '8px 10px',
                                                paddingLeft: '14px',
                                                marginRight: '8px',
                                                borderRadius: '4px',
                                                border: 'none',
                                                backgroundColor: 'green',
                                                color: '#fff',
                                                cursor: 'pointer',
                                                width: '100%'
                                            }}></i></>}</td>}

                                        {!CommonUtil.isEmpty(fileName) && <td> <input type='text' style={{ marginLeft: '8px', border: 'none', outline: 'none', cursor: 'pointer', textDecoration: 'underline', color: 'blue' }}
                                            className='form-control' value={fileName}
                                            onClick={() => displayFileDetail('UCB-Annexure-I')} readOnly /></td>}
                                        {!CommonUtil.isEmpty(fileName) && (editable || (!isMaker && locked)) && <td>
                                            <i className="fa fa-minus" onClick={() => deleteAnnexureIIFile()} style={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                padding: '8px 10px',
                                                paddingLeft: '12px',
                                                marginLeft: '18px',
                                                borderRadius: '4px',
                                                border: 'none',
                                                backgroundColor: '#f44336',
                                                color: '#fff',
                                                cursor: 'pointer',
                                                width: '80%'
                                            }}></i></td>}
                                    </tr>
                                </div> */}

                                <h4 className='ps-0'>Divergence in Asset Classification and  provisioning</h4>

                                <div className='container-fluid p-0'>
                                    <form key={25} onSubmit={handleSubmitOfDisclosure(onSubmitOfDisclosure)}>
                                        <div className='row'>
                                            <div className='col-md-6'>
                                                <div className='form-group'>
                                                    <label className='ml-6'><strong>Particulars</strong></label>
                                                </div>
                                            </div>

                                            <div className='col-md-5'>
                                                <div className='form-group'>
                                                    <label className='ml-2'><strong>Amount (in <span>&#8377;</span> crore) </strong>
                                                    </label>
                                                </div>
                                            </div>
                                            <div className='col-md-1'>
                                                <div className='form-group'>
                                                </div>
                                            </div>
                                        </div>

                                        {discFields.map((field, index) => (
                                            <div className='row p-0' key={field.id}>
                                                <div className='col-md-6'>
                                                    <div className='form-group'>
                                                        <input className='form-control'
                                                            key={field.id} // important to include key with field's id
                                                            type='text'
                                                            {...discRegister(`disclosure[${index}].particulars`, {
                                                                required: "Field is required",
                                                                validate: (value) => {
                                                                    if (Pattern.validateHtmlTags().test(value)) return "Invalid value";
                                                                    return true;
                                                                },
                                                            })}
                                                        />
                                                        <span className='vldn'>{errorOfDisc.disclosure && errorOfDisc.disclosure[index]?.particulars && errorOfDisc.disclosure[index]?.particulars.message}</span>

                                                        <input type='hidden' {...discRegister(`disclosure[${index}].id`)} />
                                                        <input type='hidden' {...discRegister(`disclosure[${index}].ifvId`)} value={appId} />
                                                    </div>
                                                </div>

                                                <div className='col-md-5'>
                                                    <div className='form-group'>
                                                        <input className='form-control'
                                                            key={field.id} // important to include key with field's id
                                                            type='number'
                                                            step='0.01'
                                                            {...discRegister(`disclosure[${index}].amount`,
                                                                {
                                                                    required: "Amount is required",
                                                                    validate: (value) => {
                                                                        if (value < 0) return "Invalid value";
                                                                        //if (value.toString().length > 8) return "Maximum length exceeded (8 digits)";
                                                                        if (!/^\d{1,8}(\.\d{1,2})?$/.test(value)) return "Enter up to 8 digits with up to 2 decimals";
                                                                        return true;
                                                                    },
                                                                    onChange: (e) => calculateDiscTotal(`disclosure[${index}].amount`, e.target.value)
                                                                })
                                                            }
                                                        />
                                                        <span className='vldn'>{errorOfDisc.disclosure && errorOfDisc.disclosure[index]?.amount && errorOfDisc.disclosure[index]?.amount.message}</span>
                                                    </div>
                                                </div>
                                                <div className='col-md-1'>
                                                    <div className='form-group'>
                                                        {(editable || (!isMaker && locked)) && <i key={field.id} className="fa fa-trash" aria-hidden="true"
                                                            onClick={() => deleteDisc(index)}></i>}
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                        <div className='container-fluid p-0'>
                                            <div className='row'>
                                                <div className='col-md-6'>
                                                    <div className='form-group'>
                                                        <strong>Total</strong>
                                                    </div>
                                                </div>

                                                <div className='col-md-5'>
                                                    <div className='form-group'>
                                                        <input className='form-control' type='number' step='any' readOnly value={totDisc} />
                                                    </div>
                                                </div>
                                                <div className='col-md-1'>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="button-container-end">
                                            <button type="button" className='remove' onClick={() => discAppend({})}>+</button>
                                        </div>
                                        <div className="button-container-center">
                                            {(editable || (!isMaker && locked)) && <button type='submit' className='save'>Save <i className="fa fa-circle-check"></i></button>}
                                        </div>
                                    </form>
                                </div>
                            </Accordion.Body>
                        </Accordion.Item>
                    }

                    {ucb && <Accordion.Item eventKey="4">
                        <Accordion.Header>Annexure-VIII</Accordion.Header>
                        <Accordion.Body>
                            <>
                                <Typography variant="h6" sx={{ mt: 1, mb: 2, fontWeight: 'normal', textTransform: 'none' }}>

                                </Typography>
                                <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
                                    {(editable || (!isMaker && locked)) && (
                                        <Box>
                                            {(CommonUtil.isEmpty(fileName) || reUpload) ? (
                                                <Box>
                                                    <input
                                                        type="file"
                                                        accept=".pdf"
                                                        id="file-upload"
                                                        style={{ display: 'none' }}
                                                        onChange={handleFileUpload}
                                                    />
                                                    <label htmlFor="file-upload">
                                                        <Button
                                                            variant="contained"
                                                            component="span"
                                                            color="primary"
                                                            startIcon={<UploadFileIcon />}
                                                            disabled={loading}
                                                        >
                                                            {loading ? (
                                                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                                                    <CircularProgress size={20} sx={{ mr: 1, color: 'white' }} />
                                                                    Uploading...
                                                                </Box>
                                                            ) : (
                                                                'Upload PDF'
                                                            )}
                                                        </Button>
                                                    </label>
                                                    <Typography variant="caption" sx={{ display: 'block', mt: 0.5, color: 'text.secondary' }}>
                                                        PDF only, maximum size 12MB
                                                    </Typography>
                                                </Box>
                                            ) : (
                                                <Button
                                                    variant="contained"
                                                    color="success"
                                                    startIcon={<RefreshIcon />}
                                                    onClick={() => setReUploadFlag()}
                                                >
                                                    Re-upload
                                                </Button>
                                            )}
                                        </Box>
                                    )}
                                    {!CommonUtil.isEmpty(fileName) && (
                                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                            <InsertDriveFileIcon color="primary" sx={{ mr: 1 }} />
                                            <TextField
                                                variant="standard"
                                                value={fileName}
                                                InputProps={{
                                                    readOnly: true,
                                                    disableUnderline: true,
                                                    style: { cursor: 'pointer', color: '#1976d2' }
                                                }}
                                                onClick={() => displayFileDetail('UCB-Annexure-VIII')}
                                                sx={{
                                                    '& .MuiInputBase-input': {
                                                        textDecoration: 'underline',
                                                        '&:hover': { color: '#0d47a1' }
                                                    }
                                                }}
                                            />
                                        </Box>
                                    )}
                                    {!CommonUtil.isEmpty(fileName) && (editable || (!isMaker && locked)) && (
                                        <IconButton
                                            color="error"
                                            onClick={() => deleteAnnexureIIFile()}
                                            sx={{ ml: 1 }}
                                        >
                                            <DeleteIcon />
                                        </IconButton>
                                    )}
                                </Box>

                            </>

                        </Accordion.Body>
                    </Accordion.Item>
                    }

                </Accordion>
            </div>
            <div className="button-container-center">
                {appId > 0 && <button type='button' className='btn btnPrev' onClick={() => navigate(-1)}><i className="fa fa-arrow-left"></i> Prev</button>}
                {(isForwarded || isRimvRejected || isRimvApproved) && <button type='button' className='btn btnSave' onClick={() => setOpenRimvDialog(true)}>View RiMV Docs</button>}
                {(locked && !isMaker) && <button type='button' className='btn btnSave' style={{ background: '#f39c12' }} onClick={() => getCheckerListForSendBack()}><i className="fa fa-mail-reply"></i> Send Back </button>}
                {(isChecker || isCheckerConvenor || isHigherAuthority || isMakerConvenor || isAdminChecker) && locked && <button type='button' className='btn bg-success btnSave' onClick={() => setShowHideApprove(true)}>Approve <i className="fa fa-thumbs-up"></i></button>}
                {((editable && isMaker) || isChecker || (!editable && !isMaker)) && !isHigherAuthority && !isApproved && <button type='button' className='btn btnSave locks' style={{ background: '#3498db' }} onClick={() => validateDataForForwarding()}> Forward <i className="fa fa-mail-forward"></i></button>}
                {/* {(locked && isChecker) && <button type='button' className='btn bg-success btnSave' onClick={() => confirmDocument()}>Confirm Document <i className="fa fa-check"></i></button>} */}

                {(isApproved) && <button type='button' className='btn bg-success btnSave' onClick={() => openCommentModel()}>Add Audit Comment <i className="fa fa-plus-circle"></i></button>}
                {(isApproved) && (isAdminChecker || isCheckerConvenor || isHigherAuthority || isMakerConvenor) && <button type='button' className='btn btnPrev' onClick={() => revertBackDocument()}>Unlock <i className="fa fa-unlock"></i></button>}
            </div>

            <Modal style={{ marginTop: "200px" }} show={openAuditComment} onHide={handleAuditCommentClose}>

                <Modal.Body >
                    <div className="conatiner text-center">
                        <div className="row">
                            <div className="col-sm-12">
                                <h5><strong>Add Audit Comment</strong></h5>
                                <div className='form-group'>
                                    <textarea className='form-control' onChange={(e) => { Pattern.sanitizeInput(e); setAuditComment(e.target.value) }} defaultValue={auditComment}></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br />
                    <div className="row text-center">
                        <div className="col-sm-12 text-center">
                            <button type="button" className=" btn btnRegister" onClick={handleAuditCommentClose}>Cancel  <i className="fa fa-close"></i></button>&nbsp;
                            <button type="button" className="btn btnProceed" onClick={() => saveOrUpdateAuditComment()}>Save <i className="fa fa-circle-check"></i></button>
                        </div>
                    </div>

                </Modal.Body>
            </Modal>

            <Modal style={{ marginTop: "200px" }} show={showHideProceed} onHide={hideProceed}>

                <Modal.Body >
                    <div className="conatiner text-center">
                        <div className="row">
                            <div className="col-sm-12">
                                <h5><strong>{sendBack ? 'Send Back To' : 'Forward to Checker'}:</strong></h5>

                                <select className="form-select" onChange={(e) => setAppChecker(e.target.value)}>
                                    <option value=''>Please select user</option>
                                    {checkerList.map((item, index) => (
                                        <option value={item.ofrCode}>{item.ofrName} {item.ofrMiddleName} {item.ofrLastName}</option>
                                    ))}

                                </select>
                            </div>

                            <div className="col-sm-12">
                                <br />
                                <h5><strong>Add comments (if any)</strong></h5>
                                <div className='form-group'>
                                    <textarea className='form-control' onChange={(e) => { Pattern.sanitizeInput(e); setForwardComment(e.target.value) }} defaultValue={forwardComment}></textarea>
                                </div>
                            </div>

                        </div>
                    </div>
                    <br />
                    <div className="row text-center">

                        <div className="col-sm-12 text-center">
                            <button type="button" className="btn btnRegister" onClick={hideProceed}>Cancel <i className="fa fa-close"></i></button>&nbsp;
                            <button type="button" className="btn btnProceed" onClick={() => proceed()}>{sendBack ? <><i className="fa fas fa-reply"></i> Send Back</> : <>Forward <i className="fa fas fa-share"></i></>}</button>
                        </div>
                    </div>

                </Modal.Body>
            </Modal>

            <Modal style={{ marginTop: "200px" }} show={showHideApprove} onHide={hideApprove}>

                <Modal.Body >
                    <div className="conatiner text-center">
                        <div className="row">
                            <div className="col-sm-12">
                                <h5><strong>Add comments (if any)</strong></h5>
                                <div className='form-group'>
                                    <textarea className='form-control' onChange={(e) => { Pattern.sanitizeInput(e); setForwardComment(e.target.value) }} defaultValue={forwardComment}></textarea>
                                </div>
                            </div>

                        </div>
                    </div>
                    <br />
                    <div className="row text-center">

                        <div className="col-sm-12 text-center">
                            <button type="button" className=" btn btnRegister" onClick={hideApprove}>Cancel <i className="fa fa-close"></i></button>&nbsp;
                            <button type="button" className="btn btnProceed" onClick={() => approveDocument()}>Approve <i className="fa fa-thumbs-up"></i></button>
                        </div>
                    </div>

                </Modal.Body>
            </Modal>
            {loading && <Loading />}
            <MessageModal
                open={isOpen}
                onClose={hideMessage}
                message={messageConfig.message}
                type={messageConfig.type}
                totalMessages={totalMessages}
                currentIndex={currentIndex}
                onNext={nextMessage}
                onPrev={prevMessage}
                hasNext={hasNext}
                hasPrev={hasPrev}
            />
            <RimvDocsDialog
                open={openRimvDialog}
                onClose={() => setRimvOnClose()}
                ifvId={appId}
                ifvName={ifvApp.ifvName}
                appNo={ifvApp.appNumber}
            />
        </Fragment >
    )
}
export default TermsAndConditions;