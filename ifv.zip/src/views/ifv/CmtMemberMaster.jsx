import BlockIcon from '@mui/icons-material/Block';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import EditIcon from '@mui/icons-material/Edit';
import {
    Box,
    Button,
    IconButton,
    Tooltip
} from '@mui/material';
import Loading from 'components/Loading';
import { MaterialReactTable, useMaterialReactTable } from 'material-react-table';
import { useEffect, useMemo, useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import { useForm } from "react-hook-form";
import ReactSelect from 'react-select';
import IfvAppraisalService from 'services/IfvAppraisalService';
import MasterService from 'services/MasterService';
import Committee from 'services/constants/Committee';
import CommitteeMemberType from 'services/constants/CommitteeMemberType';
import CommonUtil from 'services/utils/CommonUtil';

const CmtMemberMaster = () => {
    const { register, handleSubmit, setValue, watch, reset } = useForm({
        mode: "onBlur"
    });

    const [loading, setLoading] = useState(false);
    const [data, setData] = useState([]);
    const [showMsg, setShowMsg] = useState(false);
    const [message, setMessage] = useState('');
    const [modalShow, setModalShow] = useState(false);
    const [selectedOption, setSelectedOption] = useState(null);
    const [filteredOptions, setFilteredOptions] = useState([]);
    const [options, setOptions] = useState([]);
    const [enable, setEnable] = useState(true);
    const hideMsg = () => setShowMsg(false);

    useEffect(() => {
        getAllMemberNames();
        getAllCmtMembers();
    }, []);

    const getAllMemberNames = () => {
        setLoading(true);
        MasterService.getAllMemberNames().then(
            (response) => {
                const formattedOptions = response.data.map((item) => ({
                    value: item,
                    label: item,
                }));
                setOptions(formattedOptions);
                setFilteredOptions(formattedOptions);
                setLoading(false);
            },
            (error) => {
                const resMessage = getErrorMessage(error);
                setLoading(false);
                setMessage('Error occurred while loading members: ' + resMessage);
                setShowMsg(true);
            }
        );
    };

    const getAllCmtMembers = () => {
        setLoading(true);
        IfvAppraisalService.loadCommitteeMembers().then(
            (response) => {
                const formattedData = response.data.map(e => ({
                    cmtMemberCode: e.cmtMemberCode,
                    memberCode: e.memberCode,
                    memberName: e.memberName,
                    cmtMemberRole: e.cmtMemberRole,
                    cmtCode: e.cmtCode,
                    cmtCodeVal: Committee[e.cmtCode],
                    cmtType: e.cmtType,
                    cmtTypeVal: CommitteeMemberType[e.cmtType],
                    cmtRemark: e.cmtRemark,
                    memberVertical: e.memberVertical,
                    memberShortName: e.memberShortName,
                    memberMailId: e.memberMailId,
                    status: e.enableFlag === 'Y' ? 'Enabled' : 'Disabled',
                    enableFlag: e.enableFlag
                }));
                setData(formattedData);
                setLoading(false);
            },
            (error) => {
                const resMessage = getErrorMessage(error);
                setLoading(false);
                setMessage('Error occurred while loading committee members: ' + resMessage);
                setShowMsg(true);
            }
        );
    };
    const handleSearch = (inputValue) => {
        if (inputValue === "") {
            setFilteredOptions(options);
            return;
        }

        const filtered = options.filter((option) =>
            option.label.toLowerCase().includes(inputValue.toLowerCase())
        );
        setFilteredOptions(filtered);
    };

    const onSubmit = (data) => {
        setLoading(true);
        const user = IfvAppraisalService.getCurrentUser();

        if (CommonUtil.isValidNumber(data.cmtMemberCode) && data.cmtMemberCode > 0) {
            // Update existing member
            data.modifiedBy = user.name;
            IfvAppraisalService.updateMember(data).then(
                (response) => {
                    setMessage('Committee member details have been successfully updated!');
                    setShowMsg(true);
                    getAllCmtMembers();
                    setLoading(false);
                    setModalShow(false);
                },
                (error) => {
                    const resMessage = getErrorMessage(error);
                    setLoading(false);
                    setMessage('Error occurred while updating committee member: ' + resMessage);
                    setShowMsg(true);
                }
            );
        } else {
            // Create new member
            data.createdBy = user.name;
            data.enableFlag = 'Y';
            IfvAppraisalService.saveCommitteeMember(data).then(
                (response) => {
                    setMessage('Committee member details have been successfully created!');
                    setShowMsg(true);
                    getAllCmtMembers();
                    setLoading(false);
                    setModalShow(false);
                },
                (error) => {
                    const resMessage = getErrorMessage(error);
                    setLoading(false);
                    setMessage('Error occurred while creating committee member: ' + resMessage);
                    setShowMsg(true);
                }
            );
        }
    };

    const clearAndOpenModal = (id) => {
        reset();
        setSelectedOption(null);

        if (id > 0) {
            setEnable(true);
            const memberObj = data.find((item) => parseInt(item.cmtMemberCode) === parseInt(id));
            setValue('cmtMemberCode', memberObj.cmtMemberCode);
            setValue('memberCode', memberObj.memberCode);
            setValue('cmtMemberRole', memberObj.cmtMemberRole);
            setValue('cmtCode', memberObj.cmtCode);
            setValue('cmtType', memberObj.cmtType);
            setValue('cmtRemark', memberObj.cmtRemark);
            setValue('memberVertical', memberObj.memberVertical);
            setValue('memberShortName', memberObj.memberShortName);
            setValue('memberMailId', memberObj.memberMailId);

            const formattedOptions = {
                value: memberObj.memberName,
                label: memberObj.memberName,
            };
            setSelectedOption(formattedOptions);
            setValue('memberName', memberObj.memberName);
        } else {
            setEnable(false);
        }

        setModalShow(true);
    };

    const onChangeOfMemberName = (selected) => {
        setSelectedOption(selected);
        const memberName = selected.label;
        setValue('memberName', memberName);

        setLoading(true);
        MasterService.getMemberDetailsByName(memberName).then(
            (response) => {
                const memberData = response.data;
                setValue('memberCode', memberData.empCode);
                setValue('cmtMemberRole', memberData.desigDesc?.trim());
                setLoading(false);
            },
            (error) => {
                const resMessage = getErrorMessage(error);
                setLoading(false);
                setMessage('Error occurred while loading member details: ' + resMessage);
                setShowMsg(true);
            }
        );
    };

    const syncWithMIS = () => {
        if (!selectedOption) {
            setMessage('Please select a member first');
            setShowMsg(true);
            return;
        }

        const memberName = selectedOption.label;
        setValue('memberName', memberName);

        setLoading(true);
        MasterService.getMemberDetailsByName(memberName).then(
            (response) => {
                const memberData = response.data;
                setValue('memberCode', memberData.empCode);
                setValue('cmtMemberRole', memberData.desigDesc?.trim());
                setLoading(false);
            },
            (error) => {
                const resMessage = getErrorMessage(error);
                setLoading(false);
                setMessage('Error occurred while loading member details: ' + resMessage);
                setShowMsg(true);
            }
        );
    };

    const toggleMemberStatus = (id, flag) => {
        let action = flag === 'Y' ? 'disable' : 'enable';

        if (window.confirm(`Are you sure you want to ${action} this committee member?`)) {
            setLoading(true);
            const updateFlag = flag === 'Y' ? 'N' : 'Y';

            if (CommonUtil.isValidNumber(id)) {
                const updateData = {
                    cmtMemberCode: id,
                    enableFlag: updateFlag,
                    modifiedBy: IfvAppraisalService.getCurrentUser().name
                };

                IfvAppraisalService.updateMember(updateData).then(
                    (response) => {
                        setLoading(false);
                        setMessage(`Committee member ${action}d successfully!`);
                        getAllCmtMembers();
                        setShowMsg(true);
                    },
                    (error) => {
                        const resMessage = getErrorMessage(error);
                        setLoading(false);
                        setMessage('Error occurred while updating committee member: ' + resMessage);
                        setShowMsg(true);
                    }
                );
            } else {
                setLoading(false);
                setMessage('Invalid member ID');
                setShowMsg(true);
            }
        }
    };

    const getErrorMessage = (error) => {
        return (error.response &&
            error.response.data &&
            error.response.data.message) ||
            error.message ||
            error.toString();
    };

    const columns = useMemo(
        () => [
            {
                accessorKey: 'memberName',
                header: 'Member Name',
            },
            {
                accessorKey: 'memberCode',
                header: 'Member Code',
                size: 120,
            },
            {
                accessorKey: 'cmtMemberRole',
                header: 'Role',
                size: 120,
            },
            {
                accessorKey: 'cmtTypeVal',
                header: 'Member Type',
                size: 150,
            },
            {
                accessorKey: 'memberVertical',
                header: 'Vertical',
                size: 120,
            },
            {
                accessorKey: 'cmtCodeVal',
                header: 'Committee',
                size: 120,
            },
            {
                accessorKey: 'status',
                header: 'Status',
                size: 100,
            },
        ],
        []
    );

    const table = useMaterialReactTable({
        columns,
        data: data,
        enableEditing: true,
        getRowId: (row) => row.cmtMemberCode,

        muiTableContainerProps: {
            sx: {
                minHeight: '500px',
            },
        },

        renderRowActions: ({ row }) => (
            <Box sx={{ display: 'flex' }}>
                <Tooltip title="Edit">
                    <IconButton onClick={() => clearAndOpenModal(row.original.cmtMemberCode)}>
                        <EditIcon />
                    </IconButton>
                </Tooltip>
                <Tooltip title={row.original.enableFlag === 'Y' ? 'Disable' : 'Enable'}>
                    <IconButton
                        color={row.original.enableFlag === 'Y' ? 'error' : 'success'}
                        onClick={() => toggleMemberStatus(row.original.cmtMemberCode, row.original.enableFlag)}
                    >
                        {row.original.enableFlag === 'Y' ? <BlockIcon /> : <CheckCircleOutlineIcon />}
                    </IconButton>
                </Tooltip>
            </Box>
        ),

        renderTopToolbarCustomActions: () => (
            <Button
                variant="contained"
                onClick={() => clearAndOpenModal(0)}
            >
                Create New Committee Member
            </Button>
        ),
    });

    return (
        <div className={loading ? 'blur-background' : ''}>
            <MaterialReactTable table={table} />
            {loading && <Loading />}

            <Modal
                show={modalShow}
                onHide={() => setModalShow(false)}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
                className={loading ? 'blur-background' : ''}
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Committee Member Registration
                    </Modal.Title>
                </Modal.Header>
                <form onSubmit={handleSubmit(onSubmit)}>
                    <Modal.Body>
                        <div className="row mb-3">
                            <div className="col-md-4">
                                <div className="form-group">
                                    <label><strong>Member Name<span className="color-red"> *</span></strong></label>
                                    <ReactSelect
                                        value={selectedOption}
                                        onChange={(selected) => onChangeOfMemberName(selected)}
                                        options={filteredOptions}
                                        onInputChange={handleSearch}
                                        isSearchable
                                        isDisabled={enable}
                                    />
                                    <input type='hidden' {...register('memberName')} />
                                    <input type='hidden' {...register('cmtMemberCode')} />
                                </div>
                            </div>

                            <div className="col-md-4">
                                <div className="form-group">
                                    <label><strong>Member Code<span className="color-red"> *</span></strong></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        required
                                        readOnly
                                        {...register('memberCode')}
                                    />
                                </div>
                            </div>

                            <div className="col-md-4">
                                <div className="form-group">
                                    <label><strong>Member Vertical</strong></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        {...register('memberVertical')}
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="row mb-3">
                            <div className="col-md-4">
                                <div className="form-group">
                                    <label><strong>Member Role<span className="color-red"> *</span></strong></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        {...register('cmtMemberRole')}
                                    />
                                </div>
                            </div>

                            <div className="col-md-4">
                                <div className="form-group">
                                    <label><strong>Member Type<span className="color-red"> *</span></strong></label>
                                    <select
                                        className="form-select"
                                        autoComplete="off"
                                        required
                                        defaultValue={watch('cmtType')}
                                        {...register('cmtType')}
                                    >
                                        <option value="">Select Member Type</option>
                                        {Object.entries(CommitteeMemberType).map(([key, value]) => (
                                            <option value={key}>{value}</option>
                                        ))}
                                    </select>
                                </div>
                            </div>

                            <div className="col-md-4">
                                <div className="form-group">
                                    <label><strong>Committee Code<span className="color-red"> *</span></strong></label>
                                    <select
                                        className="form-select"
                                        autoComplete="off"
                                        required
                                        {...register('cmtCode')}
                                    >
                                        <option value="">Select Committee Type</option>
                                        {Object.entries(Committee).map(([key, value]) => (
                                            <option value={key}>{value}</option>
                                        ))}
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div className="row mb-3">
                            <div className="col-md-4">
                                <div className="form-group">
                                    <label><strong>Member Short Name<span className="color-red"> *</span></strong></label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        autoComplete="off"
                                        required
                                        {...register('memberShortName')}
                                    />
                                </div>
                            </div>

                            <div className="col-md-4">
                                <div className="form-group">
                                    <label><strong>Member Email<span className="color-red"> *</span></strong></label>
                                    <input
                                        type="email"
                                        className="form-control"
                                        autoComplete="off"
                                        required
                                        {...register('memberMailId')}
                                    />
                                </div>
                            </div>

                            {/* <div className="col-md-4">
                                <div className="form-group">
                                    <label><strong>Member Enabled</strong></label>
                                    
                                    <select
                                        className="form-control"
                                        autoComplete="off"
                                        required
                                        {...register('enableFlag')}
                                    >
                                        <option value="Y">Yes</option>
                                        <option value="N">No</option>
                                    </select>
                                </div>
                            </div> */}
                        </div>
                    </Modal.Body>
                    <Modal.Footer>
                        <div className="button-container-center">
                            {enable && (
                                <>
                                    <button
                                        type='button'
                                        className='btn btnPrev'
                                        onClick={syncWithMIS}
                                    >
                                        Sync with MIS <i className="fas fa-sync"></i>
                                    </button>
                                    &nbsp;
                                </>
                            )}
                            <button
                                type='submit'
                                className='save btn btnSave'
                            >
                                {!enable ? 'Save' : 'Update'} <i className="fa fa-circle-check"></i>
                            </button>
                        </div>
                    </Modal.Footer>
                </form>
            </Modal>

            <Modal
                style={{ marginTop: "200px" }}
                show={showMsg}
                onHide={hideMsg}
            >
                <Modal.Body>
                    <div className="container text-center">
                        <div className="row">
                            <div className="col-sm-12">
                                <h5 className={message.includes('Error') ? 'alertMsg' : 'loadMsg'}>
                                    {message}
                                </h5>
                            </div>
                        </div>
                    </div>

                    <div className="row text-center">
                        <div className="col-sm-12 text-center">
                            <button
                                type="button"
                                className="btn btnRegister themebutton"
                                onClick={hideMsg}
                            >
                                OK
                            </button>
                        </div>
                    </div>
                </Modal.Body>
            </Modal>
        </div>
    );
};

export default CmtMemberMaster;
