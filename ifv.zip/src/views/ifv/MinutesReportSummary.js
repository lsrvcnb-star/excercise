import DownloadIcon from '@mui/icons-material/Download';
import RefreshIcon from '@mui/icons-material/Refresh';
import { Box, IconButton, Tooltip } from '@mui/material';
import CircularProgress from '@mui/material/CircularProgress';
import {
    QueryClient,
    QueryClientProvider,
    keepPreviousData,
    useQuery
} from '@tanstack/react-query';
import axios from 'axios';
import { format } from 'date-fns';
import {
    MaterialReactTable,
    useMaterialReactTable,
} from 'material-react-table';
import { useEffect, useMemo, useState } from 'react';
import { useLocation } from "react-router-dom";
import MinutesService from 'services/MinutesService';
import Committee from "services/constants/Committee";
import CommonUtil from 'services/utils/CommonUtil';
import FileUtil from 'services/utils/FileUtil';
import { getJwtToken } from 'services/utils/JwtUtil';

const MinSummary = () => {
    const [showMsg, setShowMsg] = useState(false);
    const [errorMsg, setErrorMsg] = useState('');
    const [backendError, setBackendError] = useState(null);
    const location = useLocation();
    const mode = location.state?.mode || '';
    const [columnFilters, setColumnFilters] = useState([]);
    const [globalFilter, setGlobalFilter] = useState('');
    const [sorting, setSorting] = useState([]);
    const [loading, setLoading] = useState(null);
    const [pagination, setPagination] = useState({
        pageIndex: 0,
        pageSize: 10,
    });
    const {
        data: queryData,
        isError,
        isRefetching,
        isLoading,
        refetch,
        error,
    } = useQuery({
        queryKey: [
            'table-data',
            columnFilters,
            globalFilter,
            pagination.pageIndex,
            pagination.pageSize,
            sorting,
        ],
        queryFn: async () => {
            const url = new URL(`${process.env.REACT_APP_API_ENDPOINT}api/sanction-minutes/getAllOnUserTypeOnPage/8080/101`);
            url.searchParams.set('start', `${pagination.pageIndex * pagination.pageSize}`);
            url.searchParams.set('size', `${pagination.pageSize}`);
            url.searchParams.set('filters', JSON.stringify(columnFilters ?? []));
            url.searchParams.set('globalFilter', globalFilter);
            url.searchParams.set('sorting', JSON.stringify(sorting ?? []));
            url.searchParams.set('status', mode);
            try {
                const response = await axios.get(url.href, {
                    headers: { Authorization: `Bearer ${getJwtToken()}` },
                });
                return response.data;
            } catch (error) {
                console.error('Backend error while loading data:', error);
                setBackendError('ERR_BAD_RESPONSE');
                throw error;
            }
        },
        placeholderData: keepPreviousData,
    });
    const tableData = queryData?.content ?? [];
    const totalRows = queryData?.totalElements ?? 0;
    useEffect(() => {
        if (isError && error) {
            console.error('Query error:', error);
            setBackendError('ERR_BAD_RESPONSE');
        }
    }, [isError, error]);
    const columns = useMemo(() => [
        {
            accessorKey: 'commiteeCode',
            header: 'Committee Name',
            size: 200,
            Cell: ({ cell }) => Committee[cell.getValue()],
        },
        {
            accessorKey: 'agendaId',
            header: 'Agenda ID',
            size: 100,
        },
        {
            accessorKey: 'meetingNo',
            header: 'Meeting No',
            size: 100,
        },
        {
            accessorKey: 'createdDate',
            header: 'Created Date',
            size: 150,
            Cell: ({ cell }) => format(new Date(cell.getValue()), 'dd-MM-yyyy'),
        },
        {
            accessorKey: 'sanctStage',
            header: 'Status',
            size: 50,
        },
    ], []);
    const handleDownload = async (sanctDetailCode) => {
        setLoading(sanctDetailCode);
        try {
            const response = await MinutesService.getDocumentByMinuteId(sanctDetailCode);
            if (!CommonUtil.isEmpty(response.data.documentName)) {
                FileUtil.downloadFile(response.data.documentContent, response.data.documentName, "application/pdf");
            } else {
                alert('No file')
            }

        } catch (error) {
            const resMessage =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            console.log(resMessage);
            alert('Error occurred while generating report')
        } finally {
            setLoading(null);
        }
    };
    const table = useMaterialReactTable({
        columns,
        data: tableData,
        createDisplayMode: 'modal',
        editDisplayMode: 'modal',
        enableEditing: true,
        getRowId: (row) => row.id,
        muiTableContainerProps: {
            sx: {
                minHeight: '500px',
            },
        },
        initialState: { showColumnFilters: true },
        manualFiltering: true,
        manualPagination: true,
        manualSorting: true,
        muiToolbarAlertBannerProps: isError
            ? {
                color: 'error',
                children: 'Error loading data',
            }
            : undefined,
        onColumnFiltersChange: setColumnFilters,
        onGlobalFilterChange: setGlobalFilter,
        onPaginationChange: setPagination,
        onSortingChange: setSorting,
        renderTopToolbarCustomActions: () => (
            <Tooltip arrow title="Refresh Data">
                <IconButton onClick={() => refetch()}>
                    <RefreshIcon />
                </IconButton>
            </Tooltip>
        ),
        renderRowActions: ({ row, table }) => (
            <Box sx={{ display: 'flex' }}>
                <Tooltip title="Download">
                    <IconButton
                        onClick={() => handleDownload(row.original.sanctDetailCode)}
                        sx={{ color: loading === row.original.sanctDetailCode ? 'gray' : 'primary.main' }}
                        disabled={loading === row.original.sanctDetailCode}
                    >
                        {loading === row.original.sanctDetailCode ? (
                            <CircularProgress size={24} />
                        ) : (
                            <DownloadIcon />
                        )}
                    </IconButton>
                </Tooltip>
            </Box >
        ),
        rowCount: totalRows,
        state: {
            columnFilters,
            globalFilter,
            isLoading,
            pagination,
            showAlertBanner: isError,
            showProgressBars: isRefetching,
            sorting,
        },
        enableRowNumbers: true,
        rowNumberDisplayMode: 'static',
        muiDetailPanelProps: () => ({
            sx: (theme) => ({
                backgroundColor:
                    theme.palette.mode === 'dark'
                        ? 'rgba(255,210,244,0.1)'
                        : 'rgba(0,0,0,0.1)',
            }),
        }),
    });
    return <MaterialReactTable table={table} />;
};
const queryClient = new QueryClient();
const MinutesReportsSummary = () => (
    <QueryClientProvider client={queryClient}>
        <MinSummary />
    </QueryClientProvider>
);
export default MinutesReportsSummary;