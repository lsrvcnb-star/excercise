import AddIcon from "@mui/icons-material/Add";
import DeleteIcon from "@mui/icons-material/Delete";
import {
    Box,
    Button,
    CircularProgress,
    Collapse,
    IconButton,
    Paper,
    Table,
    TableBody,
    TableHead,
    TableRow,
} from "@mui/material";
import {
    BankSelectCell,
    LoadingSpinner,
    StyledInput,
    StyledTableCell,
    StyledTableContainer,
    StyledTableRow,
    useBankOptions
} from "components/common/colendingShared";
import { useEffect, useState } from "react";
import { Controller, useFieldArray, useForm } from "react-hook-form";
import {
    deleteInterestReset,
    getInterestResets,
    saveInterestResets,
} from "services/minutesAdditionalDetailApi";

const InterestRateResetSection = ({ minuteSanctionId, open, isEditable }) => {
    const [loading, setLoading] = useState(false);
    const [saving, setSaving] = useState(false);
    const [deletingIndex, setDeletingIndex] = useState(null);
    const { bankOptions, loadingBanks } = useBankOptions(open);

    const { control, handleSubmit, setValue, formState: { errors } } = useForm({
        defaultValues: { interestResets: [] },
        mode: "onChange",
    });

    const { fields, append, remove, replace } = useFieldArray({
        control,
        name: "interestResets",
    });

    // Validation helper functions
    const validateAmount = (value) => {
        if (!value || value === "") return "Amount is required";
        const numValue = parseFloat(value);
        if (isNaN(numValue)) return "Invalid amount";
        if (numValue <= 0) return "Amount must be greater than 0";

        const [intPart, decPart] = value.toString().split(".");
        if (intPart && intPart.length > 12) return "Max 12 digits before decimal";
        if (decPart && decPart.length > 8) return "Max 8 digits after decimal";

        return true;
    };

    const validatePeriod = (value) => {
        if (!value || value === "") return "Period is required";
        const numValue = parseInt(value);
        if (isNaN(numValue)) return "Invalid period";
        if (!Number.isInteger(parseFloat(value))) return "Period must be an integer";
        if (numValue <= 0) return "Period must be greater than 0";
        return true;
    };

    const validatePercentage = (value, fieldName) => {
        if (!value || value === "") return `${fieldName} is required`;
        const numValue = parseFloat(value);
        if (isNaN(numValue)) return `Invalid ${fieldName}`;
        if (numValue < 0 || numValue > 100) return `${fieldName} must be between 0 and 100`;

        const [, decPart] = value.toString().split(".");
        if (decPart && decPart.length > 2) return `Max 2 decimal places allowed`;

        return true;
    };

    const validateDate = (value) => {
        if (!value || value === "") return "Date is required";

        // Check if date is valid
        const date = new Date(value);
        if (isNaN(date.getTime())) return "Invalid date";

        // Additional check for realistic dates
        const year = date.getFullYear();
        if (year < 1900 || year > 2100) return "Date year must be between 1900 and 2100";

        return true;
    };

    const validateBankName = (value) => {
        if (!value || value === "") return "Bank name is required";
        return true;
    };

    const fetchData = async () => {
        try {
            setLoading(true);
            const res = await getInterestResets(minuteSanctionId);
            const formatted =
                res?.map((item) => ({
                    dbId: item.id,
                    bankName: item.bankName,
                    cifNumber: item.cifNumber,
                    amount: item.amount || "",
                    periodInMonths: item.periodInMonths || "",
                    resetDate: item.resetDate || "",
                    rateOfInterest: item.rateOfInterest || "",
                    costOfFunds: item.costOfFunds || "",
                    resetDueDate: item.resetDueDate || "",
                    remarks: item.remarks || "",
                })) || [];
            replace(formatted);
        } catch (err) {
            console.error("Fetch interest reset error", err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (open && minuteSanctionId) {
            fetchData();
        }
    }, [open, minuteSanctionId]);

    const handleAddRow = () => {
        append({
            dbId: null,
            bankName: "",
            cifNumber: "",
            amount: "",
            periodInMonths: "",
            resetDate: "",
            rateOfInterest: "",
            costOfFunds: "",
            resetDueDate: "",
            remarks: "",
        });
    };

    const handleDelete = async (index, dbId) => {
        if (!window.confirm("Delete this interest reset record?")) return;
        try {
            setDeletingIndex(index);
            if (dbId) await deleteInterestReset(dbId);
            remove(index);
        } catch (err) {
            console.error("Delete failed", err);
            alert("Delete failed. Please try again.");
        } finally {
            setDeletingIndex(null);
        }
    };

    const onSubmit = async (formData) => {
        if (!formData?.interestResets || formData.interestResets.length === 0) {
            alert("Please add at least one record before submitting.");
            return;
        }

        try {
            setSaving(true);
            const payload = formData.interestResets.map((item) => ({
                bankName: item.bankName,
                cifNumber: item.cifNumber,
                amount: item.amount,
                periodInMonths: item.periodInMonths,
                resetDate: item.resetDate,
                rateOfInterest: item.rateOfInterest,
                costOfFunds: item.costOfFunds,
                resetDueDate: item.resetDueDate,
                remarks: item.remarks,
                minuteSanctionId,
            }));
            await saveInterestResets(minuteSanctionId, payload);
            alert("Interest Reset saved successfully");
            fetchData();
        } catch (err) {
            console.error("Save failed", err);
            alert("Save failed. Please try again.");
        } finally {
            setSaving(false);
        }
    };

    return (
        <Collapse in={open} timeout="auto" unmountOnExit>
            <Box mt={2} className="intRst">
                {loading ? (
                    <LoadingSpinner />
                ) : (
                    <Box>
                        <StyledTableContainer component={Paper}>
                            <Table size="small" stickyHeader>
                                <TableHead>
                                    <TableRow>
                                        <StyledTableCell sx={{ width: "50px" }}>S.No</StyledTableCell>
                                        <StyledTableCell sx={{ minWidth: "250px" }}>Name of the Bank</StyledTableCell>
                                        <StyledTableCell sx={{ minWidth: "100px" }}>Amount (₹ in Crore)</StyledTableCell>
                                        <StyledTableCell sx={{ minWidth: "70px" }}>Period (Months)</StyledTableCell>
                                        <StyledTableCell sx={{ minWidth: "100px" }}>Reset Date</StyledTableCell>
                                        <StyledTableCell sx={{ minWidth: "80px" }}>ROI (%)</StyledTableCell>
                                        <StyledTableCell sx={{ minWidth: "80px" }}>Cost of Funds (%)</StyledTableCell>
                                        <StyledTableCell sx={{ minWidth: "120px" }}>Reset Due Date</StyledTableCell>
                                        <StyledTableCell align="center" sx={{ width: "80px" }}>
                                            {isEditable && <IconButton
                                                onClick={handleAddRow}
                                                size="small"
                                                sx={{
                                                    bgcolor: 'primary.light',
                                                    color: 'white',
                                                    padding: '4px',
                                                    '&:hover': {
                                                        bgcolor: 'primary.main',
                                                    },
                                                }}
                                            >
                                                <AddIcon fontSize="small" />
                                            </IconButton>
                                            }
                                        </StyledTableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {fields.length === 0 ? (
                                        <TableRow>
                                            <StyledTableCell colSpan={10} align="center">
                                                No Records
                                            </StyledTableCell>
                                        </TableRow>
                                    ) : (
                                        fields.map((row, index) => (
                                            <StyledTableRow key={row.id}>
                                                <StyledTableCell>{index + 1}</StyledTableCell>
                                                <StyledTableCell>
                                                    <Controller
                                                        name={`interestResets.${index}.bankName`}
                                                        control={control}
                                                        rules={{ validate: validateBankName }}
                                                        render={({ field: bankField, fieldState: { error } }) => (
                                                            <Box>
                                                                <Controller
                                                                    name={`interestResets.${index}.cifNumber`}
                                                                    control={control}
                                                                    render={({ field: cifField }) => (
                                                                        <BankSelectCell
                                                                            field={cifField}
                                                                            bankOptions={bankOptions}
                                                                            loadingBanks={loadingBanks}
                                                                            onBankChange={(name) => {
                                                                                bankField.onChange(name);
                                                                            }}
                                                                        />
                                                                    )}
                                                                />
                                                                {error && (
                                                                    <Box sx={{ color: 'error.main', fontSize: '0.75rem', mt: 0.5 }}>
                                                                        {error.message}
                                                                    </Box>
                                                                )}
                                                            </Box>
                                                        )}
                                                    />
                                                </StyledTableCell>
                                                <StyledTableCell>
                                                    <Controller
                                                        name={`interestResets.${index}.amount`}
                                                        control={control}
                                                        rules={{ validate: validateAmount }}
                                                        render={({ field, fieldState: { error } }) => (
                                                            <Box>
                                                                <StyledInput
                                                                    {...field}
                                                                    type="number"
                                                                    step="0.00000001"
                                                                    inputProps={{
                                                                        min: 0,
                                                                        style: { textAlign: 'right' }
                                                                    }}
                                                                    error={!!error}
                                                                />
                                                                {error && (
                                                                    <Box sx={{ color: 'error.main', fontSize: '0.75rem', mt: 0.5 }}>
                                                                        {error.message}
                                                                    </Box>
                                                                )}
                                                            </Box>
                                                        )}
                                                    />
                                                </StyledTableCell>
                                                <StyledTableCell>
                                                    <Controller
                                                        name={`interestResets.${index}.periodInMonths`}
                                                        control={control}
                                                        rules={{ validate: validatePeriod }}
                                                        render={({ field, fieldState: { error } }) => (
                                                            <Box>
                                                                <StyledInput
                                                                    {...field}
                                                                    type="number"
                                                                    inputProps={{
                                                                        min: 1,
                                                                        step: 1,
                                                                        style: { textAlign: 'right' }
                                                                    }}
                                                                    error={!!error}
                                                                />
                                                                {error && (
                                                                    <Box sx={{ color: 'error.main', fontSize: '0.75rem', mt: 0.5 }}>
                                                                        {error.message}
                                                                    </Box>
                                                                )}
                                                            </Box>
                                                        )}
                                                    />
                                                </StyledTableCell>
                                                <StyledTableCell>
                                                    <Controller
                                                        name={`interestResets.${index}.resetDate`}
                                                        control={control}
                                                        rules={{ validate: validateDate }}
                                                        render={({ field, fieldState: { error } }) => (
                                                            <Box>
                                                                <StyledInput
                                                                    {...field}
                                                                    type="date"
                                                                    inputProps={{
                                                                        min: "1900-01-01",
                                                                        max: "2100-12-31"
                                                                    }}
                                                                    error={!!error}
                                                                />
                                                                {error && (
                                                                    <Box sx={{ color: 'error.main', fontSize: '0.75rem', mt: 0.5 }}>
                                                                        {error.message}
                                                                    </Box>
                                                                )}
                                                            </Box>
                                                        )}
                                                    />
                                                </StyledTableCell>
                                                <StyledTableCell>
                                                    <Controller
                                                        name={`interestResets.${index}.rateOfInterest`}
                                                        control={control}
                                                        rules={{ validate: (value) => validatePercentage(value, "ROI") }}
                                                        render={({ field, fieldState: { error } }) => (
                                                            <Box>
                                                                <StyledInput
                                                                    {...field}
                                                                    type="number"
                                                                    step="0.01"
                                                                    inputProps={{
                                                                        min: 0,
                                                                        max: 100,
                                                                        style: { textAlign: 'right' }
                                                                    }}
                                                                    error={!!error}
                                                                />
                                                                {error && (
                                                                    <Box sx={{ color: 'error.main', fontSize: '0.75rem', mt: 0.5 }}>
                                                                        {error.message}
                                                                    </Box>
                                                                )}
                                                            </Box>
                                                        )}
                                                    />
                                                </StyledTableCell>
                                                <StyledTableCell>
                                                    <Controller
                                                        name={`interestResets.${index}.costOfFunds`}
                                                        control={control}
                                                        rules={{ validate: (value) => validatePercentage(value, "Cost of Funds") }}
                                                        render={({ field, fieldState: { error } }) => (
                                                            <Box>
                                                                <StyledInput
                                                                    {...field}
                                                                    type="number"
                                                                    step="0.01"
                                                                    inputProps={{
                                                                        min: 0,
                                                                        max: 100,
                                                                        style: { textAlign: 'right' }
                                                                    }}
                                                                    error={!!error}
                                                                />
                                                                {error && (
                                                                    <Box sx={{ color: 'error.main', fontSize: '0.75rem', mt: 0.5 }}>
                                                                        {error.message}
                                                                    </Box>
                                                                )}
                                                            </Box>
                                                        )}
                                                    />
                                                </StyledTableCell>
                                                <StyledTableCell>
                                                    <Controller
                                                        name={`interestResets.${index}.resetDueDate`}
                                                        control={control}
                                                        rules={{ validate: validateDate }}
                                                        render={({ field, fieldState: { error } }) => (
                                                            <Box>
                                                                <StyledInput
                                                                    {...field}
                                                                    type="date"
                                                                    inputProps={{
                                                                        min: "1900-01-01",
                                                                        max: "2100-12-31"
                                                                    }}
                                                                    error={!!error}
                                                                />
                                                                {error && (
                                                                    <Box sx={{ color: 'error.main', fontSize: '0.75rem', mt: 0.5 }}>
                                                                        {error.message}
                                                                    </Box>
                                                                )}
                                                            </Box>
                                                        )}
                                                    />
                                                </StyledTableCell>
                                                <StyledTableCell align="center">
                                                    {isEditable && <IconButton
                                                        color="error"
                                                        size="small"
                                                        onClick={() => handleDelete(index, row.dbId)}
                                                        disabled={deletingIndex === index}
                                                    >
                                                        {deletingIndex === index ? (
                                                            <CircularProgress size={20} />
                                                        ) : (
                                                            <DeleteIcon fontSize="small" />
                                                        )}
                                                    </IconButton>
                                                    }
                                                </StyledTableCell>
                                            </StyledTableRow>
                                        ))
                                    )}
                                </TableBody>
                            </Table>
                        </StyledTableContainer>
                        {isEditable && <Box mt={2} display="flex" gap={2}>
                            <Button
                                type="button"
                                variant="contained"
                                onClick={handleSubmit(onSubmit)}
                                disabled={saving}
                                startIcon={saving ? <CircularProgress size={20} color="inherit" /> : null}
                            >
                                {saving ? "Saving..." : "Save Interest Resets"}
                            </Button>
                        </Box>
                        }
                    </Box>
                )}
            </Box>
        </Collapse>
    );
};

export default InterestRateResetSection;