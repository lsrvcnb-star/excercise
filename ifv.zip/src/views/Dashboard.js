import Pagination from "@mui/material/Pagination";
import MessageModal from "components/MessageModal";
import { useErrorHandler } from "hooks/useErrorHandler";
import useMessageModal from "hooks/useMessageModal";
import usePagination from "hooks/UsePagination";
import { useCallback, useEffect, useState } from "react";
import { Card, Col, Container, Modal, Row, Table } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import Select from "react-select";
import IfvAppraisalService from "services/IfvAppraisalService";
import MasterService from "services/MasterService";
import UserService from "services/UserService";
import CommonUtil from "services/utils/CommonUtil";
const PER_PAGE = 8;

const Dashboard = () => {
  const navigate = useNavigate();
  const [loadingCounts, setLoadingCounts] = useState(true);
  const [loadingBcmCif, setLoadingBcmCif] = useState(true);
  const [loadingSanctioned, setLoadingSanctioned] = useState(true);
  const [loadingLoi, setLoadingLoi] = useState(true);
  const [modalState, setModalState] = useState({
    show: false,
    showExistingAlcoProp: false,
    showSanctionedProp: false,
  });
  const [selectedOption, setSelectedOption] = useState(null);
  const [isMaker, setMaker] = useState(false);
  const [counts, setCounts] = useState({
    existingProposal: 0,
    lockedProposal: 0,
    sanctioned: 0,
    alco: 0,
    countOfLoIs: 0,
  });
  const [options, setOptions] = useState([]);
  const [tempOptions, setTempOptions] = useState([]);
  const [alcoData, setAlcoData] = useState([]);
  const [filteredAlcoData, setFilteredAlcoData] = useState([]);
  const alcoPageData = usePagination(alcoData, PER_PAGE);
  const {
    showMessage,
    hideMessage,
    isOpen,
    messageConfig,
    totalMessages,
    currentIndex,
    nextMessage,
    prevMessage,
    hasNext,
    hasPrev,
  } = useMessageModal();
  const { handleApiError } = useErrorHandler(showMessage);

  useEffect(() => {
    const user = IfvAppraisalService.getCurrentUser();

    setMaker(UserService.isMaker(user));

    // Existing & Approved Proposal Counts
    setLoadingCounts(true);
    IfvAppraisalService.getStatusCountOfProposals(user.ofrType, user.ofrCode)
      .then((response) => {
        setCounts((prev) => ({
          ...prev,
          existingProposal: response.data.NON || 0,
          lockedProposal: response.data.APP || 0,
        }));
      })
      .catch((error) => {
        handleApiError(error, "loading proposal counts");
      })
      .finally(() => {
        setLoadingCounts(false);
      });

    // BCM CIF Master
    setLoadingBcmCif(true);
    MasterService.getAllBcmCif()
      .then((response) => {
        const mappedOptions = response.data.map((item) => ({
          value: item.customerCode,
          label: `${item.customerLongName} >> (${item.customerCode})`,
        }));

        setOptions(mappedOptions);
        setTempOptions(mappedOptions);
      })
      .catch((error) => {
        handleApiError(error, "loading BCM CIF master");
      })
      .finally(() => {
        setLoadingBcmCif(false);
      });

    // Sanctioned Proposal Count
    setLoadingSanctioned(true);
    MasterService.getSanctionedProposalsCount()
      .then((response) => {
        setCounts((prev) => ({
          ...prev,
          sanctioned: response.data || 0,
        }));
      })
      .catch((error) => {
        handleApiError(error, "loading sanctioned proposals");
      })
      .finally(() => {
        setLoadingSanctioned(false);
      });

    // LOI Count
    setLoadingLoi(true);
    IfvAppraisalService.getCountOfLoIs()
      .then((response) => {
        setCounts((prev) => ({
          ...prev,
          countOfLoIs: response.data || 0,
        }));
      })
      .catch((error) => {
        handleApiError(error, "loading LOI count");
      })
      .finally(() => {
        setLoadingLoi(false);
      });
  }, []);

  const handleModalToggle = useCallback((modalKey, value) => {
    setModalState((prev) => ({ ...prev, [modalKey]: value }));
  }, []);
  const handleNext = useCallback(() => {
    if (!selectedOption) {
      showMessage("Please select an application", "warning");
    } else {
      navigate("/ifv/basic", {
        state: {
          data: {
            ...selectedOption,
            label: selectedOption.label.split(" >> ")[0],
          },
        },
      });
    }
  }, [selectedOption, navigate, handleModalToggle]);
  const handleSearch = useCallback(
    (inputValue) => {
      const filteredOptions = tempOptions.filter((option) =>
        option.label.toLowerCase().includes(inputValue.toLowerCase())
      );
      setOptions(filteredOptions);
    },
    [options]
  );
  const handleNewOrExistingAlco = useCallback(
    (alCode) => {
      navigate("/ifv/alco", {
        state: { alCode },
      });
    },
    [navigate]
  );
  const goToProposalsSummary = useCallback(
    (mode, section) => {
      navigate("/ifv/proposalsSummary", {
        state: { mode, section },
      });
    },
    [navigate]
  );
  const goToSanctionedSummary = useCallback(() => {
    navigate("/ifv/sanctionedSummary");
  }, [navigate]);
  const goToProposalCreatedFromBankAppSummary = useCallback(() => {
    navigate("/ifv/proposalCreatedFromBankApps");
  }, [navigate]);
  const goToBankAcceptedAppSummary = useCallback(() => {
    navigate("/ifv/bankSubmittedApps");
  }, [navigate]);
  const goToBankSubmittedAssets = useCallback(() => {
    navigate("/ifv/bankSubmittedAssets");
  }, [navigate]);
  const goToComplianceManagement = useCallback(() => {
    navigate("/ifv/complianceManagement");
  }, [navigate]);
  const filterAlcoData = useCallback(
    (param) => {
      const filtered = filteredAlcoData.filter((item) =>
        item.alAppNumber.toLowerCase().includes(param.toLowerCase())
      );
      setAlcoData(filtered);
    },
    [filteredAlcoData]
  );
  const renderCard = useCallback(
    (title, count, iconClass, color, onClick, isLoading = false) => (
      <Col lg="3" sm="6">
        <Card className="card-stats">
          <Card.Body>
            <Row>
              <Col xs="5">
                <div className="icon-big text-center icon-warning">
                  <i className={`fa ${iconClass} text-${color}`}></i>
                </div>
              </Col>
              <Col xs="7">
                <div className="numbers">
                  <p className="card-category">{title}</p>
                  {count !== undefined && (
                    <Card.Title as="h4">
                      {isLoading ? (
                        <span
                          className="spinner-border spinner-border-sm"
                          role="status"
                        />
                      ) : (
                        count
                      )}
                    </Card.Title>
                  )}
                </div>
              </Col>
            </Row>
          </Card.Body>
          <Card.Footer>
            <div className="stats">
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onClick();
                }}
                className="hvr-icon-wobble-horizontal"
              >
                Know More <i className="fa fa-arrow-right hvr-icon"></i>
              </a>
            </div>
          </Card.Footer>
        </Card>
      </Col>
    ),
    []
  );
  return (
    <div>
      <Container fluid>
        <Row>
          <div className="col-md-12 p-0">
            <div className="ds_wrap">
              <h5>Proposals</h5>
              <div className="row m-2 mb-4">
                {isMaker &&
                  renderCard(
                    "Create Proposal Manually",
                    undefined,
                    "fa-file-circle-plus",
                    "warning",
                    () => handleModalToggle("show", true),
                    loadingBcmCif
                  )}
                {renderCard(
                  "Existing Proposals",
                  counts.existingProposal,
                  "fa-folder-open",
                  "info",
                  () => goToProposalsSummary("All", "Proposal"),
                  loadingCounts
                )}
                {renderCard(
                  "Approved Proposals",
                  counts.lockedProposal,
                  "fa-handshake",
                  "success",
                  () => goToProposalsSummary("AP", "Proposal"),
                  loadingCounts
                )}
                {renderCard(
                  "Sanctioned Proposals",
                  counts.sanctioned,
                  "fa-gavel",
                  "primary",
                  () => goToSanctionedSummary(),
                  loadingSanctioned
                )}
              </div>
            </div>
          </div>
        </Row>
        <Row>
          <div className="col-md-12 p-0">
            <div className="ds_wrap">
              <h5>Bank Submitted Applications</h5>
              <div className="row m-2 mb-4">
                {renderCard(
                  "Create Proposal from Bank Applications",
                  undefined,
                  "fa fa-file-circle-plus",
                  "warning",
                  () => goToBankAcceptedAppSummary()
                )}

                {renderCard(
                  "Proposals Created from Bank Applications",
                  undefined,
                  "fa fa-folder-open",
                  "success",
                  () => goToProposalCreatedFromBankAppSummary()
                )}

                {renderCard(
                  "Compliance Management",
                  undefined,
                  "fa fa-clipboard-check",
                  "primary",
                  () => goToComplianceManagement()
                )}
              </div>
            </div>
          </div>
        </Row>
        <Row>
          <div className="col-md-12 p-0">
            <div className="ds_wrap">
              <h5>LoI</h5>
              <div className="row m-2 mb-4">
                {renderCard(
                  "Generate LoI from Proposals",
                  undefined,
                  "fa fa-file-signature",
                  "warning",
                  () => goToProposalsSummary("AP", "LoI"),
                  loadingLoi
                )}
                {renderCard(
                  "Existing LoI",
                  counts.countOfLoIs,
                  "fa fa-calendar-days",
                  "info",
                  () => navigate("/ifv/loiSummary")
                )}
              </div>
            </div>
          </div>
        </Row>

        {/* {loading && <Loading />} */}
        {/* Modals */}
        <Modal
          show={modalState.show}
          onHide={() => handleModalToggle("show", false)}
        >
          <Modal.Header closeButton>
            <Modal.Title>Select Bank Name</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Select
              value={selectedOption}
              onChange={setSelectedOption}
              options={options}
              onInputChange={handleSearch}
              isSearchable
            />
          </Modal.Body>
          <Modal.Footer>
            <button
              type="button"
              className="btn btnRegister themebutton"
              onClick={handleNext}
            >
              Next
            </button>
          </Modal.Footer>
        </Modal>
        <Modal
          size="xl"
          show={modalState.showExistingAlcoProp}
          onHide={() => handleModalToggle("showExistingAlcoProp", false)}
        >
          <Modal.Header closeButton className="popHeader">
            <Modal.Title>Existing ALCOs</Modal.Title>
            <input
              type="search"
              className="form-control"
              placeholder="Search"
              onChange={(e) => filterAlcoData(e.target.value)}
            />
          </Modal.Header>
          <Modal.Body className="exi_prop">
            <Table>
              <thead>
                <tr>
                  <th style={{ color: "white" }}>Alco App Number</th>
                  <th style={{ color: "white" }}>Created Date</th>
                  <th style={{ color: "white" }}>Maker Name</th>
                  <th style={{ color: "white" }}>Status</th>
                </tr>
              </thead>
              <tbody>
                {alcoPageData.currentData().map((d, index) => (
                  <tr
                    key={index}
                    onClick={() => handleNewOrExistingAlco(d.alCode)}
                  >
                    <td>{d.alAppNumber}</td>
                    <td>{CommonUtil.formatDate(d.dateOfAction)}</td>
                    <td>{d.makerName}</td>
                    <td>{d.status}</td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </Modal.Body>
          <Modal.Footer>
            <Pagination
              count={alcoPageData.maxPage}
              size="large"
              page={alcoPageData.currentPage}
              variant="outlined"
              shape="rounded"
              color="primary"
              onChange={(e, p) => alcoPageData.jump(p)}
            />
          </Modal.Footer>
        </Modal>
        <MessageModal
          open={isOpen}
          onClose={hideMessage}
          message={messageConfig.message}
          type={messageConfig.type}
          totalMessages={totalMessages}
          currentIndex={currentIndex}
          onNext={nextMessage}
          onPrev={prevMessage}
          hasNext={hasNext}
          hasPrev={hasPrev}
        />
      </Container>
    </div>
  );
};
export default Dashboard;
