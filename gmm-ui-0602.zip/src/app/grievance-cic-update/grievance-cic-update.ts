import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatPaginatorModule } from '@angular/material/paginator';

import { finalize, forkJoin } from 'rxjs';

import { GrievanceService } from '../services/grievance.service';
import { AppAlertService } from '../shared/app-alert/app-alert.service';
import { AppLoaderService } from '../shared/app-loader/app-loader.service';
import { MatIconModule } from '@angular/material/icon';
import { dateOnly } from '../shared/utils';

@Component({
 selector: 'app-grievance-cic-update',
 standalone: true,
 imports: [
   CommonModule,
   FormsModule,
   MatTableModule,
   MatInputModule,
   MatSelectModule,
   MatCheckboxModule,
   MatPaginatorModule,
   MatIconModule
 ],
 templateUrl: './grievance-cic-update.html',
 styleUrls: ['./grievance-cic-update.css']
})
export class GrievanceCicUpdateComponent implements OnInit {
 searchText: string = '';
 filteredRows: any[] = [];

sortColumn: string = '';
sortDirection: 'asc' | 'desc' = 'asc';

 constructor(
   private grievanceService: GrievanceService,
   private alert: AppAlertService,
   private loader: AppLoaderService
 ) { }

  displayedColumns: string[] = [
    'grievanceNo',
    'receiptDate',
    'customerType',
    'customerName',
    'source',
    'confirmationSent',
    'confirmationDate',
    'edit'
  ];

 /* ✅ DATA */
 rows: any[] = [];
 pagedRows: any[] = [];

 /* ✅ PAGINATION */
 pageSize = 5;
 pageIndex = 0;

 /* ✅ MAPS */
 grievanceSourceMap: Record<string, string> = {};
 categoryMap: Record<string, string> = {};

 ngOnInit(): void {
   this.rows = [];
   this.pagedRows = [];
 }

 /* ================= NORMALIZE ================= */

 normalize(val: any): string {
   if (val === null || val === undefined) return '';
   return String(val).trim().replace(/^0+/, '');
 }

 /* ================= PAGINATION ================= */

updatePagedData(): void {
 const start = this.pageIndex * this.pageSize;
 const end = start + this.pageSize;
 this.pagedRows = this.filteredRows.slice(start, end);
}

 onPageChange(event: any): void {
   this.pageSize = event.pageSize;
   this.pageIndex = event.pageIndex;
   this.updatePagedData();
 }

 /* ================= EDIT ================= */

 toggleEdit(row: any): void {
   if (!row.edit) {
     row._original = { ...row };
     row.edit = true;
   } else {
     Object.assign(row, row._original);
     delete row._original;
     row.edit = false;
   }
 }

 /* ================= FETCH ================= */

 fetch(): void {

   this.loader.show();

   const request: any = {
     gdStatus: '',
     gdBranchVerticalCd: '',
     gdGrevCategory: '15',
     fromCreatedDt: '',
     toCreatedDt: ''
   };

   forkJoin({
     sources: this.grievanceService.getGrievanceSources(),
     categories: this.grievanceService.getGrievanceCategories(),
     data: this.grievanceService.searchGrievances(request)
   })
     .pipe(finalize(() => this.loader.hide()))
     .subscribe({

       next: (res: any) => {

         const sources = res.sources || [];
         const categories = res.categories || [];

         /* ✅ BUILD MAP */
         this.grievanceSourceMap = {};
         this.categoryMap = {};

         sources.forEach((s: any) => {
           const code = this.normalize(s.gsCd || s.GS_CD || s.code);
           const desc = s.gsDesc || s.GS_DESC || s.name;
           if (code && desc) {
             this.grievanceSourceMap[code] = desc;
           }
         });

         categories.forEach((c: any) => {
           const code = this.normalize(c.gcCd || c.GC_CD || c.code);
           const desc = c.gcDesc || c.GC_DESC || c.name;
           if (code && desc) {
             this.categoryMap[code] = desc;
           }
         });

         /* ✅ SAFE ARRAY */
         let list: any[] = res?.data?.data?.searchGrievances ?? res?.data?.searchGrievances ?? [];

         if (!list.length) {
           this.rows = [];
           this.updatePagedData();
           this.alert.warning('No CIC records found');
           return;
         }

         /* ✅ FINAL MAPPING WITH NA FALLBACK */
         this.rows = list.map((item: any) => {

           const sourceKey = this.normalize(item.gdGrevSource);
           const categoryKey = this.normalize(item.gdGrevCategory);

           const mappedSource =
             this.grievanceSourceMap[sourceKey] ||
             'NA';

           const mappedCategory =
             this.categoryMap[categoryKey] ||
             'NA';

           return {
             grievanceNo: item.gdSrNo || '',
             receiptDate: this.formatDate(item.gdSrgrDt),
             customerType: this.mapCustomerType(item.gdCustEmpFlag),
             customerName: item.gdComplaintName || '',

             source: mappedSource,
             category: mappedCategory,

              confirmationSent: item.gdCompConfSend === 'Y' ? 'Yes' : 'No',
             confirmationDate: this.formatDate(item.gdConfSendDt),

             edit: false
           };
         });

         this.filteredRows = [...this.rows];
         this.updatePagedData();


         this.pageIndex = 0;
         this.updatePagedData();
       },

       error: () => {
         this.alert.error('Failed to fetch');
       }
     });
 }

 applyFilter(): void {
 const value = this.searchText.toLowerCase().trim();

 if (!value) {
   this.filteredRows = [...this.rows];
 } else {
   this.filteredRows = this.rows.filter(r =>
     String(r.grievanceNo).toLowerCase().includes(value) ||
     String(r.receiptDate).toLowerCase().includes(value) ||
     String(r.customerType).toLowerCase().includes(value) ||
     String(r.customerName).toLowerCase().includes(value) ||
     String(r.source).toLowerCase().includes(value) ||
     String(r.confirmationSent).toLowerCase().includes(value) ||
     String(r.confirmationDate).toLowerCase().includes(value)
   );
 }

 this.pageIndex = 0;
 this.updatePagedData();
}

 /* ================= SAVE ================= */

 save(): void {

   const editedRows = this.rows.filter(r => r.edit);

   if (!editedRows.length) {
     this.alert.warning('No rows selected');
     return;
   }

   this.loader.show();

   let done = 0;

   editedRows.forEach(row => {

     const payload = {
       gdSrNo: row.grievanceNo,
       gdSrgrDt: row.receiptDate ? row.receiptDate + 'T00:00:00' : null,
       gdCustEmpFlag: this.reverseCustomerType(row.customerType),
       gdComplaintName: row.customerName,
       gdGrevSource: row.source === 'NA' ? null : row.source,
       gdGrevCategory: '15',
        gdCompConfSend: row.confirmationSent === 'Yes' ? 'Y' : 'N',
       gdConfSendDt: row.confirmationDate
         ? row.confirmationDate + 'T00:00:00'
         : null
     };

     this.grievanceService.updateGrievance(payload, row.grievanceNo)
       .subscribe({
         next: () => {
           row.edit = false;
           delete row._original;
         },
         error: () => {
           this.alert.error(`Update failed: ${row.grievanceNo}`);
         },
         complete: () => {
           done++;
           if (done === editedRows.length) {
             this.loader.hide();
             this.alert.success('Updated successfully ✅');
           }
         }
       });
   });
 }

 /* ================= UTIL ================= */

 private formatDate(d: any): string {
   return dateOnly(d);
 }

 private mapCustomerType(v: string): string {
   if (v === 'C') return 'Customer';
   if (v === 'E') return 'Employee';
   return 'Others';
 }

 private reverseCustomerType(v: string): string {
   if (v === 'Customer') return 'C';
   if (v === 'Employee') return 'E';
   return 'O';
 }

 clear(): void {
   this.rows = [];
   this.pagedRows = [];
   this.searchText = '';
 }

 sort(column: string): void {

 if (this.sortColumn === column) {
   this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
 } else {
   this.sortColumn = column;
   this.sortDirection = 'asc';
 }

 this.filteredRows.sort((a, b) => {

   let valA = a[column];
   let valB = b[column];

   // ✅ Special handling for date
   if (column === 'receiptDate' || column === 'confirmationDate') {
     valA = new Date(valA).getTime();
     valB = new Date(valB).getTime();
   }

   // ✅ String compare
   if (valA < valB) return this.sortDirection === 'asc' ? -1 : 1;
   if (valA > valB) return this.sortDirection === 'asc' ? 1 : -1;

   return 0;
 });

 this.updatePagedData();
}


}

