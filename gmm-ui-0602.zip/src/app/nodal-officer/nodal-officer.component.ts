import { Component, OnInit, ChangeDetectorRef, ViewChild, TemplateRef, ViewContainerRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

/* Angular Material */
import { MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';

import { Overlay, OverlayModule, OverlayRef } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';

import { GrievanceService } from '../services/grievance.service';
import { AppAlertService } from '../shared/app-alert/app-alert.service';
import { AppLoaderService } from '../shared/app-loader/app-loader.service';

@Component({
 selector: 'app-nodal-officer',
 standalone: true,
 imports: [
   CommonModule,
   FormsModule,
   MatTableModule,
   MatInputModule,
   MatTabsModule,
   MatIconModule,
   MatTooltipModule,
   OverlayModule
 ],
 templateUrl: './nodal-officer.component.html',
 styleUrls: ['./nodal-officer.component.css']
})
export class NodalOfficerComponent implements OnInit {

 constructor(
   private grievanceService: GrievanceService,
   private cdr: ChangeDetectorRef,
   private alert: AppAlertService,
   private loader: AppLoaderService
 ) {}

 /* ================= TABLE ================= */

 displayedColumns = [
   'branchDisplay',
   'officerDisplay',
   'newOfficer',
   'altOfficer',
   'action'
 ];

 branchData: any[] = [];
 verticalData: any[] = [];
 roData: any[] = [];

 /* ================= SEARCH ================= */

 showPopup: boolean = false;
 selectedRow: any = null;
 fieldType: 'new' | 'alt' = 'new';

 searchText: string = '';
 employeeList: any[] = [];

 @ViewChild('searchPopupTemplate') searchPopupTemplate!: TemplateRef<any>;
 private overlayRef: OverlayRef | null = null;
 private overlay: Overlay = inject(Overlay);
 private viewContainerRef: ViewContainerRef = inject(ViewContainerRef);

 ngOnInit(): void {
   this.loadNodalOfficers();
 }

 /* ================= LOAD DATA ================= */

 loadNodalOfficers(): void {
   this.loader.show();
   this.grievanceService.getAllNodalOfficers()
     .subscribe({
       next: (res: any) => {
         this.loader.hide();
         const list = Array.isArray(res)
           ? res
           : (res?.data || []);

         this.branchData = [];
         this.verticalData = [];
         this.roData = [];

         list.forEach((item: any) => {

           let displayName = '';

           // ✅ ✅ FINAL CORRECT LOGIC
           if (item?.gnoBrVrtFlag === 'B' || item?.gnoBrVrtFlag === 'R') {
             // ✅ Branch + RO
             displayName =
               (item?.gnoBrCd || '') + ' - ' + (item?.gnoBrVrtName || '');
           }
           else if (item?.gnoBrVrtFlag === 'V') {
             // ✅ Vertical
             displayName =
               (item?.gnoVrtCd || '') + ' - ' + (item?.gnoBrVrtName || '');
           }

           const row = {
             branchDisplay: displayName,

             officerDisplay:
               (item?.gnoNodalEmpCd || '') +
               ' - ' +
               (item?.gnoNodalEmpName || ''),

             unitCode:
               item?.gnoBrVrtFlag === 'B' || item?.gnoBrVrtFlag === 'R'
                 ? item?.gnoBrCd
                 : item?.gnoVrtCd,

             newOfficer: '',

             altOfficer:
               (item?.gnoAltNodalEmpCd || '') +
               ' - ' +
               (item?.gnoAltNodalEmpName || ''),

             isModified: false
           };

           if (item?.gnoBrVrtFlag === 'B') {
             this.branchData.push(row);
           }
           else if (item?.gnoBrVrtFlag === 'V') {
             this.verticalData.push(row);
           }
           else if (item?.gnoBrVrtFlag === 'R') {
             this.roData.push(row);
           }

         });

         /* ✅ SORT BY NAME ONLY */
         const sortFn = (a: any, b: any) => {
           const nameA = a.branchDisplay.split('-')[1]?.trim().toLowerCase() || '';
           const nameB = b.branchDisplay.split('-')[1]?.trim().toLowerCase() || '';
           return nameA.localeCompare(nameB);
         };

         this.branchData.sort(sortFn);
         this.verticalData.sort(sortFn);
         this.roData.sort(sortFn);

         this.cdr.detectChanges();
       },
       error:(err) => {
         this.loader.hide()
       }
     });
 }

 /* ================= OPEN POPUP ================= */

 openPopup(row: any, type: 'new' | 'alt'): void {

   this.selectedRow = row;
   this.fieldType = type;

   this.searchText = '';
   this.employeeList = [];

   this.closePopup();
   this.overlayRef = this.overlay.create({
     hasBackdrop: true,
     backdropClass: 'cdk-overlay-transparent-backdrop',
     panelClass: 'nodal-search-overlay-panel',
     scrollStrategy: this.overlay.scrollStrategies.block(),
     positionStrategy: this.overlay.position().global().centerHorizontally().centerVertically()
   });
   this.overlayRef.backdropClick().subscribe(() => this.closePopup());
   const portal = new TemplatePortal(this.searchPopupTemplate, this.viewContainerRef);
   this.overlayRef.attach(portal);
   this.showPopup = true;

   this.cdr.detectChanges();
 }

 closePopup(): void {
   this.showPopup = false;
   if (this.overlayRef) {
     this.overlayRef.detach();
     this.overlayRef.dispose();
     this.overlayRef = null;
   }
 }

 /* ================= SEARCH ================= */

 searchEmployee(): void {

   if (!this.searchText || this.searchText.trim().length < 2) {
     this.employeeList = [];
     return;
   }

   this.grievanceService.searchEmployeeByName(this.searchText)
     .subscribe({
       next: (res: any) => {

         this.employeeList = Array.isArray(res)
           ? [...res]
           : [...(res?.data || [])];

         this.cdr.detectChanges();
       }
     });
 }

 /* ================= SELECT ================= */

 selectEmployee(emp: any): void {

   const value = `${emp.employeeCode} - ${emp.name}`;

   if (this.fieldType === 'new') {
     this.selectedRow.newOfficer = value;
   } else {
     this.selectedRow.altOfficer = value;
   }

   this.selectedRow.isModified = true;

   this.closePopup();
   this.searchText = '';
   this.employeeList = [];

   this.cdr.detectChanges();
 }

 /* ================= VALIDATION ================= */

 private extractCode(display: string): string {
   return display?.split('-')[0]?.trim() || '';
 }

 isDuplicateOfficer(row: any): boolean {
   const newCode = this.extractCode(row.newOfficer);
   const altCode = this.extractCode(row.altOfficer);
   const currentCode = this.extractCode(row.officerDisplay);

   if (newCode && altCode && newCode === altCode) return true;
   if (altCode && currentCode && altCode === currentCode && !newCode) return true;
   if (newCode && currentCode && newCode === currentCode) return true;

   return false;
 }

 /* ================= SAVE ================= */

 saveRow(row: any): void {

   if (!row.newOfficer && !row.altOfficer) {
     this.alert.warning('Please fill all mandatory fields before saving');
     return;
   }

   if (this.isDuplicateOfficer(row)) {
     this.alert.warning('Current Nodal Officer and Alternate Nodal Officer cannot be the same person');
     return;
   }

   let flag = '';

   if (this.branchData.includes(row)) flag = 'B';
   else if (this.verticalData.includes(row)) flag = 'V';
   else if (this.roData.includes(row)) flag = 'R';

   const payload = [{
     gnoBrVrtFlag: flag,
     gnoBrCd: flag === 'B' || flag === 'R' ? row.unitCode : null,
     gnoVrtCd: flag === 'V' ? row.unitCode : null,
     gnoNodalEmpCd: row.newOfficer?.split('-')[0]?.trim() || null,
     gnoAltNodalEmpCd: row.altOfficer?.split('-')[0]?.trim() || null
   }];

   this.grievanceService.updateAllNodalOfficers(payload)
     .subscribe({
       next: () => {

         if (row.newOfficer) {
           row.officerDisplay = row.newOfficer;
           row.newOfficer = '';
         }

         row.isModified = false;

         this.alert.success('Row saved successfully');

         this.cdr.detectChanges();
       },
       error: () => {
         this.alert.error('Failed to save. Please try again');
       }
     });
 }

}

