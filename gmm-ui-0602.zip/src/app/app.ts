import { Component, HostListener } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AppLoaderComponent } from './shared/app-loader/app-loader';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, AppLoaderComponent],
  templateUrl: './app.html',
})
export class AppComponent {

  /**
   * Keep angle brackets out of all editable text controls, including fields
   * that do not use the grievance-entry form handlers (searches, dialogs,
   * reports, and other standalone screens).
   */
  @HostListener('document:keydown', ['$event'])
  blockAngleBrackets(event: KeyboardEvent): void {
    if (this.isEditableTextControl(event.target) && (event.key === '<' || event.key === '>')) {
      event.preventDefault();
    }
  }

  @HostListener('document:paste', ['$event'])
  blockAngleBracketPaste(event: ClipboardEvent): void {
    const pastedText = event.clipboardData?.getData('text') ?? '';
    if (this.isEditableTextControl(event.target) && /[<>]/.test(pastedText)) {
      event.preventDefault();
    }
  }

  @HostListener('document:drop', ['$event'])
  blockAngleBracketDrop(event: DragEvent): void {
    const droppedText = event.dataTransfer?.getData('text') ?? '';
    if (this.isEditableTextControl(event.target) && /[<>]/.test(droppedText)) {
      event.preventDefault();
    }
  }

  @HostListener('document:input', ['$event'])
  sanitizeEditableText(event: Event): void {
    const target = event.target as HTMLInputElement | HTMLTextAreaElement | null;
    if (!this.isEditableTextControl(target) || !/[<>]/.test(target.value)) {
      return;
    }

    target.value = target.value.replace(/[<>]/g, '');

    // Notify Angular forms/ngModel after sanitizing the DOM value.
    target.dispatchEvent(new Event('input', { bubbles: true }));
  }

  private isEditableTextControl(target: EventTarget | null): target is HTMLInputElement | HTMLTextAreaElement {
    if (!(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement)) {
      return false;
    }

    if (target.disabled || target.readOnly || target instanceof HTMLTextAreaElement) {
      return target instanceof HTMLTextAreaElement && !target.disabled && !target.readOnly;
    }

    // Passwords may legitimately contain special characters and must not be
    // altered by this generic UI validation.
    const type = target.type.toLowerCase();
    return !['password', 'file', 'date', 'datetime-local', 'month', 'week', 'time',
      'number', 'range', 'color', 'checkbox', 'radio', 'button', 'submit', 'reset', 'hidden']
      .includes(type);
  }
}
