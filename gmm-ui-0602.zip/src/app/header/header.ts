import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';

/* Angular Material */
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import { AuthService } from '../services/auth.service';

export const ROLES = {
  BM: 'Branch Maker',
  BC: 'Branch Checker',
  RM: 'RO Maker',
  RC: 'RO Checker',
  HM: 'HO Maker',
  HC: 'HO Checker',
  AM: 'Admin Maker',
  AC: 'Admin Checker'
};


@Component({
  selector: 'app-header',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule
  ],
  templateUrl: './header.html',
  styleUrls: ['./header.css']
})
export class HeaderComponent implements OnInit {

  /* ✅ Receives sidebar state from MainLayout */
  @Input() isExpanded = false;

  /* ✅ Emits event to toggle sidebar */
  @Output() toggleSidebar = new EventEmitter<void>();

  /* ✅ Logged‑in username */
  username: string | null = null;

  constructor(
    private router: Router,
    public authService: AuthService
  ) { }

  ngOnInit(): void {
    // ✅ Get username saved during login
    this.username =
      this.authService.getUsername?.() ||
      localStorage.getItem('username');
  }

  /* ✅ Toggle sidebar */
  onToggleClick(): void {
    this.toggleSidebar.emit();
  }

  /* ✅ Logout action */
  logout(): void {
    // ✅ Clear auth/session data
    this.authService.clearSession?.();
    localStorage.removeItem('username');
    sessionStorage.clear();

    this.router.navigate(['/login']);
  }

  

get roleLabel(): string {
  const role = this.authService.getRole()

  if (!role) return '';

 return role ? ROLES[role as keyof typeof ROLES] : '';
 
}

}