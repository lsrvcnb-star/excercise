import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, RouterOutlet } from '@angular/router';

/* Header */
import { HeaderComponent } from '../../header/header';

/* Auth */
import { AuthService } from '../../services/auth.service';

/* Angular Material */
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    RouterOutlet,
    HeaderComponent,
    MatSidenavModule,
    MatListModule,
    MatIconModule,
    MatButtonModule
  ],
  templateUrl: './main-layout.html',
  styleUrls: ['./main-layout.css']
})
export class MainLayoutComponent {

  /** Sidebar collapsed by default */
  isExpanded = false;

  constructor(public authService: AuthService) {}

  get role(): string | null {
    return this.authService.getRole();
  }

  toggleSidebar(): void {
    this.isExpanded = !this.isExpanded;
  }
}
