import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewToOpenDialog } from './review-to-open-dialog';

describe('ReviewToOpenDialog', () => {
  let component: ReviewToOpenDialog;
  let fixture: ComponentFixture<ReviewToOpenDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReviewToOpenDialog],
    }).compileComponents();

    fixture = TestBed.createComponent(ReviewToOpenDialog);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
