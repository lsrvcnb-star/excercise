import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { GrievanceService } from '../services/grievance.service';
import { AuthService } from '../services/auth.service';
import { AppAlertService } from '../shared/app-alert/app-alert.service';

@Component({
 selector: 'app-grievance-revert-dialog',
 standalone: true,
 imports: [
   CommonModule,
   FormsModule,
   MatDialogModule,
   MatButtonModule,
   MatIconModule
 ],
 templateUrl: './grievance-revert-dialog.html',
 styleUrls: ['./grievance-revert-dialog.css']
})
export class GrievanceRevertDialogComponent {

 grievance: any;
 complainantFiles: any[] = [];
 resolutionFiles: any[] = [];
 role: string = '';
 isReverting = false;

 typeLabels: Record<string, string> = {
   R: 'Request',
   C: 'Complaint',
   A: 'Appeal'
 };

 constructor(
   public dialogRef: MatDialogRef<GrievanceRevertDialogComponent>,
   @Inject(MAT_DIALOG_DATA) public data: any,
   private grievanceService: GrievanceService,
   private authService: AuthService,
   private alert: AppAlertService
 ) {
   this.grievance = data?.grievance ?? {};
   this.complainantFiles = data?.complainantFiles ?? [];
   this.resolutionFiles = data?.resolutionFiles ?? [];
   this.role = data?.role ?? '';
 }

 get requestTypeLabel(): string {
   const type = this.grievance?._raw?.gdRequestType;
   return this.typeLabels[type] || type || 'N/A';
 }

 close(): void {
   this.dialogRef.close();
 }

 revert(): void {
   this.isReverting = true;

   const grievanceNo = this.grievance.grievanceNo;
   const now = new Date();
   const approvedDt = now.toISOString();
   const approvedBy = this.authService.getUsername() || '';

   const payload = {
    /*  gdApprovedDt: approvedDt,
     gdApprovedBy: approvedBy, */
     gdStatus: '01'
   };

   this.grievanceService.updateGrievance(payload, grievanceNo).subscribe({
     next: () => {
       this.isReverting = false;
       this.alert.success('Grievance reverted successfully');
       this.dialogRef.close('reverted');
     },
     error: () => {
       this.isReverting = false;
       this.alert.error('Failed to revert grievance');
     }
   });
 }

 downloadFile(file: any): void {
   if (!file?.gfSno) return;
   this.grievanceService.downloadGrievancefile(file.gfSno).subscribe(res => {
     const blob = res.body;
     if (!blob) return;
     const url = window.URL.createObjectURL(blob);
     const a = document.createElement('a');
     a.href = url;
     a.download = `FILE_${file.gfSrNo}_${file.gfSno}`;
     document.body.appendChild(a);
     a.click();
     document.body.removeChild(a);
     window.URL.revokeObjectURL(url);
   });
 }

 getAttachmentFileName(file: any): string {
   return `FILE_${file.gfSrNo}_${file.gfSno}`;
 }
}



