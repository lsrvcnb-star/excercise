import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';

import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { GrievanceService } from '../services/grievance.service';
import { AuthService } from '../services/auth.service';
import { AppLoaderService } from '../shared/app-loader/app-loader.service';
import { AppAlertService } from '../shared/app-alert/app-alert.service';
import { GrievanceRevertDialogComponent } from './grievance-revert-dialog';
import { displayDate } from '../shared/utils';

@Component({
 selector: 'app-grievance-revert',
 standalone: true,
 imports: [
   CommonModule,
   FormsModule,
   MatTableModule,
   MatInputModule,
   MatButtonModule,
   MatFormFieldModule,
   MatIconModule,
   MatPaginatorModule,
   MatDialogModule,

 ],
 templateUrl: './grievance-revert.html',
 styleUrls: ['./grievance-revert.css']
})
export class GrievanceRevertComponent implements OnInit, AfterViewInit {

 role: string = '';
 searchText: string = '';

 displayedColumns: string[] = [
   'grievanceNo',
   'receiptDate',
   'customerType',
   'customerName',
   'grievanceSource',
   'category',
   'branchVertical',
   'status'
 ];

 dataSource = new MatTableDataSource<any>([]);
 @ViewChild(MatPaginator) paginator!: MatPaginator;

 selectedRow: any = null;

 grievanceSourceMap: Record<string, string> = {};
 categoryMap: Record<string, string> = {};
 branchMap: Record<string, string> = {};

 statusLabels: Record<string, string> = {
   '00': 'Created from Website API',
   '01': 'Entered by GC Maker',
   '02': 'Forwarded to GC Checker',
   '03': 'Assigned to Branch Maker',
   '04': 'Verification by Branch Checker',
   '05': 'Assigned to RO Maker',
   '06': 'Verification by RO Checker',
   '07': 'Assigned to Vertical Maker',
   '08': 'Verification by Vertical Checker',
   '09': 'Received by GC Maker',
   '10': 'Verification by GC Checker',
   '11': 'Closed by GC Checker'
 };

 constructor(
   private grievanceService: GrievanceService,
   private authService: AuthService,
   private dialog: MatDialog,
   private loader: AppLoaderService,
   private alert: AppAlertService
 ) { }

 ngOnInit(): void {
   this.role = this.authService.getRole()?.toUpperCase() || '';

   if (this.role !== 'AM' && this.role !== 'AC') {
     this.alert.warning('Access denied. Only AM and AC roles can access this page.');
     return;
   }

   this.loadSourceMaster();
   this.loadCategoryMaster();
   this.loadBranchMap();
 }

 ngAfterViewInit(): void {
   this.dataSource.paginator = this.paginator;
 }

 normalize(value: any): string {
   if (value === null || value === undefined) return '';
   return String(value).trim().replace(/^0+/, '');
 }

 formatDate(dateStr: any): string {
   return displayDate(dateStr);
 }

 loadSourceMaster(): void {
   this.grievanceService.getGrievanceSources().subscribe(res => {
     res.forEach((item: any) => {
       const code = this.normalize(item.GS_CD ?? item.gsCd ?? item.code);
       const desc = item.GS_DESC ?? item.gsDesc ?? item.name;
       if (code && desc) this.grievanceSourceMap[code] = desc;
     });
   });
 }

 loadCategoryMaster(): void {
   this.grievanceService.getGrievanceCategories().subscribe(res => {
     res.forEach((item: any) => {
       const code = this.normalize(item.GC_CD ?? item.gcCd ?? item.code);
       const desc = item.GC_DESC ?? item.gcDesc ?? item.name;
       if (code && desc) this.categoryMap[code] = desc;
     });
   });
 }

 loadBranchMap(): void {
   this.grievanceService.getBranchVerticalRo().subscribe(res => {
     res.forEach((item: any) => {
       this.branchMap[item.CODE] = item.NAME;
     });
     this.fetch();
   });
 }

 fetch(): void {
   this.selectedRow = null;
   this.loader.show();

   const request: any = {
     gdStatus: '',
     gdBranchVerticalCd: '',
     gdGrevCategory: '',
     fromCreatedDt: '',
     toCreatedDt: ''
   };

   this.grievanceService.searchGrievances(request).pipe(
     finalize(() => this.loader.hide())
   ).subscribe({
     next: (res: any) => {
       const list = res?.data?.searchGrievances ?? [];
       const filtered = list.filter((r: any) => {
         const srNo = Number(r.gdSrNo);
         return srNo > 848 && r.gdStatus !== '11';
       });
       this.dataSource.data = this.mapData(filtered);
       this.dataSource.paginator = this.paginator;
     },
     error: () => {
       this.alert.error('Failed to load grievances');
     }
   });
 }

 customerTypeLabel(value: string): string {
   const map: Record<string, string> = { C: 'Existing Customer', E: 'Employee', O: 'Others' };
   return map[value] || value || 'N/A';
 }

 mapData(data: any[]): any[] {
   return data.map((r: any) => {
     const sourceKey = this.normalize(r.gdGrevSource);
     const categoryKey = this.normalize(r.gdGrevCategory);
     return {
       grievanceNo: r.gdSrNo,
       receiptDate: this.formatDate(r.gdCreatedDt),
       customerType: this.customerTypeLabel(r.gdCustEmpFlag),
       customerName: r.gdComplaintName,
       grievanceSource:
         this.grievanceSourceMap[sourceKey] ||
         this.grievanceSourceMap[this.normalize(Number(r.gdGrevSource))] ||
         'N/A',
       category:
         this.categoryMap[categoryKey] ||
         this.categoryMap[this.normalize(Number(r.gdGrevCategory))] ||
         r.gdGrevCategory ||
         'N/A',
       branchVertical:
         this.branchMap[r.gdBranchVerticalCd] || 'N/A',
       status: this.statusLabels[r.gdStatus] || r.gdStatus,
       _raw: r
     };
   });
 }

 selectRow(row: any): void {
   this.selectedRow = row;

   this.grievanceService.getGrievancefiles(row.grievanceNo).subscribe({
     next: (res: any) => {
       const files = Array.isArray(res) ? res : [];
       const complainantFiles = files.filter((f: any) => f.gfFileType === 'G');
       const resolutionFiles = files.filter((f: any) => f.gfFileType === 'R');

       const dialogRef = this.dialog.open(GrievanceRevertDialogComponent, {
         width: '80vw',
         maxWidth: '90vw',
         data: {
           grievance: row,
           complainantFiles,
           resolutionFiles,
           role: this.role
         },
         autoFocus: false,
         panelClass: 'grievance-revert-dialog-panel'
       });

       dialogRef.afterClosed().subscribe(result => {
         if (result === 'reverted') {
           this.fetch();
         }
       });
     },
     error: () => {
       this.alert.error('Failed to load files');
     }
   });
 }

 applyFilter(event: Event): void {
   const value = (event.target as HTMLInputElement).value;
   this.dataSource.filter = value.trim().toLowerCase();
 }

 clear(): void {
   this.dataSource.data = [];
   this.selectedRow = null;
   this.searchText = '';          // clears input UI
         // resets table filter

 }
}





