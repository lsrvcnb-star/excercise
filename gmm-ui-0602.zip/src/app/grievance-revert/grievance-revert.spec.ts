import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GrievanceRevert } from './grievance-revert';

describe('GrievanceRevert', () => {
  let component: GrievanceRevert;
  let fixture: ComponentFixture<GrievanceRevert>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GrievanceRevert],
    }).compileComponents();

    fixture = TestBed.createComponent(GrievanceRevert);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
