import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { AppLoaderService } from './app-loader.service';

@Component({
  selector: 'app-loader',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './app-loader.html',
  styleUrls: ['./app-loader.css']
})
export class AppLoaderComponent {
  private readonly loader = inject(AppLoaderService);
  readonly loading$ = this.loader.loading$;
}
