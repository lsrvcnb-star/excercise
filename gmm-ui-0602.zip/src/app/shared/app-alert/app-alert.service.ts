import { Injectable, Injector, ApplicationRef, createComponent, Inject } from '@angular/core';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { InjectionToken } from '@angular/core';

import { AppAlertComponent } from './app-alert';

export type AppAlertType = 'success' | 'error' | 'warning' | 'info';

export interface AlertData {
 title: string;
 message: string;
 type: AppAlertType;
 confirmText: string;
 cancelText: string;
 showCancel: boolean;
}

export const ALERT_DATA = new InjectionToken<AlertData>('ALERT_DATA');

@Injectable({
 providedIn: 'root'
})
export class AppAlertService {
 private overlayRef: OverlayRef | null = null;
 private confirmResolver: ((confirmed: boolean) => void) | null = null;

 constructor(
   private overlay: Overlay,
   private injector: Injector
 ) {}

 show(
   message: string,
   title = 'Message',
   type: AppAlertType = 'info',
   confirmText = 'OK'
 ): void {
   this.confirmResolver = null;
   this.createAlert({ title, message, type, confirmText, cancelText: 'Cancel', showCancel: false });
 }

 confirm(
   message: string,
   title = 'Confirm Action',
   confirmText = 'OK',
   cancelText = 'Cancel',
   type: AppAlertType = 'info'
 ): Promise<boolean> {
   return new Promise(resolve => {
     this.confirmResolver = resolve;
     this.createAlert({ title, message, type, confirmText, cancelText, showCancel: true });
   });
 }

 success(message: string, title = 'Success'): void {
   this.show(message, title, 'success');
 }

 error(message: string, title = 'Error'): void {
   this.show(message, title, 'error');
 }

 warning(message: string, title = 'Attention'): void {
   this.show(message, title, 'warning');
 }

 info(message: string, title = 'Message'): void {
   this.show(message, title, 'info');
 }

 close(confirmed = false): void {
   if (this.confirmResolver) {
     this.confirmResolver(confirmed);
     this.confirmResolver = null;
   }
   this.disposeAlert();
 }

 private createAlert(data: AlertData): void {
   this.disposeAlert();

   this.overlayRef = this.overlay.create({
     hasBackdrop: true,
     backdropClass: 'alert-overlay-backdrop',
     panelClass: 'alert-overlay-panel',
     positionStrategy: this.overlay.position().global().centerHorizontally().centerVertically(),
     scrollStrategy: this.overlay.scrollStrategies.block()
   });

   const portalInjector = Injector.create({
     parent: this.injector,
     providers: [{ provide: ALERT_DATA, useValue: data }]
   });

   const portal = new ComponentPortal(AppAlertComponent, null, portalInjector);
   this.overlayRef.attach(portal);
 }

 private disposeAlert(): void {
   if (this.overlayRef) {
     this.overlayRef.dispose();
     this.overlayRef = null;
   }
 }
}

