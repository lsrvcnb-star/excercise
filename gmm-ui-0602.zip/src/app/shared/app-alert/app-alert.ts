import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

import { ALERT_DATA, AlertData, AppAlertService } from './app-alert.service';

@Component({
 selector: 'app-alert',
 standalone: true,
 imports: [CommonModule, MatIconModule],
 templateUrl: './app-alert.html',
 styleUrls: ['./app-alert.css']
})
export class AppAlertComponent {

 readonly iconByType: Record<AlertData['type'], string> = {
   success: 'check_circle',
   error: 'error',
   warning: 'warning',
   info: 'info'
 };

 constructor(
   @Inject(ALERT_DATA) public alert: AlertData,
   private alertService: AppAlertService
 ) {}

 close(): void {
   this.alertService.close();
 }

 confirm(): void {
   this.alertService.close(true);
 }
}
