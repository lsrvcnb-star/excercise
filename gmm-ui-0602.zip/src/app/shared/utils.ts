export function stripHtml(value: string): string {
 if (!value) return '';
 // Remove both HTML tags and standalone angle brackets. The latter is
 // important because a value such as "<" is not matched by the tag regex.
 return value.replace(/[<>]/g, '');
}

/** Preserve calendar dates without converting them through UTC. */
export function dateOnly(value: any): string {
 if (!value) return '';
 if (typeof value === 'string') {
   const match = value.trim().match(/^(\d{4}-\d{2}-\d{2})/);
   if (match) return match[1];
 }
 const date = value instanceof Date ? value : new Date(value);
 if (Number.isNaN(date.getTime())) return '';
 return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

export function displayDate(value: any): string {
 const day = dateOnly(value);
 if (!day) return '';
 const [year, month, date] = day.split('-');
 return `${date}/${month}/${year}`;
}

export function dateAtStartOfDay(value: any): string | null {
 const day = dateOnly(value);
 return day ? `${day}T00:00:00` : null;
}

export function dateAtEndOfDay(value: any): string | null {
 const day = dateOnly(value);
 return day ? `${day}T23:59:59` : null;
}
