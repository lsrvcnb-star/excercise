import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GrievanceViewQuery } from './grievance-view-query';

describe('GrievanceViewQuery', () => {
  let component: GrievanceViewQuery;
  let fixture: ComponentFixture<GrievanceViewQuery>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GrievanceViewQuery],
    }).compileComponents();

    fixture = TestBed.createComponent(GrievanceViewQuery);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
