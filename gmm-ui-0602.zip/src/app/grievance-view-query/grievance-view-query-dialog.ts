import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { GrievanceService } from '../services/grievance.service';

@Component({
 selector: 'app-grievance-view-query-dialog',
 standalone: true,
 imports: [
   CommonModule,
   FormsModule,
   MatDialogModule,
   MatButtonModule,
   MatIconModule
 ],
 templateUrl: './grievance-view-query-dialog.html',
 styleUrls: ['./grievance-view-query-dialog.css']
})
export class GrievanceViewQueryDialogComponent {

  grievance: any;
  complainantFiles: any[] = [];
  resolutionFiles: any[] = [];
  inchargeRemarks: string = '';
  inchargeRemarksLabel: string = '';

  constructor(
    public dialogRef: MatDialogRef<GrievanceViewQueryDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private grievanceService: GrievanceService
  ) {
    this.grievance = data?.grievance ?? {};
    this.complainantFiles = data?.complainantFiles ?? [];
    this.resolutionFiles = data?.resolutionFiles ?? [];

    const bv = this.grievance?.gdBranchVertical || '';
    if (bv === 'B') {
      this.inchargeRemarks = this.grievance?.gdResolutionBoinchRemarks || '';
      this.inchargeRemarksLabel = 'Branch Checker Remarks';
    } else if (bv === 'R') {
      this.inchargeRemarks = this.grievance?.gdResolutionRoinchRemarks || '';
      this.inchargeRemarksLabel = 'RO Checker Remarks';
    } else if (bv === 'V') {
      this.inchargeRemarks = this.grievance?.gdResolutionHoinchRemarks || '';
      this.inchargeRemarksLabel = 'Vertical Checker Remarks';
    }
  }

  close(): void {
    this.dialogRef.close();
  }

 downloadFile(file: any): void {
   if (!file?.gfSno) return;
   this.grievanceService.downloadGrievancefile(file.gfSno)
     .subscribe(res => {
       const blob = res.body;
       if (!blob) return;
       const url = window.URL.createObjectURL(blob);
       const a = document.createElement('a');
       a.href = url;
       a.download = `FILE_${file.gfSrNo}_${file.gfSno}`;
       document.body.appendChild(a);
       a.click();
       document.body.removeChild(a);
       window.URL.revokeObjectURL(url);
     });
 }

 getAttachmentFileName(file: any): string {
   return `FILE_${file.gfSrNo}_${file.gfSno}`;
 }
}

