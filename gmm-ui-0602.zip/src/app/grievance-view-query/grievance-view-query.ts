import {
 Component,
 ViewChild,
 AfterViewInit,
 OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { GrievanceService } from '../services/grievance.service';
import { GrievanceViewQueryDialogComponent } from './grievance-view-query-dialog';
import { dateAtEndOfDay, dateAtStartOfDay, displayDate } from '../shared/utils';

@Component({
 selector: 'app-grievance-view-query',
 standalone: true,
 imports: [
   CommonModule,
   FormsModule,
   MatTableModule,
   MatInputModule,
   MatButtonModule,
   MatSnackBarModule,
   MatFormFieldModule,
   MatIconModule,
   MatPaginatorModule,
   MatDialogModule,
 ],
 templateUrl: './grievance-view-query.html',
 styleUrls: ['./grievance-view-query.css']
})
export class GrievanceViewQueryComponent implements OnInit, AfterViewInit {

 constructor(
   private grievanceService: GrievanceService,
   private snackBar: MatSnackBar,
   private dialog: MatDialog
 ) {}

 // ✅ Loader
 isLoading = false;

 // ✅ Row highlight
 selectedRow: any = null;

 displayedColumns: string[] = [
   'grievanceNo',
   'receiptDate',
   'customerType',
   'customerName',
   'grievanceSource',
   'category',
   'branchVertical',
   'nodalOfficer'
 ];

 dataSource = new MatTableDataSource<any>([]);
 @ViewChild(MatPaginator) paginator!: MatPaginator;

 selectedGrievance: any = null;

 filter = {
   grievanceNo: '',
   status: '',
   fromDate: '',
   toDate: ''
 };

 statusOptions = [
 { code: '00', label: 'All - 00' },
 { code: '00', label: 'Created from Website API - 00' },
 { code: '01', label: 'Entered by GC Maker - 01' },
 { code: '02', label: 'Forwarded to GC Checker - 02' },
 { code: '03', label: 'Assigned to Branch Maker - 03' },
 { code: '04', label: 'Verification by Branch Checker - 04' },
 { code: '05', label: 'Assigned to RO Maker - 05' },
 { code: '06', label: 'Verification by RO Checker - 06' },
 { code: '07', label: 'Assigned to Vertical Maker - 07' },
 { code: '08', label: 'Verification by Vertical Checker - 08' },
 { code: '09', label: 'Received by GC Maker - 09' },
 { code: '10', label: 'Verification by GC Checker - 10' },
 { code: '11', label: 'Closed by GC Checker - 11' }
];

  grievanceSourceMap: Record<string, string> = {};
  categoryMap: Record<string, string> = {};
  branchMap: Record<string, string> = {};
  nodalOfficerMap: Record<string, string> = {};

  ngOnInit(): void {
    this.loadSourceMaster();
    this.loadCategoryMaster();
    this.loadBranchMap();
    this.loadNodalOfficers();
  }

 ngAfterViewInit(): void {
   this.dataSource.paginator = this.paginator;
 }

 normalize(value: any): string {
   if (value === null || value === undefined) return '';
   return String(value).trim().replace(/^0+/, '');
 }

  formatDate(dateStr: any): string {
    return displayDate(dateStr);
  }

  formatDateForApi(dateStr: any): string {
    return dateAtStartOfDay(dateStr) ?? '';
  }

 loadSourceMaster(): void {
   this.grievanceService.getGrievanceSources().subscribe(res => {
     res.forEach((item: any) => {
       const code = this.normalize(item.GS_CD ?? item.gsCd ?? item.code);
       const desc = item.GS_DESC ?? item.gsDesc ?? item.name;
       if (code && desc) this.grievanceSourceMap[code] = desc;
     });
   });
 }

 loadCategoryMaster(): void {
   this.grievanceService.getGrievanceCategories().subscribe(res => {
     res.forEach((item: any) => {
       const code = this.normalize(item.GC_CD ?? item.gcCd ?? item.code);
       const desc = item.GC_DESC ?? item.gcDesc ?? item.name;
       if (code && desc) this.categoryMap[code] = desc;
     });
   });
 }

  loadBranchMap(): void {
    this.grievanceService.getBranchVerticalRo().subscribe(res => {
      res.forEach((item: any) => {
        this.branchMap[item.CODE] = item.NAME;
      });
    });
  }

loadNodalOfficers(): void {
  this.grievanceService.getAllNodalOfficers().subscribe({
    next: (res: any) => {
      const list = Array.isArray(res) ? res : [];

      list.forEach((item: any) => {

        const flag = this.normalize(item.gnoBrVrtFlag);

        let code = '';

        if (flag === 'B' || flag === 'R') {
          code = this.normalize(item.gnoBrCd);
        } else if (flag === 'V') {
          code = this.normalize(item.gnoVrtCd);
        }

        // ✅ build key using correct code
        const key = flag + '|' + code;

        this.nodalOfficerMap[key] = item.gnoNodalEmpName || '';
      });
    },
    error: () => {}
  });
}

 // ✅ FETCH (UPDATED VALIDATION)
 fetch(): void {

   // ✅ Date range validation
   if (
     this.filter.fromDate &&
     this.filter.toDate &&
     new Date(this.filter.fromDate) > new Date(this.filter.toDate)
   ) {
     this.snackBar.open(
       'From Date cannot be greater than To Date',
       'Close',
       { duration: 3000 }
     );
     return;
   }

   // ✅ Allow search by date also
   if (
     !this.filter.grievanceNo &&
     !this.filter.status &&
     !this.filter.fromDate &&
     !this.filter.toDate
   ) {
     this.snackBar.open(
       'Please enter Grievance No or select Status or Date range',
       'Close',
       { duration: 3000 }
     );
     return;
   }

   this.isLoading = true;

   this.selectedGrievance = null;
   this.selectedRow = null;

   if (this.filter.grievanceNo) {
     this.loadSingle(this.filter.grievanceNo);
   } else {
     this.loadByStatus(this.filter.status);
   }
 }

 // ✅ SINGLE
 loadSingle(grievanceNo: string): void {

   this.grievanceService.getGrievanceDetails(grievanceNo)
     .subscribe({
       next: (res) => {
         const data = Array.isArray(res) ? res : [res];
         this.dataSource.data = this.mapData(data);
         this.dataSource.paginator = this.paginator;
         this.isLoading = false;
       },
       error: () => this.isLoading = false
     });
 }

  // ✅ STATUS + DATE FILTER
  loadByStatus(status: string): void {

    const request: any = {
      gdStatus: status && status !== '00' ? status : '',
      gdBranchVerticalCd: '',
      gdGrevCategory: '',
      fromCreatedDt: this.filter.fromDate ? this.formatDateForApi(this.filter.fromDate) : '',
      toCreatedDt: this.filter.toDate ? (dateAtEndOfDay(this.filter.toDate) ?? '') : ''
    };

   this.grievanceService.searchGrievances(request)
     .subscribe({
       next: (res: any) => {
         const list = res?.data?.searchGrievances ?? [];
         this.dataSource.data = this.mapData(list);
         this.dataSource.paginator = this.paginator;
         this.isLoading = false;
       },
       error: () => this.isLoading = false
     });
 }

  mapData(data: any[]): any[] {
    return data.map((r: any) => {

       const sourceKey = this.normalize(r.gdGrevSource);
       const categoryKey = this.normalize(r.gdGrevCategory);

       /* ✅ CUSTOMER TYPE */
       let customerType = 'NA';
       const ct = String(r.gdCustEmpFlag || '').trim().toUpperCase();

       if (ct === 'C') customerType = 'Customer';
       else if (ct === 'E') customerType = 'Employee';
       else if (ct === 'O') customerType = 'Others';

       /* ✅ SOURCE */
       const lookupSource =
         this.grievanceSourceMap[sourceKey] ||
         this.grievanceSourceMap[this.normalize(Number(r.gdGrevSource))] ||
         this.grievanceSourceMap[r.gdGrevSource] || '';

       /* ✅ CATEGORY */
       const lookupCategory =
         this.categoryMap[categoryKey] ||
         this.categoryMap[this.normalize(Number(r.gdGrevCategory))] ||
         this.categoryMap[r.gdGrevCategory] || '';

       /* ✅ NODAL OFFICER */
       const nodalKey = this.normalize(r.gdBranchVertical) + '|' + this.normalize(r.gdBranchVerticalCd);
       const nodalOfficer = this.nodalOfficerMap[nodalKey] || '';

       return {
         grievanceNo: r.gdSrNo,
          receiptDate: this.formatDate(r.gdCreatedDt),
         customerType: customerType,
         customerName: r.gdComplaintName,

        grievanceSource: lookupSource || r.gdGrevSource || 'N/A',

        category: lookupCategory || r.gdGrevCategory || 'N/A',

        branchVertical:
          this.branchMap[r.gdBranchVerticalCd] || r.gdBranchVertical,

        nodalOfficer: nodalOfficer,

         gdBranchVertical: r.gdBranchVertical,

         grievanceRemarks: r.gdComplaint,
         resolution: r.gdResolution,
         gdResolutionBoinchRemarks: r.gdResolutionBoinchRemarks,
         gdResolutionRoinchRemarks: r.gdResolutionRoinchRemarks,
         gdResolutionHoinchRemarks: r.gdResolutionHoinchRemarks,

         closureDate: this.formatDate(r.gdApprovedDt)
      };
    });
  }

 selectRow(row: any): void {
   this.selectedRow = row;
   this.selectedGrievance = row;

   this.grievanceService.getGrievancefiles(row.grievanceNo)
     .subscribe((res: any) => {
       const files = Array.isArray(res) ? res : [];
       const complainantFiles = files.filter((f: any) => f.gfFileType === 'G');
       const resolutionFiles = files.filter((f: any) => f.gfFileType === 'R');

       this.dialog.open(GrievanceViewQueryDialogComponent, {
         width: '80vw',
         maxWidth: '90vw',
         data: { grievance: row, complainantFiles, resolutionFiles },
         autoFocus: false,
         panelClass: 'grievance-view-query-dialog-panel'
       });
     });
 }

 clear(): void {
   this.filter = {
     grievanceNo: '',
     status: '',
     fromDate: '',
     toDate: ''
   };

   this.dataSource.data = [];
   this.selectedGrievance = null;
   this.selectedRow = null;
 }
}



