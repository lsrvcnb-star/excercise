import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GrievanceReports } from './grievance-reports';

describe('GrievanceReports', () => {
  let component: GrievanceReports;
  let fixture: ComponentFixture<GrievanceReports>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GrievanceReports],
    }).compileComponents();

    fixture = TestBed.createComponent(GrievanceReports);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
