import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { Overlay, OverlayModule, OverlayRef } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { Component, OnInit, ViewChild, TemplateRef, ViewContainerRef, inject } from '@angular/core';
import { GrievanceService } from '../services/grievance.service';
import { AppAlertService } from '../shared/app-alert/app-alert.service';
import { AppLoaderService } from '../shared/app-loader/app-loader.service';
import { finalize } from 'rxjs';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { dateAtEndOfDay, dateAtStartOfDay, displayDate } from '../shared/utils';

interface ReportOption {
value: string;
label: string;
}

@Component({
selector: 'app-grievance-reports',
standalone: true,
imports: [
 CommonModule, FormsModule, MatCardModule, MatFormFieldModule,
 MatInputModule, MatButtonModule, MatIconModule, MatDatepickerModule,
 MatNativeDateModule, MatSelectModule, OverlayModule
],
templateUrl: './grievance-reports.html',
styleUrls: ['./grievance-reports.css']
})
export class GrievanceReportsComponent implements OnInit {

fromDate: string = '';
toDate: string = '';
today: Date = new Date();
selectedReport: string = '';
selectedSubReport: string = '';

statusDescriptions: Record<string, string> = {
 '': 'All',
 '00': 'Created from Website API',
 '01': 'Entered by GC Maker',
 '02': 'Forwarded to GC Checker',
 '03': 'Assigned to Branch Maker',
 '04': 'Verification by Branch Checker',
 '05': 'Assigned to RO Maker',
 '06': 'Verification by RO Checker',
 '07': 'Assigned to Vertical Maker',
 '08': 'Verification by Vertical Checker',
 '09': 'Received by GC Maker',
 '10': 'Verification by GC Checker',
 '11': 'Closed by GC Checker'
};

reportTypes: ReportOption[] = [
 { value: 'complaint', label: 'Complaint Reports' },
 { value: 'request', label: 'Request Reports' },
 { value: 'appeal', label: 'Appeal Reports' },
 { value: 'source', label: 'Grievance Source' },
 { value: 'category', label: 'Grievance Category' },
 { value: 'status', label: 'Grievance Status' },
 { value: 'nodal', label: 'Nodal Officers' },
 { value: 'board', label: 'Board Reports' },
 { value: 'all', label: 'All Reports' },
 { value: 'ro-wise', label: 'RO Wise' }
];

subReportTypes: ReportOption[] = [];
sourceOptions: ReportOption[] = [];
categoryOptions: ReportOption[] = [];
nodalOptions: ReportOption[] = [
 { value: 'branch', label: 'Branch Nodal Officer' },
 { value: 'ro', label: 'RO Nodal Officer' },
 { value: 'vertical', label: 'Vertical Nodal Officer' }
];
statusOptions: ReportOption[] = [
 { value: '', label: 'All' },
 ...Object.entries(this.statusDescriptions)
   .filter(([k]) => k !== '')
   .map(([k, v]) => ({ value: k, label: `${v} - ${k}` }))
];
standaloneSubOptions: ReportOption[] = [
 { value: 'resolved', label: 'Resolved' },
 { value: 'pending', label: 'Pending' },
 { value: 'all', label: 'All' }
];
roWiseOptions: ReportOption[] = [];

 resultData: any[] = [];
 showPreview: boolean = false;
 sourceMap: Record<string, string> = {};
 categoryMap: Record<string, string> = {};
 grievanceTypeMap: Record<string, string> = { C: 'Complaint', R: 'Request', A: 'Appeal' };

 @ViewChild('previewTemplate') previewTemplate!: TemplateRef<any>;
 private overlayRef: OverlayRef | null = null;
 private overlay: Overlay = inject(Overlay);
 private viewContainerRef: ViewContainerRef = inject(ViewContainerRef);

customerTypeLabels: Record<string, string> = {
 C: 'Customer', E: 'Employee', O: 'Others'
};

constructor(
 private grievanceService: GrievanceService,
 private alert: AppAlertService,
 private loader: AppLoaderService
) {}

ngOnInit(): void {
 this.loadSourceMaster();
 this.loadCategoryMaster();
 this.loadRoWiseOptions();
}

loadSourceMaster(): void {
  this.grievanceService.getGrievanceSources().subscribe(res => {
    this.sourceOptions = (res || []).map((item: any) => ({
      value: this.normalize(item.GS_CD ?? item.gsCd ?? item.code),
      label: item.GS_DESC ?? item.gsDesc ?? item.name
    })).filter((o: ReportOption) => o.value && o.label);
    this.sourceMap = {};
    this.sourceOptions.forEach(o => { this.sourceMap[o.value] = o.label; });
  });
}

 loadCategoryMaster(): void {
   this.grievanceService.getGrievanceCategories().subscribe(res => {
     this.categoryOptions = (res || []).map((item: any) => ({
       value: this.normalize(item.GC_CD ?? item.gcCd ?? item.code),
       label: item.GC_DESC ?? item.gcDesc ?? item.name
     })).filter((o: ReportOption) => o.value && o.label);
     this.categoryMap = {};
     this.categoryOptions.forEach(o => { this.categoryMap[o.value] = o.label; });
   });
 }

 loadRoWiseOptions(): void {
   this.grievanceService.getBranchVerticalRo().subscribe({
     next: (res: any) => {
       const list = Array.isArray(res) ? res : res?.data ?? res?.result ?? [];
       this.roWiseOptions = list
         .filter((item: any) => item.TYPE === 'R')
         .map((item: any) => ({
           value: item.CODE ?? '',
           label: item.NAME ?? ''
         })).filter((o: ReportOption) => o.value && o.label);
     },
     error: () => {
       this.alert.error('Failed to load RO list');
     }
   });
 }

normalize(value: any): string {
  if (value === null || value === undefined) return '';
  return String(value).trim().replace(/^0+/, '');
}

getBranchVerticalLabel(flag: string): string {
  switch (flag) {
    case 'B': return 'Branch';
    case 'R': return 'RO';
    case 'V': return 'Vertical';
    default: return flag || '';
  }
}

selectReportType(value: string): void {
 this.selectedReport = value;
 this.onReportTypeChange();
}

onReportTypeChange(): void {
 this.selectedSubReport = '';
 this.resultData = [];

 switch (this.selectedReport) {
   case 'complaint':
   case 'request':
   case 'appeal':
   case 'all':
     this.subReportTypes = [...this.standaloneSubOptions];
     break;
   case 'source':
     this.subReportTypes = [...this.sourceOptions];
     break;
   case 'category':
     this.subReportTypes = [...this.categoryOptions];
     break;
   case 'status':
     this.subReportTypes = [...this.statusOptions];
     break;
   case 'nodal':
     this.subReportTypes = [...this.nodalOptions];
     break;
   case 'board':
     this.subReportTypes = [{ value: '01', label: '01 Grievance Position' }];
     break;
   case 'ro-wise':
     this.subReportTypes = [...this.roWiseOptions];
     break;
   default:
     this.subReportTypes = [];
 }
}

get showDateFilter(): boolean {
 return this.selectedReport !== 'nodal';
}

async fetchReport(): Promise<void> {
 if (!this.selectedReport) {
   this.alert.warning('Please select a Report Type');
   return;
 }
 if (!this.selectedSubReport) {
   this.alert.warning('Please select a Sub Report Type');
   return;
 }

 if (this.fromDate && this.toDate && new Date(this.fromDate) > new Date(this.toDate)) {
   this.alert.warning('To Date cannot be before From Date');
   return;
 }

 this.resultData = [];
 this.loader.show();

 try {
   if (this.selectedReport === 'nodal') {
     await this.fetchNodalReport();
   } else {
     await this.fetchGrievanceReport();
   }
 } catch {
   this.alert.error('Failed to load report');
 } finally {
   this.loader.hide();
 }
}

private async fetchNodalReport(): Promise<void> {
  return new Promise((resolve) => {
    this.grievanceService.getAllNodalOfficers().pipe(
      finalize(() => resolve())
    ).subscribe({
      next: (res: any[]) => {
        const list = res || [];
        let filtered = list;
        if (this.selectedSubReport === 'branch') {
          filtered = list.filter((r: any) => r.gnoBrVrtFlag === 'B');
        } else if (this.selectedSubReport === 'ro') {
          filtered = list.filter((r: any) => r.gnoBrVrtFlag === 'R');
        } else if (this.selectedSubReport === 'vertical') {
          filtered = list.filter((r: any) => r.gnoBrVrtFlag === 'V');
        }
         this.resultData = filtered.map((r: any, index: number) => ({
           'Sl No': index + 1,
           'RO Code': r.gnoBrCd || '',
           'RO Name': r.gnoBrVrtName || '',
           'Officer Code': r.gnoNodalEmpCd || '',
           'Nodal Officer Name': r.gnoNodalEmpName || '',
           'Alternate Code': r.gnoAltNodalEmpCd || '',
           'Alternate Officer Name': r.gnoAltNodalEmpName || '',
           'Assign Date': r.gnoAssignDt || ''
         }));

        if (this.resultData.length === 0) {
          this.alert.info('No records found for the selected criteria');
        } else {
          this.openPreview();
        }
      },
      error: () => resolve()
    });
  });
}

private async fetchGrievanceReport(): Promise<void> {
const fromCreatedDt = this.fromDate
  ? this.formatDateForApi(this.fromDate)
  : '';

const toCreatedDt = this.toDate
  ? this.formatDateForApi(this.toDate, true)
  : '';

 const request: any = {
   gdStatus: '',
   gdBranchVerticalCd: '',
   gdGrevCategory: '',
   fromCreatedDt,
   toCreatedDt
 };

 if (this.selectedReport === 'status') {
   request.gdStatus = this.selectedSubReport;
 }

 if (this.selectedReport === 'ro-wise') {
   request.gdBranchVerticalCd = this.selectedSubReport;
 }

 return new Promise((resolve) => {
   this.grievanceService.searchGrievances(request).pipe(
     finalize(() => resolve())
   ).subscribe({
     next: (res: any) => {
       let list = res?.data?.searchGrievances ?? [];

       list = this.filterByReportType(list);
       list = this.filterBySubReportType(list);

        this.resultData = list.map((r: any, index: number) => ({
          'Sl No': index + 1,
          'Grievance No.': r.gdSrNo,
          'Grievance Source': this.sourceMap[this.normalize(r.gdGrevSource)] || r.gdGrevSourceName || 'NA',
          'Customer Type': this.customerTypeLabels[r.gdCustEmpFlag] || r.gdCustEmpFlag || '',
          'Grievance Type': this.grievanceTypeMap[r.gdRequestType] || r.gdRequestType || '',
          'Customer/ Employee/ Other Name': r.gdComplaintName || '',
          'BO/ Vertical/RO': this.getBranchVerticalLabel(r.gdBranchVertical),
          'BO/ Vertical/RO Name': r.gdBranchVerticalName || '',
          'Grievance Category': this.categoryMap[this.normalize(r.gdGrevCategory)] || r.gdGrevCategoryName || 'NA',
          'Grievance Status': this.statusDescriptions[r.gdStatus] || r.gdStatusName || r.gdStatus || '',
          'Date of Receipt': this.formatDisplayDate(r.gdCreatedDt),
          'Date of Closure': this.formatDisplayDate(r.gdResolutionHoinchDt),
          'TAT (Working days from Date of Receipt to closure date)': r.gdResolutionTat != null ? r.gdResolutionTat : ''
        }));

        if (this.resultData.length === 0) {
          this.alert.info('No records found for the selected criteria');
        } else {
          this.openPreview();
        }
      },
      error: () => resolve()
   });
 });
}


formatDateForApi(dateStr: any, endOfDay: boolean = false): string {
  return (endOfDay ? dateAtEndOfDay(dateStr) : dateAtStartOfDay(dateStr)) ?? '';
}

 formatDisplayDate(dateStr: any): string {
   return displayDate(dateStr);
 }


private filterByReportType(list: any[]): any[] {
 if (this.selectedReport === 'complaint') {
   return list.filter(r => r.gdRequestType === 'C');
 }
 if (this.selectedReport === 'request') {
   return list.filter(r => r.gdRequestType === 'R');
 }
 if (this.selectedReport === 'appeal') {
   return list.filter(r => r.gdRequestType === 'A');
 }
 if (this.selectedReport === 'source') {
   const code = this.normalize(this.selectedSubReport);
   return list.filter(r => this.normalize(r.gdGrevSource) === code);
 }
 if (this.selectedReport === 'category') {
   const code = this.normalize(this.selectedSubReport);
   return list.filter(r => this.normalize(r.gdGrevCategory) === code);
 }
 return list;
}

private filterBySubReportType(list: any[]): any[] {
 if (this.selectedSubReport === 'resolved') {
   return list.filter(r => r.gdStatus === '11');
 }
 if (this.selectedSubReport === 'pending') {
   return list.filter(r => r.gdStatus !== '11');
 }
 return list;
}

 get resultKeys(): string[] {
   if (this.resultData.length === 0) return [];
   return Object.keys(this.resultData[0]);
 }

 closePreview(): void {
   this.showPreview = false;
   if (this.overlayRef) {
     this.overlayRef.detach();
     this.overlayRef.dispose();
     this.overlayRef = null;
   }
 }

 openPreview(): void {
   this.closePreview();
   this.overlayRef = this.overlay.create({
     hasBackdrop: true,
     backdropClass: 'preview-backdrop',
     panelClass: 'preview-overlay-panel',
     scrollStrategy: this.overlay.scrollStrategies.block(),
     positionStrategy: this.overlay.position().global().centerHorizontally().centerVertically()
   });
   this.overlayRef.backdropClick().subscribe(() => this.closePreview());
   const portal = new TemplatePortal(this.previewTemplate, this.viewContainerRef);
   this.overlayRef.attach(portal);
   this.showPreview = true;
 }

 downloadPdf(): void {
  if (this.resultData.length === 0) return;

  const keys = this.resultKeys;
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();

  const title = `Grievance Report - ${this.selectedReport}`;
  doc.setFontSize(14);
  doc.text(title, pageWidth / 2, 15, { align: 'center' });
  doc.setFontSize(9);
  doc.text(`Report Type: ${this.selectedReport} | Sub Type: ${this.selectedSubReport}`, pageWidth / 2, 22, { align: 'center' });

  const headers = keys.map(k => ({ header: k, dataKey: k }));
   const longTextKeys = ['Grievance Source', 'Customer/ Employee/ Other Name', 'BO/ Vertical/RO Name', 'Grievance Category'];
   const rows = this.resultData.map(row => {
     const obj: any = {};
     keys.forEach(k => {
       let val = row[k] ?? '';
       if (typeof val === 'string') {
         val = val.replace(/\n/g, ' ');
       }
       obj[k] = val;
     });
     return obj;
   });

   const columnStyles: any = {};
   const usableWidth = pageWidth - 20;
   let totalWidth = 0;
   const colWidths: number[] = [];

   keys.forEach((key, i) => {
     if (longTextKeys.includes(key)) {
       colWidths[i] = 45;
       totalWidth += 45;
     } else {
       const maxLen = Math.max(
         key.length,
         ...rows.map(r => String(r[key] || '').length)
       );
       const estWidth = Math.min(Math.max(maxLen * 1.5, 15), 30);
       colWidths[i] = estWidth;
       totalWidth += estWidth;
     }
   });

   const scale = totalWidth > usableWidth ? usableWidth / totalWidth : 1;
   keys.forEach((key, i) => {
     columnStyles[i] = { cellWidth: colWidths[i] * scale, overflow: 'linebreak' };
   });

   autoTable(doc, {
     columns: headers,
     body: rows,
     startY: 28,
     styles: { fontSize: 7, cellPadding: 1.5, overflow: 'linebreak', lineColor: [173, 216, 230], lineWidth: 0.2 },
     headStyles: { fillColor: [218, 247, 166], textColor: [0, 0, 0], fontSize: 7, halign: 'center', lineColor: [173, 216, 230], lineWidth: 0.2 },
     columnStyles,
    didDrawPage: (data: any) => {
      doc.setFontSize(8);
      doc.text(`Page ${data.pageNumber}`, pageWidth - 15, doc.internal.pageSize.getHeight() - 10, { align: 'center' });
    }
  });

  doc.save(`${this.selectedReport}_${this.selectedSubReport}_report.pdf`);
  this.closePreview();
}

downloadExcel(): void {
  if (this.resultData.length === 0) return;

  const keys = this.resultKeys;
   const style = 'style="border:1px solid lightblue;padding:4px 6px;vertical-align:top;word-wrap:break-word;white-space:normal;"';
   const headerStyle = 'style="border:1px solid lightblue;padding:4px 6px;background:#DAF7A6;color:#000;font-weight:bold;text-align:center;word-wrap:break-word;white-space:normal;"';

  let html = '<html><head><meta charset="UTF-8"><title>Report</title></head><body>';
  html += `<table style="border-collapse:collapse;width:100%;font-size:11px;font-family:Arial,sans-serif;">`;
  html += '<thead><tr>';
  keys.forEach(k => {
    html += `<th ${headerStyle}>${k}</th>`;
  });
  html += '</tr></thead><tbody>';

  this.resultData.forEach(row => {
    html += '<tr>';
    keys.forEach(k => {
      let val = row[k] ?? '';
      if (typeof val === 'string') {
        val = val.replace(/\n/g, ' ').replace(/"/g, '&quot;');
      }
      html += `<td ${style}>${val}</td>`;
    });
    html += '</tr>';
  });

  html += '</tbody></table></body></html>';

  const blob = new Blob(['\uFEFF' + html], { type: 'application/vnd.ms-excel;charset=utf-8' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${this.selectedReport}_${this.selectedSubReport}_report.xls`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.URL.revokeObjectURL(url);
  this.closePreview();
}

clear(): void {
  this.closePreview();
  this.fromDate = '';
  this.toDate = '';
  this.selectedReport = '';
  this.selectedSubReport = '';
  this.resultData = [];
}
}







