import { inject } from '@angular/core';
import { CanActivateChildFn, ActivatedRouteSnapshot, Router } from '@angular/router';
import { AuthService } from './services/auth.service';

export const AuthGuard: CanActivateChildFn = (
  route: ActivatedRouteSnapshot
) => {

  const authService = inject(AuthService);
  const router = inject(Router);

  /* ✅ 1. Check login */
  if (!authService.isLoggedIn()) {
    router.navigate(['/login']);
    return false;
  }

  /* ✅ 2. Check exact roles */
  const allowedRoles = route.data?.['roles'] as string[]; // ✅ BM, AM, etc.

  if (!allowedRoles || allowedRoles.length === 0) {
    return true;
  }

  const userRole = authService.getRole(); // ✅ exact role

  if (userRole && allowedRoles.includes(userRole)) {
    return true;
  }

  /* ❌ Unauthorized */
  router.navigate(['/grievance-list']);
  return false;
};

