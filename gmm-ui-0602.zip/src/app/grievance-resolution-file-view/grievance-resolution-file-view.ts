import {
  Component,
  ViewChild,
  AfterViewInit,
  OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { MatTableModule, MatTableDataSource } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { GrievanceService } from '../services/grievance.service';
import { AppAlertService } from '../shared/app-alert/app-alert.service';
import { AppLoaderService } from '../shared/app-loader/app-loader.service';
import { GrievanceResolutionFileDialogComponent } from './grievance-resolution-file-dialog';
import { dateOnly, displayDate } from '../shared/utils';

@Component({
  selector: 'app-grievance-resolution-file-view',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTableModule,
    MatInputModule,
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatPaginatorModule,
    MatDialogModule,
  ],
  templateUrl: './grievance-resolution-file-view.html',
  styleUrls: ['./grievance-resolution-file-view.css']
})
export class GrievanceResolutionFileViewComponent implements OnInit, AfterViewInit {

  constructor(
    private grievanceService: GrievanceService,
    private alert: AppAlertService,
    private loader: AppLoaderService,
    private dialog: MatDialog
  ) { }

  today: string = dateOnly(new Date());
  selectedRow: any = null;
  selectedGrievance: any = null;

  displayedColumns: string[] = [
    'slNo',
    'gdSrNo',
    'gdCreatedDt',
    'gdCustEmpFlag',
    'gdComplaintName',
    'gdGrevSource',
    'gdGrevCategory',
    'gdBranchVertical',
    'gdStatus',
    'gdApprovedDt'
  ];

  dataSource = new MatTableDataSource<any>([]);
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  filter = {
    start: '',
    end: ''
  };

  grievanceSourceMap: Record<string, string> = {};
  categoryMap: Record<string, string> = {};
  branchMap: Record<string, string> = {};

  statusMap: Record<string, string> = {
    '00': 'All',
    '01': 'Entered by GC Maker',
    '02': 'Forwarded to GC Checker',
    '03': 'Assigned to Branch Maker',
    '04': 'Verification by Branch Checker',
    '05': 'Assigned to RO Maker',
    '06': 'Verification by RO Checker',
    '07': 'Assigned to Vertical Maker',
    '08': 'Verification by Vertical Checker',
    '09': 'Received by GC Maker',
    '10': 'Verification by GC Checker',
    '11': 'Closed by GC Checker'
  };

  ngOnInit(): void {
    this.loadSourceMaster();
    this.loadCategoryMaster();
    this.loadBranchMap();
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
  }

  normalize(value: any): string {
    if (value === null || value === undefined) return '';
    return String(value).trim().replace(/^0+/, '');
  }

  formatDate(dateStr: any): string {
    return displayDate(dateStr);
 }

  loadSourceMaster(): void {
    this.grievanceService.getGrievanceSources().subscribe(res => {
      res.forEach((item: any) => {
        const code = this.normalize(item.GS_CD ?? item.gsCd ?? item.code);
        const desc = item.GS_DESC ?? item.gsDesc ?? item.name;
        if (code && desc) this.grievanceSourceMap[code] = desc;
      });
    });
  }

  loadCategoryMaster(): void {
    this.grievanceService.getGrievanceCategories().subscribe(res => {
      res.forEach((item: any) => {
        const code = this.normalize(item.GC_CD ?? item.gcCd ?? item.code);
        const desc = item.GC_DESC ?? item.gcDesc ?? item.name;
        if (code && desc) this.categoryMap[code] = desc;
      });
    });
  }

  loadBranchMap(): void {
    this.grievanceService.getBranchVerticalRo().subscribe(res => {
      res.forEach((item: any) => {
        this.branchMap[item.CODE] = item.NAME;
      });
    });
  }

  fetch(): void {
  if (
    this.filter.start &&
    this.filter.end &&
    new Date(this.filter.start) > new Date(this.filter.end)
  ) {
    this.alert.warning('From Date cannot be greater than To Date');
    return;
  }

  this.selectedRow = null;
  this.selectedGrievance = null;
  this.loader.show();

const fromCreatedDt = this.filter.start
  ? this.formatDateForReq(this.filter.start)
  : '';

const toCreatedDt = this.filter.end
  ? this.formatDateForReq(this.filter.end, true)
  : '';

  this.grievanceService.searchGrievances({ fromCreatedDt, toCreatedDt })
    .subscribe({
      next: (res) => {
        this.loader.hide();
        const list = res?.data?.searchGrievances ?? [];
        this.dataSource.data = this.mapData(list);
        this.dataSource.paginator = this.paginator;

        if (list.length === 0) {
          this.alert.info('No records found');
        }
      },
      error: () => {
        this.loader.hide();
        this.alert.error('Error fetching data');
      }
    });
}


  mapData(data: any[]): any[] {
    return data.map((r: any, index: number) => {
      const sourceKey = this.normalize(r.gdGrevSource);
      const categoryKey = this.normalize(r.gdGrevCategory);

      return {
        slNo: index + 1,
        gdSrNo: r.gdSrNo,
        gdSrgrDt: this.formatDate(r.gdSrgrDt),
        gdCustEmpFlag: r.gdCustEmpFlag == 'E' ? 'Employee' : r.gdCustEmpFlag == 'C' ? 'Customer' : r.gdCustEmpFlag == 'O' ? 'Others' : 'N/A',
        gdComplaintName: r.gdComplaintName,
        gdGrevSource: this.grievanceSourceMap[sourceKey] || this.grievanceSourceMap[this.normalize(Number(r.gdGrevSource))] || r.gdGrevSource || 'N/A',
        gdGrevCategory: this.categoryMap[categoryKey] || this.categoryMap[this.normalize(Number(r.gdGrevCategory))] || r.gdGrevCategory || 'N/A',
        gdBranchVertical: this.branchMap[r.gdBranchVerticalCd] || r.gdBranchVertical || r.gdBranchVerticalCd,
        // Keep the routing code separately. The details dialog uses B/R/V to
        // decide which checker remarks field should be displayed.
        gdBranchVerticalCode: r.gdBranchVertical,
        gdStatus: this.statusMap[r.gdStatus] || r.gdStatus || 'N/A',
        gdApprovedDt: this.formatDate(r.gdApprovedDt),

        // Keep raw data for details
        gdComplaint: r.gdComplaint,
        gdResolution: r.gdResolution,
        gdResolutionBoinchRemarks: r.gdResolutionBoinchRemarks,
        gdResolutionRoinchRemarks: r.gdResolutionRoinchRemarks,
        gdResolutionHoinchRemarks: r.gdResolutionHoinchRemarks,
        gdSourceEmailId: r.gdSourceEmailId,
        gdCreatedBy: r.gdCreatedBy,
        gdCreatedDt: r.gdCreatedDt,
        gdApprovedBy: r.gdApprovedBy,
        gdRequestType: r.gdRequestType,
        gdPreviousSrNo: r.gdPreviousSrNo,
        gdSrgrFlag: r.gdSrgrFlag,
        gdCustEmpCd: r.gdCustEmpCd
      };
    });
  }

formatDateForReq(dateStr: any, endOfDay: boolean = false): string {
  if (!dateStr) return '';

  const d = new Date(dateStr);

  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');

  const time = endOfDay ? '23:59:59' : '00:00:00';

  return `${yyyy}-${mm}-${dd}T${time}`;
}
  selectRow(row: any): void {
    this.loader.show();
    this.selectedRow = row;
    this.selectedGrievance = row;

    const remarks = {
      gdComplaint: row.gdComplaint,
      gdResolution: row.gdResolution,
      gdResolutionBoinchRemarks: row.gdResolutionBoinchRemarks,
      gdResolutionRoinchRemarks: row.gdResolutionRoinchRemarks,
      gdResolutionHoinchRemarks: row.gdResolutionHoinchRemarks
    };

    this.grievanceService.getGrievancefiles(row.gdSrNo)
      .subscribe({
        next: (res: any) => {
          this.loader.hide();
          const files = Array.isArray(res) ? res : [];
          const complainantFiles = files.filter((f: any) => f.gfFileType === 'G');
          const resolutionFiles = files.filter((f: any) => f.gfFileType === 'R');
          
          this.dialog.open(GrievanceResolutionFileDialogComponent, {
            width: '700px',
            maxWidth: '75vw',
            panelClass: 'grievance-resolution-file-dialog-panel',
            enterAnimationDuration: '250ms',
            exitAnimationDuration: '200ms',
            data: { grievance: row, remarks, complainantFiles, resolutionFiles },
            autoFocus: false
          });
        },
        error: () => {
          this.loader.hide();
          this.dialog.open(GrievanceResolutionFileDialogComponent, {
            width: '700px',
            maxWidth: '75vw',
            panelClass: 'grievance-resolution-file-dialog-panel',
            enterAnimationDuration: '250ms',
            exitAnimationDuration: '200ms',
            data: { grievance: row, remarks, complainantFiles: [], resolutionFiles: [] },
            autoFocus: false
          });
        }
      });
  }

  clear(): void {
    this.filter = { start: '', end: '' };
    this.dataSource.data = [];
    this.selectedRow = null;
    this.selectedGrievance = null;
  }
}


