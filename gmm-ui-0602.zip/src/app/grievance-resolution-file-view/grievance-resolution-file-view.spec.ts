import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GrievanceResolutionFileView } from './grievance-resolution-file-view';

describe('GrievanceResolutionFileView', () => {
  let component: GrievanceResolutionFileView;
  let fixture: ComponentFixture<GrievanceResolutionFileView>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GrievanceResolutionFileView],
    }).compileComponents();

    fixture = TestBed.createComponent(GrievanceResolutionFileView);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
