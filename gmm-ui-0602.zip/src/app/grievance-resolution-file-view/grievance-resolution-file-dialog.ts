import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { GrievanceService } from '../services/grievance.service';

@Component({
 selector: 'app-grievance-resolution-file-dialog',
 standalone: true,
 imports: [
   CommonModule,
   FormsModule,
   MatDialogModule,
   MatButtonModule,
   MatIconModule
 ],
 templateUrl: './grievance-resolution-file-dialog.html',
 styleUrls: ['./grievance-resolution-file-dialog.css']
})
export class GrievanceResolutionFileDialogComponent {

  grievance: any;
  remarks: any;
  complainantFiles: any[] = [];
  resolutionFiles: any[] = [];
  inchargeRemarks: string = '';
  inchargeRemarksLabel: string = '';

  constructor(
    public dialogRef: MatDialogRef<GrievanceResolutionFileDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private grievanceService: GrievanceService
  ) {
    this.grievance = data?.grievance ?? {};
    this.remarks = data?.remarks ?? {};
    this.complainantFiles = data?.complainantFiles ?? [];
    this.resolutionFiles = data?.resolutionFiles ?? [];

    // gdBranchVertical is displayed as a branch/vertical name in the parent
    // component. Use the preserved raw code to select the correct remarks.
    const bv = String(
      this.grievance?.gdBranchVerticalCode ?? this.grievance?.gdBranchVertical ?? ''
    ).trim().toUpperCase();
    if (bv === 'B') {
      this.inchargeRemarks = this.remarks?.gdResolutionBoinchRemarks || '';
      this.inchargeRemarksLabel = 'Branch Checker Remarks';
    } else if (bv === 'R') {
      this.inchargeRemarks = this.remarks?.gdResolutionRoinchRemarks || '';
      this.inchargeRemarksLabel = 'RO Checker Remarks';
    } else if (bv === 'V') {
      this.inchargeRemarks = this.remarks?.gdResolutionHoinchRemarks || '';
      this.inchargeRemarksLabel = 'Vertical Checker Remarks';
    }
  }

  close(): void {
    this.dialogRef.close();
  }

 downloadFile(file: any): void {
   if (!file?.gfSno) return;
   this.grievanceService.downloadGrievancefile(file.gfSno)
     .subscribe(res => {
       const blob = res.body;
       if (!blob) return;
       const url = window.URL.createObjectURL(blob);
       const a = document.createElement('a');
       a.href = url;
       a.download = `FILE_${file.gfSrNo}_${file.gfSno}`;
       document.body.appendChild(a);
       a.click();
       document.body.removeChild(a);
       window.URL.revokeObjectURL(url);
     });
 }
}


