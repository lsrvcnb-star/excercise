import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../environments/environment';

export interface CaptchaResponse {
  apiResponse: string;
  capId: number;
  capText: string;
}

export interface LoginResponse {
  apiResponse: string;
  authToken?: string;
}

@Injectable({
  providedIn: 'root'
})
export class AppServiceService {

  private readonly BASE_URL = environment.sso;

  constructor(private http: HttpClient) {}

  /* ✅ SIDBI SSO CAPTCHA (GET – as per real site) */
  getCaptcha(userName: string) {
  return this.http.post<CaptchaResponse>(
    `${this.BASE_URL}/login-1.0/getCaptcha`,
    {
      userName: userName
    }
  );
}

  /* ✅ SIDBI SSO LOGIN */
  login(payload: any): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(
      `${this.BASE_URL}/login-1.0/login`,
      payload
    );
  }

  /* ✅ AUTH CHECK */
  checkMasterAccess(userName: string): Observable<any> {
    return this.http.get<any>(
      `${this.BASE_URL}/login-1.0/check-access`,
      { params: { userName } }
    );
  }
}