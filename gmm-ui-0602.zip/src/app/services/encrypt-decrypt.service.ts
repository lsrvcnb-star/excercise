import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';

@Injectable({ providedIn: 'root' })
export class EncryptDecryptService {
  private base64Key_MIS = environment.aesSecretkey_MIS;
  private base64Key_SSO = environment.aesSecretkey_SSO;

  async encryptSSO(data: string): Promise<string> {
    return this.encrypt(data, this.base64Key_SSO);
  }

  async encryptMIS(data: string): Promise<string> {
    return this.encrypt(data, this.base64Key_MIS);
  }

  async encrypt(data: string, base64Key: string): Promise<string> {
    const keyBytes = this.base64ToArrayBuffer(base64Key);
    if (keyBytes.byteLength !== 32) {
      throw new Error('AES key must be 256-bit (32 bytes) after Base64 decoding.');
    }

    const iv = crypto.getRandomValues(new Uint8Array(12)); // 12-byte IV for GCM
    const cryptoKey = await crypto.subtle.importKey('raw', keyBytes, { name: 'AES-GCM' }, false, ['encrypt']);

    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      cryptoKey,
      new TextEncoder().encode(data),
    );

    const combined = new Uint8Array(iv.length + encrypted.byteLength);
    combined.set(iv, 0);
    combined.set(new Uint8Array(encrypted), iv.length);

    return this.arrayBufferToBase64(combined.buffer);
  }

  async decryptSSO(data: string): Promise<string> {
    return this.decrypt(data, this.base64Key_SSO);
  }

  async decryptMIS(data: string): Promise<string> {
    return this.decrypt(data, this.base64Key_MIS);
  }

  async decrypt(encryptedBase64: string, base64Key: string): Promise<string> {
    const keyBytes = this.base64ToArrayBuffer(base64Key);
    const encryptedData = this.base64ToArrayBuffer(encryptedBase64);

    const iv = encryptedData.slice(0, 12);
    const cipherText = encryptedData.slice(12);

    const cryptoKey = await crypto.subtle.importKey('raw', keyBytes, { name: 'AES-GCM' }, false, ['decrypt']);

    const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, cryptoKey, cipherText);
    return new TextDecoder().decode(decrypted);
  }

  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binaryString = window.atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
    return bytes.buffer;
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    return window.btoa(binary);
  }
}
