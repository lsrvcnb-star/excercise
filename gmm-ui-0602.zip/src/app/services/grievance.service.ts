import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { environment } from '../environments/environment';

export interface CustomerEmployeeLookup {

 /* EMPLOYEE */
 employeeCode?: string;
 branchCode?: string;
 designationDescription?: string;

 /* CUSTOMER */
 custCd?: string;
 custLongName?: string;
 custAddr1?: string;
 custAddr2?: string;
 custAddr3?: string;
 custCity?: string;
 custEmailId?: string;
 mobileNo?: string;

 /* COMMON */
 name?: string;
 emailId?: string;
 mobile?: string;
}

export interface BranchVerticalLookup {
 branchCd: string;
 branchName: string;
 branchEmailId?: string;
}

export interface NodalOfficerLookup {
 gnoBrCd: string;
 branchVerticalName: string;
 name: string;
 designationDescription: string;
 emailId: string;
 mobile: string;
 alternate: boolean;
}



@Injectable({
 providedIn: 'root'
})
export class GrievanceService {

 /* ================= BASE URL ================= */
 private BASE_URL = environment.api;

 constructor(private http: HttpClient) { }


 getGrievances(): Observable<any[]> {
   return this.http.get<any[]>(`${this.BASE_URL}api/grievances/getall`);
 }


 getGrievanceSources(): Observable<any[]> {
   return this.http.get<any[]>(`${this.BASE_URL}api/grievances/getGrievanceSource`);
 }


 getGrievanceCategories(): Observable<any[]> {
   return this.http.get<any[]>(`${this.BASE_URL}api/grievances/getGrievanceGategory`);
 }


 createGrievanceDraft(payload: any): Observable<any> {
   return this.http.post<any>(`${this.BASE_URL}api/grievances/create`, payload);
 }

 updateGrievance(payload: any, grievanceNo: any): Observable<any> {
   return this.http.post<any>(`${this.BASE_URL}api/grievances/update/${grievanceNo}`, payload);
 }


 saveGrievance(payload: any): Observable<any> {
   return this.http.post<any>(this.BASE_URL, payload);
 }


 getGrievanceBySerialNo(srNo: string): Observable<any> {
   return this.http.get<any>(`${this.BASE_URL}/${srNo}`);
 }

 uploadFile(formData: FormData) {
   return this.http.post(
     `${this.BASE_URL}api/grievances/uploadfile`,
     formData
   );
 }

 getGrievanceDetails(grievanceNo: any): Observable<any> {
   return this.http.post<any>(`${this.BASE_URL}api/grievances/search/${grievanceNo}`, null);
 }

 searchEmployeeByName(name: string) {

   return this.http.get<any[]>(
     `${this.BASE_URL}api/grievances/search/employee`,
     {
       params: { name }
     }
   );
 }

 searchCustomerByName(name: string) {

   return this.http.get<any[]>(
     `${this.BASE_URL}api/grievances/search/customer`,
     {
       params: { name }
     }
   );
 }


 searchBranchByCode(code: string): Observable<BranchVerticalLookup[]> {
   return this.http.get<BranchVerticalLookup[]>(
     `${this.BASE_URL}api/grievances/branch/code`,
     {
       params: {
         code: code
       }
     }
   );
 }

 getNodalOfficer(code: string) {
   return this.http.get<any[]>(
     `${this.BASE_URL}api/grievances/nodalOfficer`,
     {
       params: { code }
     }
   );
 }

 getBranchVerticalRo() {

   return this.http.get<any[]>(
     `${this.BASE_URL}api/grievances/getBranchVerticalRo`
   );
 }


 deleteGrievance(srNo: any): Observable<any> {
   return this.http.post<any>(`${this.BASE_URL}api/grievances/delete/${srNo}`, null);
 }

 getGrievancefiles(grievanceNo: any): Observable<any> {
   return this.http.get<any>(`${this.BASE_URL}api/grievances/getFiles/${grievanceNo}`);
 }

downloadGrievancefile(fileNo: any): Observable<HttpResponse<Blob>> {
 return this.http.get(`${this.BASE_URL}api/grievances/downloadfile/${fileNo}`, {
   responseType: 'blob',
   observe: 'response'
 });
}


getAllNodalOfficers() {
  return this.http.get<any[]>(
    `${this.BASE_URL}api/grievances/allNodalOfficers`
  );
}

updateAllNodalOfficers(payload: any) {
  return this.http.post<any[]>(
    `${this.BASE_URL}api/grievances/updateAllNodalOfficers`,
    payload
  );
}

 searchGrievancesByBranchAndDate(start: string, end: string): Observable<any[]> {
   return this.http.get<any[]>(`${this.BASE_URL}api/grievances/search/grievance`, {
     params: { start, end }
   });
 }

  searchGrievances(request: any): Observable<any> {
   const body = {
       query: `query($request: GrievanceSearchRequestInput) { searchGrievances(request: $request) { gdSrNo gdRequestType gdPreviousSrNo gdSrgrFlag gdSrgrDt gdCustEmpFlag gdCustEmpCd gdComplaintName gdSourceEmailId gdGrevSource gdGrevCategory gdBranchVertical gdBranchVerticalCd gdCreatedBy gdCreatedDt gdApprovedBy gdGrevSourceName gdApprovedDt gdComplaint gdResolution gdResolutionBomkrId gdResolutionBomkrDt gdResolutionBoinchId gdResolutionBoinchDt gdResolutionBoinchRemarks gdResolutionRomkrId gdResolutionRomkrDt gdGrevCategoryName gdResolutionRoinchId gdResolutionRoinchDt gdResolutionRoinchRemarks gdResolutionHomkrId gdResolutionHomkrDt gdResolutionHoinchId gdResolutionHoinchDt gdResolutionHoinchRemarks gdStatus gdStatusName gdOldSrgrId gdOldAssignId gdCompRegdWith gdCompConfSend gdConfSendDt gdMakerIdConfSend gdMakerDtConfSend gdResolutionTat gdComplAdd gdComplMobile gdWebsiteReqId gdWebsiteUpdDt gdBranchVerticalName } }`,
     variables: { request }
   };
   return this.http.post<any>(`${this.BASE_URL}api/grievances/search`, body);
 }













}

