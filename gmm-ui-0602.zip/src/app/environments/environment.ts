export const environment = {
  url: 'https://sso.sidbi.in:8443/',
  aesSecretkey_MIS: "FBVzadc/oFHpd0pHdzyD187R9f0LoSp3ZjEYfQn2n8A=",
  aesSecretkey_SSO: 'E8gKS9eSUvcCCXUgoVy0hjHToVQlJ5ZcrgI6Mia5xNQ=',
//  api: 'http://localhost:8080/',
  api: 'http://172.30.1.170:8080/gmm/',
//    api: 'https://grievance-uat.sidbi.in/gmm/',

  sso: 'https://sso.sidbi.in:8443'
};

