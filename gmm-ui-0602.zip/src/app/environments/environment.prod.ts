export const environment = {
 url: 'https://sso.sidbi.in:8443/',
 aesSecretkey_MIS: 'FBVzadc/oFHpd0pHdzyD187R9f0LoSp3ZjEYfQn2n8A=',
 aesSecretkey_SSO: 'E8gKS9eSUvcCCXUgoVy0hjHToVQlJ5ZcrgI6Mia5xNQ=',
 api: 'https://grievance.sidbi.in/',
 sso: 'https://sso.sidbi.in:8443'
};