import {
 Component,
 OnInit,
 AfterViewInit,
 ViewChild
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';

import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { Router } from '@angular/router';

import { ReviewToOpenDialogComponent } from '../review-to-open-dialog/review-to-open-dialog';

import { GrievanceService } from '../services/grievance.service';
import { finalize, forkJoin } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { MatSort } from '@angular/material/sort';
import { MatSortModule } from '@angular/material/sort';
import { MatTabsModule } from '@angular/material/tabs';
import { AppLoaderService } from '../shared/app-loader/app-loader.service';
import { AppAlertService } from '../shared/app-alert/app-alert.service';
import { displayDate } from '../shared/utils';

@Component({
 selector: 'app-grievance-list',
 standalone: true,
 imports: [
   CommonModule,
   MatTableModule,
   MatButtonModule,
   MatFormFieldModule,
   MatInputModule,
   MatIconModule,
   MatPaginatorModule,
   MatSortModule,
   MatDialogModule,
   MatTabsModule
 ],
 templateUrl: './grievance-list.html',
 styleUrls: ['./grievance-list.css'],



})
export class GrievanceListComponent
 implements OnInit, AfterViewInit {

 displayedColumns: string[] = [
   'name',
   'grvNo',
   'receiptDate',
   'customerCode',
   'customerType',
   'action'
 ];


 private readonly roleStatusMap: Record<string, string> = {
   BM: '03',
   BC: '04',
   RM: '05',
   RC: '06',
   HM: '07',
   HC: '08'
 };

 dataSource = new MatTableDataSource<any>([]);
 showTabs = false;
 roleTabs: { label: string; status: string }[] = [];
 selectedTabIndex = 0;

 @ViewChild(MatPaginator) paginator!: MatPaginator;
 @ViewChild(MatSort) sort!: MatSort;
 constructor(private grievanceService: GrievanceService, private authServices: AuthService,
   private router: Router,
   private dialog: MatDialog,
   private loader: AppLoaderService,
   private alert: AppAlertService) { }

 formatDisplayDate(value: any): string {
   return displayDate(value);
 }

 ngOnInit(): void {


   const role = this.authServices.getRole()?.toUpperCase() || '';
   this.setupTabsForRole(role);

   this.loadGrievances();
 }

 private setupTabsForRole(role: string): void {
   if (role === 'AM') {
     this.showTabs = true;
     this.roleTabs = [
       { label: 'Grievance Entry / Approval', status: '01' },
       { label: 'Grievance Resolution / Approval', status: '09' }
     ];
   } else if (role === 'AC') {
     this.showTabs = true;
     this.roleTabs = [
       { label: 'Grievance Entry / Approval', status: '02' },
       { label: 'Grievance Resolution / Approval', status: '10' }
     ];
   }
 }

 ngAfterViewInit(): void {
   setTimeout(() => {
     this.dataSource.paginator = this.paginator;
     this.dataSource.sort = this.sort;
     this.configureDateSorting();
     this.applyLatestDateSort();
   });
 }

 loadGrievances(): void {
   this.loader.show();

   const role = this.authServices.getRole()?.toUpperCase() || '';
   const request = this.buildSearchRequest(role);

   forkJoin({
     grievances: this.grievanceService.searchGrievances(request),
     sources: this.grievanceService.getGrievanceSources(),
     categories: this.grievanceService.getGrievanceCategories()
   }).pipe(
     finalize(() => this.loader.hide())
   ).subscribe({
     next: ({ grievances, sources, categories }) => {
       const grievanceList = grievances?.data?.searchGrievances ?? [];

       const sourceMap = new Map<string, string>();
       sources.forEach(s => sourceMap.set(s.gsCd, s.gsDesc));

       const categoryMap = new Map<string, string>();
       categories.forEach(c => categoryMap.set(c.gcCd, c.gcDesc));

       this.dataSource.data = grievanceList.map((item: any) => ({
         grvNo: this.getGrievanceNo(item),
         receiptDate: item.gdCreatedDt,
         customerType: item.gdRequestType,
         name: item.gdComplaintName,
         gdCustEmpCd: item.gdCustEmpCd,
         source: sourceMap.get(item.gdGrevSource) ?? item.gdGrevSource,
         category: categoryMap.get(item.gdGrevCategory) ?? item.gdGrevCategory,
         branch: item.gdBranchVertical,
         complaint: item.gdComplaint,
         gdRequestType: item.gdRequestType == 'R' ? 'Request' : item.gdRequestType == 'C' ? 'Compliant' : item.gdRequestType == 'A' ? 'Appeal' : 'NA',
         status: item.gdStatus
       }));

       this.configureDateSorting();
       this.applyLatestDateSort();
     },
     error: (err: HttpErrorResponse) => {
       console.error('API FAILED:', err);
       this.alert.error('Unable to load grievance list');
     }
   });
 }

 private buildSearchRequest(role: string): any {
   const userDetails = this.authServices.getUserBranchDetails();
   const rolesWithBranch = ['BM', 'BC', 'RM', 'RC', 'VM', 'VC'];
   const gdBranchVerticalCd = rolesWithBranch.includes(role) && userDetails?.branchCd
     ? userDetails.branchCd : '';

   let gdStatus = '';
   if (this.showTabs && this.roleTabs[this.selectedTabIndex]) {
     gdStatus = this.roleTabs[this.selectedTabIndex].status;
   } else {
     gdStatus = this.roleStatusMap[role] ?? '';
   }

   return {
     gdStatus,
     gdBranchVerticalCd,
     gdGrevCategory: '',
     fromCreatedDt: '',
     toCreatedDt: ''
   };
 }

 applyBranchFilter(event: Event): void {
   const filterValue = (event.target as HTMLInputElement).value;
   this.dataSource.filter = filterValue.trim().toLowerCase();

   // ✅ Reset pagination after filter
   if (this.dataSource.paginator) {
     this.dataSource.paginator.firstPage();
   }
 }

 private readonly reviewToOpenRoles = new Set(['BM', 'BC', 'RM', 'RC', 'HM', 'HC']);

 openResolveDialog(row: any): void {

   if (!row?.grvNo) {
     this.alert.warning('Unable to open grievance. Grievance number is missing.');
     return;
   }

   const role = this.authServices.getRole()?.toUpperCase() ?? '';

   const status = row?.status;

   // ✅ Roles allowed unconditionally
   const allowedRoles = this.reviewToOpenRoles.has(role);

   // ✅ Conditional roles
   const isAMValid =
     role === 'AM'  && status === '09';

   const isACValid =
     role === 'AC'  && status === '10';


   if (allowedRoles || isAMValid || isACValid) {
     this.loader.show();

     forkJoin({
       grievance: this.grievanceService.getGrievanceDetails(row.grvNo),
       files: this.grievanceService.getGrievancefiles(row.grvNo)
     })
       .pipe(finalize(() => this.loader.hide()))
       .subscribe({
         next: ({ grievance, files }) => {
            const dialogRef = this.dialog.open(ReviewToOpenDialogComponent, {
              width: '80vw',
              maxWidth: '90vw',
              data: {
                grievance,
                row,
                files: Array.isArray(files) ? files : [],
                role
              },
             autoFocus: false,
             panelClass: 'review-to-open-dialog-panel'
           });

           dialogRef.afterClosed().subscribe(result => {
             if (result) {
               this.loadGrievances();
             }
           });
         },
         error: () => {
           this.alert.error('Unable to load grievance details');
         }
       });

     return;
   }

   // ✅ fallback for others
   this.router.navigate([this.getGrievanceActionRoute(), row.grvNo]);
 }

 onTabChange(index: number): void {
   this.selectedTabIndex = index;
   this.loadGrievances();
 }

 getActionLabel(row: any): string {
   const role = this.authServices.getRole()?.toUpperCase() ?? '';

   if (role === 'AC' && row?.status === '02') {
     return 'Review';
   }

   if (role === 'AM' && row?.status === '09') {
     return 'To Final Verify';
   }

   if (role === 'AC' && row?.status === '10') {
     return 'Verify and Close';
   }

   if (this.reviewToOpenRoles.has(role)) {
     return 'Review to Open';
   }

   return 'Open';
 }

 private getGrievanceNo(item: any): any {
   return item?.gdSrNo ??
     item?.gdSrno ??
     item?.gdSrNO ??
     item?.gd_sr_no ??
     item?.grvNo ??
     item?.grievanceNo ??
     item?.grievanceNumber ??
     '';
 }

 private getGrievanceActionRoute(): string {
   const role = this.authServices.getRole()?.toUpperCase();

   if (role === 'AC') {
     return '/grievance-review';
   }

   return '/grievance-update';
 }

 private configureDateSorting(): void {
   this.dataSource.sortingDataAccessor = (item: any, property: string) => {
     if (property === 'receiptDate') {
       return new Date(item.receiptDate).getTime() || 0;
     }

     return item[property];
   };
 }

 private applyLatestDateSort(): void {
   if (!this.sort) {
     return;
   }

   this.sort.active = 'receiptDate';
   this.sort.direction = 'desc';
   this.sort.sortChange.emit({
     active: this.sort.active,
     direction: this.sort.direction
   });
 }

}



