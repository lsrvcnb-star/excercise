import { CommonModule } from '@angular/common';
import {
 ChangeDetectorRef,
 Component,
 Inject,
 OnInit
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
 MAT_DIALOG_DATA,
 MatDialogModule,
 MatDialogRef
} from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { finalize } from 'rxjs';
import { GrievanceService }
from '../services/grievance.service';
@Component({
 selector: 'app-branch-vertical-lookup-dialog',
 standalone: true,
 imports: [
   CommonModule,
   FormsModule,
   MatDialogModule,
   MatIconModule,
   MatInputModule,
   MatTableModule
 ],
 templateUrl:
   './branch-vertical-lookup-dialog.html',
 styleUrls:
   ['./branch-vertical-lookup-dialog.css']
})
export class BranchVerticalLookupDialogComponent
implements OnInit {
 displayedColumns = ['NAME', 'CODE'];
 searchText = '';
 allRecords: any[] = [];
 filteredRecords: any[] = [];
 loading = false;
 constructor(
   private grievanceService:
     GrievanceService,
   private dialogRef:
     MatDialogRef<BranchVerticalLookupDialogComponent>,

   private cd:
     ChangeDetectorRef,

   @Inject(MAT_DIALOG_DATA)
   public data: any
 ) { }
 ngOnInit(): void {
   this.loadData();
 }
 loadData(): void {
   this.loading = true;

   this.allRecords = [];

   this.filteredRecords = [];

   this.cd.detectChanges();
   this.grievanceService
     .getBranchVerticalRo()
     .pipe(
       finalize(() => {
         this.loading = false;
         this.cd.detectChanges();
       })
     )
     .subscribe({
       next: (res: any[]) => {
         this.allRecords =
           (res || []).filter(item =>
             item.TYPE === this.data.type
           );
         this.filteredRecords =
           [...this.allRecords];

         this.cd.detectChanges();
       },
       error: () => {
         this.allRecords = [];
         this.filteredRecords = [];

         this.cd.detectChanges();
       }
     });
 }
 search(): void {
   const value =
     this.searchText
       .trim()
       .toLowerCase();
   if (!value) {
     this.filteredRecords =
       [...this.allRecords];

     this.cd.detectChanges();
     return;
   }
   this.filteredRecords =
     this.allRecords.filter(item =>
       item.NAME
         ?.toLowerCase()
         .includes(value)
       ||
       item.CODE
         ?.toLowerCase()
         .includes(value)
     );

   this.cd.detectChanges();
 }
 selectRecord(record: any): void {

   if (this.loading) {
     return;
   }
   this.dialogRef.close(record);
 }
}

