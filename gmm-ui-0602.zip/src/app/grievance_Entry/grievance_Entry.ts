import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule
} from '@angular/forms';

/* Angular Material */
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { BranchVerticalLookup, CustomerEmployeeLookup, GrievanceService } from '../services/grievance.service';
import { FileUploadComponent } from "../file-upload/file-upload";
import { AuthService } from '../services/auth.service';
import { ActivatedRoute, Router } from '@angular/router'
import { AppAlertService } from '../shared/app-alert/app-alert.service';
import { dateAtStartOfDay, dateOnly, stripHtml } from '../shared/utils';
import { CustomerEmployeeLookupDialogComponent } from './customer-employee-lookup-dialog';
import { BranchVerticalLookupDialogComponent } from './branch-vertical-lookup-dialog';
import { AppLoaderService } from '../shared/app-loader/app-loader.service';
import { finalize, firstValueFrom, forkJoin } from 'rxjs';
import { HttpResponse } from '@angular/common/http';
import { PreviousGrievanceLookupDialogComponent } from './previous-grievance-lookup-dialog/previous-grievance-lookup-dialog';

@Component({
  selector: 'app-grievance-entry',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatDatepickerModule,
    MatNativeDateModule,
    FileUploadComponent,
    MatExpansionModule,
    MatDialogModule
  ],
  templateUrl: './grievance_Entry.html',
  styleUrls: ['./grievance_Entry.css']
})
export class GrievanceEntryComponent implements OnInit {
  today: string = dateOnly(new Date());

  grievanceForm!: FormGroup;

  grievanceTypes = [{ "name": "Complaint", "id": "C" }, { "name": "Request", "id": "R" }, { "name": "Appeal", "id": "A" }];

  gdCustomerTypes = [{ "name": "Existing Customer", "id": "C" }, { "name": "Employee", "id": "E" }, { "name": "Others", "id": "O" }];


  grievanceSources: any[] = [];
  grievanceCategories: any[] = [];
  branchVerticalList: any[] = [];   // ✅ Derived from BASE API
  closedGrievances: any[] = [];

  grievanceSrNo: number | null = null;   // backend returns this
  grievanceStatus!: string;
  userRole: any; // derive later from AuthService

  showGrievanceSection = true;
  showUploadSection = false;

  STATUS_NEW = '01';
  STATUS_IN_PROGRESS = '02';
  STATUS_PENDING = '03';
  STATUS_CLARIFICATION = '04';
  STATUS_CLOSED = '05';
  STATUS_DUPLICATE = '10';
  grvNo!: string | null;
  listOfFiles: any[] = [];
  private nodalOfficerRecord: any | null = null;
  private isHydratingGrievanceData = false;
  saveAttempted = false;
  closedGrievancesLoading = false;


  constructor(
    private fb: FormBuilder,
    private grievanceService: GrievanceService,
    private aurhService: AuthService,
    private route: ActivatedRoute,
    private alert: AppAlertService,
    private dialog: MatDialog,
    private loader: AppLoaderService,
    private router: Router,
    private cd: ChangeDetectorRef,
  ) { }

  ngOnInit(): void {
    this.initializeForm();
    this.loadMasters();

    this.grievanceForm.get('gdCustEmpCd')?.valueChanges.subscribe(v => {
      if (v) {
        this.grievanceForm.patchValue(
          { gdCustEmpCd: v.toUpperCase() },
          { emitEvent: false }
        );
      }
    });

    this.grievanceForm.get('gdCustEmpFlag')?.valueChanges.subscribe(() => {
      if (!this.isHydratingGrievanceData) {
        this.clearLookupFields();
      }
      this.applyCustomerFieldAccess();
    });

    this.grievanceForm.get('gdBranchVertical')?.valueChanges.subscribe(() => {
      if (!this.isHydratingGrievanceData) {
        this.clearBranchVerticalLookupFields();
      }
      this.applyBranchLookupFieldAccess();
    });

    this.grievanceForm.get('grievanceType')?.valueChanges.subscribe(() => {
      this.applyGrievanceTypeAccess();
      if (!this.isHydratingGrievanceData) {
        const dateControl = this.grievanceForm.get('gdCreatedDt');
        if (dateControl && !dateControl.value) {
          dateControl.setValue(this.today, { emitEvent: false });
        }
      }
    });

    this.applyCustomerFieldAccess();
    this.applyBranchLookupFieldAccess();
    this.applyGrievanceTypeAccess();

    this.userRole = this.aurhService.getRole();
    this.grievanceStatus = this.STATUS_NEW;





    this.route.paramMap.subscribe(params => {
      this.grvNo = params.get('grvNo');

      if (this.grvNo) {
        this.getGrievanceData();
      }
    });



  }

  /* ================= CUSTOM VALIDATORS ================= */
  private noFutureDateValidator(): any {
    return (control: any) => {
      if (!control.value) return null;
      const inputDate = new Date(control.value);
      const today = new Date();
      today.setHours(23, 59, 59, 999);
      return inputDate > today ? { futureDate: true } : null;
    };
  }

  private validMobileValidator(): any {
    return (control: any) => {
      if (!control.value) return null;
      const val = control.value;
      if (!/^[0-9]{10}$/.test(val)) return null;
      if (/^(\d)\1{9}$/.test(val)) return { invalidMobile: true };
      return null;
    };
  }

  /* ================= FORM ================= */
  private initializeForm(): void {
    this.grievanceForm = this.fb.group({
      gdCreatedDt: ['', [Validators.required, this.noFutureDateValidator()]],
      grievanceType: ['', Validators.required],
      gdPreviousSrNo: [{ value: '', disabled: true }],

      gdCustEmpCd: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9]+$')]],
      gdComplaintName: ['', Validators.required],
      gdComplAdd: ['', Validators.required],
      gdSourceEmailId: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$')]],
      gdComplMobile: ['', [Validators.required, Validators.pattern('^[0-9]{10}$'), this.validMobileValidator()]],

      gdGrevSource: ['', Validators.required],
      gdGrevCategory: ['', Validators.required],


      gdBranchVertical: ['', Validators.required],
      branchVerticalName: ['', Validators.required],
      gdBranchVerticalCd: [{ value: '', disabled: true }, Validators.required],
      gdCustomerType: ['',],
      nodalOfficerName: ['', Validators.required],
      gdCustEmpFlag: ['', Validators.required],

      gdComplaint: ['', Validators.required]   // ✅ NOT mandatory now
    });
  }

  /* ================= MASTER LOAD ================= */
  private loadMasters(): void {
    this.loader.show();

    forkJoin({
      categories: this.grievanceService.getGrievanceCategories(),
      sources: this.grievanceService.getGrievanceSources(),

    }).pipe(
      finalize(() => this.loader.hide())
    ).subscribe({
      next: ({ categories, sources }) => {
        this.grievanceCategories = categories;
        this.grievanceSources = sources;

        const map = new Map<string, any>();



        this.branchVerticalList = Array.from(map.values());
      },
      error: () => {
        this.alert.error('Unable to load grievance masters');
      }
    });
  }

  /* ================= SAVE ================= */
  async save(): Promise<void> {
    this.saveAttempted = true;

    if (!this.validateBeforeSave()) {
      return;
    }

    const confirmed = await this.alert.confirm(
      'Please confirm that you want to save the grievance details. The current changes will be stored as draft.',
      'Save Draft',
      'OK',
      'Cancel',
      'info'
    );

    if (!confirmed) {
      return;
    }

    const payload = this.buildPayload('01', 'G');

    this.loader.show();

    const request$ = this.grievanceSrNo
      ? this.grievanceService.updateGrievance(payload, this.grievanceSrNo)
      : this.grievanceService.createGrievanceDraft(payload);

    request$.pipe(
      finalize(() => this.loader.hide())
    ).subscribe({
      next: (res: any) => {
        this.alert.success('Grievance saved successfully');
        this.saveAttempted = false;
        this.grievanceForm.markAsPristine();
        this.grievanceForm.markAsUntouched();
        this.showGrievanceSection = false;
        this.showUploadSection = true;

        // ✅ STORE SR NUMBER (CRUCIAL)
        this.grievanceSrNo = res.gdSrNo || this.grievanceSrNo;     // adjust key as per backend
        this.grievanceStatus = res.gdStatus || this.STATUS_NEW;

        if (this.isAdminMakerDraft()) {
          this.applyFormAccess();
        } else {
          this.grievanceForm.disable({ emitEvent: false });
        }
      },
      error: err => {
        console.error('❌ API error:', err);
        this.alert.error('Unable to save grievance');
      }
    });
  }

  /* ================= CLEAR ================= */
  clearForm(): void {
    this.grievanceForm.reset();
    this.grievanceForm.markAsPristine();
    this.grievanceForm.markAsUntouched();
  }

  openCustomerEmployeeLookup(): void {

    const customerType =
      this.grievanceForm.get('gdCustEmpFlag')?.value;

    if (!customerType) {

      this.alert.warning(
        'Please select Customer Type first'
      );

      return;
    }

    if (customerType === 'O') {
      return;
    }

    const dialogRef = this.dialog.open(
      CustomerEmployeeLookupDialogComponent,
      {
        width: '980px',
        maxWidth: '94vw',
        autoFocus: false,
        panelClass: 'lookup-dialog-panel',

        data: {

          title:
            customerType === 'C'
              ? 'Existing Customer Lookup'
              : 'Employee Lookup',

          type: customerType
        }
      }
    );

    dialogRef.afterClosed().subscribe(record => {

      if (record) {

        this.applyLookupRecord(
          customerType,
          record
        );
      }
    });
  }

  private applyLookupRecord(
    customerType: string,
    record: any
  ): void {

    if (customerType === 'C') {

      const address = [
        record.custAddr1,
        record.custAddr2,
        record.custAddr3,
        record.custCity
      ]
        .filter(Boolean)
        .join(', ');

      this.grievanceForm.patchValue({

        gdCustEmpCd:
          record.custCd,

        gdComplaintName:
          record.custLongName,

        gdSourceEmailId:
          record.custEmailId || '',

        gdComplAdd:
          address,

        gdComplMobile:
          record.mobileNo || ''
      });
    }

    else {

      this.grievanceForm.patchValue({

        gdCustEmpCd:
          record.employeeCode,

        gdComplaintName:
          record.name,

        gdSourceEmailId:
          `${record.emailId}@sidbi.in` || '',

        gdComplAdd:
          record.designationDescription || '',

        gdComplMobile:
          record.mobile || ''
      });
    }

    this.applyCustomerFieldAccess();
  }




  private clearLookupFields(): void {
    this.grievanceForm.patchValue({
      gdCustEmpCd: '',
      gdComplaintName: '',
      gdSourceEmailId: '',
      gdComplAdd: '',
      gdComplMobile: ''
    }, { emitEvent: false });
  }

  private applyCustomerFieldAccess(): void {
    const fields = [

      'gdComplaintName',
      'gdSourceEmailId',
      'gdComplAdd',
      'gdComplMobile'
    ];

    const isOthers = this.grievanceForm.get('gdCustEmpFlag')?.value === 'O';
    const customerCodeControl = this.grievanceForm.get('gdCustEmpCd');

    if (isOthers) {
      customerCodeControl?.clearValidators();
    } else {
      customerCodeControl?.setValidators([Validators.required]);
    }
    customerCodeControl?.updateValueAndValidity({ emitEvent: false });

    const shouldEnable = isOthers
      && !this.grievanceForm.disabled;

    fields.forEach(field => {
      const control = this.grievanceForm.get(field);

      if (shouldEnable) {
        control?.enable({ emitEvent: false });
      } else {
        control?.disable({ emitEvent: false });
      }
    });
  }

  private applyBranchLookupFieldAccess(): void {
    [
      'gdBranchVerticalCd',
      'nodalOfficerName'
    ].forEach(field => {
      this.grievanceForm.get(field)?.disable({ emitEvent: false });
    });
  }

  private applyGrievanceTypeAccess(): void {
    const control =
      this.grievanceForm.get('gdPreviousSrNo');

    const isAppeal =
      this.grievanceForm.get('grievanceType')?.value === 'A';

    if (isAppeal && !this.grievanceForm.disabled) {
      control?.setValidators([
        Validators.required,
        Validators.pattern('^[0-9]+$')
      ]);

      if (
        !this.closedGrievancesLoading &&
        this.closedGrievances.length === 0
      ) {
        this.loadClosedGrievances();
      } else if (!this.closedGrievancesLoading) {
        control?.enable({ emitEvent: false });
      }
    } else {
      control?.clearValidators();
      control?.setValue('', { emitEvent: false });
      control?.disable({ emitEvent: false });

      this.closedGrievances = [];
      this.closedGrievancesLoading = false;
    }

    control?.updateValueAndValidity({
      emitEvent: false
    });
  }

  loadClosedGrievances(): void {
    if (this.closedGrievancesLoading) {
      return;
    }

    this.closedGrievancesLoading = true;
    this.closedGrievances = [];

    const previousControl =
      this.grievanceForm.get('gdPreviousSrNo');

    previousControl?.disable({ emitEvent: false });

    this.grievanceService.searchGrievances({
      gdStatus: '11',
      gdBranchVerticalCd: '',
      gdGrevCategory: '',
      fromCreatedDt: '',
      toCreatedDt: ''
    }).pipe(
      finalize(() => {
        this.closedGrievancesLoading = false;

        const isAppeal =
          this.grievanceForm.get('grievanceType')?.value === 'A';

        if (isAppeal && !this.grievanceForm.disabled) {
          previousControl?.enable({ emitEvent: false });
        }

        this.cd.detectChanges();
      })
    ).subscribe({
      next: (res: any) => {
        const list = res?.data?.searchGrievances ?? [];

        this.closedGrievances = [...list].sort((a: any, b: any) => {
          const dateA = a?.gdApprovedDt
            ? new Date(a.gdApprovedDt).getTime()
            : 0;

          const dateB = b?.gdApprovedDt
            ? new Date(b.gdApprovedDt).getTime()
            : 0;

          return dateB - dateA; // Descending: latest first
        });
      },
      error: () => {
        this.closedGrievances = [];
        this.alert.error(
          'Unable to load closed grievances'
        );
      }
    });
  }

  onPreviousGrievanceChange(): void {
    const grievanceNo = this.grievanceForm.get('gdPreviousSrNo')?.value;
    if (!grievanceNo) return;

    this.loader.show();
    this.grievanceService.getGrievanceDetails(grievanceNo).pipe(
      finalize(() => this.loader.hide())
    ).subscribe({
      next: (details: any) => {
        this.isHydratingGrievanceData = true;

        this.grievanceForm.patchValue({
          gdCustEmpFlag: details.gdCustEmpFlag || '',
          gdCustEmpCd: details.gdCustEmpCd || '',
          gdComplaintName: details.gdComplaintName || '',
          gdSourceEmailId: details.gdSourceEmailId || '',
          gdComplAdd: details.gdComplAdd || '',
          gdComplMobile: details.gdComplMobile || '',
          gdGrevSource: details.gdGrevSource || '',
          gdGrevCategory: details.gdGrevCategory || '',
          gdComplaint: details.gdComplaint || '',
        }, { emitEvent: false });

        this.populateBranchVerticalFromDetails(details);
        this.applyCustomerFieldAccess();
        this.applyBranchLookupFieldAccess();

        this.isHydratingGrievanceData = false;
      },
      error: () => {
        this.alert.error('Unable to load previous grievance details');
      }
    });
  }

  getCustomerCodeLabel(): string {
    const customerType = this.grievanceForm?.get('gdCustEmpFlag')?.value;

    if (customerType === 'C') {
      return 'Customer Code';
    }

    if (customerType === 'E') {
      return 'Employee Code';
    }

    return 'Customer / Employee Code';
  }

  getCustomerCodePlaceholder(): string {
    const customerType = this.grievanceForm?.get('gdCustEmpFlag')?.value;

    if (customerType === 'O') {
      return 'Enter code';
    }

    if (customerType === 'C' || customerType === 'E') {
      return 'Click search to select';
    }

    return 'Select customer type first';
  }

  getBranchVerticalNameLabel(): string {
    const type = this.grievanceForm?.get('gdBranchVertical')?.value;

    if (type === 'B') {
      return 'Branch Name';
    }

    if (type === 'V') {
      return 'Vertical Name';
    }

    if (type === 'R') {
      return 'RO Name';
    }

    return 'Branch / Vertical / RO Name';
  }

  getBranchVerticalCodeLabel(): string {
    const type = this.grievanceForm?.get('gdBranchVertical')?.value;

    if (type === 'B') {
      return 'Branch Code';
    }

    if (type === 'V') {
      return 'Vertical Code';
    }

    if (type === 'R') {
      return 'RO Code';
    }

    return 'Code';
  }

  getBranchVerticalPlaceholder(): string {
    return this.grievanceForm?.get('gdBranchVertical')?.value
      ? 'Click search to select'
      : 'Select Branch / Vertical / RO first';
  }

  isLookupMissing(controlName: string): boolean {
    if (!this.saveAttempted || !this.grievanceForm) {
      return false;
    }

    const value = this.grievanceForm.getRawValue()[controlName];
    return value === null || value === undefined || String(value).trim() === '';
  }

  private populateCustomerEmployeeFromDetails(details: any): void {
    this.grievanceForm.patchValue({
      gdCustEmpFlag: details.gdCustEmpFlag || '',
      gdCustEmpCd: details.gdCustEmpCd || '',
      gdComplaintName: details.gdComplaintName || '',
      gdSourceEmailId: details.gdSourceEmailId || '',
      gdComplAdd: details.gdComplAdd || '',
      gdComplMobile: details.gdComplMobile || '',
      gdComplaint: details.gdComplaint || ''
    }, { emitEvent: false });
    this.applyCustomerFieldAccess();
  }

  openBranchVerticalLookup(): void {

    const type =
      this.grievanceForm
        .get('gdBranchVertical')
        ?.value;

    if (!type) {

      this.alert.warning(
        'Please select Branch / Vertical / RO'
      );

      return;
    }

    const dialogRef = this.dialog.open(
      BranchVerticalLookupDialogComponent,
      {
        width: '860px',
        maxWidth: '94vw',
        autoFocus: false,

        data: {

          title:
            type === 'B'
              ? 'Branch Lookup'
              : type === 'R'
                ? 'RO Lookup'
                : 'Vertical Lookup',

          type
        }
      }
    );

    dialogRef.afterClosed()
      .subscribe(record => {

        if (record) {

          this.applyBranchVerticalLookupRecord(
            record
          );
        }
      });
  }



  private openBranchVerticalLookupDialog(type: string, records: BranchVerticalLookup[]): void {
    const title = type === 'B'
      ? 'Branch List'
      : type === 'V'
        ? 'Vertical List'
        : 'RO List';

    const dialogRef = this.dialog.open(BranchVerticalLookupDialogComponent, {
      width: '860px',
      maxWidth: '94vw',
      data: {
        title,
        records
      },
      panelClass: 'lookup-dialog-panel',
      autoFocus: false
    });

    dialogRef.afterClosed().subscribe(record => {
      if (record) {
        this.applyBranchVerticalLookupRecord(record);
      }
    });
  }

  private applyBranchVerticalLookupRecord(
    record: any
  ): void {
    this.setBranchVerticalLookupRecord(record);
  }

  openPreviousGrievanceLookup(): void {
    const dialogRef = this.dialog.open(PreviousGrievanceLookupDialogComponent, {
      width: '900px',
      maxWidth: '94vw',
      autoFocus: false,
      panelClass: 'lookup-dialog-panel',
      data: {}
    });

    dialogRef.afterClosed().subscribe(record => {
      if (record) {
        this.grievanceForm.get('gdPreviousSrNo')?.setValue(record.grievanceNo, { emitEvent: false });
        this.onPreviousGrievanceChange();
      }
    });
  }

  private setBranchVerticalLookupRecord(
    record: any
  ): void {
    this.loader.show();

    this.grievanceService
      .getNodalOfficer(record.CODE)

      .pipe(
        finalize(() => this.loader.hide())
      )

      .subscribe({

        next: (res: any[]) => {

          this.nodalOfficerRecord = this.extractPrimaryNodalOfficer(res);
          const nodalOfficer = this.nodalOfficerRecord?.name || '';

          this.grievanceForm.patchValue({

            branchVerticalName:
              record.NAME,

            gdBranchVerticalCd:
              record.CODE,

            nodalOfficerName:
              nodalOfficer
          });
          this.applyBranchLookupFieldAccess();
        },

        error: () => {

          this.nodalOfficerRecord = null;
          this.alert.error(
            'Unable to load nodal officer'
          );
        }
      });
  }

  private populateBranchVerticalFromDetails(details: any): void {
    const type = details?.gdBranchVertical;
    const code = details?.gdBranchVerticalCd;

    this.grievanceForm.patchValue({
      gdBranchVertical: type || '',
      gdBranchVerticalCd: code || '',
      branchVerticalName:
        details.branchVerticalName ||
        details.gdBranchVerticalName ||
        '',
      nodalOfficerName:
        details.nodalOfficerName ||
        ''
    }, { emitEvent: false });

    if (!type || !code) {
      return;
    }

    this.grievanceService.getBranchVerticalRo().subscribe({
      next: (records: any[]) => {
        const record = (records || []).find(item =>
          item.TYPE === type &&
          String(item.CODE) === String(code)
        );

        if (record) {
          this.setBranchVerticalLookupRecord(record);
          return;
        }

        this.loadNodalOfficerForCode(code);
      },
      error: () => {
        this.loadNodalOfficerForCode(code);
      }
    });
  }

  private loadNodalOfficerForCode(code: string): void {
    this.grievanceService.getNodalOfficer(code).subscribe({
      next: (res: any[]) => {
        this.nodalOfficerRecord = this.extractPrimaryNodalOfficer(res);
        const nodalOfficer = this.nodalOfficerRecord?.name || '';

        this.grievanceForm.patchValue({
          nodalOfficerName: nodalOfficer
        }, { emitEvent: false });
        this.applyBranchLookupFieldAccess();
      },
      error: () => {
        this.nodalOfficerRecord = null;
        this.alert.error('Unable to load nodal officer');
      }
    });
  }

  private extractPrimaryNodalOfficer(response: any): any | null {
    if (Array.isArray(response) && Array.isArray(response[0])) {
      return response[0][0] || null;
    }

    if (Array.isArray(response)) {
      return response[0] || null;
    }

    return response || null;
  }

  /*   loadNodalOfficer(code: string): void {
      this.loader.show();
      this.grievanceService.searchNodalOfficer(code)
       .pipe(finalize(() => this.loader.hide()))
       .subscribe({
         next: (res: any) => {
            if (res && res.length > 0 && res[0].length > 0) {
              const officer = res[0][0];
              this.grievanceForm.patchValue({
               nodalOfficerName: officer.name
             });
           }
         },
         error: () => {
           this.alert.error('Unable to load nodal officer');
         }
       });
   } */

  private clearBranchVerticalLookupFields(): void {
    this.nodalOfficerRecord = null;
    this.grievanceForm.patchValue({
      branchVerticalName: '',
      gdBranchVerticalCd: '',
      nodalOfficerName: ''
    }, { emitEvent: false });
  }

  blockHtmlTag(event: KeyboardEvent): void {
    if (event.key === '<' || event.key === '>') {
      event.preventDefault();
    }
  }

  sanitizeInput(event: Event, controlName: string): void {
    const input = event.target as HTMLInputElement;
    input.value = stripHtml(input.value);
    this.grievanceForm.get(controlName)?.setValue(input.value, { emitEvent: false });
  }


allowOnlyAlphaNumeric(event: KeyboardEvent): void {
  const key = event.key;

  // Allow navigation/control keys
  const allowedKeys = [
    'Backspace',
    'Delete',
    'Tab',
    'ArrowLeft',
    'ArrowRight',
    'Home',
    'End'
  ];

  if (allowedKeys.includes(key)) {
    return;
  }

  // Allow only A-Z, a-z, 0-9
  if (!/^[a-zA-Z0-9]$/.test(key)) {
    event.preventDefault();
  }
}

sanitizeAlphaNumericInput(event: Event, controlName: string): void {
  const input = event.target as HTMLInputElement;

  // Remove everything except letters and numbers
  input.value = input.value.replace(/[^a-zA-Z0-9]/g, '');

  this.grievanceForm.get(controlName)?.setValue(input.value, {
    emitEvent: false
  });
}

  /* ================= PAYLOAD ================= */
  private buildPayload(grieStatusCode: string, srgr: string): any {

    const form = this.grievanceForm.getRawValue();

    const grievanceTypeMap: any = {
      Complaint: 'C',
      Request: 'R',
      Appeal: 'A'
    };

    const now = new Date();

    const formatDateTime = (d: string | Date) => {
      if (!d) return null;

      const dateObj = typeof d === 'string' ? new Date(d) : d;
      return dateObj.toISOString().split('.')[0]; // yyyy-MM-ddTHH:mm:ss
    };

    const created = localStorage.getItem("username")?.toUpperCase();
    //  const created = "akashvbm";

    return {

      /* ---- MANDATORY BACKEND / DUMMY FIELDS ---- */
      gdSrgrFlag: srgr,
      gdCustEmpFlag: form.gdCustEmpFlag,
      gdCreatedBy: created,
      gdCreatedDt: formatDateTime(now),
      gdBranchVerticalCd: form.gdBranchVerticalCd,

      /* ---- ENTRY SCREEN DATA ---- */
      gdRequestType: form.grievanceType,
      ...(form.grievanceType === 'A'
        ? { gdPreviousSrNo: stripHtml(String(form.gdPreviousSrNo || '').trim()) }
        : {}),
      gdSrgrDt: formatDateTime(now),
      gdCustEmpCd: form.gdCustEmpCd,
      gdComplaintName: stripHtml(form.gdComplaintName || ''),
      gdSourceEmailId: stripHtml(form.gdSourceEmailId || ''),
      gdComplAdd: stripHtml(form.gdComplAdd || ''),
      gdComplMobile: stripHtml(form.gdComplMobile || ''),

      /* ---- FIELD NAME ALIGNMENT ---- */
      gdGrevSource: stripHtml(form.gdGrevSource || ''),
      gdGrevCategory: stripHtml(form.gdGrevCategory || ''),
      gdBranchVertical: stripHtml(form.gdBranchVertical || ''),
      branchVerticalName: stripHtml(form.branchVerticalName || ''),
      /* ---- OPTIONAL ---- */
      gdComplaint: stripHtml(form.gdComplaint || ''),

      gdStatus: grieStatusCode
    };
  }


  logInvalidControls(): void {
    const invalidControls: string[] = [];

    Object.keys(this.grievanceForm.controls).forEach(controlName => {
      const control = this.grievanceForm.get(controlName);
      if (control && control.invalid) {
        invalidControls.push(controlName);
      }
    });
  }

  private validateBeforeSave(): boolean {
    this.grievanceForm.markAllAsTouched();

    if (this.grievanceForm.invalid) {
      this.logInvalidControls();
      this.alert.warning('Please fill all mandatory fields before saving');
      return false;
    }

    const missingLookupFields = this.getMissingLookupFields();

    if (missingLookupFields.length > 0) {
      this.alert.warning(
        `Please fill mandatory lookup fields: ${missingLookupFields.join(', ')}`
      );
      return false;
    }

    return true;
  }

  private getMissingLookupFields(): string[] {
    const form = this.grievanceForm.getRawValue();
    const isOthers = this.grievanceForm.get('gdCustEmpFlag')?.value === 'O';

    const fields = [
      ...(isOthers ? [] : [{ label: this.getCustomerCodeLabel(), value: form.gdCustEmpCd }]),
      { label: 'Complainant Name', value: form.gdComplaintName },
      { label: 'Email ID of Complainant', value: form.gdSourceEmailId },
      { label: 'Complainant Address', value: form.gdComplAdd },
      { label: 'Complainant Mobile No', value: form.gdComplMobile },
      { label: this.getBranchVerticalNameLabel(), value: form.branchVerticalName },
      { label: this.getBranchVerticalCodeLabel(), value: form.gdBranchVerticalCd },
      { label: 'Nodal Officer', value: form.nodalOfficerName }
    ];

    return fields
      .filter(field =>
        field.value === null ||
        field.value === undefined ||
        String(field.value).trim() === ''
      )
      .map(field => field.label);
  }

  canSaveDraft(): boolean {
    return this.userRole === 'AM'
      && this.grievanceStatus === '01'
      && (!this.grievanceSrNo || this.isAdminMakerDraft());
  }

  canForwardToChecker(): boolean {
    return this.userRole === 'AM'
      && this.grievanceStatus === '01'
      && this.grievanceSrNo !== null;
  }

  canResubmit(): boolean {
    return this.userRole === 'MAKER'
      && this.grievanceStatus === '04'; // Clarification
  }

  canDelete(): boolean {
    return this.userRole === 'AM'
      && this.grievanceStatus === '01';
  }

  canUploadComplaintDocuments(): boolean {
    return (this.userRole === 'AM'
      && this.grievanceStatus === this.STATUS_NEW
      && this.grievanceSrNo !== null)
      || (this.userRole === 'AC'
        && this.grievanceStatus === this.STATUS_IN_PROGRESS
        && this.grievanceSrNo !== null);
  }

  canAdminCheckerAct(): boolean {
    return this.userRole === 'AC'
      && this.grievanceStatus === this.STATUS_IN_PROGRESS
      && this.grievanceSrNo !== null;
  }

  canAssignGrievance(): boolean {
    return this.canAdminCheckerAct();
  }

  canReturnBack(): boolean {
    return this.canAdminCheckerAct();
  }

  canAdminCheckerDelete(): boolean {
    return this.userRole === 'AC'
      && this.grievanceStatus === this.STATUS_DUPLICATE
      && this.grievanceSrNo !== null;
  }

  canAdminCheckerSave(): boolean {
    return this.canAdminCheckerAct();
  }

  private isExistingDraftEditable(): boolean {
    return !!this.grvNo
      && this.userRole === 'AM'
      && this.grievanceStatus === this.STATUS_NEW;
  }

  private isAdminMakerDraft(): boolean {
    return this.userRole === 'AM'
      && this.grievanceStatus === this.STATUS_NEW;
  }

  private applyFormAccess(): void {
    if (this.isAdminMakerDraft()) {
      this.grievanceForm.enable({ emitEvent: false });
      this.applyCustomerFieldAccess();
      this.applyBranchLookupFieldAccess();
      this.applyGrievanceTypeAccess();
      return;
    }

    if (this.userRole === 'AC' && this.grievanceStatus === this.STATUS_IN_PROGRESS) {
      this.grievanceForm.disable({ emitEvent: false });
      this.grievanceForm.get('gdComplaint')?.enable({ emitEvent: false });
      return;
    }

    this.grievanceForm.disable({ emitEvent: false });
  }



  async forwardToChecker(): Promise<void> {

    if (this.grievanceSrNo) {

      if (this.grievanceForm.invalid) {
        this.logInvalidControls();
        this.grievanceForm.markAllAsTouched();
        return;
      }

      const missingLookupFields = this.getMissingLookupFields();

      if (missingLookupFields.length > 0) {
        this.alert.warning(
          `Please fill mandatory lookup fields: ${missingLookupFields.join(', ')}`
        );
        return;
      }

      if (!this.listOfFiles || this.listOfFiles.length === 0) {
        this.alert.warning('Please upload at least one complaint document before forwarding to GC');
        return;
      }

      const confirmed = await this.alert.confirm(
        'Please confirm that you want to save the current details and forward this grievance to GC.',
        'Forward to GC',
        'OK',
        'Cancel',
        'info'
      );

      if (!confirmed) {
        return;
      }

      const payload = {
        ...this.buildPayload('02', 'G'),
        gdApprovedBy: null,
        gdApprovedDt: null
      };

      this.loader.show();

      this.grievanceService.updateGrievance(payload, this.grievanceSrNo).pipe(
        finalize(() => this.loader.hide())
      ).subscribe({
        next: (res: any) => {
          this.alert.success('Grievance forwarded to GC successfully');

          this.grievanceForm.reset();
          this.grievanceForm.markAsPristine();
          this.grievanceForm.markAsUntouched();
          this.grievanceForm.enable({ emitEvent: false });
          this.listOfFiles = [];
          this.grievanceSrNo = null;
          this.grievanceStatus = this.STATUS_NEW;
          this.showGrievanceSection = true;
          this.showUploadSection = false;
          this.cd.detectChanges();

          this.router.navigate(['grievance-entry']);
        },
        error: err => {
          console.error('❌ API error:', err);
          this.alert.error('Unable to save grievance');
        }
      });
    }

  }

  async assignGrievance(): Promise<void> {
    if (!this.grievanceSrNo) {
      return;
    }

    if (this.grievanceForm.dirty) {
      this.alert.warning('Please save the Grievance Cell Remarks before proceeding with Assign Grievance');
      return;
    }

    const assignment = this.getAssignmentDecision();

    if (!assignment) {
      this.alert.warning('Please select Branch / RO / Vertical before assigning the grievance');
      return;
    }

    const confirmed = await this.alert.confirm(
      'Do you want to assign this grievance to Branch / RO / Vertical?',
      'Assign Grievance',
      'OK',
      'Cancel',
      'info'
    );

    if (!confirmed) {
      return;
    }

    const nodalOfficer = await this.resolveNodalOfficerForAssignment();

    if (!nodalOfficer?.gnoNodalEmpCd) {
      this.alert.error('Unable to find nodal officer for assignment');
      return;
    }

    const rawForm = this.grievanceForm.getRawValue();
    const isRO = rawForm.gdBranchVertical === 'R';
    const srgrFlag = isRO ? 'G' : 'S';
    const payload: any = {
      ...this.buildPayload(assignment.status, srgrFlag),
      gdAssignTo: nodalOfficer.gnoNodalEmpCd,
      gdAssignedBy: this.getCurrentUsername(),
      gdAssignedDt: this.formatDateTime(new Date())
    };
    if (isRO) {
      payload.gdApprovedBy = this.getCurrentUsername();
      payload.gdApprovedDt = this.formatDateTime(new Date());
    }

    this.loader.show();

    this.grievanceService.updateGrievance(payload, this.grievanceSrNo).pipe(
      finalize(() => this.loader.hide())
    ).subscribe({
      next: (res: any) => {
        this.grievanceStatus = res?.gdStatus || assignment.status;
        this.nodalOfficerRecord = nodalOfficer;
        this.grievanceForm.disable();
        this.alert.success(
          `Grievance assigned to ${assignment.label} successfully`
        );
        this.router.navigate(['grievance-list'])
      },
      error: err => {
        console.error('Assignment failed:', err);
        this.alert.error('Unable to assign grievance');
      }
    });
  }

  async saveGrievanceCellRemarks(): Promise<void> {
    if (!this.grievanceSrNo) {
      return;
    }

    const payload = this.buildPayload(this.grievanceStatus, 'G');

    this.loader.show();

    this.grievanceService.updateGrievance(payload, this.grievanceSrNo).pipe(
      finalize(() => this.loader.hide())
    ).subscribe({
      next: () => {
        this.alert.success('Grievance Cell Remarks saved successfully');
        this.grievanceForm.markAsPristine();
      },
      error: () => {
        this.alert.error('Unable to save Grievance Cell Remarks');
      }
    });
  }

  async returnBack(): Promise<void> {
    if (this.grievanceForm.dirty) {
      this.alert.warning('Please save the Grievance Cell Remarks before proceeding with Return Back');
      return;
    }

    const confirmed = await this.alert.confirm(
      'Do you want to return this grievance back to GC Maker?',
      'Return Back',
      'OK',
      'Cancel',
      'info'
    );

    if (!confirmed) {
      return;
    }

    const payload = {
      ...this.buildPayload('01', 'G'),
      gdApprovedBy: null,
      gdApprovedDt: null
    };

    this.loader.show();

    this.grievanceService.updateGrievance(payload, this.grievanceSrNo).pipe(
      finalize(() => this.loader.hide())
    ).subscribe({
      next: () => {
        this.alert.success('Grievance returned back to GC Maker successfully');
        this.grievanceForm.disable();
        this.router.navigate(['grievance-list']);
      },
      error: () => {
        this.alert.error('Unable to return back grievance');
      }
    });

  }

  async deleteAdminCheckerGrievance(): Promise<void> {
    if (!this.grievanceSrNo) return;

    const confirmed = await this.alert.confirm(
      'Are you sure you want to delete this grievance?',
      'Delete Grievance',
      'OK',
      'Cancel',
      'info'
    );

    if (!confirmed) return;

    this.loader.show();

    this.grievanceService.deleteGrievance(this.grievanceSrNo).pipe(
      finalize(() => this.loader.hide())
    ).subscribe({
      next: () => {
        this.alert.success('Grievance deleted successfully');
        this.grievanceForm.disable();
        this.router.navigate(['grievance-list']);
      },
      error: () => {
        this.alert.error('Unable to delete grievance');
      }
    });
  }

  private getAssignmentDecision(): { label: string; status: string } | null {
    const type = this.grievanceForm.getRawValue().gdBranchVertical;

    if (type === 'B') {
      return { label: 'Branch', status: '03' };
    }

    if (type === 'R') {
      return { label: 'RO', status: '05' };
    }

    if (type === 'V') {
      return { label: 'Vertical', status: '07' };
    }

    return null;
  }

  private async resolveNodalOfficerForAssignment(): Promise<any | null> {
    if (this.nodalOfficerRecord?.gnoNodalEmpCd) {
      return this.nodalOfficerRecord;
    }

    const branchVerticalCode = this.grievanceForm.getRawValue().gdBranchVerticalCd;

    if (!branchVerticalCode) {
      return null;
    }

    try {
      const response = await firstValueFrom(
        this.grievanceService.getNodalOfficer(branchVerticalCode)
      );
      this.nodalOfficerRecord = this.extractPrimaryNodalOfficer(response);
      return this.nodalOfficerRecord;
    } catch {
      return null;
    }
  }

  private getCurrentUsername(): string {
    return (
      this.aurhService.getUsername() ||
      localStorage.getItem('username') ||
      ''
    ).toUpperCase();
  }

  private formatDateTime(d: string | Date): string | null {
    if (!d) {
      return null;
    }

    const dateObj = typeof d === 'string' ? new Date(d) : d;
    return dateObj.toISOString().split('.')[0];
  }

  resubmit() {

  }

  async deleteGrievance(): Promise<void> {
    if (!this.grievanceSrNo) return;

    const confirmed = await this.alert.confirm(
      'Are you sure you want to delete this grievance?',
      'Delete Grievance',
      'OK',
      'Cancel',
      'info'
    );

    if (!confirmed) return;

    this.loader.show();

    this.grievanceService.deleteGrievance(this.grievanceSrNo).pipe(
      finalize(() => this.loader.hide())
    ).subscribe({
      next: () => {
        this.alert.success('Grievance deleted successfully');
        this.grievanceForm.disable();
        this.router.navigate(['grievance-list']);
      },
      error: () => {
        this.alert.error('Unable to delete grievance');
      }
    });
  }

  getGrievanceData() {
    if (this.grvNo) {
      this.loader.show();

      this.grievanceService.getGrievanceDetails(this.grvNo).pipe(
        finalize(() => this.loader.hide())
      ).subscribe((res) => {
        const parsedData: any = res;
        this.isHydratingGrievanceData = true;

        Object.keys(parsedData).forEach(key => {
          if (this.grievanceForm.contains(key)) {

            let value = parsedData[key];
            // ✅ FIX DATE FIELD
            if (key === 'gdCreatedDt' && value) {
              value = dateOnly(value); // yyyy-MM-dd without timezone conversion
            }

            this.grievanceForm.get(key)?.setValue(value, { emitEvent: false });
          }
          if (key == 'gdRequestType') {
            this.grievanceForm.get('grievanceType')?.setValue(parsedData[key], { emitEvent: false });
          }

          if (key == 'gdPreviousSrNo') {
            this.grievanceForm.get('gdPreviousSrNo')?.setValue(parsedData[key], { emitEvent: false });
          }
        });

        if (parsedData.gdCreatedDt) {
          this.grievanceForm.get('gdCreatedDt')?.setValue(dateOnly(parsedData.gdCreatedDt), { emitEvent: false });
        }

        this.populateCustomerEmployeeFromDetails(parsedData);
        this.grievanceSrNo = res.gdSrNo;
        this.grievanceStatus = res.gdStatus || this.STATUS_NEW;
        this.populateBranchVerticalFromDetails(parsedData);
        this.applyFormAccess();

        if (this.grievanceForm.get('grievanceType')?.value === 'A') {
          this.loadClosedGrievances();
        }

        this.showGrievanceSection = true;
        this.showUploadSection = true;
        this.applyAttachedFiles();
        this.isHydratingGrievanceData = false;
      })
    }
  }



  applyAttachedFiles() {
    if (this.grievanceSrNo) {
      this.grievanceService.getGrievancefiles(this.grievanceSrNo).subscribe({
        next: ((response: any) => {
          this.listOfFiles = Array.isArray(response) ? response : [];
          this.cd.detectChanges();
        }),
        error: () => {
          this.listOfFiles = [];
          this.alert.error('Unable to load grievance files');
        }
      })
    }
  }

  getAttachmentFileName(selectedFile: any): string {
    const srNo = selectedFile?.gfSrNo || this.grievanceSrNo || '';
    const fileNo = selectedFile?.gfSno || '';

    return `FILE_${srNo}_${fileNo}`;
  }

  downloadFile(selectedFile: any) {
    this.grievanceService.downloadGrievancefile(selectedFile?.gfSno).subscribe({
      next: (response: HttpResponse<Blob>) => {
        const blob = response.body as Blob;

        const fileName = this.getAttachmentFileName(selectedFile);

        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = fileName;

        document.body.appendChild(a);
        a.click();

        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      },
      error: (err) => {
        console.error('Download failed', err);
      }
    });
  }

  trackByGrievanceSrNo(
    index: number,
    grievance: any
  ): string | number {
    return grievance?.gdSrNo ?? index;
  }



}






