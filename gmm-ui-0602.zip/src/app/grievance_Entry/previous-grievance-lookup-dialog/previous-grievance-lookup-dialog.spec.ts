import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreviousGrievanceLookupDialog } from './previous-grievance-lookup-dialog';

describe('PreviousGrievanceLookupDialog', () => {
  let component: PreviousGrievanceLookupDialog;
  let fixture: ComponentFixture<PreviousGrievanceLookupDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PreviousGrievanceLookupDialog],
    }).compileComponents();

    fixture = TestBed.createComponent(PreviousGrievanceLookupDialog);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
