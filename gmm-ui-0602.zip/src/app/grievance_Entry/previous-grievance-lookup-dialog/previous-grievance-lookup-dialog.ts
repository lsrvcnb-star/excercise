import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, Inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { finalize } from 'rxjs';
import { GrievanceService } from '../../services/grievance.service';
import { displayDate } from '../../shared/utils';


@Component({
 selector: 'app-previous-grievance-lookup-dialog',
 standalone: true,
 imports: [
   CommonModule,
   FormsModule,
   MatDialogModule,
   MatIconModule,
   MatInputModule,
   MatTableModule
 ],
 templateUrl: './previous-grievance-lookup-dialog.html',
 styleUrls: ['./previous-grievance-lookup-dialog.css']
})
export class PreviousGrievanceLookupDialogComponent implements OnInit {

 displayedColumns = ['customerName', 'grievanceNo', 'grievanceDate', 'customerCode', 'customerType'];
 searchText = '';
 allRecords: any[] = [];
 filteredRecords: any[] = [];
 loading = false;

  customerTypeLabels: Record<string, string> = {
    C: 'Existing Customer',
    E: 'Employee',
    O: 'Others'
  };

  formatDate(dateStr: any): string {
    return displayDate(dateStr);
  }

 constructor(
   private grievanceService: GrievanceService,
   private dialogRef: MatDialogRef<PreviousGrievanceLookupDialogComponent>,
   private cd: ChangeDetectorRef,
   @Inject(MAT_DIALOG_DATA) public data: any
 ) {}

 ngOnInit(): void {
   this.loadData();
 }

loadData(): void {
  this.loading = true;
  this.allRecords = [];
  this.filteredRecords = [];
  this.cd.detectChanges();

  this.grievanceService.searchGrievances({
    gdStatus: '11',
    gdBranchVerticalCd: '',
    gdGrevCategory: '',
    fromCreatedDt: '',
    toCreatedDt: ''
  })
  .pipe(
    finalize(() => {
      this.loading = false;
      this.cd.detectChanges();
    })
  )
  .subscribe({
    next: (res: any) => {
      const list = res?.data?.searchGrievances ?? [];

      // Sort by approved date: latest first
      const sortedList = [...list].sort((a: any, b: any) => {
        const dateA = a?.gdApprovedDt
          ? new Date(a.gdApprovedDt).getTime()
          : 0;

        const dateB = b?.gdApprovedDt
          ? new Date(b.gdApprovedDt).getTime()
          : 0;

        return dateB - dateA;
      });

      this.allRecords = sortedList.map((r: any) => ({
        grievanceNo: r.gdSrNo,

        grievanceDate: this.formatDate( r.gdCreatedDt),

        // Optional, if approval date needs to be displayed
        approvedDate: this.formatDate(r.gdApprovedDt),

        customerName: r.gdComplaintName,
        customerCode: r.gdCustEmpCd,

        customerType:
          this.customerTypeLabels[r.gdCustEmpFlag] ||
          r.gdCustEmpFlag ||
          'N/A'
      }));

      this.filteredRecords = [...this.allRecords];
      this.cd.detectChanges();
    },

    error: () => {
      this.allRecords = [];
      this.filteredRecords = [];
      this.cd.detectChanges();
    }
  });
}

 search(): void {
   const value = this.searchText.trim().toLowerCase();
   if (!value) {
     this.filteredRecords = [...this.allRecords];
     this.cd.detectChanges();
     return;
   }
   this.filteredRecords = this.allRecords.filter(item =>
     item.customerName?.toLowerCase().includes(value) ||
     item.grievanceNo?.toLowerCase().includes(value) ||
     item.customerCode?.toLowerCase().includes(value)
   );
   this.cd.detectChanges();
 }

 selectRecord(record: any): void {
   if (this.loading) return;
   this.dialogRef.close(record);
 }


allowAlphaNumeric(event: KeyboardEvent): void {
  const char = String.fromCharCode(event.keyCode);

  if (!/^[a-zA-Z0-9 ]+$/.test(char)) {
    event.preventDefault();
  }
}


}



