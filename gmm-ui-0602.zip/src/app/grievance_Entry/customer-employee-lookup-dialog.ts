import { CommonModule } from '@angular/common';
import {
Component,
ChangeDetectorRef,
Inject,
OnDestroy
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
MAT_DIALOG_DATA,
MatDialogModule,
MatDialogRef
} from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import {
Subject,
debounceTime,
distinctUntilChanged,
switchMap,
takeUntil,
of,
catchError,
finalize
} from 'rxjs';
import {
GrievanceService
} from '../services/grievance.service';
@Component({
selector: 'app-customer-employee-lookup-dialog',
standalone: true,
imports: [
  CommonModule,
  FormsModule,
  MatDialogModule,
  MatIconModule,
  MatInputModule,
  MatTableModule
],
templateUrl:
  './customer-employee-lookup-dialog.html',
styleUrls:
  ['./customer-employee-lookup-dialog.css']
})
export class CustomerEmployeeLookupDialogComponent
implements OnDestroy {
 searchText = '';
 records: any[] = [];
 loading = false;
 invalidInput = false;
 displayedColumns: string[] = [];
 private destroy$ =
   new Subject<void>();
 private searchSubject =
   new Subject<string>();

 private readonly namePattern = /^[a-zA-Z\s]*$/;
constructor(
  private grievanceService:
    GrievanceService,
  private dialogRef:
    MatDialogRef<CustomerEmployeeLookupDialogComponent>,

  private cd:
    ChangeDetectorRef,

  @Inject(MAT_DIALOG_DATA)
  public data: any
) {
  /* COLUMNS */
  this.displayedColumns =
    data.type === 'C'
      ? [
          'custLongName',
          'custCd',
          'custCity'
        ]
      : [
          'name',
          'employeeCode',
          'designationDescription'
        ];
  /* SEARCH PIPELINE */
  this.initializeSearch();
}
 private initializeSearch(): void {
   this.searchSubject.pipe(
     debounceTime(500),
     distinctUntilChanged(),
     switchMap((value: string) => {
       value = value.trim();

       if (!this.namePattern.test(value)) {
         this.records = [];
         this.loading = false;
         this.cd.detectChanges();
         return of([]);
       }

       /* MINIMUM SEARCH LENGTH */
       if (value.length < 2) {
         this.records = [];
         this.loading = false;
         this.cd.detectChanges();
         return of([]);
       }

       this.loading = true;
       this.records = [];
       this.cd.detectChanges();

       const apiCall =
         this.data.type === 'C'
           ? this.grievanceService
               .searchCustomerByName(value)
           : this.grievanceService
               .searchEmployeeByName(value);
       return apiCall.pipe(
         catchError(() => {
           return of([]);
         }),
         finalize(() => {
           this.loading = false;
           this.cd.detectChanges();
         })
       );
     }),
     takeUntil(this.destroy$)
   ).subscribe({
     next: (res: any[]) => {
       this.records = res || [];
       this.cd.detectChanges();
     }
   });
 }
 search(): void {
   const value = this.searchText.trim();
   this.invalidInput = !this.namePattern.test(value) && value.length > 0;
   if (!this.invalidInput) {
     this.searchSubject.next(value);
   } else {
     this.records = [];
     this.cd.detectChanges();
   }
 }
 onKeyPress(event: KeyboardEvent): void {
   const char = event.key;
   if (!/^[a-zA-Z\s]$/.test(char) && char !== 'Backspace' && char !== 'Delete' && char !== 'Tab' && char !== 'Enter' && char !== 'ArrowLeft' && char !== 'ArrowRight' && char !== 'Home' && char !== 'End') {
     event.preventDefault();
   }
 }

 selectRecord(record: any): void {

  if (this.loading) {
    return;
  }

  this.dialogRef.close(record);
}
ngOnDestroy(): void {
  this.destroy$.next();
  this.destroy$.complete();
}
}



