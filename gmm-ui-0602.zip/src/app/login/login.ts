import {
 Component,
 ElementRef,
 ViewChild,
 AfterViewInit,
 effect,
 signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
 FormBuilder,
 FormGroup,
 ReactiveFormsModule,
 Validators
} from '@angular/forms';
import { Router } from '@angular/router';

import {
 AppServiceService,
 CaptchaResponse,
 LoginResponse
} from '../services/app-service.service';
import { EncryptDecryptService } from '../services/encrypt-decrypt.service';
import { AuthService } from '../services/auth.service';
import { AppAlertService } from '../shared/app-alert/app-alert.service';

@Component({
 selector: 'app-login',
 standalone: true,
 imports: [CommonModule, ReactiveFormsModule],
 templateUrl: './login.html',
 styleUrls: ['./login.css']
})
export class LoginComponent implements AfterViewInit {

 @ViewChild('captchaCanvas', { static: false })
 captchaCanvas!: ElementRef<HTMLCanvasElement>;

 form: FormGroup;
 loading = false;
 message = '';
 messageType: 'success' | 'danger' | '' = '';

 /* ✅ Captcha state */
 captchaData = signal<{ capId: number; capText: string } | null>(null);
 private captchaLoaded = false;

 constructor(
   private fb: FormBuilder,
   private sso: AppServiceService,
   private enc: EncryptDecryptService,
   private router: Router,
   private authService: AuthService,
   private alert: AppAlertService
 ) {
   this.form = this.fb.group({
     username: ['', Validators.required],
     password: ['', Validators.required],
     captcha: ['', Validators.required],
   });

   /* ✅ Redraw captcha only when captchaData changes */
   effect(() => {
     const data = this.captchaData();
     if (data && this.captchaCanvas) {
       setTimeout(() => this.drawCaptchaOnCanvas(data.capText), 0);
     }
   });
 }

 ngAfterViewInit(): void {
   this.loadCaptcha();
 }

 get f() {
   return this.form.controls;
 }

 /* ================= LOGIN ================= */
 async onSubmit(): Promise<void> {
   this.message = '';
   this.messageType = '';

   if (this.form.invalid || !this.captchaData()) {
     this.form.markAllAsTouched();
     this.fail('Please enter username, password, and captcha.');
     return;
   }

   if (
     String(this.f['captcha'].value || '').trim() !==
     String(this.captchaData()?.capText || '').trim()
   ) {
     this.fail('Captcha is incorrect. Please enter the text shown in the image.', true);
     return;
   }

   this.loading = true;
   const username = this.f['username'].value.trim();

   // Prevent a previous user's session from surviving a new login attempt.
   this.authService.clearSession();

   try {
     const encryptedPassword = await this.enc.encryptSSO(
       this.f['password'].value
     );

     const payload = {
       userName: username,
       password: encryptedPassword,
       capText: this.f['captcha'].value,
       capId: this.captchaData()!.capId,
       redirectUrl: 'http://localhost:4200'
     };

     this.sso.login(payload).subscribe({
       next: (data: LoginResponse | string) => {
         this.loading = false;
         const apiResponse = this.getApiResponse(data);

         if (
           apiResponse === 'Auth Success' ||
           apiResponse === 'User Already Logged In'
         ) {

           // ✅ Step 1: Save login token
           this.authService.setSession(username, typeof data === 'string' ? '' : data.authToken);

           // ✅ Step 2: Call authorization API
            this.authService.getAuthorizationToken(username).subscribe({
            next: (authResp) => {
                const role = String(authResp?.role ?? '').trim().toUpperCase();
                const token = String(authResp?.token ?? '').trim();
                const allowedRoles = ['AM', 'AC', 'BM', 'BC', 'RM', 'RC', 'HM', 'HC'];

                const validRole =
                  role !== '' &&
                  role !== 'NULL' &&
                  role !== 'UNDEFINED' &&
                  allowedRoles.includes(role);

                const validToken =
                  token !== '' &&
                  token !== 'NULL' &&
                  token !== 'UNDEFINED';

                // Do not expose the protected application unless both the
                // authorization role and token are present and usable.
                if (!validRole || !validToken) {
                  this.authService.clearSession();
                  this.fail('Authorization failed. Please contact administrator.');
                  return;
                }

                this.authService.setAuthorizationSession({
                  ...authResp,
                  role,
                  token
                });

                this.router.navigate(['/grievance-list']);
              },
              error: () => {
                this.authService.clearSession();
                this.fail('Authorization failed. Please contact administrator.');
              }
            });

           return;
         }

         this.handleLoginFailure(apiResponse);
       },
       error: (err) => this.handleLoginFailure(this.getErrorResponse(err))
     });

   } catch {
     this.fail('Encryption failed.');
   }
 }

 /* ================= CAPTCHA ================= */
 loadCaptcha(force = false): void {
   if (this.captchaLoaded && !force) {
     return;
   }

   const userName = this.f['username'].value || '';

   this.sso.getCaptcha(userName).subscribe({
     next: (res: CaptchaResponse) => {
       if (res?.apiResponse === 'Success' && res.capText) {
         this.captchaData.set({
           capId: res.capId,
           capText: res.capText
         });

         this.f['captcha'].setValue('');
         this.captchaLoaded = true;
       } else {
         this.showError('Unable to load captcha.');
       }
     },
     error: () => this.showError('Unable to load captcha.')
   });
 }

 refreshCaptcha(ev?: Event): void {
   ev?.preventDefault();
   this.captchaLoaded = false;
   this.loadCaptcha(true);
 }

 /* ================= HELPERS ================= */
 private fail(msg: string, refreshCaptcha = false): void {
   this.loading = false;
   this.messageType = 'danger';
   this.message = msg;
   this.alert.error(msg, 'Sign In Failed');

   if (refreshCaptcha) {
     this.refreshCaptcha();
   }
 }

 private showError(msg: string): void {
   this.messageType = 'danger';
   this.message = msg;
   this.alert.error(msg);
 }

 private handleLoginFailure(resp?: string): void {
   const response = (resp || '').trim();
   const normalized = response.toLowerCase();

   if (!response) {
     this.fail('Login failed. Please try again.', true);
   } else if (
     normalized === 'auth failed' ||
     normalized.includes('auth failed') ||
     normalized.includes('invalid credential') ||
     response.includes('49')
   ) {
     this.fail('Invalid username or password.', true);
   } else if (response.includes('775')) {
     this.fail('User locked. Contact administrator.', true);
   } else if (response.includes('532')) {
     this.fail('Password expired.', true);
   } else if (response.includes('533')) {
     this.fail('Account disabled.', true);
   } else if (response.includes('525')) {
     this.fail('User not found.', true);
   } else if (
     normalized === 'invalid captcha' ||
     normalized.includes('captcha')
   ) {
     this.fail('Captcha is incorrect. Please enter the text shown in the image.', true);
   } else {
     this.fail(response || 'Something went wrong.', true);
   }
 }

 private getApiResponse(data: LoginResponse | string | null | undefined): string {
   if (!data) {
     return '';
   }

   return typeof data === 'string'
     ? data
     : data.apiResponse || '';
 }

 private getErrorResponse(err: any): string {
   if (!err) {
     return '';
   }

   if (typeof err.error === 'string') {
     return err.error;
   }

   if (err.error?.apiResponse) {
     return err.error.apiResponse;
   }

   if (err.message) {
     return err.message;
   }

   return '';
 }

 /* ================= CAPTCHA DRAW ================= */
 private drawCaptchaOnCanvas(text: string): void {
   const canvas = this.captchaCanvas.nativeElement;
   const ctx = canvas.getContext('2d');
   if (!ctx) return;

   const width = 180;
   const height = 60;
   const ratio = window.devicePixelRatio || 1;

   canvas.width = width * ratio;
   canvas.height = height * ratio;
   canvas.style.width = width + 'px';
   canvas.style.height = height + 'px';
   ctx.scale(ratio, ratio);

   ctx.fillStyle = '#f8fafc';
   ctx.fillRect(0, 0, width, height);

   ctx.font = 'bold 28px monospace';
   ctx.fillStyle = '#1f2937';
   ctx.textBaseline = 'middle';

   text.split('').forEach((ch, i) => {
     ctx.save();
     ctx.translate(20 + i * 26, height / 2);
     ctx.rotate((Math.random() - 0.5) * 0.4);
     ctx.fillText(ch, 0, 0);
     ctx.restore();
   });
 }
}

