export const environment = {
  production: false,
  uat: true,
  url: 'https://ssouat.sidbi.in:8443/',
  lmsbeURL: "https://loanjourney-uat.sidbi.in/",
  api:'https://dashboards.sidbi.in/dashboardbe/',
  dashboard_url: 'https://dashboard-uat.sidbi.in/',
  encryptKey : "SIBDILMS@89*97",
  aesSecretkey_MIS : "FBVzadc/oFHpd0pHdzyD187R9f0LoSp3ZjEYfQn2n8A=",
  aesSecretkey_SSO: 'PTdbACnygKIqTP5+WhsRCiVq8DeKyWNVfQx2vo9T9eQ=',
  referrerUrl: 'https://info-uat.sidbi.in/',
  powerbiApi: 'https://dashboards.sidbi.in/',
  prayaasAPI: 'https://insights-prayaas.sidbi.in/',
  accessurl: 'https://dashboards.sidbi.in/sso/',
  acessManagementApp: 'https://pnd-dashboard.sidbi.in/api/master-access'
};
