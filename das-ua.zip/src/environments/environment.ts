// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  uat: false,
  url: 'https://ssouat.sidbi.in:8443/',
  lmsbeURL: "http://localhost:3001/",
  api:'http://localhost:3001/dashboardbe/',
  dashboard_url: 'https://dashboard-uat.sidbi.in/',
  encryptKey : "SIBDILMS@89*97",
  aesSecretkey_MIS : "FBVzadc/oFHpd0pHdzyD187R9f0LoSp3ZjEYfQn2n8A=",
  aesSecretkey_SSO: 'PTdbACnygKIqTP5+WhsRCiVq8DeKyWNVfQx2vo9T9eQ=',
  referrerUrl: '',
  powerbiApi: 'https://dashboards.sidbi.in/',
  prayaasAPI: 'https://insights-prayaas.sidbi.in/',
  accessurl: 'http://localhost:8080/',
  acessManagementApp: 'https://pnd-dashboard.sidbi.in/api/master-access'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
