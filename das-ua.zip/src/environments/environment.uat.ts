export const environment = {
  production: false,
  uat:true,
  url:'https://ssouat.sidbi.in:8443/',
  encryptKey : "SIBDILMS@89*97",
  prayaasAPI: 'https://insights-prayaas.sidbi.in/',
  aesSecretkey_MIS : "FBVzadc/oFHpd0pHdzyD187R9f0LoSp3ZjEYfQn2n8A=",
  aesSecretkey_SSO: 'PTdbACnygKIqTP5+WhsRCiVq8DeKyWNVfQx2vo9T9eQ=',
  acessManagementApp: 'https://pnd-dashboard.sidbi.in/api/master-access'

};
