import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MatTableModule } from '@angular/material/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { BnNgIdleService } from 'bn-ng-idle';
import { MatSnackBarModule } from '@angular/material/snack-bar';

import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatNativeDateModule } from '@angular/material/core';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';

import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AgGridModule } from 'ag-grid-angular';

import { AppRoutingModule } from './app-routing.module';
import { CookieService } from 'ngx-cookie-service';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { DcvComponent } from './dcv/dcv.component';
/*import { ComplianceComponent } from './compliance/compliance.component';
import { NbfcComponent } from './nbfc/nbfc.component';
import { SupersetPrayaasComponent } from './superset-prayaas/superset-prayaas.component'; */
import { LoaderService } from './loader.service';
import { HttpInterceptorService } from './http-interceptor.service';
import { SidebarComponent } from './sidebar/sidebar.component';
import { CommonModule } from '@angular/common';
import { SupersetPrayaasComponent } from './superset-prayaas/superset-prayaas.component';
import { ComplianceComponent } from './compliance/compliance.component';
import { NbfcComponent } from './nbfc/nbfc.component';
import { NbfcHomeComponent } from './nbfc-home/nbfc-home.component';
import { CommitteeComponent } from './committee/committee.component';
import { ComparativeDirective } from './comparative.directive';
import { PndComponent } from './pnd/pnd.component';
import { LoadingComponent } from './loading/loading.component';
import { GrievanceComponent } from './grievance/grievance.component';

import { FooterComponent } from './footer/footer.component';
import { PowebiComponent } from './powebi/powebi.component';
import { GrievancePowerbiComponent } from './grievance-powerbi/grievance-powerbi.component';
import { ArvComponent } from './arv/arv.component';
import { CommitteePbiComponent } from './committee-pbi/committee-pbi.component';
import { NbfcPowerbiComponent } from './nbfc-powerbi/nbfc-powerbi.component';
import { NbfcHomePowerbiComponent } from './nbfc-home-powerbi/nbfc-home-powerbi.component';
import { PrayaasPowerbiComponent } from './prayaas-powerbi/prayaas-powerbi.component';
import { DcvPerformanceComponent } from './dcv-performance/dcv-performance.component';
import { ProjectTrackerComponent } from './project-tracker/project-tracker.component';
import { VisitMonitorComponent } from './visit-monitor/visit-monitor.component';
import { DormComponent } from './dorm/dorm.component';
import { EboComponent } from './ebo/ebo.component';
import { VentureDebtsComponent } from './venture-debts/venture-debts.component';
import { IncubatorComponent } from './incubator/incubator.component';
import { PreDebtsComponent } from './pre-debts/pre-debts.component';
import { AnchorInvestmentComponent } from './anchor-investment/anchor-investment.component';
import { ItvOpsComponent } from './itv-ops/itv-ops.component';
import { BenificiaryComponent } from './benificiary/benificiary.component';
import { ElseComponent } from './else/else.component';
import { IfvPortfolioDashboardComponent } from './ifv-portfolio-dashboard/ifv-portfolio-dashboard.component';
import { AssetRecoveryComponent } from './asset-recovery/asset-recovery.component';
import { DivExecutiveComponent } from './div-executive/div-executive.component';
import { VentureFinanceComponent } from './venture-finance/venture-finance.component';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    HomeComponent,
    SidebarComponent,
    DcvComponent,
    ComplianceComponent,
    NbfcComponent,
    NbfcHomeComponent,
    SupersetPrayaasComponent,
    ComplianceComponent,
    CommitteeComponent,
    ComparativeDirective,
    PndComponent,
    LoadingComponent,
    GrievanceComponent,
    PowebiComponent,
    FooterComponent,
    GrievancePowerbiComponent,
    ArvComponent,
    CommitteePbiComponent,
    NbfcPowerbiComponent,
    NbfcHomePowerbiComponent,
    PrayaasPowerbiComponent,
    DcvPerformanceComponent,
    ProjectTrackerComponent,
    VisitMonitorComponent,
    DormComponent,
    EboComponent,
    VentureDebtsComponent,
    IncubatorComponent,
    PreDebtsComponent,
    AnchorInvestmentComponent,
    ItvOpsComponent,
    BenificiaryComponent,
    ElseComponent,
    IfvPortfolioDashboardComponent,
    AssetRecoveryComponent,
    DivExecutiveComponent,
    VentureFinanceComponent
  ],
  imports: [
    HttpClientModule,
    MatNativeDateModule,
    MatSelectModule,
    BrowserModule,
    AppRoutingModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatCardModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatTableModule,
    MatAutocompleteModule,
    MatInputModule,
    MatSnackBarModule,    
    CommonModule,
    AgGridModule.withComponents([])
  ],
  providers: [CookieService, BnNgIdleService, LoaderService,
    {
      provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService, multi: true
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
