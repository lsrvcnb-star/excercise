import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { PowerBiService, TrackVisitPayload } from '../power-bi.service';
import { DashboardServiceService } from '../dashboard-service.service';
import * as pbi from 'powerbi-client';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-grievance-powerbi',
  templateUrl: './grievance-powerbi.component.html',
  styleUrls: ['./grievance-powerbi.component.scss']
})
export class GrievancePowerbiComponent implements OnInit {
  @ViewChild('reportContainer', { static: true }) reportContainer!: ElementRef;
  selctedUser: boolean = false;
  setHight:string = '2200px'
  errorMessage: any[] = [];
  reportType = 'grievance-powerbi-all'
  selectedUser: any[] = ['saravananm', 'ragrawal', 'sriram', 'pthakkur',];
  constructor(private powerBiService: PowerBiService, private elementRef: ElementRef, private dashboardServiceService: DashboardServiceService, private cookieService: CookieService,) { }

  ngOnInit(): void {
    
    this.dashboardServiceService.changeTitle('Grievance Dashboard - PBI');
    const user = this.cookieService.get('UserID').toLowerCase();
    if(user && this.selectedUser.includes(user)){
        this.setHight = '2200px';
      this.reportType = 'grievance'
    } else {
this.reportType = 'grievance-powerbi-all';
this.setHight = '2000px';
      /* const deviceRatio = Math.round(window.devicePixelRatio * 100); // Get the device pixel ratio
      console.log(deviceRatio)
      if(deviceRatio == 150){
        this.setHight = '1530px'
      } else if(deviceRatio == 135){
        this.setHight = '1703px'
      } else if(deviceRatio == 165){
        this.setHight = '1387px'
      } else if(deviceRatio == 90){
        this.setHight = '1823px'
      } else if(deviceRatio == 100){
        this.setHight = '1637px'
      }
      else if(deviceRatio == 110){
        this.setHight = '1483px'
      } */
    }

this.embedReport();

  }

  embedReport(): void {
    this.clearExistingPowerBiEmbed();
    this.tracking();
    this.powerBiService.getEmbedToken(this.reportType).subscribe(
      (embedData) => {
        const models = pbi.models;
        const reportLoadConfig: pbi.IEmbedConfiguration = {
          type: 'report',
          tokenType: models.TokenType.Embed,
          accessToken: embedData.embedToken,
          embedUrl: embedData.embedReports[0].embedUrl,
          settings: {
            navContentPaneEnabled:false,
            panes: {
              filters: {
                visible: true,
              },
              pageNavigation: {
                visible: false,
              },

            },
            background: pbi.models.BackgroundType.Transparent,
            layoutType: pbi.models.LayoutType.Custom,
            customLayout: {
              displayOption: models.DisplayOption.FitToPage,
            }
          }
        };

        // Embed Power BI report
        const powerbi = new pbi.service.Service(
          pbi.factories.hpmFactory,
          pbi.factories.wpmpFactory,
          pbi.factories.routerFactory // Add this argument
        );
        const report = powerbi.embed(
          this.reportContainer.nativeElement,
          reportLoadConfig
        );
        // Handle events
        report.on('loaded', () => console.log('Report loaded successfully'));
        report.on('rendered', () => {
          console.log('Report rendered successfully');
          this.reportContainer.nativeElement.querySelector("iframe").style.height = this.setHight;
        });
        // Adjust the size of the embedded iframe
        report.on('error', (event: any) => {
          this.errorMessage = event.detail.split('\r\n');
          console.error('Power BI Error:', event.detail);
        });
      },
      (error) => {
        this.elementRef.nativeElement.innerHTML = `<div class="text-center text-danger p-5">Error loading Power BI report</div>`;
        console.error('Error fetching embed token', error.error);
        this.errorMessage = ['Failed to fetch Power BI Embed Token.'];
      }
    );
  }


  clearExistingPowerBiEmbed(): void {
    const powerbi = new pbi.service.Service(
      pbi.factories.hpmFactory,
      pbi.factories.wpmpFactory,
      pbi.factories.routerFactory // Add this argument
    );
    powerbi.reset(this.reportContainer.nativeElement);
    this.reportContainer.nativeElement.innerHTML = ''; // Clear any previous content
  }

  
          tracking() {
            const user = this.cookieService.get('UserID').toLowerCase();
            const payload: TrackVisitPayload = {
              userId: user + '@sidbi.in',
              empId: user,
              dbVertical: 'Operational',
              dbName: 'Grievance'
            };
        
            this.powerBiService.trackVisit(payload).subscribe({
              next: () => console.log('Visit tracked'),
              error: (err) => console.error('Track failed', err)
            });
          }
  

}
