import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GrievancePowerbiComponent } from './grievance-powerbi.component';

describe('GrievancePowerbiComponent', () => {
  let component: GrievancePowerbiComponent;
  let fixture: ComponentFixture<GrievancePowerbiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GrievancePowerbiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GrievancePowerbiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
