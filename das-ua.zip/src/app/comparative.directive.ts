import { Directive, ElementRef, Input, Renderer2 } from '@angular/core';
import { debounceTime, fromEvent, throttleTime } from 'rxjs';

@Directive({
  selector: '[appComparative]'
})
export class ComparativeDirective {
  @Input() minHeight: number = 475;
  @Input() minWidth: number = 1155;
  @Input("fluidHeight") topOffset: number;
  @Input("fluidWidth") leftOffset: number;
  private domElement: HTMLElement;

  constructor(private renderer: Renderer2, private elementRef: ElementRef) {
    this.domElement = this.elementRef.nativeElement as HTMLElement;
    // register on window resize event
    fromEvent(window, "resize").pipe(throttleTime(500), debounceTime(500)).subscribe(() => {
      this.setHeight();
      this.setWidth();
    });
  }



  ngAfterViewInit() {
    this.setHeight();
    this.setWidth();
  }

  private setHeight() {
    const windowHeight = window?.innerHeight;
    const topOffset = this.topOffset || this.calcTopOffset();
    let height = windowHeight - topOffset;

    // set min height instead of the calculated

    if (this.minHeight && height < this.minHeight) {
      height = this.minHeight;
    }
    this.renderer.setStyle(this.domElement, "top", `${height}px`);
  }

  setWidth() {
    const windowWidth = window.innerWidth;
    const leftOffset = this.leftOffset || this.calcLeftOffset();
    const deviceRatio = Math.round(window.devicePixelRatio * 100);
    let left: number = 0;
    if (deviceRatio == 100) {
      left = 1155;
      this.renderer.setStyle(this.domElement, "display", `flex`);
    }  else if (deviceRatio == 80) {
      left = 1440;
      this.renderer.setStyle(this.domElement, "display", `flex`);
    } else if (deviceRatio == 90) {
      left = 1270;
      this.renderer.setStyle(this.domElement, "display", `flex`);
    } else if (deviceRatio == 110) {
      left = 1070;
      this.renderer.setStyle(this.domElement, "display", `flex`);
    } else if (deviceRatio == 120){
      left = 1340;
      this.renderer.setStyle(this.domElement, "display", `flex`);
    } else if (deviceRatio == 125){
      left = 960;
      this.renderer.setStyle(this.domElement, "display", `flex`);
    } else if(deviceRatio == 150){
      left =  1100;
      /* this.renderer.setStyle(this.domElement, "display", `flex`);
      this.renderer.setStyle(this.domElement, "width", `${9}rem`);
      this.renderer.setStyle(this.domElement, "font-size", `${0.7}rem`); */
    } else if(deviceRatio == 135){
      left =  1200;
    /*   this.renderer.setStyle(this.domElement, "display", `flex`);
      this.renderer.setStyle(this.domElement, "width", `${9}rem`);
      this.renderer.setStyle(this.domElement, "font-size", `${0.7}rem`); */
    } else if(deviceRatio == 165){
      left =  1010;
     /*  this.renderer.setStyle(this.domElement, "display", `flex`);
      this.renderer.setStyle(this.domElement, "width", `${7}rem`);
      this.renderer.setStyle(this.domElement, "font-size", `${8}px`); */
    } else if(deviceRatio == 188){
      left =  895;
     /*  this.renderer.setStyle(this.domElement, "display", `flex`);
      this.renderer.setStyle(this.domElement, "width", `${7}rem`);
      this.renderer.setStyle(this.domElement, "font-size", `${8}px`); */
    }

    this.renderer.setStyle(this.domElement, "left", `${left}px`);
  }
  private calcTopOffset(): number {
    try {
      const rect = this.domElement.getBoundingClientRect();
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      return rect.top + scrollTop;
    }
    catch (e) {
      return 0;
    }
  }


  private calcLeftOffset(): number {
    try {
      const rect = this.domElement.getBoundingClientRect();
      const scrollTop = window.pageYOffset || document.documentElement.scrollWidth;
      return scrollTop - rect.left
    }
    catch (e) {
      return 0;
    }
  }


   }


