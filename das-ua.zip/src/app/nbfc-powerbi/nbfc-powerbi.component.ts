import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nbfc-powerbi',
  templateUrl: './nbfc-powerbi.component.html',
  styleUrls: ['./nbfc-powerbi.component.scss']
})
export class NbfcPowerbiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
