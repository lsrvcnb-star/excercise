import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NbfcPowerbiComponent } from './nbfc-powerbi.component';

describe('NbfcPowerbiComponent', () => {
  let component: NbfcPowerbiComponent;
  let fixture: ComponentFixture<NbfcPowerbiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NbfcPowerbiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NbfcPowerbiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
