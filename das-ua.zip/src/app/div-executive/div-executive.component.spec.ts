import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DivExecutiveComponent } from './div-executive.component';

describe('DivExecutiveComponent', () => {
  let component: DivExecutiveComponent;
  let fixture: ComponentFixture<DivExecutiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DivExecutiveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DivExecutiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
