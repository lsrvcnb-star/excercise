import { Component, ElementRef, OnInit } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { CookieService } from 'ngx-cookie-service';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-grievance',
  templateUrl: './grievance.component.html',
  styleUrls: ['./grievance.component.scss']
})
export class GrievanceComponent implements OnInit {

  constructor(private dashboardServiceService: DashboardServiceService, private router: Router,
    private titleService: Title,
    private elementRef: ElementRef,
    private cookie:CookieService, private accountService: AccountService) { }

  ngOnInit(): void {
    this.embedComplianceDashboard('grievance');
    this.dashboardServiceService.changeTitle('Grievance Dashboard (CFY)');
  }


  embedComplianceDashboard(selected: string): void {
    const dashboardElement = this.elementRef.nativeElement.querySelector('#grievance-dashboard');

    if (dashboardElement) {
      this.dashboardServiceService.embedDashboard(dashboardElement, selected).subscribe(
        () => {
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%';
            iframe.style.height = '2800px';
          }
        },
          (error) => {
          console.error(error);
        }
      );
    }
  }

}
