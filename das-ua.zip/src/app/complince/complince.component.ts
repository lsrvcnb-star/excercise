import { Component, ElementRef, OnInit } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { CookieService } from 'ngx-cookie-service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { AccountService } from '../account.service';
import { AnyCatcher } from 'rxjs/internal/AnyCatcher';

@Component({
  selector: 'app-complince',
  templateUrl: './complince.component.html',
  styleUrls: ['./complince.component.scss']
})
export class ComplinceComponent implements OnInit {
  ischecked: string = '';

  constructor(private dashboardServiceService: DashboardServiceService, private router: Router, private titleService: Title, private elementRef: ElementRef,private cookie:CookieService, private accountService: AccountService) { }

  ngOnInit(): void {
    if(this.cookie.get('UserID') == '' ||
    this.cookie.get("UserID") == undefined){
      this.router.navigate(['/login']);
    }
    else{
      this.complainceSelect('regulatory');
    }
    this.dashboardServiceService.changeTitle('Compliance Dashboard');
  }

  embedComplianceDashboard(selected: string): void {
    const dashboardElement = this.elementRef.nativeElement.querySelector('#compliance-dashboard');

    if (dashboardElement) {
      this.dashboardServiceService.embedDashboard(dashboardElement, selected).subscribe(
        () => {
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%';
            if (selected == 'internal') {
              iframe.style.height = '1580px';
            } else if (selected == 'regulatory') {
              iframe.style.height = '2110px';
            }
          }
        },
          (error) => {
          console.error(error);
        }
      );
    }
  }

  complainceSelect(selectedTab: string) {
    this.ischecked = selectedTab;
    if (selectedTab == 'regulatory') {
      this.embedComplianceDashboard('regulatory');
    } else {
      this.embedComplianceDashboard('internal');
    }


    console.log(selectedTab);
  }

}
