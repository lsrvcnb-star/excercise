import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AuthguardGuard } from './shared/authguard.guard';
import { DcvComponent } from './dcv/dcv.component';
import { SupersetPrayaasComponent } from './superset-prayaas/superset-prayaas.component';
import { ComplianceComponent } from './compliance/compliance.component';
import { NbfcHomeComponent } from './nbfc-home/nbfc-home.component';
import { CommitteeComponent } from './committee/committee.component';
import { PndComponent } from './pnd/pnd.component';
import { GrievanceComponent } from './grievance/grievance.component';
import { PowebiComponent } from './powebi/powebi.component';
import { GrievancePowerbiComponent } from './grievance-powerbi/grievance-powerbi.component';
import { ArvComponent } from './arv/arv.component';
import { CommitteePbiComponent } from './committee-pbi/committee-pbi.component';
import { NbfcPowerbiComponent } from './nbfc-powerbi/nbfc-powerbi.component';
import { NbfcHomePowerbiComponent } from './nbfc-home-powerbi/nbfc-home-powerbi.component';
import { DcvPerformanceComponent } from './dcv-performance/dcv-performance.component';
import { CompliancePowerbiComponent } from './compliance-powerbi/compliance-powerbi.component';
import { PrayaasPowerbiComponent } from './prayaas-powerbi/prayaas-powerbi.component';
import { ProjectTrackerComponent } from './project-tracker/project-tracker.component';
import { VisitMonitorComponent } from './visit-monitor/visit-monitor.component';
import { DormComponent } from './dorm/dorm.component';
import { EboComponent } from './ebo/ebo.component';
import { AccessGuard } from './shared/access.guard';
import { VentureDebtsComponent } from './venture-debts/venture-debts.component';
import { IncubatorComponent } from './incubator/incubator.component';
import { PreDebtsComponent } from './pre-debts/pre-debts.component';
import { AnchorInvestmentComponent } from './anchor-investment/anchor-investment.component';
import { ItvOpsComponent } from './itv-ops/itv-ops.component';
import { BenificiaryComponent } from './benificiary/benificiary.component';
import { ElseComponent } from './else/else.component';
import { IfvPortfolioDashboardComponent } from './ifv-portfolio-dashboard/ifv-portfolio-dashboard.component';
import { AssetRecoveryComponent } from './asset-recovery/asset-recovery.component';
import { DivExecutiveComponent } from './div-executive/div-executive.component';
import { VentureFinanceComponent } from './venture-finance/venture-finance.component';



const routes: Routes = [
  /* { path: 'dcv', component: DcvComponent, canActivate: [AuthguardGuard, AccessGuard] }, */
  /* { path: 'compliance', component: ComplianceComponent, canActivate: [AuthguardGuard, AccessGuard] }, */
  /* { path: 'committee', component: CommitteeComponent, canActivate: [AuthguardGuard, AccessGuard] }, */
  { path: 'committee', component: CommitteePbiComponent, canActivate: [AuthguardGuard, AccessGuard] },
  /* { path: 'nbfc', component: NbfcHomeComponent, canActivate: [AuthguardGuard, AccessGuard] }, */
  {path: 'nbfc', component: NbfcHomePowerbiComponent, canActivate: [AuthguardGuard, AccessGuard]},
  { path: 'home', component: HomeComponent, canActivate: [AuthguardGuard] },
  { path: 'sfmc', component: PrayaasPowerbiComponent, canActivate: [AuthguardGuard, AccessGuard] },
  { path: 'sfmc-powerbi', component: PrayaasPowerbiComponent, canActivate: [AuthguardGuard, AccessGuard]},
  { path: 'pnd', component: PndComponent, canActivate: [AuthguardGuard, AccessGuard] },
/*   { path: 'grievance', component: GrievanceComponent, canActivate: [AuthguardGuard, AccessGuard]}, */
  { path: 'dcv', component: PowebiComponent, canActivate: [AuthguardGuard, AccessGuard]},
  { path: 'arv', component: ArvComponent, canActivate: [AuthguardGuard, AccessGuard]},
  { path: 'dcv-performance', component: DcvPerformanceComponent, canActivate: [AuthguardGuard, AccessGuard]},
  { path: 'grievance', component: GrievancePowerbiComponent, canActivate: [AuthguardGuard, AccessGuard]},
  { path: 'ebo', component: EboComponent, canActivate: [AuthguardGuard, AccessGuard]},
    { path: 'compliance', component: CompliancePowerbiComponent, canActivate: [AuthguardGuard, AccessGuard]},
    { path: 'visitMonitor', component: VisitMonitorComponent, canActivate: [AuthguardGuard, AccessGuard]},
    { path: 'dorm', component: DormComponent, canActivate: [AuthguardGuard, AccessGuard]},

    { path: 'venture-debts', component: VentureDebtsComponent, canActivate: [AuthguardGuard, AccessGuard]},
    { path: 'incubator', component: IncubatorComponent, canActivate: [AuthguardGuard, AccessGuard]},
   /*  { path: 'pre-debts', component: PreDebtsComponent, canActivate: [AuthguardGuard, AccessGuard]}, */
    { path: 'anchor-investment', component: AnchorInvestmentComponent, canActivate: [AuthguardGuard, AccessGuard]},
    { path: 'itv-ops', component: ItvOpsComponent, canActivate: [AuthguardGuard, AccessGuard]},
    { path: 'beneficiary', component: BenificiaryComponent, canActivate: [AuthguardGuard, AccessGuard]},
     { path: 'elsc', component: ElseComponent, canActivate: [AuthguardGuard, AccessGuard]},

     { path: 'ifv-portfolio', component: IfvPortfolioDashboardComponent, canActivate: [AuthguardGuard, AccessGuard] },
     { path: 'div', component: DivExecutiveComponent, canActivate: [AuthguardGuard, AccessGuard]},
     { path: 'venture-finance', component: VentureFinanceComponent, canActivate: [AuthguardGuard, AccessGuard]},
     { path: 'project_tracker', component: ProjectTrackerComponent},
     { path: 'asset-recovery', component: AssetRecoveryComponent},

  { path: 'login', component: LoginComponent },
  { path: '**', redirectTo: '/login' }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
