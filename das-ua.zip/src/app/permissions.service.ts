// permissions.service.ts
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, map, tap } from 'rxjs';
import { DashboardServiceService, MasterAccessResponse } from './dashboard-service.service';

@Injectable({ providedIn: 'root' })
export class PermissionsService {
  private allowedRoutes$ = new BehaviorSubject<Set<string>>(new Set());
  private loadedForUserId: string | null = null;

  constructor(private accessService: DashboardServiceService) {}

  ensureLoaded(userId: string): Observable<Set<string>> {
    if (this.loadedForUserId === userId && this.allowedRoutes$.value.size > 0) {
      return this.allowedRoutes$.asObservable();
    }

    return this.accessService.check(userId).pipe(
      map((res: MasterAccessResponse) => {
        if (!res.authorized) throw new Error('NOT_AUTHORIZED');
        if (!res.user) throw new Error('NO_USER_OBJECT');
        const isActive = (res.user.IS_ACTIVE || '').toString().trim().toUpperCase();
        if (isActive !== 'Y') throw new Error('INACTIVE');

        const accessToRaw = (res.user.ACCESS_TO || '').trim();
        if (accessToRaw.toUpperCase() === 'ALL') {
          return new Set<string>(['*']);
        }

        const tokens = accessToRaw
          .split(',')
          .map(t => t.trim())
          .filter(Boolean)
          .map(t => t.toLowerCase());

        return new Set<string>(tokens);
      }),
      tap(set => {
        this.loadedForUserId = userId;
        this.allowedRoutes$.next(set);
      })
    );
  }

  canAccess(routePath: string): boolean {
    const normalized = (routePath || '').toLowerCase();
    const cur = this.allowedRoutes$.value;
    if (cur.has('*')) return true;
    return cur.has(normalized);
  }

  clear(): void {
    this.loadedForUserId = null;
    this.allowedRoutes$.next(new Set());
  }
}