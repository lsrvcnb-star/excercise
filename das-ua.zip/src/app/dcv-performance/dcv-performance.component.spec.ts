import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DcvPerformanceComponent } from './dcv-performance.component';

describe('DcvPerformanceComponent', () => {
  let component: DcvPerformanceComponent;
  let fixture: ComponentFixture<DcvPerformanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DcvPerformanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DcvPerformanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
