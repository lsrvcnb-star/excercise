import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, from, map, Observable, of, switchMap, tap } from 'rxjs';
import { UserInterface } from './app.userInterface';
import { environment } from 'src/environments/environment';
import * as CryptoJS from 'crypto-js';
import { CookieService } from 'ngx-cookie-service';
import { EncryptDecryptService } from './encrypt-decrypt.service';
import { AccountService } from './account.service';


@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {

  public userSubject: BehaviorSubject<UserInterface | null>
  public user$: Observable<UserInterface | null>

  // loading and authentication subject
  private isLoadingSubject = new BehaviorSubject<boolean>(true);
  public isAuthenticatedSubject = new BehaviorSubject<boolean>(false); // making this public for login comp to access

  url: string = environment.lmsbeURL;
  encryptKey: string = environment.encryptKey;

  constructor(
    private httpClient: HttpClient,
    private cookieService: CookieService,
    private accountService: AccountService,
    private encryptDecryptService: EncryptDecryptService
  ) {
    this.userSubject = new BehaviorSubject<UserInterface | null>(null);
    this.user$ = this.userSubject.asObservable();
  }

  get isLoading$(): Observable<boolean> {
    return this.isLoadingSubject.asObservable();
  }

  get isAuthenticated$(): Observable<boolean> {
    return this.isAuthenticatedSubject.asObservable();
  }

  // return cookie value | null
  private getCookie(name: string): string | null {
    return this.cookieService.get(name) ? this.cookieService.get(name) : null;
  }

  validateTableUser(): Observable<any> {
    const userID = this.getCookie('UserID');
    const authToken = this.getCookie('authToken');
    if (!userID || !authToken) {
      this.isAuthenticatedSubject.next(false);
      this.isLoadingSubject.next(false);
      // return empty observable for invalid cookie state
      return new Observable();
    }

    return from(this.encryptDecryptService.encryptMIS(userID)).pipe(
      switchMap(encryptedUser => {
        const payload = {
            userName: encryptedUser,
            authToken: authToken
          };
        const url = environment.accessurl + 'auth/uservalid';
        return this.httpClient.post(url,payload).pipe(
          tap((response: any) => {
          if (response.apiResponse === "Valid") {
            this.setUser();
            this.isAuthenticatedSubject.next(true);
          } else {
            this.isAuthenticatedSubject.next(false);
            this.userSubject.next(null);
            this.accountService.deleteCookies();
          }
          this.isLoadingSubject.next(false);
        })
        )

      })
    )
  }

  validateSsoUser(): Observable<any> {
    const userID = this.getCookie('UserID');
    const authToken = this.getCookie('authToken');
    if (!userID || !authToken) {
      this.isAuthenticatedSubject.next(false);
      this.isLoadingSubject.next(false);
      // return empty observable for invalid cookie state
      return new Observable();
    }
    // sso service uservalid check
    return this.httpClient.post(environment.url + 'login-1.0/uservalid',
    {
      'userName': userID,
      'authToken': authToken
    }).pipe(
        tap((response: any) => {
          if (response.apiResponse === "Valid") {
            this.setUser();
            this.isAuthenticatedSubject.next(true);
          } else {
            this.isAuthenticatedSubject.next(false);
            this.userSubject.next(null);
            this.accountService.deleteCookies();
          }
          this.isLoadingSubject.next(false);
        })
      );
  }

  setUser() {
    const user = this.cookieService.get("UserID");
    const authToken = this.cookieService.get("authToken");
    this.userSubject.next({ user: user, token: authToken });
  }

  encryptUserData = (data:any) => {
    const encryptedString = CryptoJS.AES.encrypt(JSON.stringify(data), this.encryptKey).toString();
    return encryptedString;
  }

  authorizeUser(userId: string) {
    return this.httpClient.post(this.url + 'lmsbe/authorizeLogin', { 'userId': this.encryptUserData(userId) }, { headers: { "Content-Type": "application/json", 'Accept': 'application/json' } })
  }


}
