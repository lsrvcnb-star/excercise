import { Component, OnInit } from '@angular/core';
import { LoaderService } from '../loader.service';

@Component({
  selector: 'app-http-loader',
  templateUrl: './http-loader.component.html',
  styleUrls: ['./http-loader.component.scss']
})
export class HttpLoaderComponent implements OnInit {

  loading: boolean = false;
  constructor(
    private loaderService: LoaderService,
  ) {
    this.loaderService.isLoading$.subscribe({
      next: (status: boolean) => {
        this.loading = status;
      },
      error: () => {
        this.loading = false;
      }
    })
  }

  ngOnInit(): void {
  }

}
