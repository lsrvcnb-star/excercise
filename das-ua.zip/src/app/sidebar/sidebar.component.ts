import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  selected_page: string = 'home';
  @Output() selectedMenu = new EventEmitter<string>();
  currentRouter: string;
  constructor(private router: Router) { }

  ngOnInit(): void {
    this.currentRouter = this.router.url;
    if (this.currentRouter == '/') {
      this.selected_page = 'home';
    } else if (this.currentRouter == '/prayaas') {
      this.selected_page = 'prayaas'
    }
  }

  updateSuperset(page: string) {
    this.selected_page = page;
    // this.embedSupersetDashboard(page);
    this.selectedMenu.emit(page);
  }
}
