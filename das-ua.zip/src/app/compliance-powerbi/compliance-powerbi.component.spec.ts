import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompliancePowerbiComponent } from './compliance-powerbi.component';

describe('CompliancePowerbiComponent', () => {
  let component: CompliancePowerbiComponent;
  let fixture: ComponentFixture<CompliancePowerbiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompliancePowerbiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompliancePowerbiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
