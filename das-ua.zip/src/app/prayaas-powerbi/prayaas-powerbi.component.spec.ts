import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrayaasPowerbiComponent } from './prayaas-powerbi.component';

describe('PrayaasPowerbiComponent', () => {
  let component: PrayaasPowerbiComponent;
  let fixture: ComponentFixture<PrayaasPowerbiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrayaasPowerbiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrayaasPowerbiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
