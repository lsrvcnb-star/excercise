import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { PowerBiService, TrackVisitPayload } from '../power-bi.service';
import { DashboardServiceService } from '../dashboard-service.service';
import { CookieService } from 'ngx-cookie-service';
import * as pbi from 'powerbi-client';

@Component({
  selector: 'app-prayaas-powerbi',
  templateUrl: './prayaas-powerbi.component.html',
  styleUrls: ['./prayaas-powerbi.component.scss']
})
export class PrayaasPowerbiComponent implements OnInit {
  @ViewChild('prayaasPowerbi', { static: true }) reportContainer!: ElementRef;
  errorMessage: any[] = [];
  selected_page: string = 'prayaasV2'
  slectedHeight: any = '3000px';
  borderClass: string = 'prayaasClass';
  constructor(private powerBiService: PowerBiService, private elementRef: ElementRef, private dashboardServiceService: DashboardServiceService, private cookieService: CookieService,
    private cd: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.embedReport('prayaasV2');
    this.dashboardServiceService.changeTitle('SIDBI foundation for Microcredit (SFMC) - Executive Dashboard');
    const user = this.cookieService.get('UserID').toLowerCase();
  }

  embedReport(reportId): void {

    this.selected_page = reportId;

    this.clearExistingPowerBiEmbed();
    this.powerBiService.getEmbedToken(reportId).subscribe(
      (embedData) => {
        this.tracking();
        const models = pbi.models;
        const reportLoadConfig: pbi.IEmbedConfiguration = {
          type: 'report',
          tokenType: models.TokenType.Embed,
          accessToken: embedData.embedToken,
          embedUrl: embedData.embedReports[0].embedUrl,
          settings: {
            navContentPaneEnabled: false,
            panes: {
              filters: {
                visible: true,
              },
              pageNavigation: {
                visible: false,
              },

            },
            background: pbi.models.BackgroundType.Transparent,
            layoutType: pbi.models.LayoutType.Custom,
            customLayout: {
              displayOption: models.DisplayOption.FitToPage,
            }
          }
        };

        // Embed Power BI report
        const powerbi = new pbi.service.Service(
          pbi.factories.hpmFactory,
          pbi.factories.wpmpFactory,
          pbi.factories.routerFactory // Add this argument
        );
        const report = powerbi.embed(
          this.reportContainer.nativeElement,
          reportLoadConfig
        );
        // Handle events
        report.on('loaded', () => console.log('Report loaded successfully'));
        report.on('rendered', () => {
          console.log('Report rendered successfully');
          this.reportContainer.nativeElement.querySelector("iframe").style.height = this.slectedHeight;
        });
        // Adjust the size of the embedded iframe
        report.on('error', (event: any) => {
          this.errorMessage = event.detail.split('\r\n');
          console.error('Power BI Error:', event.detail);
        });
      },
      (error) => {
        console.error('Error fetching embed token', error);
        this.errorMessage = ['Failed to fetch Power BI Embed Token.'];
      }
    );
    this.cd.detectChanges();
  }

  clearExistingPowerBiEmbed(): void {
    const powerbi = new pbi.service.Service(
      pbi.factories.hpmFactory,
      pbi.factories.wpmpFactory,
      pbi.factories.routerFactory // Add this argument
    );
    powerbi.reset(this.reportContainer.nativeElement);
    this.reportContainer.nativeElement.innerHTML = ''; // Clear any previous content
  }

    tracking() {
      const user = this.cookieService.get('UserID').toLowerCase();
      const payload: TrackVisitPayload = {
        userId: user + '@sidbi.in',
        empId: user,
        dbVertical: 'IFV',
        dbName: 'Prayaas V2'
      };
  
      this.powerBiService.trackVisit(payload).subscribe({
        next: () => console.log('Visit tracked'),
        error: (err) => console.error('Track failed', err)
      });
    }

}
