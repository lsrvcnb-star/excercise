import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from "@angular/router"
import { CookieService } from 'ngx-cookie-service';
import { AccountService } from './account.service';
import { AuthserviceService } from './authservice.service';

declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  isLoading$ = this.authService.isLoading$;

  constructor(
    private AccountService: AccountService,
    private router: Router,
    private cookieService: CookieService,
    private authService: AuthserviceService
  ) { }

  ngOnInit(): void {

    const user = this.cookieService.get('UserID'); // get the user Name

    const tableUser = this.AccountService.tableUser(user);
    if (tableUser) {
      this.authService.validateTableUser().subscribe(() => {
        const isAuthenticated = this.authService.isAuthenticated$;
        if (isAuthenticated) {
          if (this.router.url == '/project_tracker') {
            this.router.navigate(['/project_tracker'])
          } else {

            this.router.navigate(['/home']);
          }
        } else {
          this.router.navigate(['/login'])
        }
      })
    } else {
      this.authService.validateSsoUser().subscribe(() => {
        const isAuthenticated = this.authService.isAuthenticated$;
        if (isAuthenticated) {
          if (this.router.url == '/project_tracker') {
            this.router.navigate(['/project_tracker'])
          } else {

            this.router.navigate(['/home']);
          }
        } else {
          this.router.navigate(['/login'])
        }
      })
    }
  }
}
