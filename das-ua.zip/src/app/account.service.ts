import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CookieService } from 'ngx-cookie-service';
import { BehaviorSubject, delay, from, Observable, of, switchMap } from 'rxjs';
import { EncryptDecryptService } from './encrypt-decrypt.service';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  headerClass = new BehaviorSubject('nbfc-class');
  currentHeaderClass = this.headerClass.asObservable();

  private winRefs: Array<Window> = [];

  constructor(
    private httpClient: HttpClient,
    private cookieservice: CookieService,
    private encryptDecryptService: EncryptDecryptService
  ) { }

  updateHeaderClass(clsName: string) {
    this.headerClass.next(clsName);
  }

  login(login_data: any) {
    return this.httpClient.post(environment.url + "login-1.0/login", {
      "userName": login_data['userName'],
      "password": login_data['password'],
      "capId": login_data['capId'],
      "capText": login_data['capText'],
      "redirectUrl": "http://localhost:8443/"
    });
  }

  logout() {
    const user = this.cookieservice.get("UserID");
    const selectedUser = this.tableUser(user);
    if (selectedUser) {
      return this.logoutTableUser(selectedUser);
    } else {
      return this.httpClient.delete(environment.url + 'login-1.0/deluser', {
        'body': { 'userName': this.cookieservice.get("UserID") }
      })
    }
  }

  logoutTableUser(user: any) {
    return from(this.encryptDecryptService.encryptMIS(user)).pipe(
      switchMap(encryptedUser => {
        const payload = { userName: encryptedUser };
        const url = environment.accessurl + 'auth/deluser';

        return this.httpClient.post(url, payload)

      })
    );
  }

  captcha() {
    return this.httpClient.post(environment.url + 'login-1.0/getCaptcha', {
      'userName': ''
    })
  }

  getConfig() {
    return this.httpClient.get('assets/config.json');

  }

  // compliance authorization
  user_access() {
    return this.httpClient.get(environment.api + 'users', {});
  }

  // returns winRefs array
  getWindowReferences(): Array<Window> {
    return this.winRefs;
  }

  // push window references of dashboards opened to winRefs array
  windowReferences(winRef: Window) {
    this.winRefs.push(winRef);
  }

  clearWindowRefs() {
    let winRefs = this.winRefs;

    if (winRefs && winRefs.length > 0) {
      winRefs.forEach((ref: Window) => {
        ref.close();
      })
    }

  }

  deleteCookies(): void {
    this.cookieservice.set("UserID", '',
      {
        expires: new Date('Thu, 01 Jan 1970 00:00:01 GMT'),
        path: '/',
        domain: 'sidbi.in'
      });
    this.cookieservice.set("authToken", '',
      {
        expires: new Date('Thu, 01 Jan 1970 00:00:01 GMT'),
        path: '/',
        domain: 'sidbi.in'
      });

    // remove loan journey cookie values
    if (this.cookieservice.get('username') && this.cookieservice.get('lmsAuthToken')) {
      this.cookieservice.delete('username', '/', 'sidbi.in');
      this.cookieservice.delete('lmsAuthToken', '/', 'sidbi.in');
    }

    // remove loan journey bearer token values
    if (this.cookieservice.get('userToken')) {
      this.cookieservice.delete('userToken');
    }
  }

  getUserIP() {
    return this.httpClient.get(environment.url + 'login-1.0/getClientIp',);
  }

  getMasterAccessList(user: string) {
    return from(this.encryptDecryptService.encryptMIS(user)).pipe(
      switchMap(encryptedUser => {
        const payload = { userName: encryptedUser };
        const url = environment.accessurl + 'auth/getMasterAccessList';

        return this.httpClient.post(url, payload)

      })
    );
    // return of({
    //   dept: "ALL",
    //   userName: "nisg_salamonraja"
    // }).pipe(delay(400));
  }

  getAccessList(user: string) {
    return from(this.encryptDecryptService.encryptMIS(user)).pipe(
      switchMap(encryptedUser => {
        const payload = { userName: encryptedUser };
        const url = environment.accessurl + 'auth/getAccessList';

        return this.httpClient.post(url, payload)

      })
    );
    // return of({
    //   dept: "ALL",
    //   userName: "nisg_salamonraja"
    // }).pipe(delay(400));
  }

  // for CDAC
  tableUser(userName: string): any {
    const users = [
      {
        user: 'vapt_userA'
      },
      {
        user: 'vapt_userB'
      },
      {
        user: 'cmd'
      },
      {
        user: 'cmdsecretariat'
      },
      {
        user: 'saravananm',
      },
      {
        user: 'standon'
      },
      {
        user: 'parul'
      },
      {
        user: 'santanu',
      },
      {
        user: 'bipinkumar',
      }
    ]
    return users.find((user: any) => user.user === userName);
  }


  getAccessToken(): Observable<{ access_token: string }> {
    const tenantId = '6e001869-c40c-4edf-aa16-9eff4917feb3';
    const clientId = '9430373d-edae-4068-9b96-ad8fce2bff6f';
    const clientSecret = 'jeT8Q~eKJzQ1aEdlRSE6USTc90FxEv.EmVksAavm';
    const authority = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;
    const body = new URLSearchParams();
    body.set('grant_type', 'client_credentials');
    body.set('client_id', clientId);
    body.set('client_secret', clientSecret);
    body.set('scope', `https://analysis.windows.net/powerbi/api/.default`);

    const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });

    return this.httpClient.post<{ access_token: string }>(authority, body.toString(), { headers });
  }

}
