import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArvComponent } from './arv.component';

describe('ArvComponent', () => {
  let component: ArvComponent;
  let fixture: ComponentFixture<ArvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ArvComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ArvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
