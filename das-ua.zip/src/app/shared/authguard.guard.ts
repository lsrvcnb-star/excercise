import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, } from '@angular/router';
import { map, Observable } from 'rxjs';
import { AuthserviceService } from '../authservice.service';

@Injectable({
  providedIn: 'root'
})
export class AuthguardGuard implements CanActivate {

  constructor(
    private authService: AuthserviceService,
    private router: Router,) {

  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> {

    return this.authService.isAuthenticated$.pipe(
      map((isAuthenticated)=>{
        if(!isAuthenticated){
          this.router.navigate(['/login'])
        }
        return isAuthenticated;
      })
    )
  }

}
