// access.guard.ts
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie-service';
import { PermissionsService } from '../permissions.service';

@Injectable({ providedIn: 'root' })
export class AccessGuard implements CanActivate {
  constructor(
    private permissions: PermissionsService,
    private cookie: CookieService,
    private router: Router
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    const userId = this.cookie.get('UserID');
    const path = (route.routeConfig?.path || '').toLowerCase();

    // Let open routes (like login) pass through. If a route has no path, allow it.
    if (!path) return of(true);

    if (!userId) {
      alert('Session Invalid. Please login again.');
      this.router.navigate(['/login']);
      return of(false);
    }

    return this.permissions.ensureLoaded(userId).pipe(
      map(() => {
        const ok = this.permissions.canAccess(path);
        if (!ok) {
          alert(`You are not authorized to access ${path} Dashboard`);
          this.router.navigate(['/home']);
        }
        return ok;
      }),
      catchError(err => {
        const msg = err?.message;
        if (msg === 'NOT_AUTHORIZED') {
          alert(`You are not authorized to access ${path} Dashboard`);
        } else if (msg === 'INACTIVE') {
          alert('Your access is inactive. Please contact the administrator.');
        } else {
          console.error('Authorization check failed:', err);
          alert('Authorization check failed. Please try again later.');
        }
        this.router.navigate(['/home']);
        return of(false);
      })
    );
  }
}