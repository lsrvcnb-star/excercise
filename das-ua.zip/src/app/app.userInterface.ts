export interface UserInterface {
    user: string,
    token: string
}