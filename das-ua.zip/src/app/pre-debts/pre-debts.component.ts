import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pre-debts',
  templateUrl: './pre-debts.component.html',
  styleUrls: ['./pre-debts.component.scss']
})
export class PreDebtsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
