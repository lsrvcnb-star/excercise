import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreDebtsComponent } from './pre-debts.component';

describe('PreDebtsComponent', () => {
  let component: PreDebtsComponent;
  let fixture: ComponentFixture<PreDebtsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PreDebtsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PreDebtsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
