import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommitteePbiComponent } from './committee-pbi.component';

describe('CommitteePbiComponent', () => {
  let component: CommitteePbiComponent;
  let fixture: ComponentFixture<CommitteePbiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommitteePbiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommitteePbiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
