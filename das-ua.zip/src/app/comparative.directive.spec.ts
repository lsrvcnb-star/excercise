import { ComparativeDirective } from './comparative.directive';

describe('ComparativeDirective', () => {
  it('should create an instance', () => {
    const directive = new ComparativeDirective();
    expect(directive).toBeTruthy();
  });
});
