import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { AccountService } from '../account.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AuthserviceService } from '../authservice.service';
import { UserInterface } from '../app.userInterface';
import { environment } from 'src/environments/environment';
import { Title } from '@angular/platform-browser';
import { DashboardServiceService } from '../dashboard-service.service';
import { PermissionsService } from '../permissions.service';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  user: UserInterface | null = null;
  isLoggedIn = false;
  isHomeEnabled: boolean;
  myReferer: string;
  appTitle: string;
  routeName: string;
  appIconSrc: string;

  constructor(
    public router: Router,
    private cookieservice: CookieService,
    private AccountService: AccountService,
    private authService: AuthserviceService,
    private _snackBar: MatSnackBar,
    private titleService: Title,
    private dashboardServiceService: DashboardServiceService,
    private permission: PermissionsService
  ) {
    this.setAppIcon(this.router.url);
  }



  ngOnInit(): void {
    this.myReferer = document.referrer;
    console.log(this.myReferer);
    this.authService.user$.subscribe({
      next: (response) => {
        if (response !== null) {
          this.user = { user: response?.user, token: response?.token }
          if (document.referrer == environment.referrerUrl) {
            this.isHomeEnabled = true;
          } else {
            this.isHomeEnabled = false;
          }
          this.isLoggedIn = true;
        } else {
          // do something
          this.isLoggedIn = false;
        }
      },
      error: (error) => {
        console.log("Error fetching user data, Error: ", error);
        this.authService.userSubject.next(null);
        this.isLoggedIn = false;
      }
    })
    this.dashboardServiceService.currentTitle.subscribe(title => {
      this.titleService.setTitle(title);
      this.appTitle = title;
    });

    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.setAppIcon(event.urlAfterRedirects);
      }
    });


  }

  setAppIcon(url: string) {

    // ✅ Remove query params
    const cleanUrl = url.split('?')[0];

    switch (cleanUrl) {
      case '/dcv':
        this.appIconSrc = '../../assets/dcv.png';
        break;

      case '/pnd':
        this.appIconSrc = '../../assets/pnd.png';
        break;

      case '/nbfc':
        this.appIconSrc = '../../assets/nbfc.png';
        break;

      case '/dcv-performance':
        this.appIconSrc = '../../assets/performance.png';
        break;

      case '/compliance':
        this.appIconSrc = '../../assets/compliance.png';
        break;

      case '/sfmc':
      case '/sfmc-powerbi':
        this.appIconSrc = '../../assets/sfmc.png';
        break;

      case '/committee':
        this.appIconSrc = '../../assets/Meeting-Minutes.png';
        break;

      case '/grievance':
        this.appIconSrc = '../../assets/grievance-icon.png';
        break;

      case '/arv':
        this.appIconSrc = '../../assets/arv-icon.png';
        break;

      case '/visitMonitor':
        this.appIconSrc = '../../assets/visitIcon.png';
        break;

      case '/dorm':
        this.appIconSrc = '../../assets/dorm-icon.png';
        break;

      case '/ebo':
        this.appIconSrc = '../../assets/ebo-icon.png';
        break;

      case '/anchor-investment':
        this.appIconSrc = '../../assets/anchor-investment-icon.png';
        break;

      case '/venture-debts':
        this.appIconSrc = '../../assets/venture-debts-icon.png';
        break;

      case '/incubator':
        this.appIconSrc = '../../assets/incubator-icon.png';
        break;

      case '/itv-ops':
        this.appIconSrc = '../../assets/itvOperations-icon.png';
        break;

      case '/elsc':
        this.appIconSrc = '../../assets/else-icon.png';
        break;
      case '/asset-recovery':
        this.appIconSrc = '../../assets/assets-recovery-vertical-icon.png';
        break;

      default:
        this.appIconSrc = '';
        break;
    }
  }



  logout() {
    this.appTitle = '';
    if (document.referrer == environment.referrerUrl || document.referrer == 'https://loanjourney-uat.sidbi.in/') {
      this.cookieservice.set("UserID", '',
        {
          expires: new Date('Thu, 01 Jan 1970 00:00:01 GMT'),
          path: '/',
          domain: 'sidbi.in'
        });
      this.cookieservice.set("authToken", '',
        {
          expires: new Date('Thu, 01 Jan 1970 00:00:01 GMT'),
          path: '/',
          domain: 'sidbi.in'
        });
      this.AccountService.deleteCookies();
      window.open('https://info-uat.sidbi.in/', '_self');
    } else {
      this.AccountService.logout().subscribe((data: any) => {
        if (data.apiResponse === "User Logged Out Succesfully") {
          this.AccountService.deleteCookies();
          this.authService.userSubject.next(null);
          this.isLoggedIn = false;
          this.AccountService.clearWindowRefs();
          if (document.referrer == environment.referrerUrl) {
            window.open('https://info-uat.sidbi.in/', '_self');
          } else {
            this.router.navigate(["/login"]);
          }
        }
      },
        (error) => {
          this._snackBar.open("", "Close", {
            duration: 10000
          });
        })

    }
    this.permission.clear();

  }

  /*   home() {
      if (this.router.url == '/home') {
        window.open('https://info-uat.sidbi.in/', '_self');
      } else {
        this.router.navigate(['/home'])
      }
      this.appTitle = '';
    } */

  home() {

    if (this.router.url.startsWith('/home')) {
      window.open('https://info-uat.sidbi.in/', '_self');
      return
    }
    const home =
      this.router.routerState.snapshot.root.firstChild
        ?.queryParams?.['home'];

    this.router.navigate(['/home'], {
      queryParams: { tab: home || 'dcv' }
    });

    this.appTitle = '';
  }
}
