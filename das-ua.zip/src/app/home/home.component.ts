import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { AccountService } from '../account.service';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { AuthserviceService } from '../authservice.service';
import { UserInterface } from '../app.userInterface';
import { DashboardServiceService } from '../dashboard-service.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  @ViewChild('dcvDashboard') dcvDashboard: ElementRef
  loanjourneyURL: string = "https://loanjourney-uat.sidbi.in/";
  user: UserInterface | null = null;

  // for compliance dash
  hasComplianceAccess = false;
  modalTitle: string = '';

  // for loan journey
  activeTab: string = 'dcv'; // default tab
  constructor(
    private cookieService: CookieService,
    private router: Router,
    private AccountService: AccountService,
    private authService: AuthserviceService,
    private dashboardServiceService: DashboardServiceService,
    private route: ActivatedRoute,
    
  ) { }

  ngOnInit(): void {
    const user = this.cookieService.get('UserID'); // get the user Name
    this.dashboardServiceService.changeTitle('SIDBI Dashboards');
    const tableUser = this.AccountService.tableUser(user);
    if (tableUser) {
      this.authService.validateTableUser().subscribe(() => {
        const isAuthenticated = this.authService.isAuthenticated$;
        if (isAuthenticated) {
          // do nothing
          this.authService.user$.subscribe((res: any) => {
            this.user = res;
          })
        } else {
          this.router.navigate(['/login'])
          alert("Session Invalid. Please login again.")
        }
      })
    } else {
      this.authService.validateSsoUser().subscribe(() => {
        const isAuthenticated = this.authService.isAuthenticated$;
        if (isAuthenticated) {
          // do nothing
          this.authService.user$.subscribe((res: any) => {
            this.user = res;
          })
        } else {
          this.router.navigate(['/login'])
          alert("Session Invalid. Please login again.")
        }
      })
    }
    /* this.AccountService.getAccessToken().subscribe((res) =>{
      console.log(res);
    }) */

    this.route.queryParams.subscribe(params => {
      this.activeTab = params['tab'] || 'dcv';
    });

  }

  // open comp in a new tab
  openNewTab(url: string, routeName: string): void {
    let winRef = window.open(url, routeName);
    // push window references of dashboards opened to an array
    this.AccountService.windowReferences(winRef);
  }

  // conditionally navigate urls
navigateToUrl(route: string): void {

  // external dashboards
  if (route === 'loanJourney') {
    window.open('https://loanjourney-uat.sidbi.in/', '_self');
    return;
  }

  if (route.toLowerCase() === 'application journey') {
    window.open(
      'https://uat-onlineloanjourney.sidbi.in/online-loan-monitoring/dashbord',
      '_self'
    );
    return;
  }

  // ✅ internal routes → pass home tab
  this.router.navigate([`/${route}`], {
    queryParams: { home: this.activeTab }
  });
}



  // // Step 2: Define the getAccessList logic
  callAccessListAPI(user: string, routeLower: string, deptRouteMap: { [key: string]: string[] }) {
    this.AccountService.getAccessList(user).subscribe({
      next: (res: any) => {
        const dept = res?.dept?.toLowerCase();
        const accessList = dept?.split(',').map(item => item.trim().toLowerCase()) || [];

        // Collect all allowed routes from the user's departments
        const allowedRoutesForUser = accessList.flatMap(deptKey => deptRouteMap[deptKey] || []);

        const hasAccess = allowedRoutesForUser.includes(routeLower);

        if (hasAccess) {
          this.router.navigate([`/${routeLower}`]);
        } else {
          alert(`You don't have access to ${routeLower} Dashboard`);
        }
      },
      error: (err) => {
        if (err.status === 401) {
          alert('Unauthorized access.');
        } else if (err.status === 404) {
          alert('User not found.');
        } else {
          alert('An error occurred while checking access. Please try again later.');
        }
      }
    });
  }

  closeModal() {
    const modal = document.querySelector('#dcvDashboard');
    if (modal) {
      modal.classList.remove('show');
      document.body.classList.remove('modal-open');
      const backdrop = document.querySelector('.modal-backdrop');
      if (backdrop) {
        backdrop.remove();
      }
    }
  }

  selectTab(tab: string) {
  this.activeTab = tab;

  this.router.navigate([], {
    relativeTo: this.route,
    queryParams: { tab },
    queryParamsHandling: 'merge'
  });
}
}
