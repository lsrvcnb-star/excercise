import { Component, ElementRef, OnInit } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-superset-prayaas',
  templateUrl: './superset-prayaas.component.html',
  styleUrls: ['./superset-prayaas.component.scss']
})
export class SupersetPrayaasComponent implements OnInit {
  selected_page: any;

  constructor(private dashboardServiceService: DashboardServiceService, private router: Router, private titleService: Title, private elementRef: ElementRef,) { }
  borderClass: string = ' c';
  ngOnInit(): void {
    this.embedSupersetDashboard('sfmc')

  }

  embedSupersetDashboard(selected: string): void {
    this.selected_page = selected;
    const dashboardElement = this.elementRef.nativeElement.querySelector('#prayaas');

    if (dashboardElement) {
      this.dashboardServiceService.embedDashboard(dashboardElement, selected).subscribe(
        () => {
          // Adjust the size of the embedded iframe
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%';
            iframe.style.height = '1630px';
          }
        },
        (error) => {
          console.error(error);
        }
      );
    }
  }

}
