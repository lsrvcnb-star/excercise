import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { DashboardServiceService } from '../dashboard-service.service';

import * as pbi from 'powerbi-client';

@Component({
  selector: 'app-dcv',
  templateUrl: './dcv.component.html',
  styleUrls: ['./dcv.component.scss'],
})
export class DcvComponent implements OnInit {
  selected_page: string = 'home';
  supersetBorder: string = 'nbfcBorderClass';
  isPowerBiEnabled: boolean = false;
  menus: any = {
    "home": {
      "name": "Home"
    },
    "express": {
      "name": "Express"
    },
    "elsc": {
      "name": "ELSC"
    },
    "top10": {
      "name": "Top & Bottom 10 Branches(All Schemes)"
    },
    "topTenexpress": {
      "name": "Top 10 Branches(Express)"
    }
  }
  @ViewChild('reportContainer', { static: true }) reportContainer!: ElementRef;
  errorMessage: any[] = [];
  constructor(private dashboardServiceService: DashboardServiceService, private router: Router, private titleService: Title, private elementRef: ElementRef) { }

  ngOnInit(): void {
    this.isPowerBiEnabled = false

    this.updateSuperset(this.selected_page);
    this.dashboardServiceService.changeTitle('DCV Executive Dashboard');
  }

  updateSuperset(page: string) {
    this.selected_page = page;
    this.embedSupersetDashboard(page);
  }

  embedSupersetDashboard(selected: string): void {
    this.selected_page = selected;

    // Clear the report container before embedding a new report
    const dashboardElement = this.reportContainer.nativeElement;
    if (dashboardElement) {
      dashboardElement.innerHTML = '';  // Clears any previous iframe or embedded content
    }

    if (selected !== 'pbi') {
      this.isPowerBiEnabled = false;

      this.dashboardServiceService.embedDashboard(dashboardElement, selected).subscribe(
        () => {
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%';
            iframe.style.height = this.getDashboardHeight(selected);
          }
        },
        (error) => {
          console.error(error);
        }
      );
    } else {
     /*  this.isPowerBiEnabled = true;
      this.embedReport(); */
    }
  }

  // Utility function to get iframe height dynamically
  getDashboardHeight(selected: string): string {
    const heights: Record<string, string> = {
      home: '4500px',
      express: '1650px',
      elsc: '2000px',
      topTenexpress: '1000px',
      top10: '1800px',
      leads: '2800px',
      gstSahay: '1300px',
    };
    return heights[selected] || '1000px';
  }



  embedReport(): void {
 /*    this.clearExistingPowerBiEmbed();
    this.powerBiService.getEmbedToken().subscribe(
      (embedData) => {
        const models = pbi.models;
        const reportLoadConfig: pbi.IEmbedConfiguration = {
          type: 'report',
          tokenType: models.TokenType.Embed,
          accessToken: embedData.accessToken,
          embedUrl: embedData.embedUrl[0].embedUrl
        };

        // Embed Power BI report
        const powerbi = new pbi.service.Service(
          pbi.factories.hpmFactory,
          pbi.factories.wpmpFactory,
          pbi.factories.routerFactory // Add this argument
        );
        const report = powerbi.embed(
          this.reportContainer.nativeElement,
          reportLoadConfig
        );
        // Handle events
        report.on('loaded', () => console.log('Report loaded successfully'));
        report.on('rendered', () => {
          console.log('Report rendered successfully');
          this.reportContainer.nativeElement.querySelector("iframe").style.height = '3100px';
        });
        // Adjust the size of the embedded iframe
        report.on('error', (event: any) => {
          this.errorMessage = event.detail.split('\r\n');
          console.error('Power BI Error:', event.detail);
        });
      },
      (error) => {
        console.error('Error fetching embed token', error);
        this.errorMessage = ['Failed to fetch Power BI Embed Token.'];
      }
    ); */
  }


  clearExistingPowerBiEmbed(): void {
    const powerbi = new pbi.service.Service(
      pbi.factories.hpmFactory,
      pbi.factories.wpmpFactory,
      pbi.factories.routerFactory // Add this argument
    );
    powerbi.reset(this.reportContainer.nativeElement);
    this.reportContainer.nativeElement.innerHTML = ''; // Clear any previous content
  }

}
