import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DcvComponent } from './dcv.component';

describe('DcvComponent', () => {
  let component: DcvComponent;
  let fixture: ComponentFixture<DcvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DcvComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DcvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
