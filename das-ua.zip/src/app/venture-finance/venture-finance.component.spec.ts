import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VentureFinanceComponent } from './venture-finance.component';

describe('VentureFinanceComponent', () => {
  let component: VentureFinanceComponent;
  let fixture: ComponentFixture<VentureFinanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VentureFinanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VentureFinanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
