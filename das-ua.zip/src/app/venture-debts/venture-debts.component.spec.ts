import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VentureDebtsComponent } from './venture-debts.component';

describe('VentureDebtsComponent', () => {
  let component: VentureDebtsComponent;
  let fixture: ComponentFixture<VentureDebtsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VentureDebtsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VentureDebtsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
