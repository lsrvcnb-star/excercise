import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EboComponent } from './ebo.component';

describe('EboComponent', () => {
  let component: EboComponent;
  let fixture: ComponentFixture<EboComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EboComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EboComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
