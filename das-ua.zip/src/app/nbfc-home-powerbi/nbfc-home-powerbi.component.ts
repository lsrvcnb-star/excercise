import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { AccountService } from '../account.service';
import { PowerBiService, TrackVisitPayload } from '../power-bi.service';
import * as pbi from 'powerbi-client';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-nbfc-home-powerbi',
  templateUrl: './nbfc-home-powerbi.component.html',
  styleUrls: ['./nbfc-home-powerbi.component.scss']
})
export class NbfcHomePowerbiComponent implements OnInit, AfterViewInit {
  selected_page: string = 'co-lending-powerbi';
  errorMessage: any[] = [];
  borderClass: string = 'nbfcBorderClass';
  isDashboardEnable: boolean = true;
  isNBFCenabled: boolean = false;
  assignHieght: string = '2500px'
  @ViewChild('reportContainer', { static: true }) reportContainer!: ElementRef;
  dbName: string;

  constructor(private powerBiService: PowerBiService,
    private router: Router, private titleService: Title, private elementRef: ElementRef,
    private renderer: Renderer2, private accountService:
      AccountService, private cdr: ChangeDetectorRef,
    private cookieService: CookieService) { }

  ngOnInit(): void {
    this.selected_page = 'nbfc';
  }


  ngAfterViewInit(): void {
    // Wait for DOM to be ready
    this.cdr.detectChanges();
    this.updateSuperset('nbfc');
  }


  updateSuperset(page: string) {

    this.selected_page = page;
    this.embedReport(page);
    if (page == 'nbfc') {
      this.dbName = 'NBFC';
      this.assignHieght = '1500px'
      this.borderClass = 'nbfcBorderClass'
      this.accountService.updateHeaderClass('nbfc-class');
    } else if (page == 'co-lending-powerbi') {
      this.dbName = 'Co-Lending';
      this.assignHieght = '2500px'
      this.borderClass = 'colendingBorderClass'
      this.accountService.updateHeaderClass('colending-class');
    } else if (page == 'directAssignment-powerbi') {
      this.dbName = 'Direct Assignment';
      this.assignHieght = '2500px'
      this.borderClass = 'directAssistBorderClass'
      this.accountService.updateHeaderClass('directAssist-class');
    } else if (page == 'cda-powerbi') {
      this.dbName = 'CDA';
      this.assignHieght = '2500px'
      this.borderClass = 'cdaBorderClass'
      this.accountService.updateHeaderClass('cda-class');
    }

  }


  embedReport(reportId): void {

    this.clearExistingPowerBiEmbed();
    this.powerBiService.getEmbedToken(reportId).subscribe(
      (embedData) => {
        this.tracking();
        const models = pbi.models;
        const reportLoadConfig: pbi.IEmbedConfiguration = {
          type: 'report',
          tokenType: models.TokenType.Embed,
          accessToken: embedData.embedToken,
          embedUrl: embedData.embedReports[0].embedUrl,
          settings: {
            navContentPaneEnabled: false,
            panes: {
              filters: {
                visible: true,
              },
              pageNavigation: {
                visible: false,
              },

            },
            background: pbi.models.BackgroundType.Transparent,
            layoutType: pbi.models.LayoutType.Custom,
            customLayout: {
              displayOption: models.DisplayOption.FitToPage,
            }
          }
        };

        // Embed Power BI report
        const powerbi = new pbi.service.Service(
          pbi.factories.hpmFactory,
          pbi.factories.wpmpFactory,
          pbi.factories.routerFactory // Add this argument
        );
        const report = powerbi.embed(
          this.reportContainer.nativeElement,
          reportLoadConfig
        );
        // Handle events
        report.on('loaded', () => console.log('Report loaded successfully'));
        report.on('rendered', () => {
          console.log('Report rendered successfully');
          this.reportContainer.nativeElement.querySelector("iframe").style.height = this.assignHieght;
        });
        // Adjust the size of the embedded iframe
        report.on('error', (event: any) => {
          this.errorMessage = event.detail.split('\r\n');
          console.error('Power BI Error:', event.detail);
        });
      },
      (error) => {
        console.error('Error fetching embed token', error);
        this.errorMessage = ['Failed to fetch Power BI Embed Token.'];
      }
    );
  }

  clearExistingPowerBiEmbed(): void {
    const powerbi = new pbi.service.Service(
      pbi.factories.hpmFactory,
      pbi.factories.wpmpFactory,
      pbi.factories.routerFactory // Add this argument
    );
    powerbi.reset(this.reportContainer?.nativeElement);
    this.reportContainer.nativeElement.innerHTML = ''; // Clear any previous content
  }

  tracking() {
    const user = this.cookieService.get('UserID').toLowerCase();
    const payload: TrackVisitPayload = {
      userId: user + '@sidbi.in',
      empId: user,
      dbVertical: 'IFV',
      dbName: this.dbName
    };

    this.powerBiService.trackVisit(payload).subscribe({
      next: () => console.log('Visit tracked'),
      error: (err) => console.error('Track failed', err)
    });
  }

}
