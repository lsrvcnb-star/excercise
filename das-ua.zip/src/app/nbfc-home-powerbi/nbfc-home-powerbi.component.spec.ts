import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NbfcHomePowerbiComponent } from './nbfc-home-powerbi.component';

describe('NbfcHomePowerbiComponent', () => {
  let component: NbfcHomePowerbiComponent;
  let fixture: ComponentFixture<NbfcHomePowerbiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NbfcHomePowerbiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NbfcHomePowerbiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
