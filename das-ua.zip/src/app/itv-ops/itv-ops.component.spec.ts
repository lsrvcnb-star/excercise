import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItvOpsComponent } from './itv-ops.component';

describe('ItvOpsComponent', () => {
  let component: ItvOpsComponent;
  let fixture: ComponentFixture<ItvOpsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItvOpsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItvOpsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
