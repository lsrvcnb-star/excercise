import { HttpClient, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { from, Observable, of, switchMap, tap } from 'rxjs';
import { AccountService } from './account.service';
import { AuthserviceService } from './authservice.service';
import { environment } from 'src/environments/environment';
import { EncryptDecryptService } from './encrypt-decrypt.service';


@Injectable()
export class HttpInterceptorService implements HttpInterceptor {

  constructor(
    private cookieService: CookieService,
    private accountService: AccountService,
    private httpClient: HttpClient,
    private encryptDecryptService: EncryptDecryptService

  ) { }


  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const apiList = ['userValid', 'uservalid', 'login', 'deluser', 'logout', 'getCaptcha', 'doLogin'];
    const endpoint = req.url.split("/").slice(-1)[0];

    if (!apiList.includes(endpoint)) {
      const user = this.cookieService.get('UserID');
      const authToken = this.cookieService.get('authToken');
      const tableUser = this.accountService.tableUser(user);

      // Convert the promise to an observable
      return from(this.encryptDecryptService.encryptMIS(user)).pipe(
        switchMap(encryptedUser => {
          const payload = {
            userName: encryptedUser,
            authToken: authToken
          };

          const url = environment.accessurl + 'auth/uservalid';

          return this.httpClient.post(url, payload).pipe(
            switchMap((res: any) => {
              if (res.apiResponse === "Valid") {
                return next.handle(req);
              } else {
                return of(); // or throw an error if needed
              }
            })
          );
        })
      );
    }

    return next.handle(req);
  }
}
