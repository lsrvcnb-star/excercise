import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NbfcHomeComponent } from './nbfc-home.component';

describe('SupersetPrayaasComponent', () => {
  let component: NbfcHomeComponent;
  let fixture: ComponentFixture<NbfcHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NbfcHomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NbfcHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
