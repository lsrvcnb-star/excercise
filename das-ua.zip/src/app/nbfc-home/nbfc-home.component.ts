import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-superset-prayaas',
  templateUrl: './nbfc-home.component.html',
  styleUrls: ['./nbfc-home.component.scss']
})
export class NbfcHomeComponent implements OnInit {
  selected_page: string;
  borderClass: string = 'nbfcBorderClass';
  isDashboardEnable: boolean = true;
  isNBFCenabled: boolean = false;
  @ViewChild('infoBtn', { static: false }) infoBtn: ElementRef
  width: number;
  height: number;

  constructor(private dashboardServiceService: DashboardServiceService,
    private router: Router, private titleService: Title, private elementRef: ElementRef,
    private renderer: Renderer2, private accountService: AccountService
  ) { }

  ngOnInit(): void {

    const infoButton = this.infoBtn?.nativeElement

    this.updateSuperset('nbfc');

    const observer = new ResizeObserver(entries => {
      entries.forEach(entry => {
        // console.log("width", entry.contentRect.width);
        // console.log("height", entry.contentRect.height);
      });
    });


  }

  updateSuperset(page: string) {

    this.selected_page = page;
    this.embedSupersetDashboard(page);
    if (page == 'nbfc') {
      this.borderClass = 'nbfcBorderClass'
      this.accountService.updateHeaderClass('nbfc-class');
    } else if (page == 'co-lending') {
      this.borderClass = 'colendingBorderClass'
      this.accountService.updateHeaderClass('colending-class');
    } else if (page == 'directAssignment') {
      this.borderClass = 'directAssistBorderClass'
      this.accountService.updateHeaderClass('directAssist-class');
    } else if (page == 'cda') {
      this.borderClass = 'cdaBorderClass'
      this.accountService.updateHeaderClass('cda-class');
    }

  }

  modalClicked() {
    const dashboardElement = this.elementRef.nativeElement.querySelector('#modalDashboardContainer');
    if (dashboardElement) {


      this.dashboardServiceService.embedDashboard(dashboardElement, 'Comparative').subscribe(
        () => {
          // Adjust the size of the embedded iframe
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%';
            iframe.style.height = '83vh';

          }
        },
        (error) => {
          console.error(error);
        }
      );

    }
  }




  embedSupersetDashboard(selected: string): void {
    setTimeout(() => {
      const dashboardElement = this.elementRef.nativeElement.querySelector('#prayaas');

      if (dashboardElement && selected !== 'nbfc') {

        this.isDashboardEnable = true;


        this.dashboardServiceService.embedDashboard(dashboardElement, selected).subscribe(
          () => {
            // Adjust the size of the embedded iframe
            const iframe = dashboardElement.querySelector('iframe');
            if (iframe) {
              iframe.style.width = '100%';
              if (selected == 'prayaas') {
                setTimeout(() => {

                }, 3000)
                iframe.style.height = '2900px';
              } else if (selected == 'co-lending') {
                iframe.style.height = '3260px';
              } else if (selected == 'directAssignment') {
                iframe.style.height = '2300px';
              } else if (selected == 'cda') {
                iframe.style.height = '2500px';
              } else if (selected == 'scdf') {
                iframe.style.height = '1950px';
              }
            }
          },
          (error) => {
            console.error(error);
          }
        );


      }
    }, 500)

  }


}
