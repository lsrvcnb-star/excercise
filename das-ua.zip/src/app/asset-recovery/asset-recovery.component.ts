import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { PowerBiService, TrackVisitPayload } from '../power-bi.service';
import { DashboardServiceService } from '../dashboard-service.service';
import * as pbi from 'powerbi-client';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-asset-recovery',
  templateUrl: './asset-recovery.component.html',
  styleUrls: ['./asset-recovery.component.scss']
})
export class AssetRecoveryComponent implements OnInit {
  @ViewChild('reportContainer', { static: true }) reportContainer!: ElementRef;
  errorMessage: any[] = [];
  setHight: any = '3500px';
  pages: pbi.Page[] = [];
  selected: string = '';
  sidebarCollapsed = false;
  constructor(private powerBiService: PowerBiService, private elementRef: ElementRef, private dashboardServiceService: DashboardServiceService, private cookieService: CookieService,) { }

  ngOnInit(): void {
    this.embedReport();
    this.dashboardServiceService.changeTitle('Assets Recovery Vertical dashboard');
    const user = this.cookieService.get('UserID').toLowerCase();


  }

  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  switchPage(pageName: string): void {

    const targetPage = this.pages.find(
      p => p.name === pageName
    );

    if (targetPage) {
      this.setHight = `${targetPage.defaultSize.height}px`
      this.selected = targetPage.displayName;
      targetPage.setActive();
    }
  }

  embedReport(): void {

    this.clearExistingPowerBiEmbed();

    this.powerBiService.getEmbedToken('asset-recovery').subscribe(
      (embedData) => {

        this.tracking();

        const models = pbi.models;

        const reportLoadConfig: pbi.IEmbedConfiguration = {
          type: 'report',
          tokenType: models.TokenType.Embed,
          accessToken: embedData.embedToken,
          embedUrl: embedData.embedReports[0].embedUrl,
          settings: {
            navContentPaneEnabled: false,
            panes: {
              filters: {
                visible: true,
              },
              pageNavigation: {
                visible: false,
              }
            },
            background: models.BackgroundType.Transparent,
            layoutType: models.LayoutType.Custom,
            customLayout: {
              displayOption: models.DisplayOption.FitToPage,
            }
          }
        };

        const powerbi = new pbi.service.Service(
          pbi.factories.hpmFactory,
          pbi.factories.wpmpFactory,
          pbi.factories.routerFactory
        );

        const report = powerbi.embed(
          this.reportContainer.nativeElement,
          reportLoadConfig
        ) as pbi.Report;

        // Load all pages
        report.on('loaded', async () => {

          console.log('Report loaded successfully');

          try {

            const pages = await report.getPages();

            // Exclude hidden pages
            this.pages = pages.filter((page: any) => !page.isHidden);

            console.log('Available Pages', this.pages);

            // Find currently active page
            const activePage = this.pages.find(
              page => page.isActive
            );

            if (activePage) {
              this.selected = activePage.displayName;
            } else if (this.pages.length > 0) {
              this.selected = this.pages[0].displayName;
            }

          } catch (err) {
            console.error('Error getting pages:', err);
          }

        });

        report.on('pageChanged', (event: any) => {

          const newPage = event.detail.newPage;

          if (newPage) {
            this.selected = newPage.displayName;
            console.log(
              'Current Page:',
              newPage.displayName
            );
          }

        });

        report.on('rendered', () => {

          console.log('Report rendered successfully');

          const iframe =
            this.reportContainer.nativeElement.querySelector('iframe');

          if (iframe) {
            iframe.style.height = this.setHight;
          }

        });

        report.on('error', (event: any) => {

          console.error('Power BI Error:', event.detail);

          this.errorMessage =
            typeof event.detail === 'string'
              ? event.detail.split('\r\n')
              : ['Power BI Error'];

        });

      },
      (error) => {

        this.elementRef.nativeElement.innerHTML =
          `<div class="text-center text-danger p-5">
         Error loading Power BI report
       </div>`;

        console.error(
          'Error fetching embed token',
          error.error
        );

        this.errorMessage = [
          'Failed to fetch Power BI Embed Token.'
        ];

      }
    );
  }

  clearExistingPowerBiEmbed(): void {
    const powerbi = new pbi.service.Service(
      pbi.factories.hpmFactory,
      pbi.factories.wpmpFactory,
      pbi.factories.routerFactory
    );

    powerbi.reset(this.reportContainer.nativeElement);
    this.reportContainer.nativeElement.innerHTML = '';
  }


  tracking() {
    const user = this.cookieService.get('UserID').toLowerCase();
    const payload: TrackVisitPayload = {
      userId: user + '@sidbi.in',
      empId: user,
      dbVertical: 'DCV',
      dbName: 'asset-recovery'
    };

    this.powerBiService.trackVisit(payload).subscribe({
      next: () => console.log('Visit tracked'),
      error: (err) => console.error('Track failed', err)
    });
  }

}
