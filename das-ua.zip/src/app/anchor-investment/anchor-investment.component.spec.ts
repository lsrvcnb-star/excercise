import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnchorInvestmentComponent } from './anchor-investment.component';

describe('AnchorInvestmentComponent', () => {
  let component: AnchorInvestmentComponent;
  let fixture: ComponentFixture<AnchorInvestmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnchorInvestmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AnchorInvestmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
