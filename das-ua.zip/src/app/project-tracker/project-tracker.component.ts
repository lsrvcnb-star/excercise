import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { PowerBiService } from '../power-bi.service';
import { DashboardServiceService } from '../dashboard-service.service';
import { CookieService } from 'ngx-cookie-service';
import * as pbi from 'powerbi-client';

@Component({
  selector: 'app-project-tracker',
  templateUrl: './project-tracker.component.html',
  styleUrls: ['./project-tracker.component.scss']
})
export class ProjectTrackerComponent implements OnInit {
  @ViewChild('reportContainerARV', { static: true }) reportContainer!: ElementRef;
  errorMessage: any[] = [];
  pages: pbi.Page[];
  selected: string = 'Sample 1';
  constructor(private powerBiService: PowerBiService, private elementRef: ElementRef, private dashboardServiceService: DashboardServiceService, private cookieService: CookieService,) { }

  ngOnInit(): void {
    this.embedReport();
    this.dashboardServiceService.changeTitle('Project Tracker dashboard');
  }

  embedReport(): void {
    this.clearExistingPowerBiEmbed();
    this.powerBiService.getEmbedToken('project_tracker').subscribe(
      (embedData) => {
        const models = pbi.models;
        const reportLoadConfig: pbi.IEmbedConfiguration = {
          type: 'report',
          tokenType: models.TokenType.Embed,
          accessToken: embedData.embedToken,
          embedUrl: embedData.embedReports[0].embedUrl,
          settings: {
            navContentPaneEnabled: false,
            panes: {
              filters: {
                visible: true,
              },
              pageNavigation: {
                visible: false,
              },

            },
            background: pbi.models.BackgroundType.Transparent,
            layoutType: pbi.models.LayoutType.Custom,
            customLayout: {
              displayOption: models.DisplayOption.FitToPage,
            }
          }
        };

        // Embed Power BI report
        const powerbi = new pbi.service.Service(
          pbi.factories.hpmFactory,
          pbi.factories.wpmpFactory,
          pbi.factories.routerFactory // Add this argument
        );
        const report = powerbi.embed(
          this.reportContainer.nativeElement,
          reportLoadConfig
        ) as pbi.Report;


        report.on('loaded', () => {
          report.getPages().then(pages => {

            this.pages = pages.filter((res) => {
              return res.displayName;
            });
            console.log(this.pages)
          });
        });

        // Handle events
        report.on('loaded', () => console.log('Report loaded successfully'));
        report.on('rendered', () => {
          console.log('Report rendered successfully');
          this.reportContainer.nativeElement.querySelector("iframe").style.height = '1200px';
        });
        // Adjust the size of the embedded iframe
        report.on('error', (event: any) => {
          this.errorMessage = event.detail.split('\r\n');
          console.error('Power BI Error:', event.detail);
        });
      },
      (error) => {
        this.elementRef.nativeElement.innerHTML = `<div class="text-center text-danger p-5">Error loading Power BI report</div>`;
        console.error('Error fetching embed token', error.error);
        this.errorMessage = ['Failed to fetch Power BI Embed Token.'];
      }
    );
  }

  clearExistingPowerBiEmbed(): void {
    const powerbi = new pbi.service.Service(
      pbi.factories.hpmFactory,
      pbi.factories.wpmpFactory,
      pbi.factories.routerFactory // Add this argument
    );
    powerbi.reset(this.reportContainer.nativeElement);
    this.reportContainer.nativeElement.innerHTML = ''; // Clear any previous content
  }

  switchPage(pageName: string): void {
    const targetPage = this.pages.find(p => p.name === pageName);
    if (targetPage) {
      this.selected = targetPage.displayName;
      targetPage.setActive();
    }
  }

}
