import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PowebiComponent } from './powebi.component';

describe('PowebiComponent', () => {
  let component: PowebiComponent;
  let fixture: ComponentFixture<PowebiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PowebiComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PowebiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
