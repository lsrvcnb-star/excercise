import { ChangeDetectorRef, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { PowerBiService, TrackVisitPayload } from '../power-bi.service';
import * as pbi from 'powerbi-client';
import { DashboardServiceService } from '../dashboard-service.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-powebi',
  templateUrl: './powebi.component.html',
  styleUrls: ['./powebi.component.scss'],

})
export class PowebiComponent implements OnInit {
  @ViewChild('reportContainer', { static: true }) reportContainer!: ElementRef;
  errorMessage: any[] = [];
  selected_page: string = 'leadFunnel'
  slectedHeight: any = '3100px';
  constructor(private powerBiService: PowerBiService, private cookieService: CookieService, private elementRef: ElementRef, private dashboardServiceService: DashboardServiceService, private cd: ChangeDetectorRef) {

  }

  ngOnInit(): void {
    this.embedReport('leadFunnel');
    this.dashboardServiceService.changeTitle('DCV Executive Dashboard - PBI');
  }

  embedReport(reportId): void {
    this.selected_page = reportId;
    this.tracking(this.selected_page);
    if (this.selected_page == 'top10-express') {
      this.slectedHeight = '700px'
    } else if (this.selected_page == 'top10-all-schemes') {     
      this.slectedHeight = '2000px'
    } else {
      this.slectedHeight = '3100px'
    }
    this.clearExistingPowerBiEmbed();
    const appType = this.selected_page == 'leadFunnel' ? 'crm' : null;
    this.powerBiService.getEmbedToken(reportId, appType).subscribe(
      (embedData) => {
        const models = pbi.models;
        const reportLoadConfig: pbi.IEmbedConfiguration = {
          type: 'report',
          tokenType: models.TokenType.Embed,
          accessToken: embedData.embedToken,
          embedUrl: embedData.embedReports[0].embedUrl,
          settings: {
            navContentPaneEnabled: false,
            panes: {
              filters: {
                visible: true,
              },
              pageNavigation: {
                visible: false,
              },

            },
            background: pbi.models.BackgroundType.Transparent,
            layoutType: pbi.models.LayoutType.Custom,
            customLayout: {
              displayOption: models.DisplayOption.FitToPage,
            }
          }
        };

        // Embed Power BI report
        const powerbi = new pbi.service.Service(
          pbi.factories.hpmFactory,
          pbi.factories.wpmpFactory,
          pbi.factories.routerFactory // Add this argument
        );
        const report = powerbi.embed(
          this.reportContainer.nativeElement,
          reportLoadConfig
        );
        // Handle events
        report.on('loaded', () => console.log('Report loaded successfully'));
        report.on('rendered', () => {
          console.log('Report rendered successfully');
          this.reportContainer.nativeElement.querySelector("iframe").style.height = this.slectedHeight;
        });
        // Adjust the size of the embedded iframe
        report.on('error', (event: any) => {
          this.errorMessage = event.detail.split('\r\n');
          console.error('Power BI Error:', event.detail);
        });
      },
      (error) => {
        console.error('Error fetching embed token', error);
        this.errorMessage = ['Failed to fetch Power BI Embed Token.'];
      }
    );
    this.cd.detectChanges();
  }

  clearExistingPowerBiEmbed(): void {
    const powerbi = new pbi.service.Service(
      pbi.factories.hpmFactory,
      pbi.factories.wpmpFactory,
      pbi.factories.routerFactory // Add this argument
    );
    powerbi.reset(this.reportContainer.nativeElement);
    this.reportContainer.nativeElement.innerHTML = ''; // Clear any previous content
  }

  tracking(page) {
    const user = this.cookieService.get('UserID').toLowerCase();
    const payload: TrackVisitPayload = {
      userId: user + '@sidbi.in',
      empId: user,
      dbVertical: 'DCV',
      dbName: page =='express-powerbi' ? 'Express' : page == 'gstSahay-powerbi' ? 'GST Sahay' : page == 'leads-powerbi' ? 'Leads' : page
    };

    this.powerBiService.trackVisit(payload).subscribe({
      next: () => console.log('Visit tracked'),
      error: (err) => console.error('Track failed', err)
    });
  }
}
