import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { DashboardServiceService } from '../dashboard-service.service';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-pnd',
  templateUrl: './pnd.component.html',
  styleUrls: ['./pnd.component.scss']
})
export class PndComponent implements OnInit {
  selected_page: string;
  isDashboardEnable: boolean = true;
  isComparitiveEnabled: boolean = false;
  @ViewChild('infoBtn', { static: false }) infoBtn: ElementRef
  width: number;
  height: number;

  constructor(private dashboardServiceService: DashboardServiceService,
    private router: Router, private titleService: Title, private elementRef: ElementRef,
    private renderer: Renderer2, private accountService: AccountService
  ) { }

  ngOnInit(): void {
    this.isComparitiveEnabled = false;
    const infoButton = this.infoBtn?.nativeElement

    this.updateSuperset('scdf');

    const observer = new ResizeObserver(entries => {
      entries.forEach(entry => {
        // console.log("width", entry.contentRect.width);
        // console.log("height", entry.contentRect.height);
      });
    });

    this.dashboardServiceService.changeTitle('Promotion and Development (PnD) - Dashboard');
  }

  updateSuperset(page: string) {
    this.isComparitiveEnabled = false;
    this.selected_page = page;
    this.embedSupersetDashboard(page);
    if (page == 'prayaas') {
      this.accountService.updateHeaderClass('prayaas-class');
    } else if (page == 'co-lending') {
      this.accountService.updateHeaderClass('colending-class');
    } else if (page == 'directAssignment') {
      this.accountService.updateHeaderClass('directAssist-class');
    } else if (page == 'cda') {
      this.accountService.updateHeaderClass('cda-class');
    } else if (page == 'scdf') {
      this.accountService.updateHeaderClass('scdf-class');
    }

  }

  modalClicked() {
    const dashboardElement = this.elementRef.nativeElement.querySelector('#modalDashboardContainer');
    if (dashboardElement) {
      this.isDashboardEnable = true;

      this.dashboardServiceService.embedDashboard(dashboardElement, 'Comparative').subscribe(
        () => {
          // Adjust the size of the embedded iframe
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%';
            iframe.style.height = '83vh';

          }
        },
        (error) => {
          console.error(error);
        }
      );
    }
  }

  embedSupersetDashboard(selected: string): void {
    const dashboardElement = this.elementRef.nativeElement.querySelector('#prayaas');

    if (dashboardElement) {

      this.isDashboardEnable = true;


      this.dashboardServiceService.embedDashboard(dashboardElement, selected).subscribe(
        () => {
          // Adjust the size of the embedded iframe
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%';
            if (selected == 'prayaas') {
              setTimeout(() => {
                this.isComparitiveEnabled = true;
              }, 3000)
              iframe.style.height = '2900px';
            } else if (selected == 'co-lending') {
              iframe.style.height = '3260px';
            } else if (selected == 'directAssignment') {
              iframe.style.height = '2300px';
            } else if (selected == 'cda') {
              iframe.style.height = '2500px';
            } else if (selected == 'scdf') {
              iframe.style.height = '1950px';
            }
          }
        },
        (error) => {
          console.error(error);
        }
      );
    }
  }
}
