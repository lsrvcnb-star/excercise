import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupersetPrayaasComponent } from './superset-prayaas.component';

describe('SupersetPrayaasComponent', () => {
  let component: SupersetPrayaasComponent;
  let fixture: ComponentFixture<SupersetPrayaasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SupersetPrayaasComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SupersetPrayaasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
