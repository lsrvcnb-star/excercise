import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VisitMonitorComponent } from './visit-monitor.component';

describe('VisitMonitorComponent', () => {
  let component: VisitMonitorComponent;
  let fixture: ComponentFixture<VisitMonitorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VisitMonitorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VisitMonitorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
